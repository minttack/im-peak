# H132 · The BIE Experience × Codex × Robinhood Windows research kit

October 17, 2026. Isolated H132 from H131 archive. No actual Robinhood authentication, live market retrieval, Windows installation, or live trade was performed here. Contains a bounded synthetic ten-stock diagnostic and a real-market CSV evaluator waiting for legitimate source data.

## Using Windows (no other operating system required)
1. Extract the full H132 ZIP to a **separate folder** on Windows, not over your active BIE build.
2. Install Python 3 and Codex if not installed: official documentation https://developers.openai.com/codex/ . CLI setup from a PowerShell window: `npm install -g @openai/codex` (Node.js/npm required). You can instead install/open the official Windows Codex desktop app.
3. Double-click `RUN_H132_ALL_TESTS.bat` to run inherited + H132 tests, verify vendor hashes, and generate one new *synthetic* research report. This doesn't access brokerage data and doesn't call Codex.
4. Open this extracted project folder in the Windows Codex app OR double-click `OPEN_CODEX_H132.bat` to start Codex CLI. Codex will find root `AGENTS.md`. Give Codex this instruction: **"Read CODEX_FIRST_TASK_H132.md and complete its next bounded, read-only experiment; preserve failures and test evidence."**
5. If you later authorize Robinhood market-data reads, connect Robinhood MCP interactively as detailed in `H132_ROBINHOOD_READONLY_RESEARCH.md`. **Turn ON external-agent trade approvals in Robinhood first.** Do not connect it to unattended code-writing sessions.
6. Have Codex collect actual OHLCV and point-in-time H131 data for ten stocks plus SPY/QQQ; then run `universe-h132-csv` as described in the read-only research instructions. Treat a failed/missing import as a blocker, not as permission to invent prices.

## What is and is not proven
H132 test counts measure software properties and research on synthetic scenarios. Even when all unit tests pass, there is no proof that stock picks have positive expected returns or that strategy adaptation will work in live trading. H132 is a controlled, deterministic experiment; the optional local BIE model is consulted only when installed and running. For untrusted input the source labels are not independently authenticated by the software.

## Commands
`py -3 -m unittest discover -s tests -p "test_*.py"`
`py -3 -m bie verify-vendor`
`py -3 -m bie universe-h132-battery`
`py -3 -m bie universe-h132-battery --ask-experience`
`py -3 -m bie universe-h132-csv stock_ohlcv_h132.csv --as-of 2026-10-17 --evidence stock_evidence_h131.json`

H132's market-simulation scheduler does not make the passage of physical time slower. An efficiency goal is more independent verified discoveries per measured CPU second. All outputs distinguish what was observed, simulated or unavailable.
