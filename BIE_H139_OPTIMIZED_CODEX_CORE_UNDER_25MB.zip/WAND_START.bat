@echo off
setlocal
cd /d "%~dp0"
echo BIE H130 Wand - Codex local research only. Robinhood trading is NOT used.
py -3 -m bie wand-h130 --run-dir "%~dp0wand_runs\run_%RANDOM%_%RANDOM%" --ask-experience --invoke-codex --max-attempts 2
if errorlevel 1 echo Research did not complete verification. Read the printed report.
pause
