# BIE THRIVES Experience: consolidated Robinhood & Codex mission from this chat

**Purpose:** Preserve the creator's entire **relevant design direction** and the historical experiments that should change future engineering. This summary is NOT a declaration that BIE already has the specified capabilities. A BIE research "Flood Movement" engine must learn when information matters and when it becomes dangerous, propose the next test and keep the evidence ledger.

## The creator's target

- BIE chooses which liquid stocks have sufficient **timely, verifiable** information to research. Start with MSFT AAPL NVDA AMZN GOOGL META JPM XOM WMT JNJ, SPY/QQQ as benchmarks, and ultimately expand using data coverage and liquidity, not popularity alone.
- BIE chooses indicators, settings, timing horizons and risk controls from outcomes, **not** because fixed EMA/RSI/MACD/VWAP/ATR/RVOL combinations were suggested earlier. What matters is incremental out-of-sample usefulness after costs.
- Combine all relevant accessible lenses: price, volume, liquidity, earnings, fundamentals, news timing, attention, investor/company familiarity, historical analogs, economic regimes, cross-market movement, and **missing factors**. Never invent unavailable fields.
- Treat "Experience" as an active falsifiable learning cycle: Memory -> Hypothesis -> Evidence -> Prediction -> Time-stamped action / paper trade -> Outcome -> Error -> Correction -> New question. Immediately ask which next experiment maximizes verified learning per second and what could disprove it.
- User calls Codex the **Wand**: create an objective, have Codex implement source, test newly added checks, preserve failures, verify code changed, and rollback if worse. One tap starts the bounded offline process, not a promise of magic completeness.
- "More thinking within the same time" is a measurable algorithmic goal (data caching, reduced redundancy, parallel experiments and benchmarked information per second), not literal physical spacetime dilation.
- Keep creator's original five glyphs **Chance, Probability, Intelligence, Accuracy, Win** with SHA-verified original images where recovered. Accuracy the *concept* (scoring and correction) is not automatically evidence that image geometry improves trading. Preserve image/no-image/meaning-only/shuffled-symbol controls. Don't manufacture a replacement symbol.
- Measure historical **market-pattern familiarity** separately from investor familiarity/attention and from confirmation bias. Different market environments change what features mean.
- Track virtual P&L in dollars and percent, max drawdown, position sizing, spread/slippage, time delay, predictions invalidated by new data, and avoidance of the false confidence after a winning streak.
- Spread research across several virtual small positions; never infer a larger buy is justified from one gain or a high relevance score. Market profits are not guaranteed.
- Continue using ChatGPT/Codex as teachers and BIE as a potential local learner, but teacher explanations are untrusted until tests; don't claim independent model replies when local Ollama is offline.

## What earlier BIE research showed (all findings are bounded)

| Line | Core experiment and outcome to preserve | Confidence boundary |
|---|---|---|
| H129 | 120 synthetic selection worlds: 36/120 beat synthetic buy/hold baseline; self-question after tests | No real alpha |
| H130 | Codex Wand task scaffolding, no-change rejection, optional actual local model question | Codex CLI not executed in sandbox |
| H131 | Nine-field source-data completeness ranking over 10 provisional large caps | Rich data not an attractive trade |
| H132 | 10-stock simulation and benchmark comparisons; mixed or weak results | No live prices ingested |
| H133 | Teacher-guided evidence rule achieved 97.67% on 12,000 synthetic classifications vs 51.13% naive | Not retraining model weights or forecasting prices |
| H134 | Cost/freshness rule improved over earlier simple rule; harder 45k-case audit exposed transfer failure | Don't auto-promote complexity |
| H135-R | Incremental relevance tests: stable programmed worlds were favorable (60/60); **reversed worlds 0/60** | Regime drift is critical; synthetic |
| H136 | Dollar P&L and familiarity/attention; drift guard reduced reversal loss around -6.11% to -1.86% in simulated regime group | Not real portfolio ROI |
| H137A | Accuracy-feedback or optional cost filter helped vs weak raw controls, **failed to reliably beat H136 guard**; 0 decisions verified as original glyph-derived | Strong H136 default retained |
| H138A | 15-case new-information pilot: availability guard changed 0/15 cases; full inherited suite timed out | Do not promote redundant guard |
| H139 | This branch: new price/volume Flood features + as-of/causality + validation-frozen selection, virtual testing, cross-sector choice and Codex handoff | Must test now, before any deployment |

These numbers came from earlier in-chat simulation reports, which are preserved where available in the source. They must not be pooled into an invented overall BIE success percentage.

## Architecture

`Codex/Robinhood read-only export (human reviewed)` -> `source/time validator` -> `Flood signal features` -> `historical pattern familiarity and optional observed attention` -> `training-only research stock ranking` -> `model fit` -> `validation selection` -> `sealed chronological holdout` -> `no-trade or small virtual positions` -> `cash/SPY/QQQ comparison` -> `ThoughtPacket` -> `new BIE hypothesis` -> `Codex implements bounded test` -> `repeat`.

Key distinctions:

1. Data coverage != relevance != forecast confidence != cash P&L.
2. Raw volume/price bars != true market-buying pressure, order-book fills or hidden trader intent.
3. A familiar stock may be *less* reliable due to bias; prior visual similarity must be tested with time-locked independent outcomes.
4. A positive synthetic return != transferable out-of-sample edge, and successful code tests != winning real trades.
5. Model suggestions are hypotheses; statistical and operational verification decides whether to keep them.

## Acceptance gates for future promotions

Freeze symbols, universe selection, timestamp cutoff, features, horizon, costs, benchmarks and metrics before each holdout; record what is new versus previously tested. Require proper bar adjustment for corporate actions, no data from after prediction time, calibrate direction and magnitude, compare Brier/expected error to prevalence, compare virtual after-cost results to liquid ETF controls and cash, measure drawdowns, stress execution, missing data and drift. Correct the model only using data available at the time. Don't optimize the same final holdout repeatedly. Forward paper tests take place before *any* suggested live-money experiment, and there is always a no-trade option.

## User-facing completion definition

The system is useful when it can **prove** (not just claim): (a) what it observed, (b) why that source mattered, (c) what future outcome it predicted and when, (d) what actually happened, (e) the incremental improvement versus independent controls, (f) where it failed, and (g) what experiment it wants Codex to test next. Do not promise "absolute" intelligence, 100% trading wins, or risk-free gains.
