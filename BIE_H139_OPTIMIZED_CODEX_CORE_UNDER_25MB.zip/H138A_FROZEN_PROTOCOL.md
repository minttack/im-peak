# H138A frozen protocol (not a live trading or glyph learning claim)

Parent H137A, newest relevant earlier evidence H127 original symbol study,
H135 relevance, H136 familiarity + money feedback, H137A Accuracy concept.
Hypothesis: an input-availability abstention improves H136's original strong
drift guard when decisive public factors go missing or become stale; separate
H137A high-cost overlay may help only under modeled cost shocks. Do not tune
threshold after confirmation. No original glyph pixels available in parent.

Frozen comparison of H136 drift guard, H138A availability, H137A cost screen,
and their combination, five artificial market regimes x 8 novel seeds
88001..88008 x five observation conditions = 200 paired scenario comparisons.
Perturb holdout only; selection frozen before perturbation; no future leakage.
Evaluate paper net returns after modeled fees, drawdown, trade count, direction
of incremental effects. Null/stress outcomes remain recorded including losses.
No live Robinhood trading, verified data provider, authentic image geometry or
claimed gains from original glyph. No promotion without independent evidence.

## Rescoped execution, before any completed output
The initial 40-world/200-case attempt timed out before a result existed. To avoid incomplete selective reporting, a new frozen run uses 5 regimes x 4 FRESH seeds 88111..88114 x 3 disturbances (missing, misleading, expensive) = 60 matched scenario conditions, 90 bars/world, 1 worker. No thresholds or scoring policies are changed. The 20 unfinished attempted worlds are not counted.

## Second execution-limit note
The 20-world run also exceeded execution time before saving a result. Final feasible pilot: one new seed 88201 × five worlds × three disruptions = 15 paired stress cases at 90 snapshots; same original hypothesis and frozen policies. Treat this as exploratory diagnostic only; not holdout success/proof. Do not substitute selection of favorable outcomes for sealed confirmation.
