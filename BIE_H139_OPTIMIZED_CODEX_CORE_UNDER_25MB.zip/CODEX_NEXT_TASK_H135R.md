# Codex task: Make BIE's Relevance Bloom active in research, not brokerage execution

## Objective
Support BIE's capability to choose relevant factors and a diversified shortlist from reliable point-in-time data, learn from errors, and run **shadow paper allocations first**, with *no automatic live or enlarged trades*. Be truthful: relevance is calculated predictive Brier improvement, not guarantee of profitability.

## Windows setup / commands
1. Open this extracted project folder in Codex on Windows. Check root `AGENTS.md` and this file before edits.
2. `py -3 -m unittest discover -s tests -p "test_*.py"`
3. `py -3 -m bie verify-vendor`
4. `py -3 -m bie relevance-h135r-demo --world causal --report reports/causal-new.json`
5. `py -3 -m bie relevance-h135r-demo --world shift --report reports/shift-new.json`
6. If the configured local Ollama model actually runs: `py -3 -m bie relevance-h135r-demo --ask-experience --report reports/model-next-new.json`.
7. After collecting verified data locally, use `py -3 -m bie relevance-h135r-file point_in_time_market_labels.json --ask-experience --report reports/real-new.json`. Never call this on synthetic data while labeling it real.

## Robinhood read-only connection, user driven
Robinhood public page: https://robinhood.com/us/en/support/articles/onboarding-an-external-agent/
- Codex GUI: Settings > MCP servers > Streamable HTTP, URL `https://agent.robinhood.com/mcp/trading`.
- Codex CLI: `codex mcp add robinhood-trading --url https://agent.robinhood.com/mcp/trading` then authenticate `/mcp` as USER.
- Confirm in Robinhood account settings that **Trade approvals are ON for external MCP agent** (the public docs say external approvals default OFF). This is separate from the code's explicit no-order behavior.
- Brokerage connector may read account holdings/transactions and can write orders: do NOT feed your full brokerage account data to unrelated tools or leave uncontrolled Codex sessions running. Use **market-only read** tools, ask before individual calls, and ideally a read-only data snapshot outside an order-capable MCP session.
- Never invoke `place_equity_order`, `preview_equity_order` for execution, other order placement, cancellation, transfers, or approval toggles during research. Never auto-purchase in the absence of direct human review.

## BIE's relevant factors
Collect as-of-time market OHLCV/volatility, liquidity/spreads/impact, momentum, fundamentals, valuations, earnings, independently sourced macro/news, sector and cross-asset indicators, and options positioning only where legally available. Exclude paywalled, stale, future, unverified, or unavailable factors (mark as missing). Normalize values and use source labels/reference; do not invent.

### Critical target correctness
The H135-R experimental learner expects *resolved* decisions with `target_up_after_costs` computed **after** a predeclared holding period and after modeled spreads, impact, brokerage fees and realized slippage. Values MUST be calculated using data and timestamps available at the respective decision. Corporate-action adjustments should be versioned and recorded. Events from the same day are kept together in one split; training targets must resolve before validation begins, and validation targets before holdout begins. Do not fetch a ready-made price signal or data series that embeds future bars.

Example object structure (`events` array requires >=80 rows, >=20 separate dates):
```json
{
 "schema":"bie.h135r.relevance.v1",
 "source_mode":"historical_user_supplied",
 "as_of_utc":"2026-10-17T17:00:00+00:00",
 "events":[{
   "ticker":"MSFT", "decision_at_utc":"2025-05-05T20:00:00+00:00",
   "outcome_at_utc":"2025-05-06T20:00:00+00:00",
   "target_up_after_costs":false,
   "signals":{"trend":{"value":0.4,"observed_at_utc":"2025-05-05T20:00:00+00:00", "source":"provider_csv","reference":"data-source-version-or-url"}}
 }]
}
```
Do not copy this fake sample into a real data file; it is only schema documentation.

## Required measured report
- Score relevance separate from coverage, and explicitly distinguish synthetic/real.
- Print dev/validation/holdout split dates, resolved label counts, feature selection, validation and final Brier, missed relevant information, false correlations and uncertainty.
- Compare paper P&L after realistic costs with **SPY, QQQ, stock buy-hold and cash**, considering correlation and drawdown.
- Keep a **read-only** self-question feedback packet after every completed experiment: observation -> alternative explanation -> falsifier -> next bounded experiment.
- Paper-test a maximum five diverse candidate research positions. For an eventual separately funded and explicitly approved micro trial, propose only limited sizes as *examples*, do not interpret 0.5% or 2.5% as a proven optimum.
- NEVER automatically escalate to a big order because a relevance score, a few winners, or this project's software tests passed. Later stages require reliable multi-regime historical + fresh forward paper evidence and human decision.

## Known limitation (preserve verbatim meaning)
H135-R uses a **simple binned probability feature learner**, not updated neural network weights or general self-learning. `--ask-experience` attempts a real local Ollama reply and records unavailability. The generic factor values, provenance, and labels require trusted adapters; no authenticated Robinhood market feed or Windows always-on runner exists here yet.
