# BIE THRIVES Experience 26 — Intelligence, Data and Wi-Fi Storage

**Release type:** complete source-bearing additive upgrade of recovered BIE Experience Assistant v25. It inherits the v24 learning records, Desktop v1 adapter, and unchanged original BIE v8 ZIP. This is not omnipotence or AGI. It is an extensible, local-first system with measurable actions and provenance.

## Start in Windows

1. Extract **the entire ZIP** into a normal writable folder. Do not launch from within the ZIP.
2. Install Python 3.10 or later **with Tkinter**; start with `START_BIE.bat` (also works with Python 3.13 in Linux tests).
3. For conversational responses and coding, install [Ollama](https://ollama.com/) and a local language model, such as the inherited `qwen2.5:3b` (model not included); check with `ollama list` and click **Find models**. Knowledge search, data storage and local discovery do not require a model.
4. Select the **Data & Wi-Fi Storage** tab in the desktop window. Read the safety description and follow the steps below.

## Can it find another Wi-Fi storage device?

**Possibly, when run on your own machine and local network.** Press **Find devices on my Wi-Fi**. It sends a standard *SSDP multicast discovery* packet and, on Windows, runs the built-in network browser (`net view`). Discovery returns advertised devices and network computers, not guaranteed accessible storage shares. It is **not** a subnet/IP brute-force scanner. Routers and devices that do not advertise discovery may be invisible.

If a storage device appears, enter its **authorized** Windows server/share path, such as `\\MYNAS\Shared`, in **Folder or network path**, then press **Open share in File Explorer**. The operating system handles any credentials and authorization. No password is supplied to or kept by BIE. If needed, use Windows File Explorer → **This PC → Map network drive** and map an accessible folder to a drive letter. You may also share a folder on another Windows PC, using Windows' normal file-sharing controls.

After the share works in File Explorer, enter its UNC path or mapped-folder path, choose a meaningful name (e.g. `my-nas`), and press **Register**. This registers the root for *read-only* browsing/import. Nothing is indexed automatically. Click **Browse files** to inspect the top level. Click **Import top-level text files** and confirm to index at most 50 documents (UTF-8 TXT, MD, CSV, TSV, JSON, JSONL), each up to 2MB. Symlinks, dot-files, suspicious key/password names and nested folders are skipped. For a nested folder, use the CLI `storage-import --dir` to explicitly choose it. These filters are imperfect: **review the folder before importing**.

Use the data search entry and click **Search local**. Queries search SQLite FTS5, preserve source paths/timestamps/hashes, and mark evidence unverified. No file is removed, uploaded, modified or copied by discovery or registration. Imported text is stored separately in `knowledge.sqlite3`, so keep it private and back it up.

## Public research data

Type a research query and choose **PubMed**, **OpenAlex**, **Crossref**, **Wikipedia**, or **World Bank**; click **Search public API**. Internet access is required, and servers may restrict request volumes or require keys. Public results are *metadata and leads*, not proof. Click **Save last reference results** and confirm to index references locally. Except for the public search phrase, no local files, memories or project contents are uploaded by these connectors.

World Bank uses `COUNTRY:INDICATOR`, e.g. `US:SP.POP.TOTL` for US population. Optional free OpenAlex API key: set environment variable `BIE_OPENALEX_API_KEY` locally; never paste it into prompts or save it in the project. See `DATA_SOURCES.json` for official endpoint documentation.

## Terminal commands

From the extracted root (using `py -3 -m bie` on Windows):

```shell
python -m bie storage-discover
python -m bie storage-list
python -m bie storage-add my-nas "Z:/Research"
python -m bie storage-browse my-nas
python -m bie storage-import my-nas --max-files 50
python -m bie storage-import my-nas --dir Papers
python -m bie knowledge-status
python -m bie knowledge-search "glioblastoma"
python -m bie public-search pubmed "glioblastoma boron neutron capture" --limit 5
python -m bie public-search crossref "brain nanomedicine" --save
python -m bie public-search worldbank "US:SP.POP.TOTL"
python -m bie storage-remove my-nas
python -m bie verify-vendor
python -m unittest discover -s tests -v
```

`storage-remove` unregisters a folder but does not delete previously indexed evidence. `--save` is explicit consent to local reference indexing. Other inherited assistant commands from `README_START_HERE.md` are unchanged. The original version-25 internal state directory is reused for continuity, while the data hub uses an additive SQLite file.

## What is and is not connected

- **Operational in local tests:** native interface, SQLite-indexed opt-in files, source-based full-text search, local device advertisement discovery logic, permission checks, public API request/parse logic (offline fixture tests), BIE v25/v24/v8 inheritance.
- **Requires your environment:** your Wi-Fi/NAS discovery, permissioned SMB share, reachable Internet, any private external accounts, Ollama model, and real Windows desktop testing. No user Wi-Fi share was detected from this build environment.
- **Not implemented:** bypassing passwords, connecting to all clouds automatically, downloading the entire Internet, unrestricted self-modification, accessing every device, a globally conscious/omnipotent intelligence, or a guaranteed correct answer to every question.
- **Local AI caveat:** enabling *Run project tests* runs untrusted project Python with your Windows user rights; leave it off unless you trust the selected project.

The agent's ThoughtPacket philosophy is preserved: retrieved records carry sources, confidence/evidence status and chronology; predictions and decisions stay provisional until checked by tests or better evidence. Untrusted documents and public API results cannot grant tool permissions.
