# BIE H130 Codex Wand — project instructions

This repository is a source-copy **research candidate**, not the user's active desktop installation.

## Goals
- Treat BIE's H129/H130 next-step ThoughtPackets as hypotheses, not verified discoveries.
- Produce one bounded implementation and tests for a concrete objective. After each genuine discovery or failure, ask which testable next change is worth making and what would falsify it.
- Keep an append-only evidence chain with timestamps, source hashes, test logs, honest failure counts, and rollback instructions.
- Optimize *verified learning per wall-clock second* by deduplication, caching, profiling, prioritizing high-information tests and bounded parallelism. Do not interpret metaphors about time curves as physically changing time.
- For markets, use point-in-time information, sealed holdouts, realistic trade costs, simple cash/buy-hold controls, and paper research. Never optimize to a 100%-win-rate claim.

## Absolute limits for this candidate
- No Robinhood, brokerage, bank or account access in an automated code-writing cycle.
- No order placement. No tokens/passwords in repository files. No live brokerage actions or funding.
- No online external commands or dependencies without user approval.
- Never rewrite frozen tests/holdouts to hide failures, skip core checks, or call a failed result success.
- Give clear test commands and whether actual Codex, local BIE model, and market feeds were available.
