# H138A Accuracy / New-Information Transfer Experiment

**2026-10-17 · Isolated H137A-derived BIE source · Synthetic only**

## Scope and evidence

Recovered authentic H137A source and integrated previous BIE H127, H135-R,
H136 and H137A knowledge as distinct **test hypotheses**, rather than
mistaking remembered concepts for the geometry of the creator's drawing.
New optional missing-evidence `signal_guard` evaluates whether a stock still
has the factors selected before the holdout. Unchanged-default H136 strong
drift guard is the real comparator. Separately compared the preexisting
experimental H137A estimated-cost filter. No brokerage authentication,
actual exchanges or real account balances were involved.

## New tests actually completed

- 20 H138A source, leakage, money, missing evidence, freeze and no-order checks
- 23 H137A tests: **43/43 passed** in focused test batch
- H135-R + H136 test batch: **58/58 passed**
- Combined observed targeted checks: **101/101 passed**, with some overlap
  in inherited infrastructure but no counted duplication of test methods
- Vendor SHA checks: **11/11 passed**
- Complete all-tests attempt **TIMED OUT**; no claim that a new full-suite
  regression passed.
- Larger 40-world and reduced 20-world attempted confirmation jobs **TIMED
  OUT without producing sealed reports**; not counted as evidence.

## Completed frozen pilot: 15 artificial scenarios

Five worlds, one previously uninspected seed 88201 per world, three distinct
holdout perturbations (missing, misleading, expensive). 90 chronological daily
snapshots per world; strategy selected before observation corruption. Initial
virtual capital $10,000. Original H136 drift guard vs H138A availability,
preexisting H137A cost-only overlay, and combination.

| World and held-out disturbance | H136 strong guard | New availability guard | H137A cost screen |
|:--|--:|--:|--:|
| Familiarity signal + missing observations | +1.550% | +1.550% | +1.550% |
| Familiarity signal + misleading observations | -2.834% | -2.834% | -2.834% |
| Familiarity signal + expensive execution | -5.088% | -5.088% | +1.462% |
| Familiarity reversal + missing | -1.775% | -1.775% | -1.775% |
| Familiarity reversal + misleading | +4.428% | +4.428% | +4.428% |
| Familiarity reversal + expensive execution | -4.021% | -4.021% | +0.048% |
| Attention signal + missing | +1.837% | +1.837% | +1.837% |
| Attention signal + misleading | -1.066% | -1.066% | -1.066% |
| Attention signal + expensive execution | -5.645% | -5.645% | +1.285% |
| Null + all disturbances | 0.000% | 0.000% | 0.000% |
| Thin liquidity + missing | -0.399% | -0.399% | 0.000% |
| Thin liquidity + misleading | -2.384% | -2.384% | 0.000% |
| Thin liquidity + expensive execution | -5.687% | -5.687% | 0.000% |

Results come from `reports/H138A_FROZEN_CONFIRM.json`, and are **returns on
simulated virtual cash**, not real returns. The new `signal_guard` changed
**0/15 policy/perturbation runs** and was therefore **not promoted**.
The existing cost filter changed simulated choices under high costs, but
single-seed scripted shocks are inadequate to show a dependable improvement.
Misleading, freshly timestamped information remains a critical weakness;
knowing a data point is recent is not knowing it is true.

**Attribution to original Accuracy drawing: 0 verified direct decisions.**
Authentic glyph bytes are absent from this branch. The earlier H127 symbol
holdout gave zero additional weighting and no independent predictive gain.

## Decision

KEEP existing H136 drift guard by default. DO NOT PROMOTE H138A availability
filter, glyph-prediction weights or real-money escalation. Consider independent
provenance checks and prospective market paper-trading trials as next tests.
