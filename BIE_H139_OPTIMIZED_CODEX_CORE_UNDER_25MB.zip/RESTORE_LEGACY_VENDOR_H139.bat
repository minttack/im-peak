@echo off
setlocal
cd /d "%~dp0"
echo Restores optional original historical BIE v8 archive.
echo No live trading functions are involved.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0RESTORE_LEGACY_VENDOR_H139.ps1"
if errorlevel 1 (echo RESTORE FAILED. Read the message above. & pause & exit /b 1)
pause
