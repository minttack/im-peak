# H133: Codex mission — Learn from ChatGPT without copying unsupported claims

This repo is an ISOLATED experimental candidate, not the user's currently installed unified BIE application. Do not overwrite that installation.

## Creator's highest-potential objective
Build a verifiable teacher → Experience → verification → correction → new direction loop. The human may provide ChatGPT-authored lessons as JSON in a local folder; BIE can attempt to test and generalize the ideas within strict limits. Ask the real local BIE model (Ollama) for its plan if available, and never invent a response if not.

## First verified project tasks
1. Read root AGENTS.md, `H133_TEACHER_TRANSFER_GUIDE.md`, `bie/teacher_bloom_h133.py`, and `tests/test_teacher_bloom_h133.py`.
2. Run all inherited unit tests, the vendor integrity audit, and the standalone teacher study. Record exact pass/fail counts.
3. Generate independent holdout seeds (never select better results by optimizing those seeds) and challenge the policy with missing provenance, future data, unknown liquidity slippage, contradictory results, and negative controls. Record failures.
4. Compare against naive positive-return-only decisions and an explicit *no-trade / abstain* baseline. For actual stock research, do not infer investment returns from the H131 data-coverage score.
5. Ask BIE's actual local language model for a proposed next experiment via `--ask-experience`. Clearly show status; absent Ollama means it did not answer, and the deterministic algorithm is not its voice.
6. If adding connection from ChatGPT, use only a user-authorized official API or locally saved human-supplied packets. Keep keys out of Git and project archives. Cache only user-approved non-sensitive lessons.
7. Before promoting any real-market proposal, require valid point-in-time data, cold holdouts, realistic costs, risk-adjusted baselines, failed-model controls and later forward paper testing; no real-money orders.

## Commands
```
python -m unittest discover -s tests -p "test_*.py"
python -m bie verify-vendor
python -m bie teacher-h133-create --output NEW_TEACHER_LESSON.json
python -m bie teacher-h133-study --lesson NEW_TEACHER_LESSON.json --ask-experience --report NEW_TEACHER_REPORT.json
python -m bie stock-h131
python -m bie universe-h132-battery
```

Always ask: **"What did Experience actually learn; how was it verified; what disconfirms it; and what test most increases verified learning per wall-clock second?"**
