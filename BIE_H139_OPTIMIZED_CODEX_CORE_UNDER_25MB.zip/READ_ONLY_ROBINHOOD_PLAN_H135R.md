# Robinhood BIE research connection (not an active authenticated session)

Official integration: https://robinhood.com/us/en/support/articles/onboarding-an-external-agent/

BIE's current relevance code runs OFFLINE on an exported, labeled dataset. A human-directed Codex session can fetch market data with official Robinhood MCP after authentication. That does not create a headless continuous-market bot: a production adapter would need persistent credentials managed by the user, read-only permissions or isolated transport, schedule, rate-limit handling, logging, order-proof state, monitoring, and reconciliation. No broker credentials, orders, or placements are included. External MCP connectors may have trading rights by default; restrict access and toggle trade approvals ON before connection.

Process: (1) obtain permitted point-in-time snapshots, (2) verify timestamps/source coverage, (3) derive features without future leakage, (4) freeze strategy+costs, (5) evaluate sealed holdout, (6) shadow-track proposed diverse portfolio with daily statements, (7) require fresh human permission for each experimental real order, (8) reevaluate evidence before increasing ANY funding. Never convert `NO_LIVE_TRADING_AUTHORIZED` into execution authority.
