# BIE Experience Assistant v25 — release report

Built October 15, 2026 as an additive integration of the recovered BIE AI Desktop v1 and BIE Experience v24.

The release adds persistent full-text memory with provenance and historical corrections, recent project conversation, a tool-using local model loop, resumable tasks, project editing and test execution, a native desktop workbench, Windows voice hooks, and measured tool-outcome feedback. Burst is the default: 32 rounds, 64 tool calls and a 15-minute per-run budget. Work can continue from a saved checkpoint.

## Observed verification

| Check | Result |
|---|---:|
| New assistant functional and integration tests | 49/49 passed |
| Unchanged original Desktop v1 tests | 8/8 passed |
| Unchanged v24 experience-policy tests | 24/24 passed |
| Total | 81/81 passed |
| Original BIE objective, actually executed in a separate working copy | 4/4 tasks DONE |
| Native working-copy audit after objective | 77 events passed |
| Bundled parent files checked byte-for-byte | 11 unchanged |
| Python syntax compilation | Passed |

The new checks include real project writes and unittest execution; post-failure repair; restart/replay; a 6-process single-claim race; cancellation; prevention of stale writes and path escape; memory correction chronology; imported-history audit; and actual HTTP transport to a local protocol fixture. Fixture-generated model replies do not test a real language model's judgment.

## Measured retrieval

On this Linux host, with 5,000 synthetic unique-key notes and 100 seeded queries:

| Method | Targets found | Median query time | 95th percentile |
|---|---:|---:|---:|
| New indexed lookup | 100/100 | 0.802 ms | 2.418 ms |
| Correct full-corpus scan | 100/100 | 4.979 ms | 7.963 ms |
| Original v1 last-200-note lookup | 2/100 | 0.445 ms | 0.871 ms |

Indexed lookup was 6.21× faster by the ratio of medians versus the correct full-corpus scan on this workload. Original v1 searches only its latest 200 notes, so its coverage result is not an equal-work speed comparison. This is warm local retrieval of synthetic unique keys, not semantic reasoning, GPU performance, or a prediction of the user's PC latency. All raw trials are in `reports/retrieval_benchmark.json`; `BENCHMARK.py` reproduces the workload.

## Continuity

The complete original v8 archive and Desktop v1 adapter are unchanged. The v24 database, policy module, tests and reported failed promotion are preserved. New assistant state is separate. Search reads the latest checkpoint's 62 sources and 345 original processor events; original BIE goal execution uses its own copied v8 working memory. No old experiment is relabeled as a new success.

New implementation, tests and benchmark total **2,428 Python lines across 18 files**. This is useful bounded code rather than a fabricated 150-million-line output. It does not change ChatGPT's response limits or train new model weights.

## Deployment checks still needed

A real Ollama model was not available in the host; transport was checked with controlled protocol fixtures. The host had no graphical display, Windows speech stack, or NVIDIA GPU. Windows GUI rendering, microphone/speech, live tool-selection quality and hardware throughput remain unverified. These limits are included in the startup guide. Python 3.10+ and an installed local Ollama model are required for AI tasks; no pip install is required for the application itself.

Start with `START_BIE.bat`. Use a small trusted project, then try a coding task with test execution enabled. The app reports observed verification separately from the model's answer. External ChatGPT @ integrations are not inherited by this local application.

## Parent evidence

Desktop v1 archive SHA256: `8e1d2f4a0f0074c181529600325881b51a275eafc00e22f596bf6c7ce13c173d`.

v24 archive SHA256: `afeb892dc3cc74f01ff499ec2df64a39a40746333a158b39fc6423e0f9f6a821`.

The supplied Dimensions count and bibliography were not verified. The first record URL was inaccessible. The local model protocol was checked against the [official Ollama chat documentation](https://docs.ollama.com/api/chat).
