# BIE THRIVES Experience v27 — Wi-Fi Wiggle Discovery & Inference

**A genuine additive upgrade of v26 source.** It retains the inherited BIE v25 assistant, v24 learning/history data, original BIE v8 vendor snapshot, the v26 public data and authorized storage features, and adds a new **Wi-Fi Wiggle Lab** in the Windows desktop. It does **not** promise novel radio physics, omnipotence, access to another person's Wi-Fi, or increased transmission strength without supporting hardware.

## Windows installation

1. Download and **extract the complete v27 ZIP** to a writable folder. Open `START_BIE.bat`. Python 3.10+ and Tkinter are required. The local Ollama model is optional for the Wi-Fi lab but required for inherited conversational coding tools.
2. Click **Wi-Fi Wiggle Lab** (sixth tab).
3. Click **Snapshot current Wi-Fi**. This requests three read-only Windows reports: `netsh wlan show interfaces`, `netsh wlan show networks mode=bssid`, `netsh wlan show drivers`. No password is queried; no network is joined, probed or changed.
4. Click **Compare & infer**. The lab shows signal/protocol observations, whether any Wi-Fi 6/6E/7 radio type was reported, adapter compatibility clues, and explicit causal hypotheses with *if / then / test / not proven* sections.
5. Capture **at least nine manual snapshots at different times** before interpreting the experimental one-step signal predictor. The system compares a simple last-value baseline with a Wiggle adaptive trend candidate on later observations; the candidate is **never automatically adopted**. For credible improvement, repeat independent sessions and measure real latency, packet loss and throughput using authorized test tools.

If Windows denies nearby Wi-Fi listing, respect its privacy controls. Windows may require **Location** permission before showing BSSID/network discovery data; you decide whether to enable this in Windows Settings. A missing scan is NOT evidence that no other wireless network exists.

## What a discovery means

- `802.11ax`: typically **Wi-Fi 6**; only claim **6E** when the *6 GHz band is explicitly reported*.
- `802.11be`: suggests an AP advertises **Wi-Fi 7**, not that your adapter supports it or you can use that AP.
- `802.11bn` / Wi-Fi 8: **a developing IEEE ultra-high-reliability standard** as of October 2026, not something BIE can discover or create from signal variations alone.
- **A stronger signal is not proven faster Internet**. The actual speed depends on authorized access, link negotiation, interference, provider connection, congestion and hardware.
- Wi-Fi 7 multi-link operation (MLO), 320 MHz operation and interoperability are **not proven** by `netsh` radio type alone.
- The Wi-Fi Wiggle Lab's *predictor* makes no changes to Wi-Fi settings, radio power, channels, router configurations or authentication.

## Tested evidence, not magical inference

**IF** a Windows scan reports `802.11be`, **THEN** it might be a Wi-Fi 7-capable AP. **TEST** the adapter's listed radio support and the authorized router's specifications. **CONTRADICTION**: a Wi-Fi 6-only adapter cannot claim a negotiated Wi-Fi 7 link.

**IF** successive signal percentages vary significantly, **THEN** movement, interference, roaming, or measurement error are possible. **TEST** repeatability under matched conditions. **CONTRADICTION**: the same amplitude of signal variation might occur with unchanged network technology.

**IF** the Wiggle candidate predicts held-out signal better than the last-value baseline, **THEN** it has a possible narrow predictive edge. **TEST** independent sessions, intentional change/no-change conditions, and negative controls. **FAILURE**: synthetic oscillations already produce cases where adaptive Wiggle is worse than baseline; the candidate remains experimental.

## Storage and privacy

- This feature only accesses your PC's own Windows Wi-Fi observations after an explicit click. It does not attempt to connect to new networks, send probes, crack passwords, or search other people's storage.
- Captured **network names and access point addresses may appear transiently in the on-screen output**, because you requested a local scan. The persistent SQLite lab (`wifi_wiggle.sqlite3` in the assistant's state folder) stores **salted pseudonyms and numeric/protocol features only**—no raw SSIDs, MAC/BSSIDs or passwords. There is no automatic upload.
- `Data & Wi-Fi Storage` remains a separate tab for advertised **local LAN** storage discovery and explicit import of already authorized files. Neither a discovery nor a Wi-Fi 7 advertisement is a permission to access storage.
- The parser recognizes the **English** `netsh` output. On other language versions of Windows, unknown fields remain unknown rather than fabricated.

## Terminal operations

From the extracted source root:

```powershell
py -3 -m bie wifi-snapshot
py -3 -m bie wifi-infer
py -3 -m bie storage-discover
py -3 -m bie knowledge-status
py -3 -m bie verify-vendor
py -3 -m unittest discover -s tests -v
```

`wifi-snapshot` runs on Windows only; other operating systems report `unsupported` and save nothing. The synthetic fixtures in `tests/test_wifi_lab.py` are provided for offline reproducibility, not proof of discovery of any real network.

## References (checked 2026-10-15)

- Microsoft `netsh wlan`: https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/netsh-wlan
- Microsoft Wi-Fi/Location privacy: https://learn.microsoft.com/windows/win32/nativewifi/wi-fi-access-location-changes
- Wireless Broadband Alliance on Wi-Fi 7 MLO: https://wballiance.com/wba-validates-wifi-7-mlo-reliability-cablelabs-intel/
- IEEE P802.11bn / Wi-Fi 8 Ultra High Reliability project: https://standards.ieee.org/ieee/802.11bn/11393/

**Capability boundary:** This v27 release was built and tested in a Linux container. The Windows report reader was tested with representative mocked command output, and the Tk GUI was opened in a virtual display. A real Windows radio scan and network connection have **not** been conducted here. Run on your own PC to gather real evidence; no third-party network access is required or authorized by this project.
