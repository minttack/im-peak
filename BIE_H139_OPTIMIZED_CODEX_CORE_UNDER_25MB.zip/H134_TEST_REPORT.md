# BIE THRIVES Experience · H134 Transfer and Correction Bloom

**Date:** October 17, 2026. **Scope:** isolated derived H133 source. Not merged with newest unified BIE project; user's Windows PC and Robinhood untouched.

## Code verification
- **386 / 386** Python tests passed (361 inherited + 25 newly authored).
- **11 / 11** vendor integrity checks passed.
- The H134 research source is a NEW bounded program, not a trained language model or trading model.
- Additional checks include timestamp leakage, missing/NaN/infinite costs, fake/negative provenance, holdout seed independence, forced abstention, false-promotion veto, immutable audit reports and CLI tests.

## Original synthetic multi-regime transfer challenge
- **30 fresh seeds × 2,500 sealed cases = 75,000 synthetic cases**.
- Development uses calm, volatile, high-spread and source-delay simulated regimes; sealed holdout also contains synthetic shock cases.
- H133 evidence policy average: **57.20% precision**, **72.24% recall**, **198.5 false acceptances per 2,500 cases**, F0.5 **0.5967**.
- H134 cost/time-aware frozen policy average: **95.70% precision**, **88.56% recall**, **14.6 false acceptances per 2,500 cases**, F0.5 **0.9418**.
- **30/30** development-selected complex thresholds correctly reverted to a simpler fixed cost-aware rule when they did not demonstrate adequate advantage on a SECOND development-confirmation dataset. This means H134 did **NOT** verify an incremental benefit from automated parameter search over its strong simple cost-aware comparator.
- All metrics are **toy evidence accept/reject classifications**, not real market trades or return accuracy.

## Independent alternative simulation audit: transfer failure retained
- **45,000** cases from a separately authored generator with a DIFFERENT target rule and missing/slippage/staleness scenarios.
- H133 precision **36.90%**, F0.5 **0.4037**, mean false accepts **248.1 per 1,500**.
- Fixed H134 cost-aware precision **51.98%**, F0.5 **0.5635**, mean false accepts **176.0 per 1,500**.
- This shows positive transfer relative to H133 but **inadequate reliability in tougher simulations**. The '94%+' figure from the original toy generator does not generalize unchanged. This audit must now be considered consumed, not repeatedly retuned into a fresh holdout.

## Actual Experience availability
- `--ask-experience` attempted the configured `qwen2.5:3b` local BIE/Ollama model and received **local_model_unavailable**.
- No actual response was attributed to Experience; next-question prompts are deterministic proposals.
- No official API teacher bridge or model-weight training has been implemented, no real history ingested, no broker trades placed, and no real alpha measured.

## Evidence-based next experiment
**Hypothesis:** Independently observed source-staleness and actual liquidity/impact estimates can reduce false acceptance in shifted environments better than either H133 or H134 fixed baseline. **Falsifier:** the refined policy fails to improve precision/F0.5 or materially harms correctly accepted recall on a new, predeclared holdout, and fails after realistic costs.

Before further changes, collect a new independent development source and freeze criteria. Later validate on real point-in-time U.S. stock data without leakage and forward paper trading. A 100% software test pass rate establishes code consistency, not 100% success in trading or general intelligence.

## Commands
- `py -3 -m unittest discover -s tests -p "test_*.py"`
- `py -3 -m bie verify-vendor`
- `py -3 -m bie transfer-h134 --ask-experience --report reports/NEW_UNIQUE_RUN.json`
- Double-click `TEST_BIE_H134.bat` on Windows. Open project in Codex and read `AGENTS.md`, `CODEX_NEXT_TASK_H134.md`.
