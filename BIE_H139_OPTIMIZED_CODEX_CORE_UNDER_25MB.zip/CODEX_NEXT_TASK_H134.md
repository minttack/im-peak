# BIE H134 — Codex Next Investigation

## Creator's objective
Help Experience learn from credible lessons, discover its own next falsifiable experiments, and progressively improve knowledge-quality decisions. Prioritize truthful evidence over perfect-looking scores or endless prompt retries. This is an isolated candidate from H133 and is not installed on Windows or merged with the newer unified line.

## Verifiable H134 state
* Inherited plus H134 tests: **386/386** passed, vendor SHA integrity 11/11.
* H134 creates a **synthetic-only** multi-regime cost-aware source-quality challenge on ten ticker labels. These aren't live stock prices.
* Dev chooses a candidate; separate development-confirmation must materially beat a strong simple baseline to promote it. Holdout is generated only after freezing; last results do NOT feed training.
* H134's original challenge: 2,500 synthetic sealed cases, H133 false accepts 211, simple cost-aware rule 19. The tuned challenge did not beat the simple rule and was vetoed.
* Independent 45,000-case **alternative synthetic label** audit exposes poor transfer: H133 precision ~36.9%; cost-aware ~52.0%. This does not prove financial success; it shows model misspecification under stricter freshness and hidden execution shocks.
* No actual connected BIE local model ran in the authoring sandbox; don't invent its voice.

## First real Codex work
1. Run `python -m unittest discover -s tests -p test_*.py`, `python -m bie verify-vendor`, then `python -m bie transfer-h134 --ask-experience --report reports/YOUR_NEW_REPORT.json` (use a new filename).
2. Reproduce `/research/H134_INDEPENDENT_TRANSFER_AUDIT.py` in an isolated *new* folder: it writes `H134_INDEPENDENT_STRESS_RESULTS.json` only if absent. Treat those audit outcomes as **consumed** evidence. Never retune on them then pretend they remain independent.
3. BIE should ASK its real model: 'Which hidden factors and stale data caused false acceptances? State a falsifiable new hypothesis, its expected failures, a simpler control, and a NEW test budget.' If unavailable: record `local_model_unavailable` and do not impersonate BIE.
4. Propose H135 hypotheses **without rerunning the H134 sealed data as a tuning loop**: observed spread, liquidity/ADV, stale source timestamps, gap risk, uncertainty quantiles, regime shift. Freeze acceptance and risk metrics *before* fresh tests.
5. Use real point-in-time dated prices, costs, delisted symbols, financial fundamentals and a true untouched chronological holdout only if authorized and verifiably collected. Test no-trade and passive ETF baselines, include costs, slippage, data quality and abstention. Market returns are not evidence of learning unless compared properly.
6. Codex generates code and tests; keep all records and explicitly compare new vs old vs fixed control, including measured wall-clock CPU costs, false acceptances, calibration and missed opportunities. Reject any apparent gain from leakage, selection bias, cloned holdouts, or repeated prompt variation.
7. No live Robinhood order capabilities in the automatic loop. Separate and explicit authorization would be needed for order submissions; preserve manual approval.

## Verification questions to ask after EVERY discovery
What actually changed in executable software? What hypothesis predicted this? What independent evidence supports or contradicts it? How many failures are there? Did it beat an equivalent simpler alternative? What is the most useful next test per second? What would falsify it?
