# First task when opening this repo in Codex

**Immediate objective:** Audit and extend BIE's evidence-based selection for the ten candidate stocks MSFT, AAPL, NVDA, AMZN, GOOGL, META, JPM, XOM, WMT, JNJ. SPY and QQQ are held out as broad-market benchmarks. This is research, not order execution.

1. Read `AGENTS.md`, `START_HERE_H131_STOCK_SELECTION.md`, `START_HERE_H132_WINDOWS_CODEX.md`, and the source in `bie/market_discovery_h129.py`, `bie/stock_universe_h131.py`, `bie/universe_lab_h132.py`.
2. Run the inherited Python unittest suite AND the H132 synthetic battery. Preserve all failure counts. Check the hash manifest / vendor integrity. Do NOT assert that simulated returns are real historical stock returns.
3. Inspect every H132 source of lookahead, trading cost understatement, missing-bar survivorship bias, changes to the test after outcomes, selection bias across ten stocks x eleven indicators, and unrealistic execution at next day's open. Add independent counterexample tests before refining the model.
4. Ask BIE's actual local model (if running) what its best next *falsifiable* experiment would be. Never invent its answer; use bounded deterministic proposals as fallback. Give at least two rival hypotheses.
5. When Robinhood MCP has been connected by the user and the user explicitly authorizes market-data reads, request ONLY public read-only market information using `H132_ROBINHOOD_READONLY_RESEARCH.md`. Never query personal portfolio/accounts unless the user explicitly requests. Do not call order/review/cancel/transfer functions.
6. Write `stock_ohlcv_h132.csv` with ALL ten stocks plus SPY/QQQ, genuine date-stamped OHLCV, correct split-adjustment documentation, normalized dates, and original data provenance; also write `stock_evidence_h131.json` with observed timestamp, metric, source reference. If any mandatory source cannot be retrieved, leave it missing and declare the blocker; NEVER backfill with generated prices.
7. Re-run the untouched pipeline and compare selection against buy-and-hold, SPY and QQQ. Give a ranking of reliable **research** candidates separately from forward *trading* performance. Never claim an investment advantage based on coverage alone.
8. Preserve a short audit report with pass/fail counts, total compute time, experiment IDs, metric results, rejected ideas, missing sources, and the next experiment's falsifier. A failing experiment is valuable evidence.

**One-wand objective rule:** one request may trigger the build → test → reflect → next-plan workflow, but it may NOT bypass data provenance, independent holdouts, test requirements, or Robinhood approval. If Codex is unavailable, the source remains usable locally for offline tests.
