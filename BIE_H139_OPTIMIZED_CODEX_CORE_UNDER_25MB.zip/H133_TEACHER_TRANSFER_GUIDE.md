# H133 · Teaching BIE with ChatGPT — Windows + Codex guide

## What this does
A bounded Teacher–Learner Bloom: a ChatGPT-authored lesson is saved as a local file, BIE selects a conservative evidence-screening policy from that lesson, tests it on unseen toy cases, records failures, and proposes the next independent experiment. Codex can use the study's ThoughtPacket-like audit to implement the next *bounded* research objective.

This is **not** a continuous direct ChatGPT connection, retrained neural network, guaranteed stock prediction model, or live brokerage automation. Genuine model questions go to an optional locally running Ollama model and are labeled with their actual status. ChatGPT information can be wrong; treat lesson claims as hypotheses for verification.

## Use on Windows
1. Extract this package to a separate folder (never over the existing BIE unified installation).
2. Install Python 3, if needed. Double-click `TEACH_BIE_H133.bat`. This runs a teaching packet, the lesson test and an optional local-model question, leaving a new report in the `H133_RUN_*` directory.
3. To ask Experience itself, install and start Ollama, have a matching model such as `qwen2.5:3b` available, and rerun. If the model is absent, BIE truthfully reports `local_model_unavailable`.
4. Open the extracted project folder in Codex (Windows desktop app or `codex` CLI). Codex reads `AGENTS.md`. Tell it: "Read `CODEX_NEXT_TASK_H133.md`, challenge the teacher lesson with new evidence, and preserve all failures."
5. To teach with future ChatGPT work, author/review new bounded JSON lessons using `teacher_lesson_h133.json` as an example. Do not paste API keys, account numbers or passwords, and don't let lesson content issue executable commands. The current learner implements only the explicit `stock_research_integrity` schema; other domains need new testable evaluators written and tested in Codex.

## A limitation worth keeping
Our starter lesson's synthetic world defines certain obvious evidence failures as disqualifying. The learner can learn this rubric but that does **not** transfer automatically to real prices or trading probabilities. Hidden execution-friction cases produce some false acceptances even in the simulated holdout. The next scientific step is real point-in-time data and prospective forward paper trading, not making the toy score look perfect.

## How to validate results
Run `py -3 -m unittest discover -s tests -p "test_*.py"` and `py -3 -m bie verify-vendor`. Preserve the failing cases as corrections. Confirm `real_market_proof=false`, `live_trading_allowed=false` and `local_language_model_trained=false` in the H133 report. No market funds can be accessed by this module.
