"""BLOOM v32 computational planetary reconstruction — hypothetical, not imaging.

Standard-library, transparent zero-D energy balance plus conditional spatial
insolation/heat-redistribution grid. NOT a radiative-transfer solver, 3D GCM,
terrain scanner, atmospheric retrieval or Bayesian climate posterior.

Catalog values are reported measurements/estimates. Atmospheres, pressure,
albedo, water and redistribution are explicitly unobserved prior assumptions.
Optional X-ray/spectrum JSON is user-provided context, never silently treated
as confirmation. All outputs retain provenance, units and limitations.
"""
from __future__ import annotations

import hashlib
import json
import math
import random
import statistics
from dataclasses import dataclass
from pathlib import Path

from .exoplanets import ExoplanetLab, public_fields

SOLAR_CONSTANT = 1361.0   # W m^-2, reference convention, not source star measurement
SIGMA = 5.670374419e-8
AU_METERS = 149597870700.0
EARTH_MASS = 5.9722e24
EARTH_RADIUS = 6371000.0
G = 6.67430e-11
SOURCES = {
    "nasa": "https://exoplanetarchive.ipac.caltech.edu/docs/TAP/usingTAP.html",
    "model_limits": "https://doi.org/10.3847/1538-4357/abdeb4",
    "proxima": "https://exoplanetarchive.ipac.caltech.edu/cgi-bin/DisplayOverview/nph-DisplayOverview?objname=Proxima+Cen+b",
}

# These are scenario PRlORS (not measured facts or estimates of likely realities).
SCENARIOS = {
    "airless_rock": {"albedo": (0.08, 0.35), "emissivity": (0.93, 1.0), "redistribution": (0.0, 0.07), "pressure_bar": (0.0, 0.00001), "water_assumed": False},
    "thin_atmosphere": {"albedo": (0.12, 0.42), "emissivity": (0.82, 0.96), "redistribution": (0.1, 0.35), "pressure_bar": (0.001, 0.09), "water_assumed": False},
    "earthlike_assumed": {"albedo": (0.20, 0.44), "emissivity": (0.58, 0.74), "redistribution": (0.55, 0.89), "pressure_bar": (0.5, 2.5), "water_assumed": True},
    "dense_greenhouse": {"albedo": (0.19, 0.56), "emissivity": (0.24, 0.51), "redistribution": (0.77, 1.0), "pressure_bar": (3.0, 25.0), "water_assumed": False},
    "ice_rich_assumed": {"albedo": (0.48, 0.8), "emissivity": (0.66, 0.95), "redistribution": (0.35, 0.85), "pressure_bar": (0.2, 2.0), "water_assumed": True},
}


def _finite(value, name, *, low=None, high=None):
    if isinstance(value, bool) or not isinstance(value, (float, int)) or not math.isfinite(value):
        raise ValueError(name + " must be a finite number")
    value = float(value)
    if low is not None and value < low or high is not None and value > high:
        raise ValueError(name + " outside supported scientific range")
    return value


def _quantiles(xs):
    a = sorted(xs)
    if not a:
        return None
    def interp(p):
        idx = (len(a) - 1) * p
        lo = int(idx)
        frac = idx - lo
        return round(a[lo] * (1 - frac) + a[min(lo + 1, len(a) - 1)] * frac, 3)
    return {"p05": interp(.05), "median": interp(.5), "p95": interp(.95)}


def _truncated_gauss(rng, mean, sigma, lower, upper):
    return min(upper, max(lower, rng.gauss(mean, sigma)))


def _grid(insolation, albedo, emissivity, redistribution, *, tidally_locked=True, rows=18, columns=36):
    """Idealized steady energy budget with assumed horizontal power redistribution.

    Dayside local forcing is stellar constant times projected incidence;
    redistribution blends local power with global area-mean absorbed power.
    It is not a dynamical atmospheric calculation. Area-weighted cell center
    discretization is normalized to conserve global incoming power exactly.
    """
    unscaled = []
    weights = []
    for j in range(rows):
        lat = -math.pi / 2 + (j + .5) * math.pi / rows
        weight = math.cos(lat)
        for i in range(columns):
            lon = -math.pi + (i + .5) * 2 * math.pi / columns
            if tidally_locked:
                factor = max(0.0, math.cos(lat) * math.cos(lon))
            else:
                # Insolation averaged over fast diurnal rotation (zero obliquity).
                factor = math.cos(lat) / math.pi
            unscaled.append(factor)
            weights.append(weight)
    weighted_factor = sum(a * w for a, w in zip(unscaled, weights)) / sum(weights)
    if weighted_factor <= 0:
        raise ValueError("Invalid grid geometry")
    # Normalize to exact 1/4 average of substellar incident power.
    local_power = [SOLAR_CONSTANT * insolation * (1 - albedo) * x / (4 * weighted_factor) for x in unscaled]
    global_mean = SOLAR_CONSTANT * insolation * (1 - albedo) / 4
    temps = [max(0.0, ((1 - redistribution) * power + redistribution * global_mean) / (emissivity * SIGMA)) ** .25 for power in local_power]
    avg_temp = sum(t * w for t, w in zip(temps, weights)) / sum(weights)
    min_t, max_t = min(temps), max(temps)
    thermal_band = sum(w for t, w in zip(temps, weights) if 273.15 <= t <= 373.15) / sum(weights)
    energy_check = sum(p * w for p, w in zip(local_power, weights)) / sum(weights)
    return {"mean_surface_proxy_k": avg_temp, "min_surface_proxy_k": min_t,
            "max_surface_proxy_k": max_t, "temperate_thermal_fraction": thermal_band,
            "energy_check_w_m2": energy_check, "temperatures_k": [temps[r * columns:(r + 1) * columns] for r in range(rows)]}


def _validate_observations(obs, target):
    """No claims that user-provided spectrum/X-ray records are independently confirmed."""
    if obs is None:
        return {"kind": "no_optional_measurements", "note": "No observed spectrum or stellar X-ray luminosity supplied"}
    if not isinstance(obs, dict) or obs.get("planet") != target:
        raise ValueError("Evidence object requires exact matching 'planet' field")
    extra = set(obs) - {"planet", "spectrum", "xray", "source"}
    if extra:
        raise ValueError("Unrecognized observation fields: " + ", ".join(sorted(extra)))
    source = obs.get("source")
    if not isinstance(source, str) or not 3 <= len(source) <= 1000:
        raise ValueError("Evidence provenance source is required")
    out = {"kind": "user_supplied_unverified", "source": source, "planet": target}
    if "spectrum" in obs:
        spectrum = obs["spectrum"]
        if not isinstance(spectrum, list) or len(spectrum) > 40:
            raise ValueError("spectrum must be a list of at most 40 species assessments")
        species_out = []
        for s in spectrum:
            if not isinstance(s, dict) or set(s) != {"species", "assessment"}:
                raise ValueError("Each spectrum entry needs species and assessment")
            if not isinstance(s["species"], str) or not 1 <= len(s["species"]) <= 60 or s["assessment"] not in ("detected", "not_detected", "inconclusive"):
                raise ValueError("Invalid spectral species/assessment")
            species_out.append(dict(s))
        out["spectrum"] = species_out
        out["spectrum_caveat"] = "User-supplied assertion only; no calibration, retrieval likelihood or atmospheric pressure inference"
    if "xray" in obs:
        val = obs["xray"]
        if not isinstance(val, dict) or set(val) != {"stellar_luminosity_erg_s"}:
            raise ValueError("X-ray must specify stellar_luminosity_erg_s")
        L = _finite(val["stellar_luminosity_erg_s"], "X-ray luminosity", low=0, high=1e38)
        out["xray_stellar_luminosity_erg_s"] = L
        out["xray_caveat"] = "Reported stellar luminosity requires bandpass, date, flux calibration and temporal variation; not an atmospheric-loss model"
    return out


def _profile(row, name, *, insolation_rel_error=None):
    flux = row.get("pl_insol")
    if flux is None:
        raise ValueError("Planet lacks stellar insolation: cannot reconstruct conditions without user-supplied stellar irradiance")
    flux = _finite(flux, "pl_insol", low=.00001, high=5000)
    orbit = row.get("pl_orbsmax")
    radius = row.get("pl_rade")
    mass = row.get("pl_bmasse")
    # Composite values like planet radius for RV-only planet are estimates.
    profile = {"name": name, "stellar_insolation_earth": flux, "orbital_period_days": row.get("pl_orbper"),
               "orbital_distance_au": orbit, "host_distance_pc": row.get("sy_dist"),
               "reported_or_estimated_radius_earth": radius, "reported_minimum_or_mass_earth": mass,
               "method": row.get("discoverymethod"), "source_kind": row.get("source_kind")}
    profile["insolation_relative_sigma_assumed"] = .10 if insolation_rel_error is None else _finite(insolation_rel_error, "relative insolation sigma", low=0, high=.8)
    if mass and radius and mass > 0 and radius > 0:
        profile["gravity_proxy_m_s2"] = round(G * mass * EARTH_MASS / (radius * EARTH_RADIUS) ** 2, 4)
        profile["gravity_caveat"] = "Depends on uncertain mass and estimated radius; not measured surface gravity"
    else:
        profile["gravity_proxy_m_s2"] = None
    return profile


def reconstruct(name, catalog: ExoplanetLab, *, draws=160, seed=2177, evidence=None,
                assumed_insolation_relative_error=None, rotation="synchronous"):
    """Reproducible competing-scenario ensemble conditional on explicit assumptions."""
    if not isinstance(name, str) or not name.strip() or len(name) > 170:
        raise ValueError("Planet name required")
    if type(draws) is not int or not 10 <= draws <= 2000:
        raise ValueError("draws must be 10..2000")
    if type(seed) is not int or not 0 <= seed <= 2**32 - 1:
        raise ValueError("seed must be an unsigned 32-bit integer")
    if rotation not in ("synchronous", "fast_rotating"):
        raise ValueError("Unknown assumed rotation configuration")
    target = catalog.target(name)
    if not target.get("found"):
        raise ValueError("Planet absent from local catalog; load NASA reference examples or explicitly sync NASA")
    row = target["planet"]
    profile = _profile(row, name, insolation_rel_error=assumed_insolation_relative_error)
    extra = _validate_observations(evidence, name)
    if "xray_stellar_luminosity_erg_s" in extra:
        orbit = profile["orbital_distance_au"]
        if orbit is not None:
            orbit = _finite(orbit, "orbital distance", low=.00001, high=200000)
            # erg/s to W: 1e-7; geometric dilution at measured orbital radius.
            extra["orbital_xray_flux_w_m2"] = extra["xray_stellar_luminosity_erg_s"] * 1e-7 / (4 * math.pi * (orbit * AU_METERS)**2)
            extra["xray_interpretation"] = "Geometric irradiance estimate only, NOT a surface radiation dose or atmosphere survival probability"
        else:
            extra["orbital_xray_flux_w_m2"] = None
            extra["xray_interpretation"] = "Cannot infer orbital flux without a known orbital distance"
    rng = random.Random(seed)
    rows_out = []
    for scenario_name, prior in SCENARIOS.items():
        mean_temp, fraction, temp_min, temp_max = [], [], [], []
        for _ in range(draws):
            lum = _truncated_gauss(rng, profile["stellar_insolation_earth"], profile["stellar_insolation_earth"] * profile["insolation_relative_sigma_assumed"], .00001, 5000)
            albedo = rng.uniform(*prior["albedo"])
            emissivity = rng.uniform(*prior["emissivity"])
            redistribution = rng.uniform(*prior["redistribution"])
            grid = _grid(lum, albedo, emissivity, redistribution, tidally_locked=rotation == "synchronous")
            mean_temp.append(grid["mean_surface_proxy_k"])
            fraction.append(grid["temperate_thermal_fraction"])
            temp_min.append(grid["min_surface_proxy_k"])
            temp_max.append(grid["max_surface_proxy_k"])
        midpoint = {k: sum(v) / 2 for k, v in prior.items() if isinstance(v, tuple)}
        map_grid = _grid(profile["stellar_insolation_earth"], midpoint["albedo"], midpoint["emissivity"], midpoint["redistribution"], tidally_locked=rotation == "synchronous")
        # Qualitative indicators, never probability of habitability or life.
        spectral_tensions = []
        if scenario_name == "airless_rock" and any(item["assessment"] == "detected" for item in extra.get("spectrum", [])):
            spectral_tensions.append("Atmospheric species reported by supplied spectrum would conflict with an airless scenario IF independently confirmed as planetary")
        if extra.get("xray_stellar_luminosity_erg_s") is not None:
            spectral_tensions.append("Stellar X-ray flux requires a separate atmospheric escape / photochemistry model; it is not used to tune this thermal map")
        row_result = {
            "scenario": scenario_name,
            "evidence_consistency_cautions": spectral_tensions,
            "assumed_ranges": prior,
            "mean_surface_temperature_k": _quantiles(mean_temp),
            "minimum_grid_temperature_k": _quantiles(temp_min),
            "maximum_grid_temperature_k": _quantiles(temp_max),
            "fraction_of_area_in_273_373_k_band": _quantiles(fraction),
            "water_possibility": ("Thermal-only screen conditional on water and sufficient pressure; no oceans observed" if prior["water_assumed"] else "No surface liquid water was assumed; temperature alone does not create water"),
            "illustrative_grid": {"coordinate_system": "latitude-longitude centered, synchronous substellar longitude=0",
                                  "rows": 18, "columns": 36,
                                  "units": "kelvin",
                                  "surface_temperature_proxy_k": [[round(x, 1) for x in row] for row in map_grid["temperatures_k"]]},
        }
        rows_out.append(row_result)
    digest = hashlib.sha256(json.dumps({"planet": row, "evidence": evidence, "seed": seed, "draws": draws, "rotation": rotation}, sort_keys=True).encode()).hexdigest()
    return {
        "kind": "HYPOTHETICAL_CLIMATE_ENSEMBLE_NOT_SURFACE_OBSERVATION",
        "target": name, "seed": seed, "draws_per_scenario": draws,
        "rotation_hypothesis": rotation,
        "catalog_provenance": {"kind": target["source_kind"], "snapshot_at": target["snapshot_at"], "url": target["source_url"], "sha256": target["snapshot_sha256"]},
        "planetary_inputs": profile,
        "ancillary_evidence": extra,
        "assumption_model": "Grey one-layer equilibrium temperature with redistributive mixing on an idealized sphere; NOT a 3D GCM, spectrum retrieval, or X-ray propagation model",
        "assumption_weighting": "Five equal-priority storylines; no observational posterior or habitability probability computed",
        "results": rows_out,
        "thoughtpacket": {
            "source": "catalog + explicitly assumed atmospheric/surface scenarios; optional unverified user measurements",
            "supported": ["Host orbital/stellar properties as reported by catalog", "Conditional thermal calculations and energy normalization"],
            "hypotheses": ["Airless or thin atmosphere", "Temperate redistributed atmosphere", "Dense greenhouse", "High-albedo frozen environment"],
            "contradictions": ["Spectrum/X-ray records alone cannot establish surface pressure, terrain or inhabitants", "Different assumed atmospheres produce incompatible temperature predictions"],
            "confidence": "high in arithmetic and repeatability; uncalibrated for true environmental conditions",
            "next_test": "Obtain independent, calibrated spectra and X-ray time series; constrain atmospheric composition/stellar activity, then compare predictions with withheld observations",
            "no_claim": ["no actual mountains/oceans mapped", "no measured surface temperatures", "no people or life detected", "no atmosphere confirmed"]
        },
        "digest_sha256": digest,
        "references": SOURCES,
    }


def load_evidence_file(path):
    p = Path(path)
    if p.stat().st_size > 100_000:
        raise ValueError("Evidence JSON exceeds 100 kB")
    return json.loads(p.read_text(encoding="utf-8"))


def export_reconstruction(result, path):
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open("x", encoding="utf-8") as f:
        json.dump(result, f, indent=2, ensure_ascii=False, allow_nan=False)
    return {"saved": str(p.resolve()), "sha256": hashlib.sha256(p.read_bytes()).hexdigest()}
