"""BIE Wi-Fi Wiggle Lab: explainable, passive network observation and testing.

Only gathers information the user's own Windows OS already exposes through
read-only `netsh wlan show ...` commands after an explicit user action.
Never joins a network, exports passwords, probes hosts, transmits traffic, or
assumes that an advertised protocol implies access or better performance.
"""
from __future__ import annotations

from datetime import datetime, timezone
from contextlib import closing
import hashlib
import hmac
import json
from pathlib import Path
import re
import secrets
import uuid
import sqlite3
import subprocess
import sys
import statistics


_RADIO_ORDER = {"802.11b": 1, "802.11g": 2, "802.11a": 2,
                "802.11n": 4, "802.11ac": 5, "802.11ax": 6, "802.11be": 7}
_RADIO_PATTERN = re.compile(r"802\.11(?:be|ax|ac|n|g|b|a)\b", re.I)
_CMD = (("netsh", "wlan", "show", "interfaces"),
        ("netsh", "wlan", "show", "networks", "mode=bssid"),
        ("netsh", "wlan", "show", "drivers"))


def _standard(text, band=""):
    radios = _RADIO_PATTERN.findall(str(text))
    if not radios:
        return {"standard": "unknown", "generation": None}
    radio = max((r.lower() for r in radios), key=lambda r: _RADIO_ORDER.get(r, 0))
    generation = _RADIO_ORDER[radio]
    if generation == 6 and "6 ghz" in (band or "").lower():
        return {"standard": "Wi-Fi 6E", "generation": 6}
    if generation >= 4:
        return {"standard": f"Wi-Fi {generation}", "generation": generation}
    return {"standard": "legacy Wi-Fi", "generation": generation}


def _fields(text):
    result = {}
    for line in str(text).splitlines():
        if ":" in line:
            k, v = line.split(":", 1)
            result[k.strip().lower()] = v.strip()
    return result


def _percentage(text):
    m = re.search(r"\b(\d{1,3})\s*%", str(text))
    if not m:
        return None
    n = int(m.group(1))
    return n if 0 <= n <= 100 else None


def parse_interfaces(text):
    """Use connection statistics only; no MAC, SSID or BSSID persisted."""
    f = _fields(text)
    # Ignore interface hardware addresses and GPS-like BSSID identifiers entirely.
    radio = f.get("radio type", f.get("radio type (802.11)", ""))
    return {"state": f.get("state", "unknown"), "ssid": f.get("ssid", ""),
            "radio": radio, "band": f.get("band", ""),
            "channel": f.get("channel", ""),
            "signal_pct": _percentage(f.get("signal", "")),
            "rx_mbps": _float(f.get("receive rate (mbps)", "")),
            "tx_mbps": _float(f.get("transmit rate (mbps)", "")),
            "authentication": f.get("authentication", "unknown"),
            **_standard(radio, f.get("band", ""))}


def _float(value):
    try:
        return float(str(value).split()[0])
    except (ValueError, IndexError):
        return None


def parse_networks(text):
    """Parse English Windows netsh output; unknown/localized fields stay unknown."""
    result, current, ap = [], None, None

    def finish():
        nonlocal ap
        if ap is not None and current is not None:
            ap.update({"ssid": current["ssid"], "authentication": current["authentication"]})
            ap.update(_standard(ap.get("radio", ""), ap.get("band", "")))
            result.append(ap)
        ap = None

    for line in str(text).splitlines():
        line = line.strip()
        match_ssid = re.match(r"^SSID\s+\d+\s*:\s*(.*)$", line, re.I)
        match_bssid = re.match(r"^BSSID\s+\d+\s*:\s*(.*)$", line, re.I)
        if match_ssid:
            finish()
            current = {"ssid": match_ssid.group(1), "authentication": "unknown"}
            continue
        if current is None:
            continue
        if match_bssid:
            finish()
            # Kept in RAM only, to deduplicate multiple APs of the same SSID.
            ap = {"bssid": match_bssid.group(1), "signal_pct": None, "band": "",
                  "radio": "", "channel": ""}
            continue
        if ":" not in line:
            continue
        key, value = [x.strip() for x in line.split(":", 1)]
        key = key.lower()
        if key == "authentication":
            current["authentication"] = value
        elif ap is not None:
            if key == "signal":
                ap["signal_pct"] = _percentage(value)
            elif key == "radio type":
                ap["radio"] = value
            elif key in ("band", "channel"):
                ap[key] = value
    finish()
    return result


def parse_drivers(text):
    radios = sorted(set(x.lower() for x in _RADIO_PATTERN.findall(str(text))),
                    key=lambda s: _RADIO_ORDER[s])
    f = _fields(text)
    return {"supported_radios": radios,
            "best_standard": _standard(" ".join(radios))["standard"],
            "adapter_description": f.get("description", "unknown")}


def capture_windows(runner=subprocess.run, platform_name=None):
    """Explicit, read-only Wi-Fi snapshot. Does not claim to scan radio frequencies."""
    current_platform = platform_name if platform_name is not None else sys.platform
    if current_platform != "win32":
        return {"ok": False, "status": "unsupported", "warnings": [
            "Read-only Windows Wi-Fi collection requires running this on your Windows PC."],
            "connection": {}, "access_points": [], "adapter": {}}
    outputs, errors = [], []
    for cmd in _CMD:
        try:
            result = runner(list(cmd), capture_output=True, text=True, errors="replace",
                            timeout=9, shell=False)
            content = (result.stdout or "")[:250000]
            if result.returncode:
                errors.append(f"{cmd[3]}: Windows did not provide data (exit {result.returncode}).")
                if any(word in ((content + (result.stderr or "")).lower())
                       for word in ("location", "denied", "access is denied")):
                    errors.append("Windows may require your location/privacy permission to list nearby Wi-Fi; BIE cannot override that permission.")
                outputs.append("")
            else:
                outputs.append(content)
        except (OSError, subprocess.TimeoutExpired) as ex:
            errors.append(f"{cmd[3]}: {type(ex).__name__}")
            outputs.append("")
    connection, aps, drivers = parse_interfaces(outputs[0]), parse_networks(outputs[1]), parse_drivers(outputs[2])
    if not aps and not any("location" in e for e in errors):
        errors.append("No access points were returned. This does not prove there are no nearby networks.")
    return {"ok": bool(outputs[0] or outputs[1] or outputs[2]),
            "status": "observed" if not errors else "partial",
            "captured_at": datetime.now(timezone.utc).isoformat(),
            "connection": connection, "access_points": aps, "adapter": drivers,
            "warnings": errors,
            "scope": "Current Windows wireless adapter observations only; no access checks, no joining networks, no passwords."}


def _mae(xs, ys):
    return round(statistics.mean(abs(a-b) for a, b in zip(xs, ys)), 3)


def forward_predictor_test(values):
    """Chronological last-30%-only comparison. Candidate requires external replication."""
    values = [v for v in values if isinstance(v, (int, float)) and 0 <= v <= 100]
    if len(values) < 9:
        return {"status": "insufficient_evidence", "samples": len(values),
                "needed": 9, "reason": "Need at least nine manually acquired snapshots."}
    start = max(3, int(len(values) * 0.7))
    actual, naive, adaptive = [], [], []
    for i in range(start, len(values)):
        actual.append(values[i])
        naive.append(values[i-1])
        step = values[i-1] - values[i-2]
        # The Wiggle candidate reacts to a sharp change. Controls use last value.
        extrap = values[i-1] + (0.5 * step if abs(step) >= 8 else 0)
        adaptive.append(max(0, min(100, extrap)))
    baseline, candidate = _mae(actual, naive), _mae(actual, adaptive)
    return {"status": "holdout_measured_no_promotion", "samples": len(values),
            "holdout_samples": len(actual), "baseline_last_signal_mae": baseline,
            "wiggle_adaptive_mae": candidate,
            "relative_improvement_pct": round((baseline-candidate)/baseline*100, 1) if baseline else None,
            "decision": "candidate_only; independent sessions and controlled throughput/latency tests required",
            "baseline_wins_or_ties": baseline <= candidate}


class WifiLab:
    """Stores only salted pseudonyms and derived measurements, never raw network names."""
    def __init__(self, home):
        self.db_path = Path(home) / "wifi_wiggle.sqlite3"
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        with closing(self._db()) as con, con:
            con.executescript("""
            CREATE TABLE IF NOT EXISTS settings (k TEXT PRIMARY KEY, v TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS readings (
                id INTEGER PRIMARY KEY, observed_at TEXT NOT NULL, connected_id TEXT,
                signal_pct INTEGER, rx_mbps REAL, tx_mbps REAL, connected_radio TEXT,
                connected_band TEXT, adapter_json TEXT NOT NULL, aps_json TEXT NOT NULL, warnings_json TEXT NOT NULL);
            """)
            # v28 migration: never discard or reset older v27 observations.
            columns = {r[1] for r in con.execute("PRAGMA table_info(readings)")}
            if "session_id" not in columns:
                con.execute("ALTER TABLE readings ADD COLUMN session_id TEXT")
            if "connected_channel" not in columns:
                con.execute("ALTER TABLE readings ADD COLUMN connected_channel TEXT")
            if con.execute("SELECT v FROM settings WHERE k='salt'").fetchone() is None:
                con.execute("INSERT INTO settings VALUES ('salt', ?)", (secrets.token_hex(32),))

    def _db(self):
        return sqlite3.connect(str(self.db_path))

    def _id(self, raw):
        if not raw:
            return None
        with closing(self._db()) as con, con:
            salt = con.execute("SELECT v FROM settings WHERE k='salt'").fetchone()[0]
        return "wifi-" + hmac.new(bytes.fromhex(salt), raw.encode("utf-8", "replace"), hashlib.sha256).hexdigest()[:14]

    def new_session(self):
        """Explicit operator-labeled measurement session; not proof of independence."""
        session_id = "session-" + uuid.uuid4().hex[:12]
        with closing(self._db()) as con, con:
            con.execute("INSERT OR REPLACE INTO settings(k,v) VALUES ('current_session', ?)", (session_id,))
        return {"session_id": session_id, "status": "started", "meaning":
                "Manual session boundary only; repeat conditions and physical measurements to claim replication."}

    def current_session(self):
        with closing(self._db()) as con:
            row = con.execute("SELECT v FROM settings WHERE k='current_session'").fetchone()
            if row:
                return row[0]
        return self.new_session()["session_id"]

    def snapshot(self, captured=None):
        data = capture_windows() if captured is None else captured
        if not data.get("ok"):
            return {"saved": False, **data}
        link = data.get("connection", {})
        aps = data.get("access_points", [])
        safe_aps = []
        for ap in aps[:120]:
            safe_aps.append({"network_id": self._id(ap.get("ssid", "") + "|" + ap.get("bssid", "")),
                             "signal_pct": ap.get("signal_pct"), "radio": ap.get("radio", ""),
                             "channel": ap.get("channel", ""), "band": ap.get("band", ""), "standard": ap.get("standard", "unknown"),
                             "generation": ap.get("generation"), "authentication": ap.get("authentication", "unknown")})
        session_id = self.current_session()
        with closing(self._db()) as con, con:
            con.execute("INSERT INTO readings (observed_at,connected_id,signal_pct,rx_mbps,tx_mbps,connected_radio,connected_band,adapter_json,aps_json,warnings_json,session_id,connected_channel) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
                        (data.get("captured_at") or datetime.now(timezone.utc).isoformat(),
                         self._id(link.get("ssid", "")), link.get("signal_pct"), link.get("rx_mbps"),
                         link.get("tx_mbps"), link.get("radio", ""), link.get("band", ""),
                         json.dumps(data.get("adapter", {}).get("supported_radios", [])), json.dumps(safe_aps), json.dumps(data.get("warnings", [])),
                         session_id, str(link.get("channel", ""))[:8]))
        return {"saved": True, "session_id": session_id, **data, "storage_privacy": "Only salted IDs and numeric/protocol observations are saved locally, not SSIDs, BSSIDs or passwords.",
                "next": "Take snapshots at different times, then press Compare & infer to test whether fluctuations predict anything."}

    def analyze(self):
        with closing(self._db()) as con, con:
            con.row_factory = sqlite3.Row
            rows = [dict(row) for row in con.execute("SELECT * FROM readings ORDER BY id ASC LIMIT 10000")]
        if not rows:
            return {"status": "no_measurements", "hypotheses": [], "steps": [
                "Press Snapshot current Wi-Fi at least once on your Windows PC."]}
        last = rows[-1]
        aps = json.loads(last["aps_json"])
        max_gen = max((ap["generation"] or 0 for ap in aps), default=0)
        adapter_radios = json.loads(last["adapter_json"])
        adapter_generation = max((_RADIO_ORDER.get(s, 0) for s in adapter_radios), default=0)
        candidates = [ap for ap in aps if ap.get("generation") == max_gen and max_gen >= 6]
        link_id = last["connected_id"]
        series = [r["signal_pct"] for r in rows if r["connected_id"] == link_id and link_id and isinstance(r["signal_pct"], int)]
        predictor = forward_predictor_test(series)
        hypotheses = []
        if candidates:
            hypotheses.append({"if": "Windows advertises a nearby AP with radio type 802.11be" if max_gen == 7 else "Windows advertises a nearby AP with 802.11ax",
                               "then": ("Your adapter appears compatible by listed radio types; an authorized network might negotiate this generation."
                                        if adapter_generation >= max_gen else
                                        "Your adapter has not reported this generation; a hardware or driver update may be required."),
                               "confidence": "medium (reported capabilities only)",
                               "test": "Check the actual authorized router and adapter; benchmark throughput, latency and stability under controlled conditions.",
                               "not_proven": "Permission, actual negotiated rate, 6 GHz support or MLO are not established."})
        else:
            hypotheses.append({"if": "No 802.11ax/be radio type appeared in available observations",
                               "then": "A newer network has not been observed, rather than proven absent",
                               "confidence": "low", "test": "Review adapter support and try a later OS-permitted snapshot; the router could be out of range or discovery denied."})
        if len(series) >= 3:
            jitter = max(series[-6:]) - min(series[-6:])
            hypotheses.append({"if": f"Observed received signal changed by {jitter} percentage points over the last {min(len(series),6)} connected readings",
                               "then": "Interference, movement, roaming, or measurement noise might explain the wiggle" if jitter >= 15 else "Signal seems comparatively steady in this short sample",
                               "confidence": "medium for measured variation; low for its cause",
                               "test": "Repeat in the same location and compare against simple baselines; signal strength alone is not a measure of Internet speed."})
        hypotheses.append({"if": "The Wiggle predictor beats last-value prediction on sequential data",
                           "then": "It is only an exploratory predictive improvement, NOT a stronger Wi-Fi signal or new wireless technology",
                           "confidence": "undetermined until replicated",
                           "test": "Record independent later sessions and examine packet loss, throughput and latency; keep the no-change baseline."})
        return {"status": "hypotheses_not_proof", "snapshots": len(rows),
                "current_observations": {"access_point_count": len(aps), "highest_advertised_generation": max_gen or None,
                                         "adapter_reported_generation": adapter_generation or None,
                                         "connected_signal_pct": last["signal_pct"]},
                "predictor": predictor, "hypotheses": hypotheses,
                "data_limitation": "Windows may omit bands or access points. A higher generation does not imply better connection or authorization.",
                "privacy": "Salted local pseudonyms; no passwords, SSIDs, MAC/BSSIDs, probing or automatic network connections."}
