"""Local Ollama transport. A model is supplied by the user, not by this package."""
from __future__ import annotations

import json
import socket
import time
import urllib.error
import urllib.request

from .config import valid_model


class ModelUnavailable(RuntimeError):
    pass


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise ModelUnavailable("The local model endpoint attempted a redirect")


class Ollama:
    HOST = "http://127.0.0.1:11434"

    def __init__(self, model, opener=None):
        self.model = valid_model(model)
        self.opener = opener or urllib.request.build_opener(urllib.request.ProxyHandler({}), NoRedirect())

    def models(self):
        try:
            with self.opener.open(self.HOST + "/api/tags", timeout=3) as r:
                data = json.loads(r.read(1024 * 1024))
            return [m["name"] for m in data.get("models", [])]
        except (OSError, ValueError) as ex:
            raise ModelUnavailable("Start Ollama and select a model from ollama list") from ex

    def reply(self, messages, tools, budget, cancel, on_text, deadline):
        payload = {"model": self.model, "messages": messages, "tools": tools, "stream": True,
                   "keep_alive": "10m", "options": {"temperature": .2, "num_ctx": budget.model_context,
                                                     "num_predict": budget.output_tokens}}
        request = urllib.request.Request(self.HOST + "/api/chat", data=json.dumps(payload).encode(),
                                         headers={"Content-Type": "application/json"}, method="POST")
        content, calls = [], []
        final = None
        total_bytes = 0
        start = time.perf_counter()
        try:
            with self.opener.open(request, timeout=min(30, max(1, deadline - time.monotonic()))) as r:
                while True:
                    if cancel.is_set():
                        raise InterruptedError("Task cancelled")
                    if time.monotonic() >= deadline:
                        raise TimeoutError("Work budget reached")
                    line = r.readline(512 * 1024 + 1)
                    if not line:
                        break
                    total_bytes += len(line)
                    if len(line) > 512 * 1024 or total_bytes > 2 * 1024 * 1024:
                        raise ValueError("Model response exceeded the bounded response limit")
                    chunk = json.loads(line)
                    if chunk.get("error"):
                        raise ModelUnavailable(str(chunk["error"])[:500])
                    msg = chunk.get("message", {})
                    segment = msg.get("content", "")
                    if not isinstance(segment, str) or not isinstance(msg.get("tool_calls", []), list):
                        raise ValueError("Malformed model response")
                    if segment:
                        content.append(segment)
                        on_text(segment)
                    calls.extend(msg.get("tool_calls", []))
                    if len(calls) > 16:
                        raise ValueError("Too many tool calls in one model response")
                    if chunk.get("done"):
                        final = chunk
                        break
        except InterruptedError:
            raise
        except urllib.error.HTTPError as ex:
            raise ModelUnavailable(f"Ollama returned HTTP {ex.code}; check the model name and server") from ex
        except (urllib.error.URLError, socket.timeout, ConnectionError) as ex:
            raise ModelUnavailable("Local model did not respond. Start Ollama and ensure the selected model is installed.") from ex
        if final is None:
            raise ModelUnavailable("Model stream ended before completion; no tool calls were executed")
        if final.get("done_reason") == "length":
            raise ModelUnavailable("Model response hit its output limit; retry with a smaller implementation step")
        if not content and not calls:
            raise ModelUnavailable("Model returned an empty response")
        return {"role": "assistant", "content": "".join(content), "tool_calls": calls}, {
            "elapsed_ms": (time.perf_counter() - start) * 1000,
            "output_tokens": final.get("eval_count"), "eval_duration_ns": final.get("eval_duration"),
            "prompt_tokens": final.get("prompt_eval_count"), "source": "local model API reported counters"}
