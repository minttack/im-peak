"""H137A Accuracy Attribution & Verification Bloom (offline research only).

The user's Accuracy symbol serves as a *named reasoning principle*, not an
image-derived market predictor. Authentic Accuracy pixels are NOT available in
this research branch; no glyph-trained benefit can be claimed.  All policies
are causal: split/selection is pre-holdout; feedback observes resolved labels.
This is research infrastructure, never a trading authorization.
"""
from __future__ import annotations
from collections import defaultdict
from datetime import datetime, timezone
import hashlib
import json
import math
import statistics
from . import familiarity_money_h136 as h

SCHEMA = 'bie.h137a.accuracy-attribution.v1'
POLICIES = ('baseline', 'accuracy_feedback', 'accuracy_cost', 'sham_accuracy')


def _clip(x, lo=0.01, hi=0.99):
    return max(lo, min(hi, float(x)))


def brier(p, y):
    return (p - int(y)) ** 2


def accuracy_weight(resolved_daily, *, window=6, margin=0.0):
    """One-day-lagged outcome feedback only. Returns (0, .5 or 1) depending
    on already matured relative Brier gains. Early data never changes weight.
    """
    if len(resolved_daily) < window:
        return 1.
    recent = resolved_daily[-window:]
    score = sum(recent) / window
    if score < -margin:
        return 0.
    if score < margin + .003:
        return .5
    return 1.


def _conditional_return_means(data, dates, train_stop, ticker):
    pos, neg = [], []
    for i in range(train_stop - 1):
        r = h._label(data, dates[i], dates[i + 1], ticker)
        (pos if r > 0 else neg).append(r)
    return statistics.mean(pos) if pos else .005, statistics.mean(neg) if neg else -.005


def _derived_evidence(payload, virtual_budget=10000.):
    source_mode, dates, data = h.validate(payload)
    train_end, hold_start = int(len(dates)*.5), int(len(dates)*.75)
    selected, dev = h._validation(data, dates, train_end, hold_start)
    # Fixed pre-holdout probability model and pre-holdout return magnitudes.
    history = h._observations(data, dates, hold_start)
    means = {t: _conditional_return_means(data, dates, hold_start, t) for t in h.STOCKS}
    observations = []
    for i in range(hold_start, len(dates)-1):
        day, next_day=dates[i], dates[i+1]
        group=[]
        for ticker in h.STOCKS:
            row=data[(day,ticker)]
            p=_clip(h._predict(row,history,selected))
            prior=_clip(h._predict(row,history,'prior'))
            ret=h._label(data,day,next_day,ticker)
            cost=h._cost_bps(virtual_budget*.10,row)/10000.
            # This is a training-conditioned expected-return proxy; never a
            # scientifically validated estimate of executable alpha.
            positive, negative=means[ticker]
            estimated_return=p*positive+(1-p)*negative
            group.append({'ticker':ticker,'sector':h.SECTORS[ticker],
                'p':p,'prior':prior,'realized_direction':int(ret>0),
                'return':ret,'cost_fraction':cost,
                'estimated_return':estimated_return})
        observations.append((day.isoformat(),group))
    return {'source_mode':source_mode,'chosen_policy':selected,'dev_scores':dev,
        'observations':observations, 'as_of':payload['as_of_utc'],
        'input_sha256':hashlib.sha256(json.dumps(payload,sort_keys=True).encode()).hexdigest()}


def _run(observations, mode, budget):
    cash=float(budget); peak=cash; worst_dd=0.; fee_total=0.; trades=0
    daily_scores=[]; delta_prior=[]; selected_records=[]; probs=[]
    chosen_before_feedback=[]
    for day, group in observations:
        weight=accuracy_weight(delta_prior)
        if mode == 'baseline':
            weight=1.
        # Negative control: same type of on/off decision, but a pseudo-random
        # uninformative score instead of actual matured forecast errors.
        if mode=='sham_accuracy' and len(delta_prior)>=6:
            digest=hashlib.sha256(day.encode()).digest()
            weight=(0.,.5,1.)[digest[0]%3]
        scored=[]
        for r in group:
            p=_clip(r['prior']+weight*(r['p']-r['prior']))
            probs.append((p,r['realized_direction'],r['prior']))
            scored.append((p,r))
        scored.sort(key=lambda z:(-z[0],z[1]['ticker']))
        picks=[]; by_sector=defaultdict(int)
        if mode != 'sham_accuracy':
            # Accuracy feedback can also return a no-trade decision.
            choose_allowed=bool(weight)
        else:
            choose_allowed=bool(weight)
        if choose_allowed:
            for p, r in scored:
                if p<=.565 or by_sector[r['sector']]>=1:
                    continue
                if mode=='accuracy_cost':
                    # Decline only high-cost cases (>50bps modeled);
                    # additionally require training-based expected gross
                    # return to exceed costs + 10bps. Development-chosen
                    # guard, must be frozen on confirmation seeds.
                    if r['cost_fraction'] > .005 and r['estimated_return'] <= r['cost_fraction']+.001:
                        continue
                picks.append((p,r))
                by_sector[r['sector']]+=1
                if len(picks)>=3: break
        start_cash=cash; pnl=0.; costs=0.
        for p,r in picks:
            amount=start_cash*.10
            costs+=amount*r['cost_fraction']
            pnl+=amount*(r['return']-r['cost_fraction'])
        cash=max(0,cash+pnl)
        peak=max(peak,cash)
        worst_dd=max(worst_dd,1-cash/peak)
        trades+=len(picks); fee_total+=costs
        daily_gain=statistics.mean(brier(r['prior'],r['realized_direction'])-brier(r['p'],r['realized_direction']) for r in group)
        # Append after today's decision: NO access to today's label before scoring.
        delta_prior.append(daily_gain)
        daily_scores.append(statistics.mean(brier(p,r['realized_direction']) for p,r in scored))
        selected_records.append({'day':day,'weight_before_label':weight,
            'tickers':[r['ticker'] for _,r in picks],
            'after_cost_pnl_dollars':round(pnl,4),'forecast_gain_resolved_after_decision':round(daily_gain,6)})
    cal=[]
    for k in range(5):
        window=[(p,y) for p,y,_ in probs if k/5<=p<(k+1)/5 or (k==4 and p==1.)]
        if window:
            cal.append((len(window),abs(statistics.mean(p for p,y in window)-statistics.mean(y for p,y in window))))
    ece=sum(n*v for n,v in cal)/len(probs) if cal else None
    confident_errors=sum(1 for p,y,_ in probs if (p>=.65 and y==0) or (p<=.35 and y==1))
    return {'brier':round(statistics.mean(daily_scores),6),'ece':round(ece,6) if ece is not None else None,
        'confident_errors':confident_errors,'samples':len(probs),
        'net_return_pct':round((cash/budget-1)*100,4),'net_pnl_dollars':round(cash-budget,2),
        'max_drawdown_pct':round(worst_dd*100,4),'transaction_costs_dollars':round(fee_total,2),
        'paper_trades':trades,'audit':selected_records,'never_live_orders':True}


def analyze(payload, *, virtual_budget=10000.):
    if type(virtual_budget) not in (int,float) or not math.isfinite(virtual_budget) or not 1<=virtual_budget<=1e7:
        raise ValueError('Invalid paper-only budget')
    d=_derived_evidence(payload,virtual_budget)
    scores={k:_run(d['observations'],k,virtual_budget) for k in POLICIES}
    base_audit=scores['baseline']['audit']
    guarded_audit=scores['accuracy_cost']['audit']
    changed=sum(a['tickers']!=b['tickers'] for a,b in zip(base_audit,guarded_audit))
    weight_changed=sum(x['weight_before_label']<1 for x in guarded_audit)
    return {'schema':SCHEMA,'source_mode':d['source_mode'],'input_sha256':d['input_sha256'],
       'accuracy_concept_intervention':{
           'decision_days':len(base_audit),
           'days_with_different_paper_stock_choices':changed,
           'decisions_changed_pct':round(changed/len(base_audit)*100,2) if base_audit else 0.,
           'days_feedback_weight_reduced':weight_changed,
           'feedback_weight_reduced_pct':round(weight_changed/len(base_audit)*100,2) if base_audit else 0.,
           'source':'previously resolved errors and cost estimates; NOT the creator glyph pixels'},
       'market_policy_frozen_on_development':d['chosen_policy'],
       'symbol_meaning_attribution':'Accuracy symbol as verifier/correction concept; NOT learned from pixels',
       'original_accuracy_glyph_bytes_available_in_this_branch':False,
       'percentage_new_glyph_derived_market_decisions':0.0,
       'authentic_glyph_visual_ablation':'NOT RUN: no SHA-verified Accuracy drawing in this source branch',
       'comparison':{k:{kk:vv for kk,vv in v.items() if kk!='audit'} for k,v in scores.items()},
       'decision_log':scores['accuracy_cost']['audit'],
       'not_evidence_of_live_market_edge':True,'broker_orders_executed':0,
       'next_test':{'hypothesis':'Time-stamped accuracy feedback and cost gating improve unseen after-cost outcomes over baseline and sham, without raising Brier or hidden-regime drawdowns',
       'falsifier':'Same gain from shuffled feedback, deterioration in unexpected regimes, or poor prospective results; keep as research only.'}}


def compare_h136_guard_overlay(payload, *, virtual_budget=10000.):
    """Paired test keeping original H136 drift guard as the control.

    Measures only the incremental high-cost screen. Both arms have identical
    policy and matured-feedback; the original H136 source default is intact.
    """
    if type(virtual_budget) not in (float,int) or not math.isfinite(virtual_budget) or not 1<=virtual_budget<=1e7:
        raise ValueError('Invalid virtual-only capital amount')
    mode, dates, data=h.validate(payload)
    train_end, start=int(len(dates)*.5),int(len(dates)*.75)
    selected,_=h._validation(data,dates,train_end,start)
    control=h._paper(data,dates,start,virtual_budget,selected,dynamic=True,drift_guard=True)
    candidate=h._paper(data,dates,start,virtual_budget,selected,dynamic=True,drift_guard=True,cost_guard=True)
    return {'schema':'bie.h137a.h136-overlay.v1','source_mode':mode,'frozen_selected':selected,
            'existing_h136_drift_guard':{k:v for k,v in control.items() if k!='audit'},
            'h137a_cost_overlay':{k:v for k,v in candidate.items() if k!='audit'},
            'paper_decisions_changed_count':sum(a['selected_tickers']!=b['selected_tickers'] for a,b in zip(control['audit'],candidate['audit'])),
            'real_broker_orders':0, 'authentic_glyph_geometry_used':False}


def synthetic_study(worlds, seeds, *, days=104):
    if not isinstance(seeds,(list,tuple)) or not all(type(s) is int for s in seeds) or len(seeds)>200:
        raise ValueError('Explicit bounded seed list required')
    records=[]
    for world in worlds:
        for seed in seeds:
            r=analyze(h.synthetic(seed,world,days=days))
            records.append({'world':world,'seed':seed,'selection':r['market_policy_frozen_on_development'],
                 **{k:r['comparison'][k] for k in POLICIES}})
    groups={}
    for world in worlds:
        subset=[x for x in records if x['world']==world]
        groups[world]={'count':len(subset),'mean_brier':{p:round(statistics.mean(x[p]['brier'] for x in subset),6) for p in POLICIES},
           'mean_net_return_pct':{p:round(statistics.mean(x[p]['net_return_pct'] for x in subset),4) for p in POLICIES},
           'mean_drawdown_pct':{p:round(statistics.mean(x[p]['max_drawdown_pct'] for x in subset),4) for p in POLICIES},
           'cost_guard_beats_baseline_count':sum(x['accuracy_cost']['net_return_pct']>x['baseline']['net_return_pct'] for x in subset),
           'accuracy_feedback_beats_baseline_brier_count':sum(x['accuracy_feedback']['brier']<x['baseline']['brier'] for x in subset)}
    return {'schema':'bie.h137a.synthetic-study.v1','modes':'synthetic only; no real market prices',
        'worlds':groups,'results':records,'no_live_trading':True}
