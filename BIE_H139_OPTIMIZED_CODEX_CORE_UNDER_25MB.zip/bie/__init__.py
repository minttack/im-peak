"""BIE THRIVES Experience: local-first assistant and evidence lab."""
__version__ = "32.0.0"
