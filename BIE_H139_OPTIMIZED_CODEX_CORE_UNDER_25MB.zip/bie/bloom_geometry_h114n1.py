"""H114-N1: equal-rectangle holdout for optional visual Bloom geometry.

Not a compression, model-learning, hardware, or program-execution optimization.
Defaults are finite. Does not read or mutate BIE app state. Frozen experiment
seed and hypotheses precede the holdout; no test-set tuning.
"""
from __future__ import annotations
import math
import random
import statistics
import time
from .bloom_line_lab import Geometry, safe_pack, check_integrity

PROTOCOL = {
    "id": "H114-N1",
    "seed": 20261016,
    "cases": 60,
    "status": "offline local Python geometry experiment; separate from H114 design and confirmation",
    "controls": ("straight_one_row", "orthogonal_grid", "hexagonal_grid"),
    "primary_outcome": "number of verified non-overlapping circles in an identical fixed 2D viewport",
    "decision_rule": "No default promotion unless Wiggle exceeds hex-grid count by >5% in >=60% of sealed cases, with 0 integrity failures and lower/equal median construction time",
    "constraints": "all candidate circles wholly inside viewport; identical radii; exact pairwise center checks",
}


def _params(width, height, radius, amplitude, cycles):
    values = (width, height, radius, amplitude, cycles)
    if not all(isinstance(v,(int,float)) and math.isfinite(v) for v in values):
        raise ValueError('Nonfinite parameters')
    if not (48<=width<=960 and 32<=height<=512 and 2<=radius<=32 and 0<=amplitude<=128 and 0<=cycles<=16):
        raise ValueError('Viewport settings out of bounds')
    if width<2*radius or height<2*radius or amplitude>height/2-radius:
        raise ValueError('Wiggle does not fit inside viewport')


def _grid(width,height,r,hexagonal):
    rows=[]
    v_step=(math.sqrt(3)*r if hexagonal else 2*r)
    idx=0
    y=r
    while y<=height-r+1e-8:
        offset=(r if (idx%2 and hexagonal) else 0)
        x=r+offset
        while x<=width-r+1e-8:
            rows.append((round(x,9),round(y,9)))
            x+=2*r
        y+=v_step
        idx+=1
    return rows


def _check(points,width,height,r):
    for x,y in points:
        if not (r-1e-8<=x<=width-r+1e-8 and r-1e-8<=y<=height-r+1e-8):
            return False
    mind2=(2*r-1e-7)**2
    for i,(x,y) in enumerate(points):
        for u,v in points[:i]:
            if (x-u)**2+(y-v)**2 < mind2: return False
    return True


def _layout(width,height,r,amp,cycles,kind):
    if kind=='wiggle':
        original=safe_pack(Geometry(radius=r, amplitude=amp, cycles=cycles,
                                    phase=.42,width=width-2*r,center_focus=True))
        return [(x+r,y+height/2) for x,y in original]
    if kind=='straight':
        return [(r+2*r*i,height/2) for i in range(int((width-2*r)//(2*r))+1)]
    if kind=='grid': return _grid(width,height,r,False)
    if kind=='hex': return _grid(width,height,r,True)
    raise ValueError('Unknown layout')


def compare_layouts(width=480,height=128,radius=8.,amplitude=32.,cycles=5., timed=False):
    _params(width,height,radius,amplitude,cycles)
    coords={}; durations={}
    for kind in ('straight','grid','hex','wiggle'):
        t0=time.perf_counter_ns()
        coords[kind]=_layout(width,height,radius,amplitude,cycles,kind)
        durations[kind]=round((time.perf_counter_ns()-t0)/1e6,6)
    valid={key:_check(points,width,height,radius) for key,points in coords.items()}
    # H114's own integrity check also validates Wiggle x-order and no overlaps.
    geometry=Geometry(radius=radius,amplitude=amplitude,cycles=cycles,width=width-2*radius,phase=.42)
    shifted=[(x-radius,y-height/2) for x,y in coords['wiggle']]
    valid['wiggle_h114']=bool(check_integrity(shifted,geometry)['valid'])
    if not all(valid.values()): raise AssertionError('Geometry integrity failure')
    counts={key:len(points) for key,points in coords.items()}
    return {'viewport':{'width':width,'height':height,'radius':radius,'amplitude':amplitude,'cycles':cycles},
            'counts':counts,'integrity_pass':True, 'integrity_by_layout':valid,
            'wiggle_vs_hex_ratio':round(counts['wiggle']/counts['hex'],5),
            'wiggle_vs_straight_ratio':round(counts['wiggle']/counts['straight'],5),
            'build_ms':durations, 'coordinates':coords}


def run_holdout():
    rng=random.Random(PROTOCOL['seed'])
    rows=[]
    for i in range(PROTOCOL['cases']):
        radius=rng.choice((6,8,10,12,14,16))
        width=rng.choice((240,360,480,600))
        height=rng.choice((64,96,128,160))
        amplitude=round(rng.uniform(0, min(64.,height/2-radius)), 3)
        cycles=round(rng.uniform(1,12),4)
        m=compare_layouts(width,height,radius,amplitude,cycles)
        rows.append({'trial':i,'params':m['viewport'],'counts':m['counts'],
                     'wiggle_vs_hex_ratio':m['wiggle_vs_hex_ratio'],
                     'wiggle_vs_straight_ratio':m['wiggle_vs_straight_ratio'],
                     'build_ms':m['build_ms'],'passed':m['integrity_pass']})
    wins=sum(r['wiggle_vs_hex_ratio']>1.05 for r in rows)
    wiggle_faster=sum(r['build_ms']['wiggle']<=r['build_ms']['hex'] for r in rows)
    return {'experiment':PROTOCOL,'summary':{'integrity_pass_count':sum(r['passed'] for r in rows),
         'num_trials':len(rows),'wiggle_beats_hex_by_over_5_percent':wins,
         'wiggle_at_least_5_percent_worse_than_hex':sum(r['wiggle_vs_hex_ratio']<0.95 for r in rows),
         'wiggle_better_than_single_straight_row':sum(r['wiggle_vs_straight_ratio']>1 for r in rows),
         'median_wiggle_vs_hex_ratio':round(statistics.median(r['wiggle_vs_hex_ratio'] for r in rows),4),
         'median_wiggle_vs_one_row_ratio':round(statistics.median(r['wiggle_vs_straight_ratio'] for r in rows),4),
         'wiggle_construction_at_least_as_fast_cases':wiggle_faster,
         'median_build_ms':{name:round(statistics.median(r['build_ms'][name] for r in rows),5)
                            for name in ('straight','grid','hex','wiggle')}},
         'promotion_decision':'HOLD',
         'limitations':['Synthetic 2D visualization geometry only; does not benchmark BIE learning or coding',
                        'Python timings affected by host conditions; no Windows or GPU tests',
                        'Different algorithms construct different node counts; timings are not normalized per useful node',
                        'Equal rectangular viewport is a more relevant comparison than horizontal span alone'],
         'trials':rows}
