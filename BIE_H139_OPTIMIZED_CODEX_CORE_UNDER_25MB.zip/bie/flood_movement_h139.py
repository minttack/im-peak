"""H139 FLOOD MOVEMENT: offline, causal, evidence-ranked stock-flow research.

No brokerage client, no credentials, no execution APIs, no live orders.
A 'flood' is a research METAPHOR for price/volume/attention movement, not
an observation of actual institutional capital flow or a market prediction.
"""
from __future__ import annotations
from collections import defaultdict
from datetime import date, timedelta
from pathlib import Path
import json
import math
import random
import statistics

SCHEMA = "bie.h139.flood-movement.v1"
BENCHMARKS = ("SPY", "QQQ")
STOCK_SECTORS = {"MSFT":"Technology", "AAPL":"Technology", "NVDA":"Semiconductors",
 "AMZN":"Consumer", "GOOGL":"Communication", "META":"Communication", "JPM":"Financials",
 "XOM":"Energy", "WMT":"Retail", "JNJ":"Healthcare"}
FEATURES = ("momentum", "relative_volume_flow", "relative_strength", "range_pressure",
            "familiarity_pattern", "investor_attention")
MODELS = {"prior": (), "price": ("momentum", "relative_strength"),
          "flood": ("relative_volume_flow", "range_pressure"),
          "price_flood": ("momentum", "relative_strength", "relative_volume_flow", "range_pressure"),
          "all_evidence": FEATURES}


def _finite(x, lo=None, hi=None):
    if isinstance(x, bool) or not isinstance(x, (int, float)) or not math.isfinite(x):
        raise ValueError("Expected finite numeric market measurement")
    if lo is not None and x < lo or hi is not None and x > hi:
        raise ValueError("Market measurement outside supported range")
    return float(x)


def _clamp(x, lo=-1., hi=1.):
    return min(hi, max(lo, x))


def _median(x):
    return statistics.median(x)


def validate(payload):
    if not isinstance(payload, dict) or payload.get("schema") != SCHEMA:
        raise ValueError("Invalid H139 schema")
    mode = payload.get("source_mode")
    if mode not in ("synthetic", "user_supplied_historical"):
        raise ValueError("Source mode must be explicit")
    try:
        as_of = date.fromisoformat(payload["as_of_date"])
    except (KeyError, TypeError, ValueError) as e:
        raise ValueError("Invalid as_of_date") from e
    if as_of > date.today():
        raise ValueError("Future as_of_date")
    raw = payload.get("bars")
    if not isinstance(raw, list) or len(raw)>150000 or len(raw)<200:
        raise ValueError("Need 200..150000 source bars")
    securities = payload.get("sectors")
    if not isinstance(securities,dict) or any(not isinstance(k,str) or not isinstance(v,str) for k,v in securities.items()):
        raise ValueError("Missing sector map")
    names = sorted(k for k in securities if k not in BENCHMARKS)
    if not 3 <= len(names) <= 25 or not all(n.isupper() and n.replace('.','').isalpha() for n in names):
        raise ValueError("Require 3..25 named stock symbols")
    required=set(names) | set(BENCHMARKS)
    book={}; dates=set()
    for i,row in enumerate(raw):
        if not isinstance(row,dict) or row.get("ticker") not in required:
            raise ValueError(f"Unknown stock at row {i}")
        ticker=row["ticker"]
        try: d=date.fromisoformat(row["date"])
        except (TypeError,KeyError,ValueError) as e: raise ValueError("Invalid source bar date") from e
        if d>as_of: raise ValueError("Future price bar / as-of leakage")
        key=(d,ticker)
        if key in book: raise ValueError("Duplicate time/ticker")
        op, hi, lo, cl = (_finite(row.get(f),0.001,1e7) for f in ("open","high","low","close"))
        vol=_finite(row.get("volume"),1,1e12)
        if mode=="user_supplied_historical" and ("spread_bps" not in row or row.get("spread_basis") not in ("historical_observation", "explicit_cost_assumption")):
            raise ValueError("Real historical input requires an explicit spread_bps and historical_observation/explicit_cost_assumption label")
        spread=_finite(row.get("spread_bps",12.),0,2000.)
        if hi < max(op,cl,lo) or lo > min(op,cl,hi):
            raise ValueError("Invalid OHLC ordering")
        if mode=="user_supplied_historical" and not isinstance(row.get("source_ref"),str):
            raise ValueError("Historical bar source reference is required")
        if mode=="user_supplied_historical" and (not row.get("source_ref","").strip() or row["source_ref"].lower().startswith("synthetic")):
            raise ValueError("No synthetic/empty reference for real history")
        extras={}
        for name in ("investor_attention",):
            if name in row and row[name] is not None:
                sig=row[name]
                if not isinstance(sig,dict): raise ValueError("Extra observation must contain value, observed_at, source_ref")
                value=_finite(sig.get("value"),-1,1)
                try: seen=date.fromisoformat(sig["observed_at"])
                except (KeyError,TypeError,ValueError) as e: raise ValueError("Invalid observation timestamp") from e
                if seen>d: raise ValueError("Lookahead in extra observation")
                if not isinstance(sig.get("source_ref"),str) or not sig["source_ref"].strip():
                    raise ValueError("Missing extra observation provenance")
                if mode=="user_supplied_historical" and sig["source_ref"].startswith("synthetic"):
                    raise ValueError("Synthetic extra evidence cannot masquerade as real")
                if (d-seen).days <= 7: extras[name]=value
        book[key]={"open":op,"high":hi,"low":lo,"close":cl,"volume":vol,
                   "spread_bps":spread,"extras":extras}
        dates.add(d)
    dates=sorted(dates)
    if not 140 <= len(dates) <= 4000: raise ValueError("Need 140..4000 aligned trading days")
    if len(book)!=len(dates)*len(required): raise ValueError("All ticker-date rows must align; no silent filling")
    if any((d,t) not in book for d in dates for t in required):
        raise ValueError("Missing aligned stock/benchmark bar")
    return mode,dates,names,book,securities


def feature_matrix(dates,names,book):
    samples=[]
    for i in range(21,len(dates)-1):
        d=dates[i]; nd=dates[i+1]
        spy_now=book[(d,"SPY")];spy_prev=book[(dates[i-1],"SPY")]
        spy_ret=(spy_now["close"]/spy_prev["close"]-1)
        for t in names:
            r=book[(d,t)]; prev=book[(dates[i-1],t)]; nxt=book[(nd,t)]
            history=[book[(dates[j],t)] for j in range(i-20,i)]
            rvol = r["volume"] / max(1, _median([v["volume"] for v in history]))
            daily_ret=r["close"]/prev["close"]-1
            close_loc=2*(r["close"]-r["low"])/max(.001,r["high"]-r["low"])-1
            daily_changes=[book[(dates[j],t)]["close"]/book[(dates[j-1],t)]["close"]-1 for j in range(i-4,i+1)]
            # "familiarity" = observed historical consistency; NOT human familiarity.
            positive=sum(x>0 for x in daily_changes)
            x={"momentum":_clamp((r["close"]/book[(dates[i-5],t)]["close"]-1)*8),
               "relative_volume_flow":_clamp(close_loc*min(2.5,rvol)/2.5),
               "relative_strength":_clamp((daily_ret-spy_ret)*20),
               "range_pressure":_clamp(close_loc * ((r["high"]-r["low"])/r["close"])*25),
               "familiarity_pattern":_clamp((positive-2.5)/2.5)}
            x.update(r["extras"])
            # Decision uses completed session d. Outcome is NEXT session's
            # open-to-close movement; no hypothetical close-d fill.
            target = nxt["close"]/nxt["open"]-1
            samples.append({"date":d,"outcome_date":nd,"ticker":t,"x":x,
                            "y":int(target>0),"gross":target,
                            "cost_bps":r["spread_bps"]+6.,
                            "dollar_volume":r["close"]*r["volume"]})
    return samples


def _split(dates):
    # Same frozen chronological split for all tickers. Outcomes d+1 require embargo.
    valid=dates[21:-1]
    a=int(.55*len(valid));b=int(.78*len(valid))
    train=set(valid[:max(0,a-2)])
    val=set(valid[a:max(a,b-2)])
    hold=set(valid[b:])
    return train,val,hold,{"train_end":str(valid[max(0,a-3)]),"validation_start":str(valid[a]),
            "validation_end":str(valid[max(a,b-3)]),"holdout_start":str(valid[b]),
            "label_horizon_days":"next trading session","embargo_decision_bars":2}


def choose_universe(samples,train_dates,names,sectors):
    ranked=[]
    for t in names:
        rows=[s for s in samples if s["ticker"]==t and s["date"] in train_dates]
        if not rows:continue
        volume=_median([s["dollar_volume"] for s in rows]);
        coverage=sum(len(s["x"]) for s in rows)/(len(rows)*len(FEATURES))
        # Data sufficiency and liquidity; not expected-return forecast.
        score=round(60*min(1., math.log10(1+volume)/10)+40*coverage,2)
        ranked.append({"ticker":t,"sector":sectors[t],"coverage_score_not_profit":score,
                       "median_dollar_volume_train":round(volume,2)})
    ranked.sort(key=lambda r:(-r["coverage_score_not_profit"],r["ticker"]))
    chosen=[];counts=defaultdict(int)
    for r in ranked:
        if len(chosen)>=5: break
        if counts[r["sector"]]>=2:continue
        if r["median_dollar_volume_train"]<250000:continue
        chosen.append(r["ticker"]);counts[r["sector"]]+=1
    return chosen,ranked


def _fit(rows,features):
    if not rows:return {"prior":.5,"weights":{}}
    prior=(sum(r["y"] for r in rows)+15)/(len(rows)+30)
    weights={}
    for f in features:
        available=[r for r in rows if f in r["x"]]
        if len(available)<60:continue
        mean_x=statistics.mean(r["x"][f] for r in available)
        var=statistics.mean((r["x"][f]-mean_x)**2 for r in available)
        cov=statistics.mean((r["x"][f]-mean_x)*(r["y"]-prior) for r in available)
        if var>.005:
            weights[f]=_clamp(cov/max(.02,var)*.65, -.34,.34)
    return {"prior":prior,"weights":weights}


def _predict(model,row,omit=None):
    p=model["prior"]
    for f,w in model["weights"].items():
        if f!=omit: p+=w*row["x"].get(f,0)
    return min(.97,max(.03,p))


def _brier(rows, model,omit=None):
    return statistics.mean((_predict(model,r,omit)-r["y"])**2 for r in rows) if rows else None


def paper(rows,model,*,max_per_name=.10,max_total=.30,threshold=.60):
    """One-session next-open to next-close shadow, no leverage, no overnight PnL.

    Cost assumptions are intentionally simplified, not broker fill prices.
    """
    byday=defaultdict(list)
    for r in rows:byday[r["date"]].append(r)
    equity=10000.;peak=equity;drawdown=0.;trades=0;daily=[];log=[]
    for d in sorted(byday):
        candidates=sorted((r for r in byday[d] if _predict(model,r)>=threshold
                           and r["dollar_volume"]>=250000),
                          key=lambda r:(-_predict(model,r),r["ticker"]))
        chosen=candidates[:min(3,int(max_total/max_per_name+1e-8))]
        ret=sum(max_per_name*(r["gross"]-2*r["cost_bps"]/10000) for r in chosen)
        equity*=max(.001,1+ret);peak=max(peak,equity)
        drawdown=max(drawdown,1-equity/peak);trades+=len(chosen)
        daily.append(ret)
        log.append({"decision_date":str(d),"symbols":[r["ticker"] for r in chosen],
                    "gross_exposure":round(len(chosen)*max_per_name,3),
                    "daily_paper_return_pct":round(ret*100,5)})
    return {"initial_virtual_cash":10000,"ending_virtual_cash":round(equity,2),
            "virtual_return_pct":round((equity/10000-1)*100,4),
            "max_drawdown_pct":round(drawdown*100,4),"trade_count":trades,
            "days":len(daily),"decisions":log,
            "cost_model":"two-sided (spread_bps + 6bps) per proposed virtual trade; no overnight returns/real fills",
            "trading":"VIRTUAL ONLY"}



def benchmark_shadow(dates, hold_dates, book, ticker, exposure=.30):
    """Matched next-open/next-close virtual benchmark, 30% of cash exposed.

    Explicitly not buy-and-hold, because the candidate exits at each close.
    """
    result=10000.;peak=result;maxdd=0.;trades=0
    for i,d in enumerate(dates[:-1]):
        if d not in hold_dates:continue
        r=book[(dates[i+1],ticker)]
        nxt_ret=r["close"]/r["open"]-1
        cost=2*(r["spread_bps"]+6.)/10000
        result*=max(.001,1+exposure*(nxt_ret-cost));trades+=1
        peak=max(result,peak);maxdd=max(maxdd,1-result/peak)
    return {"virtual_return_pct":round((result/10000-1)*100,4),
            "max_drawdown_pct":round(maxdd*100,4),"trade_count":trades,
            "benchmark_design":"30% exposure, next-session open-to-close only, liquidated every close; not ETF buy-and-hold"}


def benchmark_buy_hold(dates, hold_dates, book, ticker, exposure=.30):
    """30% allocated at first unseen session open, liquidated final close.

    Holds overnight unlike candidate's intraday positions: useful additional
    market comparison, not directly identical exposure/timing risk.
    """
    first = next((i+1 for i,d in enumerate(dates[:-1]) if d in hold_dates), None)
    if first is None:return {"virtual_return_pct":0.0,"max_drawdown_pct":0.0,"trades":0}
    last=len(dates)-1
    a=book[(dates[first],ticker)];b=book[(dates[last],ticker)]
    entry=a["open"]
    entry_cost=(a["spread_bps"]+6.)/10000
    exit_cost=(b["spread_bps"]+6.)/10000
    equity=10000.;peak=equity;dd=0.
    for k in range(first,last+1):
        price=book[(dates[k],ticker)]["close"]
        unrealized=(price/entry-1-entry_cost)
        mark=10000*(1+exposure*unrealized)
        peak=max(peak,mark);dd=max(dd,1-mark/peak)
    equity=10000*(1+exposure*(b["close"]/entry-1-entry_cost-exit_cost))
    peak=max(peak,equity);dd=max(dd,1-equity/peak)
    return {"virtual_return_pct":round((equity/10000-1)*100,4),
            "max_drawdown_pct":round(dd*100,4),"trades":2,
            "benchmark_design":"30% buy-and-hold ETF allocation from first holdout session open to last close; includes overnight risk and entry/exit costs"}

def analyze(payload):
    mode,dates,names,book,sectors=validate(payload)
    samples=feature_matrix(dates,names,book)
    train,val,hold,splits=_split(dates)
    chosen,ranking=choose_universe(samples,train,names,sectors)
    if len(chosen)<2:raise ValueError("Insufficient liquid, sector-diversified research universe")
    use=[r for r in samples if r["ticker"] in chosen]
    tr=[r for r in use if r["date"] in train]
    va=[r for r in use if r["date"] in val]
    te=[r for r in use if r["date"] in hold]
    if min(len(tr),len(va),len(te))<60:raise ValueError("Too little chronology-safe evidence")
    models={m:_fit(tr,fs) for m,fs in MODELS.items()}
    validation={m:round(_brier(va,fit),7) for m,fit in models.items()}
    # Chronological validation alone chooses final model, never holdout.
    best=min(validation,key=lambda m:(validation[m],len(MODELS[m]),m))
    improvement=validation["prior"]-validation[best]
    val_shadow=paper(va,models[best]) if best!="prior" else {"virtual_return_pct":0}
    promote=best!="prior" and improvement>=.002 and val_shadow["virtual_return_pct"]>0
    selected=best if promote else "prior"
    # Nonpromoted policy must abstain; baseline prediction is NOT trade authorization.
    chosen_fit=models[selected]
    baseline_fit=models["prior"]
    holdout_brier=_brier(te,chosen_fit)
    baseline_brier=_brier(te,baseline_fit)
    frozen_paper=paper(te,chosen_fit) if promote else paper(te,{"prior":0.,"weights":{}})
    # Fair no-glyph/signal ablations: no assumption original artwork is present.
    relevance={}
    for f in FEATURES:
        if f not in chosen_fit["weights"]:
            relevance[f]={"validation_brier_gain":0.,"selected_weight":0.,"source":"historical observation or unavailable"}
        else:
            relevance[f]={"validation_brier_gain":round(_brier(va,chosen_fit,omit=f)-validation[selected],7),
                          "selected_weight":round(chosen_fit["weights"][f],5),
                          "source":"measured validation, not causal proof"}
    if not promote:
        reason="Validation did not establish positive calibrated and virtual-after-cost improvement over prior"
        next_question="Can a simpler or new flow indicator beat the unconditional prior on a new development window?"
    elif holdout_brier>=baseline_brier:
        reason="Frozen policy lost its Brier advantage on holdout; likely shifted relevance"
        next_question="Does a chronological, label-lagged drift detector identify the loss of relevance before reducing paper returns?"
    else:
        reason="Provisional held-out Brier gain; still requires independent prospective market evidence"
        next_question="Will this survive new calendar periods and real spread/fill observations against SPY, QQQ and cash?"
    return {"schema":"bie.h139.flood-report.v1","source_mode":mode,
            "interpretation":"Flood is a bounded price/volume-flow research metaphor; not institutional money-flow proof",
            "universe_ranked_on_train_only":ranking,"research_stocks_selected":chosen,
            "chronological_split":splits,"feature_defs":list(FEATURES),
            "validation_brier_lower_is_better":validation,
            "selected_model_frozen_before_holdout":selected,
            "complexity_promotion":bool(promote),"validation_advantage_vs_prior":round(improvement,7),
            "holdout_evaluation":{"samples":len(te),"brier":round(holdout_brier,7),
                                   "prior_brier":round(baseline_brier,7),
                                   "incremental_brier_gain":round(baseline_brier-holdout_brier,7)},
            "relevance_attribution":relevance,"paper_portfolio":frozen_paper,
            "comparison_benchmarks":{"cash":{"virtual_return_pct":0.0},
                  "SPY":benchmark_shadow(dates,hold,book,"SPY"),
                  "QQQ":benchmark_shadow(dates,hold,book,"QQQ"),
                  "SPY_buy_hold":benchmark_buy_hold(dates,hold,book,"SPY"),
                  "QQQ_buy_hold":benchmark_buy_hold(dates,hold,book,"QQQ")},
            "accuracy_glyph_derived_predictions":0,
            "historical_familiarity_is_not_investor_identity":True,
            "learning_mode":"frozen parameter fit on train; validation selects policy; holdout only evaluates; no auto-retraining weights",
            "proof_ladder":{"stage":"paper research", "large_real_purchase_authorized":False,
                            "live_orders_executed":0,"automatic_live_position_scaling":False,
                            "manual_trade_approval_required_for_future_explicit_user_request":True},
            "thought_packet":{"goal":"Find time-locked incremental predictability that survives market regime changes",
                              "result":reason,"contradiction":None if promote else "More observations did not justify deployment",
                              "confidence":"synthetic/retrospective ONLY, not real-world trade probability",
                              "next_test":next_question,
                              "falsifier":"No prospective after-cost gain on new previously untouched data",
                              "source":"H139 bounded research analysis"},
            "data_restrictions":"Historical source IDs are not independently authenticated; split-adjustment, bid/ask history, earnings release timestamps and all cost assumptions need independent review",
            "not_proven":["real-world alpha", "real fills", "fully continuous independent learning",
                          "original Accuracy drawing predictive effect", "safe position sizing based on one test"]}


def synthetic(seed=13901,world="flow",days=260):
    if world not in ("flow","reversal","null","illiquid") or not 170<=days<=1000:
        raise ValueError("Invalid H139 synthetic experiment")
    rng=random.Random(seed)
    names=list(STOCK_SECTORS)
    prices={s:80+rng.uniform(0,40) for s in names+list(BENCHMARKS)}
    prev_sign={s:0 for s in prices}
    bars=[];start=date(2024,1,2)
    trading_dates=[];k=0
    while len(trading_dates)<days:
        d=start+timedelta(days=k);k+=1
        if d.weekday()<5:trading_dates.append(d)
    for idx,d in enumerate(trading_dates):
        for s in names+list(BENCHMARKS):
            sign=rng.uniform(-1,1)
            if s in BENCHMARKS:
                daily=rng.gauss(0,.004)
            else:
                factor= .014 if world in ("flow","illiquid","reversal") else 0.
                if world=="reversal" and idx>int(days*.77):factor=-factor
                daily=prev_sign[s]*factor+rng.gauss(0,.006)
            op=prices[s]*(1+rng.gauss(0,.001))
            cl=op*(1+_clamp(daily,-.08,.08))
            buffer=op*.006
            if sign>0:
                lo=min(op,cl)-buffer;hi=cl+buffer*.15 if cl>=op else op+buffer
            else:
                hi=max(op,cl)+buffer;lo=cl-buffer*.15 if cl<=op else op-buffer
            hi=max(hi,op,cl);lo=min(lo,op,cl)
            volume=int((600000 if world!="illiquid" else 30000)*(1+.3*abs(sign)+rng.random()))
            bars.append({"date":d.isoformat(),"ticker":s,"open":round(op,6),"high":round(hi,6),
                         "low":round(lo,6),"close":round(cl,6),"volume":volume,
                         "spread_bps":15 if world!="illiquid" else 280,
                         "source_ref":"synthetic-H139"})
            prices[s]=cl;prev_sign[s]=sign
    return {"schema":SCHEMA,"source_mode":"synthetic","as_of_date":trading_dates[-1].isoformat(),
            "sectors":STOCK_SECTORS,"bars":bars,"simulation_assumptions":world}


def run_file(path):
    p=Path(path)
    if not p.is_file() or p.stat().st_size>60_000_000:
        raise ValueError("Missing/oversized JSON; no network requests will be made")
    return analyze(json.loads(p.read_text(encoding="utf-8")))


def write_new(path,obj):
    p=Path(path);p.parent.mkdir(parents=True,exist_ok=True)
    with p.open("x",encoding="utf-8") as f: json.dump(obj,f,indent=2,allow_nan=False,default=str)
