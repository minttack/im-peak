"""BIE v28 passive Wi-Fi Discovery & Reasoning.

No radio transmission, probes, credentials, connection attempts or undocumented
capability claims. Consumes pseudonymized observations collected by wifi_lab.
Each finding carries source, supported observation, alternatives, refutation,
confidence and an actionable, authorized verification step.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from contextlib import closing
from datetime import datetime
import json
from math import sqrt
from pathlib import Path
import random
import sqlite3
import statistics

from .wifi_lab import WifiLab, _RADIO_ORDER


def _safe_load(text, default):
    try:
        x = json.loads(text)
        return x if isinstance(x, type(default)) else default
    except (TypeError, ValueError):
        return default


def _wilson(count, total):
    """Approximate 95% interval for per-snapshot detection frequency, NOT availability."""
    if total < 1:
        return None
    p, z = count / total, 1.96
    den = 1 + z*z/total
    center = (p + z*z/(2*total))/den
    radius = z*sqrt((p*(1-p)+z*z/(4*total))/total)/den
    return [round(max(0, center-radius), 3), round(min(1, center+radius), 3)]


def _errors(values):
    """Predeclared walk-forward predictions; all forecasts use only preceding values."""
    if len(values) < 12:
        return None
    start = max(6, int(len(values)*.7))
    errors = {"last_value": [], "rolling_median_3": [], "wiggle_gradient": []}
    for i in range(start, len(values)):
        target, previous = values[i], values[i-1]
        delta = previous-values[i-2]
        guesses = (previous, statistics.median(values[i-3:i]),
                   max(0, min(100, previous+(.5*delta if abs(delta) >= 8 else 0))))
        for name, guess in zip(errors, guesses):
            errors[name].append(abs(target-guess))
    return errors


def _paired_bootstrap(baseline, candidate):
    """Exploratory block-resampling of forecast error differences, not a causal test."""
    differences = [b-c for b,c in zip(baseline, candidate)]
    n = len(differences)
    if n < 8:
        return None
    rng = random.Random(28015)
    block = min(3, n)
    reps = []
    for _ in range(400):
        sampled = []
        while len(sampled) < n:
            start = rng.randrange(n-block+1)
            sampled.extend(differences[start:start+block])
        reps.append(statistics.mean(sampled[:n]))
    reps.sort()
    return [round(reps[10], 3), round(reps[389], 3)]


def _predict(values, sessions, timestamps=None):
    errs = _errors(values)
    session_count = len(set(sessions))
    if errs is None:
        return {"status": "insufficient_snapshots", "need": 12,
                "have": len(values), "user_labeled_sessions": session_count,
                "claim": "No predictive result yet"}
    mae = {name: round(statistics.mean(v), 3) for name, v in errs.items()}
    paired_ci = _paired_bootstrap(errs["last_value"], errs["wiggle_gradient"])
    delta = round(mae["last_value"]-mae["wiggle_gradient"], 3)
    # Reused/imported timestamps cannot demonstrate repeated field observations.
    time_quality = ("repeated_timestamps" if timestamps is not None and
                    len(set(timestamps)) < max(2, int(len(values)*.75)) else "distinct_timestamps")
    enough = (len(values) >= 24 and session_count >= 2 and paired_ci is not None and
              time_quality == "distinct_timestamps")
    improved = delta > 0 and paired_ci is not None and paired_ci[0] > 0
    status = ("provisional_prediction_signal_needs_external_replication" if enough and improved
              else "not_supported_vs_baseline" if delta <= 0
              else "exploratory_unconfirmed")
    return {"status": status, "snapshots": len(values), "holdout": len(errs["last_value"]),
            "user_labeled_sessions": session_count, "timestamp_quality": time_quality, "mean_absolute_error": mae,
            "wiggle_gain_vs_last_value_mae": delta, "exploratory_block_bootstrap_95_pct_delta": paired_ci,
            "relative_gain_percent": round(100*delta/mae["last_value"], 1) if mae["last_value"] else None,
            "method": "Fixed 70/30 chronological split; predeclared one-step models; no look-ahead; block bootstrap is only descriptive",
            "limitations": "User-marked sessions are not proven independent. Irregular sampling, environment changes, and correlated observations confound inference. No speed or RF performance gain established."}


def _packet(identifier, observation, inference, confidence, source, alternatives, contradiction, verification):
    return {"id": identifier, "observation": observation, "if_then": inference,
            "confidence": confidence, "source": source, "alternative_explanations": alternatives,
            "would_contradict": contradiction, "next_test": verification,
            "classification": "inference_not_physical_discovery"}


class WifiDiscovery:
    def __init__(self, home):
        self.lab = WifiLab(home)

    def report(self):
        with closing(sqlite3.connect(str(self.lab.db_path))) as con:
            con.row_factory = sqlite3.Row
            records = [dict(r) for r in con.execute("SELECT * FROM readings ORDER BY id LIMIT 10000")]
        if not records:
            return {"version": 28, "status": "no_measurements", "next":
                    "Use Snapshot current Wi-Fi on your own Windows PC; then Advanced discovery."}
        readings = []
        for r in records:
            aps = _safe_load(r.get("aps_json"), [])
            warnings = _safe_load(r.get("warnings_json"), [])
            radios = _safe_load(r.get("adapter_json"), [])
            readings.append({"id": r["id"], "time": r["observed_at"],
                             "link": r["connected_id"], "signal": r["signal_pct"],
                             "session": r.get("session_id") or "legacy_unlabeled",
                             "aps": aps, "warnings": warnings,
                             "adapter_radios": radios, "connected_channel": r.get("connected_channel")})
        # Windows may report no APs due to privacy / hardware; such readings do not
        # count as absence evidence. AP visibility is conditional on complete reports.
        valid = [r for r in readings if r["aps"] and not r["warnings"]]
        occurrence = Counter()
        protocols = defaultdict(set)
        ap_signals = defaultdict(list)
        for r in valid:
            seen = set()
            for ap in r["aps"]:
                ident = ap.get("network_id")
                if not ident:
                    continue
                if ident not in seen:
                    occurrence[ident] += 1
                    seen.add(ident)
                if isinstance(ap.get("generation"), int):
                    protocols[ident].add(ap["generation"])
                pct = ap.get("signal_pct")
                if isinstance(pct, int) and 0 <= pct <= 100:
                    ap_signals[ident].append(pct)
        last = readings[-1]
        last_known = valid[-1] if valid else None
        recent = {a.get("network_id") for a in last_known["aps"] if a.get("network_id")} if last_known else set()
        previous = set()
        if len(valid) > 1:
            previous = {a.get("network_id") for a in valid[-2]["aps"] if a.get("network_id")}
        # Keep identifiers opaque and data volume bounded. Count ≠ device identity or rights.
        indicators = []
        for key, count in sorted(occurrence.items(), key=lambda t:(-t[1],t[0]))[:30]:
            indicators.append({"local_pseudonym": key, "seen_snapshots": count,
                               "eligible_snapshots": len(valid),
                               "observed_fraction": round(count/len(valid),3),
                               "descriptive_wilson_interval": _wilson(count,len(valid)),
                               "advertised_generations": sorted(protocols[key]),
                               "median_signal_pct": round(statistics.median(ap_signals[key]),1) if ap_signals[key] else None})
        highest = max((max(v) for v in protocols.values() if v), default=0)
        adapter_gen = max((_RADIO_ORDER.get(x,0) for x in last["adapter_radios"]),default=0)
        channel_counts = Counter()
        if last_known:
            for ap in last_known["aps"]:
                channel = str(ap.get("channel", "")).strip()
                if channel.isdigit() and 1 <= int(channel) <= 233:
                    band = str(ap.get("band", "")).strip()[:16] or "band_not_reported"
                    channel_counts[band+" / channel "+channel] += 1
        packets = []
        if highest >= 7:
            packets.append(_packet("observed_wifi7_advertisement",
                "At least one Windows-advertised AP reported an 802.11be radio type.",
                "IF radio type 802.11be is reported, THEN a Wi-Fi 7-capable AP might be nearby; actual link capability remains untested.",
                "moderate_for_advertisement_only", "Windows-reported nearby radio type in stored snapshots",
                ["misreported drivers", "router capabilities differ from negotiated mode", "beacon seen without access"],
                "Adapter cannot establish authorized 802.11be link even when router and device specifications support it.",
                "On your own router, confirm adapter specs and permitted association, then measure throughput and latency with controls."))
        elif highest:
            packets.append(_packet("highest_observed_protocol",
                f"Highest generation seen in eligible stored snapshots was {highest}.",
                "IF no newer radio appears, THEN none was observed by this adapter at those times; that does not show it is absent.",
                "moderate_for_this_sample_only", "Windows-reported AP radio types",
                ["hidden or out-of-range AP", "adapter band limitation", "OS permission", "intermittent beacon visibility"],
                "A later read-only authorized snapshot finds a higher-generation AP.",
                "Repeat manually from the same location and compare current driver and router documentation."))
        if highest and adapter_gen < highest:
            packets.append(_packet("adapter_capability_gap",
                f"Observed advertised generation {highest} exceeds reported driver generation {adapter_gen or 'unknown'}.",
                "IF the adapter does not report that standard, THEN it may not be able to negotiate the advertised mode.",
                "moderate_not_a_hardware_diagnosis", "Windows driver reported radio types",
                ["driver reports incomplete", "OS parser misread localized fields"],
                "Official adapter specification and an authorized negotiated link confirm support.",
                "Check the adapter maker's spec, driver version, and an authorized router's negotiated link mode."))
        if len(valid) >= 2:
            introduced = recent-previous
            disappeared = previous-recent
            if introduced or disappeared:
                packets.append(_packet("visibility_wiggle",
                    f"Between two eligible snapshots: {len(introduced)} newly visible, {len(disappeared)} no longer visible pseudonymous AP observations.",
                    "IF observed visibility changes, THEN AP visibility changed in this sample; it is not evidence a new technology or storage device was created.",
                    "moderate_for_observation_low_for_cause", "Paired read-only Windows network lists",
                    ["moving device", "radio scheduling", "range/multipath", "interference", "access point reboot", "sampling variance"],
                    "Repeated same-position snapshots do not reproduce the change.",
                    "Compare across separate user-started sessions at a fixed position; review router logs only for your devices."))
        if channel_counts:
            busiest, count = channel_counts.most_common(1)[0]
            packets.append(_packet("advertisement_channel_counts",
                f"The latest eligible report contained {count} listed AP entries on {busiest} (of {len(last_known['aps'])} reported AP entries).",
                "IF several APs advertise the same channel, THEN that channel has more visible advertisements in this report; actual airtime utilization is unknown.",
                "high_for_report_count_low_for_interference", "Windows per-AP channel metadata",
                ["one router exposes several BSSIDs", "channel width overlap not measured", "channel use is not captured"],
                "Authorized channel-utilization or throughput tests disagree with apparent contention.",
                "Use router-provided channel utilization and controlled latency tests; do not infer interference from a count alone."))
        link = last["link"]
        # Only predict values for the latest connected pseudonym, never stitch
        # different users' routers or unrelated networks into a fake trend.
        link_rows = [r for r in readings if link and r["link"] == link and isinstance(r["signal"], int) and 0 <= r["signal"] <= 100]
        values = [r["signal"] for r in link_rows]
        sessions = [r["session"] for r in link_rows]
        predictive = _predict(values, sessions, [r["time"] for r in link_rows])
        if len(values) >= 4:
            window = values[-min(10,len(values)):]
            spread = max(window)-min(window)
            packets.append(_packet("connected_signal_variation",
                f"The same pseudonymous connected SSID had a {spread}-percentage-point reported signal range over {len(window)} readings.",
                "IF the measured signal changed, THEN variation occurred; the cause and link quality consequences are not identified.",
                "high_for_signal_readings_low_for_cause", "Windows connected signal (%) reports",
                ["movement", "device antenna positioning", "interference", "roaming within the same SSID", "OS sampling noise"],
                "A controlled fixed-position repeat shows this spread does not recur.",
                "Keep device position fixed, record session and time, and separately measure authorized link latency and throughput."))
        packets.append(_packet("prediction_gate",
            f"Prediction status: {predictive['status']}.",
            "IF Wiggle forecasts lower later-sample error, THEN it may describe signal variation better than a trivial baseline; it does NOT amplify Wi-Fi.",
            "insufficient_for_technology_discovery", "Chronologically ordered, locally stored signal readings",
            ["chance", "nonstationarity", "selection bias", "timing differences"],
            "A later independent run does not replicate improvement or the simple baseline wins.",
            "Collect at least 24 readings in multiple labeled sessions, then run independent experiments on a network you control."))
        return {"version": 28, "status": "observations_and_testable_hypotheses",
                "scope": "Passive Windows Wi-Fi reports, not spectral scanning, access discovery or identification of new physics",
                "sample_summary": {"total_snapshots": len(readings), "eligible_ap_snapshots": len(valid),
                    "excluded_ap_snapshots": len(readings)-len(valid),
                    "latest_snapshot_ap_count": len(last["aps"]),
                    "highest_observed_advertised_generation": highest or None,
                    "latest_adapter_reported_generation": adapter_gen or None,
                    "session_labels": len(set(r["session"] for r in readings)),
                    "local_pseudonymous_aps": len(occurrence)},
                "signal_model": predictive,
                "most_observed_access_points": indicators,
                "latest_reported_channel_counts": dict(sorted(channel_counts.items())),
                "change_summary": {"newly_visible_local_ids": sorted(recent-previous)[:20] if len(valid)>1 else [],
                                  "no_longer_visible_local_ids": sorted(previous-recent)[:20] if len(valid)>1 else [],
                                  "change_is_not_discovery": True},
                "thought_packets": packets,
                "limitations": ["A local pseudonym is not proof of ownership or a unique physical device.",
                                "Wilson bounds describe snapshot detection frequency only; correlated snapshots violate independence assumptions.",
                                "Windows channel counts do not reveal airtime congestion, hidden networks, or spectrum occupancy.",
                                "No packet capture, unauthorized connection, password extraction, network probing or real-world radio test occurred.",
                                "Fresh Windows results and hardware capabilities must be verified on your own PC."],
                "privacy": "Exports omit SSIDs, BSSIDs, raw device addresses, passwords and precise location."}
