"""BIE THRIVES v33 additive, offline Wiggle/Bloom packing experiment.

This deliberately treats a Bloom as a *labeled circular data node* and Wiggle
as a 2D monotone-x embedding, not as a physical frequency, CPU booster, or a
cryptographic shortcut. No application state, live connections, or original
source files are written.  Python 3.10+, standard library only.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
import hashlib
import math
from pathlib import Path
import random
import statistics
import struct
import time
import zlib

WIDTH = 960.0
STEP = 0.5
MAGIC = b"BIELINE1"


@dataclass(frozen=True)
class Geometry:
    radius: float = 8.0
    amplitude: float = 24.0
    cycles: float = 7.0
    phase: float = 0.0
    width: float = WIDTH
    center_focus: bool = True

    def valid(self):
        fields = [self.radius, self.amplitude, self.cycles, self.phase, self.width]
        if any(not math.isfinite(a) for a in fields):
            raise ValueError("Nonfinite geometry")
        if not (0 < self.radius <= 64 and 0 <= self.amplitude <= 128 and
                0 <= self.cycles <= 32 and 0 < self.width <= 2000):
            raise ValueError("Geometry exceeds tested safety bounds")


def y_at(x: float, c: Geometry) -> float:
    """An *experimental* center-focused sine Wiggle, not the prior HFW04 curve."""
    scale = (0.55 + 0.45 * math.exp(-((x - c.width / 2) / (0.27 * c.width)) ** 2)) if c.center_focus else 1.0
    return c.amplitude * scale * math.sin(2 * math.pi * c.cycles * x / c.width + c.phase)


def safe_pack(c: Geometry, resolution: float = STEP):
    """First-fit discretized packing; guarantees pairwise clearance, NOT optimality.

    Checking all earlier disks guards against the Wiggle folding back near
    itself. ``resolution`` is a sampling resolution, not a physical constant.
    """
    c.valid()
    if resolution <= 0 or resolution > c.radius / 2:
        raise ValueError("Resolution out of bounds")
    count = math.ceil(c.width / resolution)
    if count > 20_000:
        raise ValueError("Too many sample locations")
    coords = []
    req2 = (2*c.radius - 1e-9)**2
    for i in range(count+1):
        x = min(c.width, i*resolution)
        y = y_at(x, c)
        if all((x-a)**2+(y-b)**2 >= req2 for a,b in coords):
            coords.append((x,y))
    return coords


def arc_pack_naive(c: Geometry, resolution: float = STEP):
    """Chord-unsafe control: adjacent points separated by circle diameter in ARC length."""
    c.valid()
    count = math.ceil(c.width/resolution)
    last = (0., y_at(0., c))
    found = [last]
    arclen = 0.
    for i in range(1,count+1):
        x = min(c.width,i*resolution)
        cur = (x,y_at(x,c))
        arclen += math.dist(last,cur)
        if arclen >= 2*c.radius:
            found.append(cur)
            arclen = 0.
        last = cur
    return found


def straight_pack(c: Geometry):
    c.valid()
    return [(min(c.width,i*2*c.radius),0.) for i in range(math.floor(c.width/(2*c.radius))+1)]


def check_integrity(points, c: Geometry):
    c.valid()
    if not points or not all(math.isfinite(v) for p in points for v in p):
        return {"valid":False,"reason":"empty_or_nonfinite","pair_checks":0}
    if abs(points[0][0]) > 1e-8 or any(not (-1e-8 <= x <= c.width+1e-8) for x,_ in points):
        return {"valid":False,"reason":"invalid_x","pair_checks":0}
    if any(points[i][0] >= points[i+1][0] for i in range(len(points)-1)):
        return {"valid":False,"reason":"nonmonotone","pair_checks":0}
    bad = 0
    closest = math.inf
    checks = 0
    req = 2*c.radius
    for i,(x,y) in enumerate(points):
        for a,b in points[:i]:
            checks += 1
            d = math.hypot(x-a,y-b)
            closest = min(closest,d)
            if d < req - 1e-7:
                bad += 1
    return {"valid":bad == 0,"overlaps":bad,"min_clearance_px":None if math.isinf(closest) else round(closest-req,6),"pair_checks":checks,
            "node_id_preservation":True,"chain_order_preserved":True}


def packetize(source: bytes, chunk_size: int = 128):
    if not isinstance(source, bytes) or not source or len(source)>1_000_000:
        raise ValueError("Source must be 1..1,000,000 bytes")
    if not 1 <= chunk_size <= 8192:
        raise ValueError("Invalid chunk_size")
    return [(i,source[start:start+chunk_size]) for i,start in enumerate(range(0,len(source),chunk_size))]


def code_order(packets, strategy: str, seed: int = 4471):
    if strategy == "linear":
        return list(packets)
    if strategy == "random":
        rng = random.Random(seed)
        result = list(packets)
        rng.shuffle(result)
        return result
    if strategy == "wiggle":
        n = len(packets)
        if n==1:
            return list(packets)
        # Sorting by the 2D Wiggle's vertical bands is a toy cache/layout
        # hypothesis. It deliberately breaks source locality and requires IDs.
        return sorted(packets, key=lambda p:(round(math.sin(2*math.pi*7*p[0]/(n-1)),3),p[0]))
    raise ValueError("Unknown code order")


def encode(source: bytes, strategy: str, chunk_size: int=128):
    packets = code_order(packetize(source,chunk_size),strategy)
    header = MAGIC+struct.pack('<III',len(packets),len(source),chunk_size)+hashlib.sha256(source).digest()
    uncompressed = header+b''.join(struct.pack('<II',i,len(part))+part for i,part in packets)
    return zlib.compress(uncompressed,9)


def decode(blob: bytes) -> bytes:
    # Guard zip-bomb-like expansion in this offline bounded experiment.
    z=zlib.decompressobj()
    raw=z.decompress(blob,1_200_100)
    if z.unconsumed_tail or not z.eof or z.unused_data or len(raw)>1_200_000:
        raise ValueError("Malformed/excessively large encoded data")
    if not raw.startswith(MAGIC) or len(raw)<len(MAGIC)+44:
        raise ValueError("Bad signature")
    off=len(MAGIC)
    count,total,chunk=struct.unpack_from('<III',raw,off);off+=12
    digest=raw[off:off+32];off+=32
    if total>1_000_000 or count<1 or count>total or not 1<=chunk<=8192 or count!=(total+chunk-1)//chunk:
        raise ValueError("Malformed packet counts")
    parts={}
    for _ in range(count):
        if off+8>len(raw):
            raise ValueError("Truncated index")
        i,n=struct.unpack_from('<II',raw,off);off+=8
        expected=chunk if i<count-1 else total-chunk*(count-1)
        if i>=count or i in parts or n!=expected or off+n>len(raw):
            raise ValueError("Repeated/missing/invalid packet")
        parts[i]=raw[off:off+n];off+=n
    if off!=len(raw):
        raise ValueError("Unexpected trailing data")
    result=b''.join(parts[i] for i in range(count))
    if len(result)!=total or hashlib.sha256(result).digest()!=digest:
        raise ValueError("SHA-256 mismatch")
    return result


def geometry_suite(seed: int=20261015, random_cases: int=120, quick: bool=False):
    scenarios=[]
    # Frozen design grid; varied density, frequency, phase, focus, and amplitude.
    for radius in (8.,12.,16.):
        for amplitude in (0.,8.,24.,48.):
            for cycles in (1.,3.,7.,13.):
                for center_focus in (True,False):
                    scenarios.append(Geometry(radius,amplitude,cycles,0.,WIDTH,center_focus))
    if quick:
        scenarios = scenarios[::16]
        random_cases = 10
    # Out-of-design, pre-defined confirmation generator.
    rng=random.Random(seed)
    holdout=[Geometry(radius=rng.uniform(6,24),amplitude=rng.uniform(0,72),
                     cycles=rng.uniform(.2,17),phase=rng.uniform(0,2*math.pi),
                     center_focus=bool(rng.getrandbits(1))) for _ in range(random_cases)]
    result={}
    for group,cases in (("design",scenarios),("fresh_seeded",holdout)):
        rows=[]
        for c in cases:
            t0=time.perf_counter_ns();s=safe_pack(c);t1=time.perf_counter_ns()
            a=arc_pack_naive(c);straight=straight_pack(c)
            si=check_integrity(s,c);ai=check_integrity(a,c);bi=check_integrity(straight,c)
            if not si['valid'] or not bi['valid']:
                raise AssertionError(("SAFETY_FAILURE",asdict(c),si,bi))
            vertical_span = max(y for _,y in s)-min(y for _,y in s)
            area_density_ratio = (len(s)/len(straight)) * (2*c.radius/(vertical_span+2*c.radius))
            rows.append({"geometry":asdict(c),"safe_count":len(s),"straight_count":len(straight),
                         "horizontal_min_spacing_px":round(min(s[i+1][0]-s[i][0] for i in range(len(s)-1)),5),
                         "vertical_span_px":round(vertical_span,5),"relative_2d_footprint_density":round(area_density_ratio,5),
                         "arc_count":len(a),"arc_overlaps":ai['overlaps'],
                         "safe_clearance":si['min_clearance_px'],
                         "safe_ms":round((t1-t0)/1e6,4),"gain_pct":round(100*(len(s)-len(straight))/len(straight),3)})
        result[group]={"cases":len(rows),"safe_integrity_passes":len(rows),
                       "arc_cases_with_overlaps":sum(x['arc_overlaps']>0 for x in rows),
                       "arc_total_overlap_pairs":sum(x['arc_overlaps'] for x in rows),
                       "safe_better":sum(x['safe_count']>x['straight_count'] for x in rows),
                       "safe_equal":sum(x['safe_count']==x['straight_count'] for x in rows),
                       "safe_worse":sum(x['safe_count']<x['straight_count'] for x in rows),
                       "median_gain_pct":round(statistics.median(x['gain_pct'] for x in rows),3),
                       "median_relative_2d_footprint_density":round(statistics.median(x['relative_2d_footprint_density'] for x in rows),4),
                       "cases_with_more_2d_density":sum(x['relative_2d_footprint_density']>1.00001 for x in rows),
                       "median_compute_ms":round(statistics.median(x['safe_ms'] for x in rows),4),
                       "max_compute_ms":round(max(x['safe_ms'] for x in rows),4),
                       "best_gain_example":max(rows,key=lambda x:x['gain_pct']),
                       "worst_gain_example":min(rows,key=lambda x:x['gain_pct']),
                       "rows":rows}
    return result


def code_suite(samples):
    ret={}
    for name,source in samples.items():
        sizes={};rates={}
        baseline=zlib.compress(source,9)
        for strategy in ('linear','wiggle','random'):
            enc=encode(source,strategy)
            if decode(enc)!=source: raise AssertionError('Broken code bytes')
            sizes[strategy]={'tagged_compressed_bytes':len(enc), 'vs_direct_zlib_pct':round(100*(len(enc)/len(baseline)-1),2)}
            # identical returned program for each layout, hash verified.
            times=[]
            for _ in range(7):
                t0=time.perf_counter_ns()
                for k in range(30):
                    _=decode(enc)
                times.append((time.perf_counter_ns()-t0)/30/1e6)
            rates[strategy]=round(statistics.median(times),5)
        ret[name]={'source_bytes':len(source),'sha256':hashlib.sha256(source).hexdigest(),
                   'direct_zlib_bytes':len(baseline), 'packed':sizes,'median_decode_ms':rates}
    return ret


def visual_compaction_suite():
    # A 2D waveform cannot retain its *rendered geometry* under non-identity
    # vertical squeezing; reversible metadata can retain the original geometry.
    c=Geometry(8.,48.,7.,.7)
    original=[(x,y_at(x,c)) for x in range(0,961,4)]
    out=[]
    for scale in (1.,.75,.5,.25,.1,0.):
        squeezed=[(x,y*scale) for x,y in original]
        err=max(abs(a[1]-b[1]) for a,b in zip(original,squeezed))
        restored=[(x,y/scale) for x,y in squeezed] if scale else None
        # Store original shape parameters instead: exact reproducible y(x).
        recipe=[(x,y_at(x,c)) for x,_ in squeezed]
        out.append({'visual_y_scale':scale,'max_pixel_displacement':round(err,5),
                    'reversible_with_recipe':recipe==original,
                    'without_metadata_restorable':bool(restored is not None and all(abs(v[1]-w[1])<1e-8 for v,w in zip(restored,original)))})
    return out


def run_study(paths,seed=20261015,quick=False):
    samples={Path(p).name:Path(p).read_bytes() for p in paths}
    geo=geometry_suite(seed=seed,quick=quick)
    codes=code_suite(samples)
    comp=visual_compaction_suite()
    return {"name":"BIE Bloom/Wiggle line packing study H114", "status":"offline bounded experimental / no promotion",
            "hypotheses":{"H1":"Wiggle safe packing can fit more intact Bloom disks in fixed x-length than straight packing on test curves",
                          "H2":"Moving executable source chunks along Wiggle will improve source compression/decode versus contiguous layout",
                          "H3":"Geometric squeezing without metadata can preserve the exact rendered shape"},
            "definitions":{"bloom":"one labeled disk, with intact original bytes and adjacency records held separately",
                           "intact":"zero disk intersections, monotonically ordered identifiers, SHA-256 exact source roundtrip",
                           "wiggle":"non-self-overturning x-monotone 2D sinusoid, optionally center-enveloped",
                           "safety":"no source logic mutated or executed by the packing algorithms",
                           "optimality":"first-fit sampled feasible layout, not a mathematical optimum"},
            "precommitted_acceptance":"Integrity must pass ALL cases; candidate default activation needs >5% verified end-to-end net gain with 0 defects on external realistic tasks (not measured here)",
            "geometry":geo,"payload_code":codes,"visual_squeeze":comp}
