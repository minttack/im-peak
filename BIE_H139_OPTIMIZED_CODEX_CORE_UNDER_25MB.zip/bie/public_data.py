"""Explicit public evidence lookup from named, trusted API endpoints.

Never upload local documents or memories. Results are references, not verified facts;
API calls require Internet, respect service rate limits and never run silently.
"""
from __future__ import annotations
import json
import html
import re
import os
import ssl
from urllib.parse import urlencode, urlsplit
from urllib.request import Request, build_opener, HTTPSHandler, HTTPRedirectHandler

MAX_RESPONSE = 1_200_000
ENDPOINTS = {"pubmed": "eutils.ncbi.nlm.nih.gov", "openalex": "api.openalex.org",
             "crossref": "api.crossref.org", "wikipedia": "en.wikipedia.org",
             "worldbank": "api.worldbank.org"}


class NoRedirects(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise ValueError("Public data endpoint redirected; not following unknown hosts")


def get_json(url, *, limit=MAX_RESPONSE):
    parsed = urlsplit(url)
    if (parsed.scheme != "https" or parsed.hostname not in set(ENDPOINTS.values()) or
            parsed.username or parsed.password or parsed.port not in (None, 443)):
        raise ValueError("Only approved HTTPS evidence API endpoints are allowed")
    opener = build_opener(HTTPSHandler(context=ssl.create_default_context()), NoRedirects())
    req = Request(url, headers={"User-Agent": "BIEExperience/26 (user-initiated research; local assistant)",
                                "Accept": "application/json"})
    with opener.open(req, timeout=8) as response:
        data = response.read(limit + 1)
    if len(data) > limit:
        raise ValueError("Remote result exceeds size limit")
    return json.loads(data.decode("utf-8"))


def search_public(provider, query, limit=5, *, fetch=get_json):
    if provider not in ENDPOINTS:
        raise ValueError("Supported services: pubmed, openalex, crossref, wikipedia, worldbank")
    if not isinstance(query, str) or not query.strip() or len(query) > 300:
        raise ValueError("Use a query of 1–300 characters")
    n = min(max(int(limit), 1), 10)
    if provider == "openalex":
        params = {"search": query, "per_page": n,
                  "select": "id,title,publication_year,doi,primary_location,type"}
        key = os.getenv("BIE_OPENALEX_API_KEY")
        if key:
            params["api_key"] = key
        payload = fetch("https://api.openalex.org/works?" + urlencode(params))
        results = []
        for x in payload.get("results", [])[:n]:
            doi = x.get("doi") or x.get("id") or ""
            results.append({"title": x.get("title") or "Untitled", "url": doi,
                            "year": x.get("publication_year"), "identifier": x.get("id"),
                            "description": x.get("type", ""), "provider": provider})
    elif provider == "crossref":
        payload = fetch("https://api.crossref.org/works?" + urlencode({"query.bibliographic": query, "rows": n}))
        results = []
        for x in (payload.get("message") or {}).get("items", [])[:n]:
            year_parts = ((x.get("published") or {}).get("date-parts") or [[]])[0]
            results.append({"title": (x.get("title") or ["Untitled"])[0],
                            "url": x.get("URL") or "", "year": year_parts[0] if year_parts else None,
                            "identifier": x.get("DOI"), "description": x.get("type", ""), "provider": provider})
    elif provider == "wikipedia":
        params = {"action": "query", "list": "search", "srsearch": query,
                  "srlimit": n, "format": "json", "formatversion": "2"}
        payload = fetch("https://en.wikipedia.org/w/api.php?" + urlencode(params))
        results = []
        for x in (payload.get("query") or {}).get("search", [])[:n]:
            ident = x.get("pageid")
            if type(ident) is not int or ident <= 0:
                continue
            description = html.unescape(re.sub(r"<[^>]*>", "", x.get("snippet") or ""))[:300]
            results.append({"title": x.get("title") or "Untitled",
                            "url": "https://en.wikipedia.org/?curid=" + str(ident),
                            "year": x.get("timestamp"), "identifier": ident,
                            "description": description, "provider": provider})
    elif provider == "worldbank":
        # Country/indicator query, e.g. US:SP.POP.TOTL or ALL:NY.GDP.MKTP.CD.
        match = re.fullmatch(r"([A-Za-z]{2,3}|ALL):([A-Za-z0-9.]{3,50})", query.strip(), re.IGNORECASE)
        if not match:
            raise ValueError("World Bank query format: COUNTRY:INDICATOR, e.g. US:SP.POP.TOTL")
        country, indicator = match.groups()
        country, indicator = country.upper(), indicator.upper()
        payload = fetch("https://api.worldbank.org/v2/country/" + country + "/indicator/" +
                        indicator + "?" + urlencode({"format": "json", "per_page": n, "page": 1}))
        rows = payload[1] if isinstance(payload, list) and len(payload) > 1 else []
        results = []
        for x in (rows or [])[:n]:
            results.append({"title": (x.get("indicator") or {}).get("value", indicator) + " – " +
                            (x.get("country") or {}).get("value", country),
                            "url": "https://api.worldbank.org/v2/country/" + country + "/indicator/" + indicator,
                            "year": x.get("date"), "identifier": x.get("countryiso3code"),
                            "description": "Value: " + str(x.get("value")), "provider": provider})
    else:
        base = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/"
        search = fetch(base + "esearch.fcgi?" + urlencode({"db": "pubmed", "term": query,
                                                            "retmode": "json", "retmax": n}))
        ids = (search.get("esearchresult") or {}).get("idlist", [])[:n]
        results = []
        if ids:
            details = fetch(base + "esummary.fcgi?" + urlencode({"db": "pubmed", "id": ",".join(ids),
                                                                "retmode": "json"})).get("result", {})
            for ident in ids:
                x = details.get(str(ident), {})
                results.append({"title": x.get("title", "Untitled"),
                                "url": "https://pubmed.ncbi.nlm.nih.gov/" + str(ident) + "/",
                                "year": x.get("pubdate"), "identifier": str(ident),
                                "description": x.get("source", ""), "provider": provider})
    return {"provider": provider, "query": query, "count": len(results), "records": results,
            "saved": False, "status": "live public API results, not independently verified"}


def save_results(hub, results):
    """Explicit opt-in index: only titles/metadata/links, no article paywall bypass."""
    if not isinstance(results, dict) or results.get("provider") not in ENDPOINTS:
        raise ValueError("Not a supported public result set")
    imported = []
    for r in results.get("records", [])[:10]:
        url = r.get("url", "")
        if not str(url).startswith("https://"):
            continue
        value = json.dumps({"title": r.get("title"), "year": r.get("year"),
                            "description": r.get("description"), "identifier": r.get("identifier")},
                           ensure_ascii=False)
        imported.append(hub.put(origin="api:" + results["provider"], title=r["title"],
                                uri=url, content=value, category="public-reference",
                                evidence="external-source-unverified"))
    return {"imported": len(imported), "documents": imported}
