"""H136 familiarity / market-attention / virtual-profit-feedback research.

Offline evidence laboratory only. No broker access, APIs, real orders, position
promotion, inference that a familiar stock is a better stock, or model self-training.
This does NOT authenticate supplied price/source data. All features timestamped.
"""
from __future__ import annotations

from collections import defaultdict
from datetime import datetime, timedelta, timezone
import hashlib
import json
import math
from pathlib import Path
import random

from .stock_universe_h131 import SEED_STOCKS
from .relevance_ladder_h135r import utc, ALLOWED_SOURCES

SCHEMA = 'bie.h136.money-familiarity.v1'
STOCKS = tuple(t for t, _, _ in SEED_STOCKS)
BENCHMARKS = ('SPY', 'QQQ')
FEATURES = ('trend', 'attention', 'investor_familiarity', 'regime')
POLICIES = ('trend', 'trend_attention', 'trend_familiarity', 'all_three', 'analogy')
FEATURE_MAX_DAYS = {'trend': 3, 'attention': 4, 'investor_familiarity': 30, 'regime': 7}
SECTORS = {ticker: sector for ticker, sector, _ in SEED_STOCKS}


def validate(payload):
    if not isinstance(payload, dict) or payload.get('schema') != SCHEMA:
        raise ValueError('H136 dataset schema mismatch')
    mode = payload.get('source_mode')
    if mode not in ('synthetic', 'historical_user_supplied'):
        raise ValueError('Explicit source_mode required')
    as_of = utc(payload.get('as_of_utc'))
    if as_of > datetime.now(timezone.utc) + timedelta(minutes=5):
        raise ValueError('Future knowledge cutoff')
    raw = payload.get('rows')
    if not isinstance(raw, list) or not 12 * 90 <= len(raw) <= 12 * 2000:
        raise ValueError('Requires 90..2000 daily snapshots for 10 stocks plus SPY and QQQ')
    data, seen = {}, set()
    for index, r in enumerate(raw):
        if not isinstance(r, dict) or r.get('ticker') not in STOCKS + BENCHMARKS:
            raise ValueError(f'Unexpected security row {index}')
        ticker = r['ticker']
        date = utc(r.get('decision_at_utc'))
        if date > as_of:
            raise ValueError('Future-dated decision')
        if (date, ticker) in seen:
            raise ValueError('Duplicate stock/date')
        seen.add((date, ticker))
        def number(name, minimum, maximum):
            v = r.get(name)
            if type(v) not in (int, float) or not math.isfinite(v) or not minimum <= v <= maximum:
                raise ValueError(f'Invalid {name} at record {index}')
            return float(v)
        close = number('close', 0.000001, 1e7)
        volume = number('dollar_volume', 0.01, 1e14)
        spread = number('spread_bps', 0, 2500)
        signals, clean = r.get('signals'), {}
        if not isinstance(signals, dict) or set(signals) - set(FEATURES):
            raise ValueError('Invalid signal fields')
        if ticker in STOCKS:
            for f in FEATURES:
                sig = signals.get(f)
                if sig is None:
                    continue
                if not isinstance(sig, dict):
                    raise ValueError('Bad feature record')
                v = sig.get('value')
                if type(v) not in (int, float) or not math.isfinite(v) or not -1 <= v <= 1:
                    raise ValueError('Feature outside normalized range')
                observed = utc(sig.get('observed_at_utc'))
                if observed > date:
                    raise ValueError('Future knowledge leakage')
                source = sig.get('source')
                ref = sig.get('reference')
                if source not in ALLOWED_SOURCES or not isinstance(ref, str) or not ref.strip() or len(ref) > 250:
                    raise ValueError('Missing feature provenance')
                if mode != 'synthetic' and source == 'synthetic_only':
                    raise ValueError('Synthetic data cannot be labeled historical')
                if date - observed <= timedelta(days=FEATURE_MAX_DAYS[f]):
                    clean[f] = float(v)
        data[(date, ticker)] = {'date': date, 'ticker': ticker, 'close': close, 'volume': volume,
                                 'spread': spread, 'x': clean}
    dates = sorted({d for d, _ in data})
    if not 90 <= len(dates) <= 2000:
        raise ValueError('Insufficient distinct dates')
    for d in dates:
        if any((d, s) not in data for s in STOCKS + BENCHMARKS):
            raise ValueError('Missing security on a date; alignment not independently supported')
    return mode, dates, data


def _label(data, day, next_day, ticker):
    a, b = data[(day, ticker)], data[(next_day, ticker)]
    gross = b['close'] / a['close'] - 1
    # A paper model, NOT actual broker execution. No market-impact claims.
    return gross


def _observations(data, dates, stop):
    """Outcomes available only if next snapshot was already observed, by `stop`."""
    results = []
    for i in range(stop):
        if i + 1 >= stop:
            break
        a, b = dates[i], dates[i + 1]
        for t in STOCKS:
            r = data[(a, t)]
            results.append((r, int(_label(data, a, b, t) > 0)))
    return results


def _predict(row, hist, policy):
    prior = (sum(y for _, y in hist) + 10) / (len(hist) + 20)
    if policy == 'prior':
        return prior
    if policy == 'analogy':
        # Familiarity with *past price/attention patterns*, not investors' identities.
        available = [f for f in ('trend', 'attention', 'regime') if f in row['x']]
        if not available:
            return prior
        nearby = []
        for past, label in hist:
            overlapping = [f for f in available if f in past['x']]
            if len(overlapping) < 2:
                continue
            distance = sum((row['x'][f] - past['x'][f]) ** 2 for f in overlapping) / len(overlapping)
            nearby.append((distance, label, past['date'], past['ticker']))
        if len(nearby) < 20:
            return prior
        nearest = sorted(nearby, key=lambda x: (x[0], x[2], x[3]))[:35]
        return (sum(label for _, label, _, _ in nearest) + 15 * prior) / (len(nearest) + 15)
    names = {'trend': ('trend',), 'trend_attention': ('trend', 'attention'),
             'trend_familiarity': ('trend', 'investor_familiarity'),
             'all_three': ('trend', 'attention', 'investor_familiarity')}[policy]
    ps = []
    for name in names:
        if name not in row['x']:
            continue
        group = [y for past, y in hist if name in past['x'] and
                 (past['x'][name] >= 0) == (row['x'][name] >= 0)]
        if len(group) < 15:
            continue
        ps.append((sum(group) + 12 * prior) / (len(group) + 12))
    return sum(ps) / len(ps) if ps else prior


def _cost_bps(dollars, row):
    # Conservative hypothetical spread+fees+square-root participation impact.
    # RISK: this is a toy impact model; a real broker fill can differ.
    participation = min(1.0, dollars / row['volume'])
    return row['spread'] + 8.0 + 120.0 * math.sqrt(participation)


def _paper(data, dates, start, initial, policy, *, dynamic=False, chase=False, drift_guard=False, cost_guard=False, signal_guard=False):
    cash, peak, holdings, total_cost, trades = float(initial), float(initial), [], 0., 0
    drawdown = 0.
    cumulative_exposure = 0.
    last_five = []
    previous_forecasts = {}
    resolved_diagnostic = []
    decisions = []
    # H137A optional, development-frozen return profile for high-cost paper filtering.
    # The default original H136 behavior is byte-for-byte-equivalent in results.
    profiles = {}
    if cost_guard:
        for t in STOCKS:
            plus, minus = [], []
            for j in range(start - 1):
                change = _label(data, dates[j], dates[j + 1], t)
                (plus if change > 0 else minus).append(change)
            profiles[t] = (sum(plus)/len(plus) if plus else .005,
                           sum(minus)/len(minus) if minus else -.005)
    for i in range(start, len(dates) - 1):
        day, nxt = dates[i], dates[i + 1]
        # date i is known and allows all labels through i-1, not label i.
        hist = _observations(data, dates, i + 1)
        # Realize ONLY previous day's pre-recorded forecast once its return is known.
        if previous_forecasts:
            diagnostics = []
            for t, (forecast, prior_forecast, previous_date) in previous_forecasts.items():
                y = int(_label(data, previous_date, day, t) > 0)
                diagnostics.append((prior_forecast-y)**2 - (forecast-y)**2)
            resolved_diagnostic.append(sum(diagnostics)/len(diagnostics))
        expected = []
        new_forecasts = {}
        for t in STOCKS:
            r = data[(day,t)]
            new_forecasts[t] = (_predict(r, hist, policy), _predict(r,hist,'prior'), day)
        previous_forecasts = new_forecasts
        for t in STOCKS:
            row = data[(day, t)]
            score = _predict(row, hist, policy)
            expected.append((score, t))
        expected.sort(key=lambda x: (-x[0], x[1]))
        if policy == 'prior':
            expected = [] # no predictive edge => abstain
        chosen, per_sector = [], defaultdict(int)
        for p, t in expected:
            if p <= 0.565 or per_sector[SECTORS[t]] >= 1:
                continue
            chosen.append((t, p))
            per_sector[SECTORS[t]] += 1
            if len(chosen) == 3:
                break
        factor = 1.
        if dynamic and (drawdown >= .04 or sum(last_five[-5:]) < -.0075):
            factor = .5
        if dynamic and drawdown >= .08:
            factor = 0.
        if drift_guard and len(resolved_diagnostic) >= 6 and sum(resolved_diagnostic[-6:]) / 6 < -.04:
            factor = 0.
        # Compare a deliberately reckless profit-chase negative control.
        if chase and last_five and sum(last_five[-5:]) > 0:
            factor = 3.0
        # H137A: decision-time *modeled* high-cost filter. Never changes
        # historical labels, prior-day forecasts or real broker positions.
        if cost_guard and chosen:
            safe = []
            for t, probability in chosen:
                estimate_cost = _cost_bps(cash * .10 * factor, data[(day,t)])/10000.
                up, down = profiles[t]
                expected_gross = probability * up + (1 - probability) * down
                if estimate_cost <= .005 or expected_gross > estimate_cost + .001:
                    safe.append((t,probability))
            chosen = safe
        if signal_guard and chosen:
            # H138A opt-in paper-only missing-evidence guard. A model selected
            # on complete historical factors must not silently accept a
            # one-factor forecast after its required inputs disappear.
            required = {
                'trend': ('trend',),
                'trend_attention': ('trend', 'attention'),
                'trend_familiarity': ('trend', 'investor_familiarity'),
                'all_three': ('trend', 'attention', 'investor_familiarity'),
                'analogy': ('trend', 'attention', 'regime'),
            }.get(policy, ())
            threshold = 2 if policy == 'analogy' else len(required)
            chosen = [(t, p) for t, p in chosen if
                      sum(f in data[(day,t)]['x'] for f in required) >= threshold]
        # Each stock gets 10% of current virtual capital; 30% normal cap.
        old = cash
        gross_return, cost_dollars, pnl_dollars = 0., 0., 0.
        if chosen:
            for t, p in chosen:
                dollar = old * .10 * factor
                row = data[(day, t)]
                fee = dollar * _cost_bps(dollar, row) / 10000.0
                change = _label(data, day, nxt, t)
                gross_return += dollar * change
                cost_dollars += fee
                pnl_dollars += dollar * change - fee
                trades += 1
        cash = max(0.0, old + pnl_dollars)
        peak = max(peak, cash)
        drawdown = max(drawdown, 1 - cash / peak)
        total_cost += cost_dollars
        cumulative_exposure += (len(chosen) * .1 * factor)
        last_five.append((cash - old) / old if old else 0.)
        decisions.append({'date': day.isoformat(), 'selected_tickers': [x[0] for x in chosen],
                          'virtual_before': round(old, 4), 'virtual_after': round(cash, 4),
                          'pnl_dollars': round(pnl_dollars, 4), 'trading_cost_dollars': round(cost_dollars, 4),
                          'exposure_fraction': round(len(chosen) * .1 * factor, 4),
                          'max_drawdown_to_date': round(drawdown, 6),
                          'drift_guard_active': bool(drift_guard and len(resolved_diagnostic) >= 6 and sum(resolved_diagnostic[-6:])/6 < -.04),
                          'pnl_affects': 'risk_exposure_only_not_next_return_label'})
    return {'net_pnl_dollars': round(cash - initial, 2),
            'net_return_pct': round(100 * (cash / initial - 1), 3),
            'max_drawdown_pct': round(drawdown * 100, 3),
            'transaction_costs_dollars': round(total_cost, 2),
            'paper_rebalance_trades': trades,
            'mean_paper_exposure_fraction': round(cumulative_exposure / max(1, len(decisions)), 4),
            'final_virtual_equity': round(cash, 2), 'audit': decisions,
            'no_real_orders': True}


def _benchmark(data, dates, start, initial, ticker):
    a = data[(dates[start], ticker)]
    gross = data[(dates[-1], ticker)]['close'] / a['close'] - 1
    cost = _cost_bps(initial, a)/10000.
    return {'return_pct': round(100 * (gross-cost), 3),
            'hypothetical_buy_hold_pnl_dollars': round(initial * (gross-cost), 2)}


def _validation(data, dates, end_train, end_val):
    train = _observations(data, dates, end_train)
    val = [(data[(dates[i], t)], int(_label(data, dates[i], dates[i+1], t) > 0))
           for i in range(end_train, end_val - 1) for t in STOCKS]
    scores = {}
    for pol in ('prior',) + POLICIES:
        loss = sum((_predict(r, train, pol) - y) ** 2 for r, y in val)/len(val)
        # Complexity penalty predeclared to reduce multiple comparison selection.
        penalty = {'prior': 0, 'trend': 0.0005, 'trend_attention': .0015,
                   'trend_familiarity': .0015, 'all_three': .0025,
                   'analogy': .0030}[pol]
        scores[pol] = {'validation_brier': round(loss, 6), 'selection_score': round(loss + penalty, 6)}
    best = min(POLICIES, key=lambda p: scores[p]['selection_score'])
    # Require meaningful development advantage; no-trade if nothing predictive.
    selected = best if scores['prior']['selection_score'] - scores[best]['selection_score'] >= .004 else 'prior'
    return selected, scores


def analyze(payload, *, virtual_budget=10000.0):
    if type(virtual_budget) not in (int, float) or not math.isfinite(virtual_budget) or not 1 <= virtual_budget <= 1e7:
        raise ValueError('Invalid shadow-only budget')
    mode, dates, data = validate(payload)
    start_train, start_hold = int(len(dates) * .50), int(len(dates) * .75)
    selected, scores = _validation(data, dates, start_train, start_hold)
    # Holdout selection is frozen. Rolling historical familiarity updates only
    # outcomes that have resolved, never future prices or later holdout decisions.
    paper = _paper(data, dates, start_hold, virtual_budget, selected, dynamic=True)
    static = _paper(data, dates, start_hold, virtual_budget, selected, dynamic=False)
    drift = _paper(data, dates, start_hold, virtual_budget, selected, dynamic=True, drift_guard=True)
    chaser = _paper(data, dates, start_hold, virtual_budget, selected, chase=True)
    trend = _paper(data, dates, start_hold, virtual_budget, 'trend')
    holdout_hist = _observations(data, dates, start_hold)
    holdout_score = []
    for i in range(start_hold, len(dates)-1):
        d, n = dates[i], dates[i+1]
        for t in STOCKS:
            r = data[(d,t)]
            y = int(_label(data, d, n, t)>0)
            holdout_score.append((_predict(r, holdout_hist, selected)-y)**2)
        # Evaluation logs use fixed training state; no holdout refit for model-selection.
    brier = round(sum(holdout_score)/len(holdout_score), 6)
    benchmarks = {t: _benchmark(data, dates, start_hold, virtual_budget, t) for t in BENCHMARKS}
    prior_brier = sum(
        (_predict(data[(dates[i], t)], holdout_hist, 'prior') - int(_label(data, dates[i], dates[i+1], t) > 0)) ** 2
        for i in range(start_hold, len(dates)-1) for t in STOCKS
    ) / len(holdout_score)
    # The dollar P&L is not a source for target-price prediction; controls for oversizing.
    return {'schema': 'bie.h136.money-familiarity.report.v1', 'source_mode': mode,
            'provenance_status': 'Provider/source labels unverified unless independently audited',
            'dataset_sha256': hashlib.sha256(json.dumps(payload, sort_keys=True).encode()).hexdigest(),
            'objective': 'Measure market familiarity and money-related feedback without retrospective leakage or automatic staking',
            'date_splits': {'train_to_date_exclusive': dates[start_train].isoformat(),
                            'validation_to_date_exclusive': dates[start_hold].isoformat(),
                            'holdout_start': dates[start_hold].isoformat(),
                            'holdout_end': dates[-1].isoformat(), 'holdout_rebalances': len(dates)-start_hold-1},
            'pre_holdout_policy_selection': {'selected': selected, 'validation': scores},
            'holdout_probability_diagnostic': {'frozen_model_brier': brier, 'prior_brier': round(prior_brier,6),
                                                'gain': round(prior_brier-brier,6)},
            'paper_portfolio': {key: {k:v for k,v in record.items() if k != 'audit'}
                                for key, record in [('pnl_feedback_guard',paper), ('drift_guard_precommitted',drift), ('same_rule_no_feedback',static),
                                                    ('profit_chase_negative_control',chaser), ('trend_control',trend)]},
            'benchmarks': benchmarks,
            'simulated_audit': paper['audit'],
            'relevance_assumptions': {
                'investor_familiarity': 'An explicitly observed public proxy; familiarity can mean bias, not predictive knowledge',
                'experience_analogy': 'Similarity to already resolved historical patterns; no future access',
                'money_feedback': 'Updates exposure/risk only, not the expected stock return or probability model',
                'market_impact': 'Square-root participation toy slippage penalty; not actual impact measurement',
                'unknown_information': 'Private beliefs, future news, actual order execution, and true investor understanding are unobserved'},
            'decision': 'RESEARCH_AND_SHADOW_ONLY_NO_BROKER_ORDERS',
            'next_test': {'question': 'Does investor attention or pattern familiarity add independently replicated after-cost benefit after accounting for familiarity bias and volatility-regime reversals?',
                          'hypothesis': 'Proven, timestamped behavior proxies outperform price-only controls in prospectively observed market periods',
                          'falsifier': 'No lift on unseen market data or higher realized costs/drawdowns; then revert or hold cash'},
            'no_live_broker_calls': True}


def synthetic(seed=13601, world='familiarity_signal', days=160):
    if world not in ('familiarity_signal','familiarity_trap','attention_only','null','thin_liquidity') or type(days) is not int or not 90 <= days <= 450:
        raise ValueError('Unsupported synthetic world')
    rng = random.Random(seed)
    first = datetime(2025, 1, 2, 21, tzinfo=timezone.utc)
    dates = [first + timedelta(days=i) for i in range(days)]
    prices = {t: (70. + 50 * rng.random()) for t in STOCKS + BENCHMARKS}
    rows = []
    previous_returns = {}
    for i, d in enumerate(dates):
        next_returns = {}
        market = rng.gauss(.0003, .007)
        for t in STOCKS + BENCHMARKS:
            if i > 0:
                prices[t] *= (1 + previous_returns[t])
            trend = rng.choice((-1., 1.))
            attention = rng.choice((-1., 1.))
            familiar = rng.choice((-1., 1.))
            regime = rng.choice((-1., 1.))
            if t in BENCHMARKS:
                next_return = market if t == 'SPY' else 1.25 * market + rng.gauss(0, .002)
            else:
                v = rng.gauss(0,.01)
                if world == 'familiarity_signal':
                    next_return = .008 * familiar + .001 * trend + .002 * attention + v
                elif world == 'familiarity_trap':
                    next_return = (.012 if i < .75 * days else -.014) * familiar + .002 * trend + v
                elif world == 'attention_only':
                    next_return = .01 * attention + .0005 * familiar + v
                elif world == 'thin_liquidity':
                    next_return = .012 * familiar + v
                else:
                    next_return = v
            next_returns[t] = next_return
            volume = 4000. if world == 'thin_liquidity' and t in STOCKS else 1e8
            spread = 60. if world == 'thin_liquidity' and t in STOCKS else 8.
            signals = {} if t in BENCHMARKS else {
                f: {'value':v,'observed_at_utc':d.isoformat(),'source':'synthetic_only','reference':f'{world}-seed{seed}'}
                for f,v in [('trend',trend),('attention',attention),('investor_familiarity',familiar),('regime',regime)]}
            rows.append({'decision_at_utc':d.isoformat(), 'ticker': t, 'close': round(prices[t], 7),
                         'dollar_volume':volume, 'spread_bps':spread, 'signals':signals})
        previous_returns = next_returns
    return {'schema':SCHEMA,'source_mode':'synthetic','as_of_utc':dates[-1].isoformat(),'rows':rows}


def save_new(path, result):
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open('x', encoding='utf-8') as f:
        json.dump(result, f, indent=2, sort_keys=True)
    return p
