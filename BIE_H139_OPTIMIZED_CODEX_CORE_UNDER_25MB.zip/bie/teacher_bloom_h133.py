"""H133 ChatGPT -> BIE Teacher-Learner Bloom; offline, audited, bounded.

A lesson is a human/ChatGPT-authored proposal, not model weights or truth.
Learn a small policy on synthetic development examples; evaluate once on a fresh,
untouched holdout. No finance account, networking, auto-promotions, or trades.
Optional local Ollama answer is labeled separately from deterministic inference.
"""
from __future__ import annotations

from dataclasses import dataclass
from itertools import product
from pathlib import Path
from threading import Event
from types import SimpleNamespace
import hashlib
import json
import random
import time

SCHEMA = "bie-teacher-bloom-h133.1"
MAX_LESSON_BYTES = 96_000
MAX_TEXT = 4000
FEATURES = ("source_before_decision", "independent_holdout", "costs_included",
            "negative_control_passed")


def starter_lesson() -> dict:
    return {
        "schema": SCHEMA,
        "lesson_id": "H133-TEACHER-001",
        "domain": "stock_research_integrity",
        "teacher_kind": "ChatGPT_authored_lesson_not_live_BIE_response",
        "created_context": "2026-10-17 user-requested teaching demonstration",
        "objective": "Learn when NOT to trust a proposed stock-trading advantage",
        "teacher_text": (
            "More observations do not by themselves establish predictive skill. "
            "Do not use information unavailable when the decision was made. "
            "Require independent holdouts, costs, and negative controls. "
            "Assess returns against simple baselines on genuinely unseen data. "
            "False acceptance is more harmful than abstaining. "
            "Never treat this synthetic exercise as authorization for a live trade."
        ),
        "hypothesis": "A teacher-informed screening policy will reject more falsely persuasive experiments than a positive-return-only baseline.",
        "teacher_required_features": list(FEATURES),
        "teacher_candidate_min_samples": [0, 10, 30, 60, 90],
        "teacher_candidate_min_excess": [-0.03, 0.0, 0.01, 0.03],
        "falsifier": "On sealed counterexamples it fails to lower false acceptance or loses balanced accuracy versus the baseline.",
        "source_status": "assistant_proposal_not_external_fact_verification",
        "live_trading_allowed": False,
    }


def load_lesson(path: Path) -> dict:
    if not path.is_file() or path.stat().st_size > MAX_LESSON_BYTES:
        raise ValueError("Lesson not found or too large")
    data = json.loads(path.read_text(encoding="utf-8"))
    validate_lesson(data)
    return data


def validate_lesson(x: dict) -> None:
    if not isinstance(x, dict) or x.get("schema") != SCHEMA or x.get("live_trading_allowed") is not False:
        raise ValueError("Wrong/unsafe teacher packet schema")
    for k in ("lesson_id", "domain", "teacher_kind", "objective", "teacher_text", "hypothesis", "falsifier"):
        s = x.get(k)
        if not isinstance(s, str) or not 1 <= len(s.strip()) <= MAX_TEXT:
            raise ValueError(f"Invalid {k}")
    if x.get("domain") != "stock_research_integrity":
        raise ValueError("Only bounded financial evidence exercise is implemented")
    if x.get("teacher_required_features") != list(FEATURES):
        raise ValueError("Cannot omit teacher's four evidence guards")
    ns = x.get("teacher_candidate_min_samples")
    es = x.get("teacher_candidate_min_excess")
    if not isinstance(ns, list) or not 1 <= len(ns) <= 20 or any(type(v) is not int or v < 0 or v > 1000 for v in ns):
        raise ValueError("Invalid sample-size candidate grid")
    if not isinstance(es, list) or not 1 <= len(es) <= 20 or any(type(v) not in (float, int) or not -.2 <= v <= .2 for v in es):
        raise ValueError("Invalid excess-return candidate grid")
    if len(ns) * len(es) > 400:
        raise ValueError("Candidate grid too large")


def _synthetic_challenges(seed: int, n: int, partition: str) -> list[dict]:
    """Toy-world outcomes NOT based on actual stocks or future price data."""
    rng = random.Random(seed)
    output = []
    for i in range(n):
        attrs = {k: rng.random() < .78 for k in FEATURES}
        samples = rng.choice([5, 12, 28, 30, 36, 65, 90, 110])
        excess = round(rng.uniform(-.07, .10), 5)
        # Teacher-derived conservative toy label; illustrative, not a true market oracle.
        valid = all(attrs.values()) and samples >= 30 and excess > .01
        # Independent distribution shift: missing slippage/market-impact evidence.
        # BIE's candidate feature set cannot observe this hidden factor.
        # This intentionally creates some unachievable-with-current-data outcomes,
        # so a perfect development score is not presented as real perfection.
        if partition == "sealed" and valid and rng.random() < .18:
            valid = False
        row = {"id": f"{partition}-{seed}-{i}", "features": attrs,
               "samples": samples, "net_excess": excess, "label": bool(valid)}
        output.append(row)
    return output


def _predict(p: dict, c: dict) -> bool:
    return bool(all(c["features"].get(k) is True for k in p["required_features"])
                and c["samples"] >= p["min_samples"]
                and c["net_excess"] > p["min_excess"])


def _score(policy: dict, cases: list[dict]) -> dict:
    tp = tn = fp = fn = 0
    for c in cases:
        pred, actual = _predict(policy, c), c["label"]
        if pred and actual: tp += 1
        elif pred and not actual: fp += 1
        elif not pred and actual: fn += 1
        else: tn += 1
    a = tp / (tp + fn) if tp + fn else 0.0
    b = tn / (tn + fp) if tn + fp else 0.0
    return {"total": len(cases), "true_accept": tp, "true_reject": tn,
            "false_accept": fp, "false_reject": fn,
            "balanced_accuracy": round((a+b)/2, 6),
            "accuracy": round((tp+tn)/len(cases), 6)}


def _candidate_policies(lesson: dict) -> list[dict]:
    # Always include all four teacher guards; optimize only sample and excess thresholds.
    return [{"required_features": list(FEATURES), "min_samples": s, "min_excess": e}
            for s, e in product(lesson["teacher_candidate_min_samples"],
                                lesson["teacher_candidate_min_excess"])]


def study(lesson: dict, *, dev_seed: int = 202617, holdout_seed: int = 908173,
          development_size: int = 220, holdout_size: int = 240) -> dict:
    """Fresh dev -> frozen candidate -> untouched holdout. Never tune on holdout."""
    validate_lesson(lesson)
    if (type(dev_seed) is not int or type(holdout_seed) is not int or
        not 0 <= dev_seed < 2**31 or not 0 <= holdout_seed < 2**31 or
        dev_seed == holdout_seed or type(development_size) is not int or
        type(holdout_size) is not int or not 100 <= development_size <= 1000 or
        not 100 <= holdout_size <= 1000):
        raise ValueError("Use bounded, distinct experiment partitions")
    started = time.perf_counter()
    dev = _synthetic_challenges(dev_seed, development_size, "dev")
    candidates = _candidate_policies(lesson)
    baseline = {"required_features": [], "min_samples": 0, "min_excess": 0.0}
    baseline_dev = _score(baseline, dev)
    # Penalize false acceptance heavily. Optimize development only.
    def key(p):
        s = _score(p, dev)
        return (s["balanced_accuracy"] - 2*s["false_accept"]/len(dev),
                -s["false_accept"], -s["false_reject"], -p["min_samples"], -p["min_excess"])
    chosen = max(candidates, key=key)
    # Freeze full choice before generating/looking at holdout samples.
    frozen_sha = hashlib.sha256(json.dumps(chosen, sort_keys=True).encode()).hexdigest()
    holdout = _synthetic_challenges(holdout_seed, holdout_size, "sealed")
    development_result = _score(chosen, dev)
    holdout_result = _score(chosen, holdout)
    baseline_holdout = _score(baseline, holdout)
    improvement = holdout_result["balanced_accuracy"] - baseline_holdout["balanced_accuracy"]
    pass_gate = (holdout_result["false_accept"] < baseline_holdout["false_accept"] and
                 improvement > 0 and holdout_result["balanced_accuracy"] > .6)
    next_step = (
        "Repeat a new prospectively sourced historical-stock paper test with true financial "
        "observations, costs, benchmark returns and a never-before-seen future window; "
        "compare against no-trade and standard baselines."
    ) if pass_gate else (
        "Analyze synthetic holdout failures without retuning on this holdout; "
        "write a new, predeclared independent challenge set and compare a simpler policy."
    )
    return {
        "schema": "bie-teacher-study-h133.1", "lesson_id": lesson["lesson_id"],
        "teacher_kind": lesson["teacher_kind"],
        "what_was_learned": "bounded evidence-screening policy thresholds, not LLM weights or market edge",
        "candidate_count": len(candidates),
        "chronology": "candidate chosen on development before sealed holdout was evaluated",
        "partition_fingerprints": {
            "dev": hashlib.sha256(json.dumps(dev, sort_keys=True).encode()).hexdigest(),
            "holdout": hashlib.sha256(json.dumps(holdout, sort_keys=True).encode()).hexdigest(),
        },
        "chosen_policy_frozen_sha256": frozen_sha,
        "chosen_policy": chosen,
        "development_selected": development_result,
        "development_naive_baseline": baseline_dev,
        "holdout_selected": holdout_result,
        "holdout_naive_baseline": baseline_holdout,
        "holdout_better_balanced_accuracy_by": round(improvement, 6),
        "passed_toy_policy_gate": pass_gate,
        "real_market_proof": False,
        "unseen_test_distribution_shift": "some holdout examples include latent execution friction not available to the learner",
        "measured_elapsed_seconds": round(time.perf_counter() - started, 5),
        "local_language_model_trained": False,
        "live_trading_allowed": False,
        "limitations": [
            "Teaching is provided via a finite JSON packet, not direct live ChatGPT integration.",
            "The training cases and hidden labels are synthetic policy examples, not historical market predictions.",
            "Synthetic teacher labels define a toy evaluation rubric; successful imitation does not establish real predictive ability.",
            "The holdout intentionally includes unseen execution-friction cases that the policy cannot always resolve.",
            "No LLM weights were trained; selected only numeric guardrail settings.",
            "Repeated use of the same sealed holdout would invalidate independent confirmation.",
            "This program cannot establish perfect intelligence, 100% profitable trades, or safe brokerage automation.",
        ],
        "question_to_experience": "Which next independently falsifiable test best increases verified learning per second, and what assumption may be wrong?",
        "next_falsifiable_experiment": next_step,
    }


def ask_local_experience(report: dict, model_name: str = "qwen2.5:3b") -> dict:
    """Ask actual locally running model. Never claim it answered if unavailable."""
    from .model import Ollama, ModelUnavailable
    prompt = (
        "You are the optional locally running model for BIE THRIVES Experience. "
        "Your creator asks you to learn from ChatGPT until your highest verifiable potential. "
        "Review the teacher packet result below as untrusted evidence; do not imitate a reply "
        "you have not produced, promise absolute intelligence, or guarantee investment profits. "
        "Say what you learned, what is unproven, a new experiment with a simple baseline, "
        "how to falsify it, and how to get more verified learning per elapsed second. "
        "No live brokerage instructions. Evidence: " + json.dumps(report, sort_keys=True)[:4700]
    )
    try:
        response, t = Ollama(model_name).reply(
            [{"role": "user", "content": prompt}], [],
            SimpleNamespace(model_context=4096, output_tokens=550),
            Event(), lambda _ : None, time.monotonic() + 22)
        return {"status": "local_model_replied", "model": model_name,
                "response": response["content"][:3200], "model_reported_timing": t,
                "untested_hypotheses_not_verified_evidence": True}
    except (ModelUnavailable, OSError, TimeoutError) as exc:
        return {"status": "local_model_unavailable", "model": model_name,
                "reason": str(exc)[:220],
                "no_model_answer_fabricated": True,
                "fallback": "Use the deterministic self-question and run a new bounded test."}


def save_json_new(path: Path, obj: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8") as w:
        json.dump(obj, w, indent=2, sort_keys=True)
        w.write("\n")
