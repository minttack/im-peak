"""BLOOM X-ray transit and motion evidence lab, not an X-ray imager.

Input: already calibrated/binned, time-referenced, background-measured counts.
A declared ephemeris is *fixed* before reviewing the light curve.  The code
checks visit-to-visit agreement and placebo phases, but its score is not a
calibrated scientific false-alarm probability.  No claim of a new planet.
"""
from __future__ import annotations

import csv
from dataclasses import dataclass
import hashlib
import io
import json
import math
from pathlib import Path
import random
from statistics import median

MAX_BYTES = 8_000_000
MAX_ROWS = 100_000
PERIOD_HD189733_B = 2.21857312  # published 2013 ephemeris, older reference
EPOCH_HD189733_B = 2453988.80261  # BJD, input must also be BJD for physical match
PUBLISHED_OPTICAL_DEPTH = 0.0241
PUBLISHED_XRAY_DEPTH_RANGE = (0.06, 0.08)
PUBLICATION = 'Poppenhaeger, Schmitt & Wolk 2013, ApJ 773, 62; doi:10.1088/0004-637X/773/1/62'


def _isfinite(value):
    return math.isfinite(float(value))


def _safe_json(x):
    return json.loads(json.dumps(x, allow_nan=False))


@dataclass(frozen=True)
class Bin:
    time_days: float
    source_counts: float
    background_counts: float
    exposure_s: float
    background_scale: float
    visit: str


def read_counts_csv(path):
    path = Path(path)
    if not path.is_file() or path.stat().st_size > MAX_BYTES:
        raise ValueError('Choose a local prepared light-curve CSV of 8 MB or less')
    data = path.read_bytes()
    bins = parse_counts_csv(data)
    return bins, {'origin': 'user-selected-local-csv', 'sha256': hashlib.sha256(data).hexdigest(),
                   'bytes': len(data), 'calibration': 'user supplied; not independently verified'}


def parse_counts_csv(data: bytes):
    if not isinstance(data, bytes) or len(data) > MAX_BYTES:
        raise ValueError('Invalid or oversized light-curve input')
    try:
        text = data.decode('utf-8-sig')
        reader = csv.DictReader(io.StringIO(text, newline=''))
    except UnicodeError as ex:
        raise ValueError('CSV must use UTF-8') from ex
    required = {'time_days', 'source_counts', 'background_counts', 'exposure_s', 'visit'}
    if not reader.fieldnames or not required.issubset(reader.fieldnames):
        raise ValueError('CSV columns required: time_days,source_counts,background_counts,exposure_s,visit; optional background_scale')
    if len(set(reader.fieldnames)) != len(reader.fieldnames):
        raise ValueError('Duplicate column names')
    output = []
    seen = set()
    for idx, row in enumerate(reader):
        if idx >= MAX_ROWS:
            raise ValueError('More than 100000 bins; pre-bin the measurements')
        try:
            vals = [float(row[k]) for k in ('time_days', 'source_counts', 'background_counts', 'exposure_s')]
            alpha = float(row.get('background_scale') or 1)
            visit = str(row['visit']).strip()
        except (TypeError, KeyError, ValueError) as ex:
            raise ValueError(f'Non-numeric or missing fields at row {idx + 2}') from ex
        if not all(map(math.isfinite, (*vals, alpha))):
            raise ValueError(f'Nonfinite values at row {idx + 2}')
        time, s, b, exposure = vals
        if time < 0 or s < 0 or b < 0 or exposure <= 0 or not (0 < alpha <= 10):
            raise ValueError(f'Invalid counts, time, exposure or scale at row {idx + 2}')
        if not visit or len(visit) > 64 or any(ord(c) < 32 for c in visit):
            raise ValueError('Visit identifiers must be 1–64 printable characters')
        key = (visit, time)
        if key in seen:
            raise ValueError('Duplicate time within the same visit')
        seen.add(key)
        output.append(Bin(time, s, b, exposure, alpha, visit))
    if len(output) < 24:
        raise ValueError('At least 24 binned observations are required')
    return sorted(output, key=lambda x: (x.time_days, x.visit))


def read_prepared_fits(path):
    """Optional FITS support for *prepared binned* tables, NOT raw Chandra events.

    The user must first reduce raw photon events with instrument-specific tools,
    apply source/background spatial regions, and provide exposure-corrected bins.
    """
    try:
        from astropy.io import fits
    except ImportError as ex:
        raise ValueError('Prepared FITS requires optional dependency: pip install astropy. CSV needs no extras.') from ex
    path = Path(path)
    if not path.is_file() or path.stat().st_size > 25_000_000:
        raise ValueError('Select a local prepared binned FITS file smaller than 25 MB')
    columns = ('time_days', 'source_counts', 'background_counts', 'exposure_s', 'visit', 'background_scale')
    with fits.open(path, memmap=False) as hdu:
        tab = next((x for x in hdu[1:] if hasattr(x, 'columns') and x.data is not None and
                    {'TIME_DAYS', 'SOURCE_COUNTS', 'BACKGROUND_COUNTS', 'EXPOSURE_S', 'VISIT'}.issubset({n.upper() for n in x.columns.names})), None)
        if tab is None:
            raise ValueError('No prepared FITS table found. Raw event FITS needs prior instrument-specific calibration/reduction.')
        mapping = {n.upper(): n for n in tab.columns.names}
        rows = []
        for rec in tab.data:
            rows.append({c: rec[mapping[c.upper()]] if c.upper() in mapping else 1 for c in columns})
    stream = io.StringIO(); out = csv.DictWriter(stream, fieldnames=columns); out.writeheader()
    for rec in rows:
        out.writerow({k:(v.decode('utf-8') if isinstance(v, bytes) else v) for k,v in rec.items()})
    bins = parse_counts_csv(stream.getvalue().encode())
    raw = path.read_bytes()
    return bins, {'origin': 'user-selected-prepared-fits', 'sha256': hashlib.sha256(raw).hexdigest(),
                   'bytes': len(raw), 'calibration': 'user supplied; not independently verified'}


def phase_at(t, period, epoch):
    return ((t - epoch) / period + 0.5) % 1.0 - 0.5


def _summary(bins, period, epoch, width):
    selected = {'in': [], 'out': []}
    for b in bins:
        ph = abs(phase_at(b.time_days, period, epoch))
        if ph <= width/2:
            selected['in'].append(b)
        elif 0.15 <= ph <= 0.45:
            selected['out'].append(b)
    if len(selected['in']) < 3 or len(selected['out']) < 4:
        return {'status': 'insufficient-phase-coverage', 'in_bins': len(selected['in']), 'out_bins': len(selected['out'])}
    estimates = {}
    for key, group in selected.items():
        exposure = sum(b.exposure_s for b in group)
        net = sum(b.source_counts - b.background_scale*b.background_counts for b in group)
        variance = sum(b.source_counts + b.background_scale**2*b.background_counts for b in group)
        estimates[key] = {'rate': net/exposure, 'variance': variance/exposure**2,
                          'bins': len(group), 'exposure_s': exposure, 'net_counts': net}
    a,b = estimates['in'],estimates['out']
    if a['rate'] <= 0 or b['rate'] <= 0:
        return {'status': 'insufficient-background-subtracted-counts', 'in_bins':len(selected['in']), 'out_bins':len(selected['out'])}
    depth = 1 - a['rate']/b['rate']
    sigma = math.sqrt(a['variance']/(b['rate']**2) + (a['rate']**2*b['variance'])/(b['rate']**4))
    return {'status':'evaluated', 'depth_fraction':round(depth,7), 'approx_1sigma_fraction':round(sigma,7),
            'heuristic_z': round(depth/sigma,4) if sigma else None,
            'in_bins':a['bins'], 'out_bins':b['bins'],
            'in_exposure_s':round(a['exposure_s'],3), 'out_exposure_s':round(b['exposure_s'],3),
            'net_in_counts':round(a['net_counts'],3),'net_out_counts':round(b['net_counts'],3)}


def analyze(bins, *, period_days, epoch_days, width_fraction=0.08, source=None, target='unlabeled target'):
    period, epoch, width = float(period_days), float(epoch_days), float(width_fraction)
    if not all(map(math.isfinite,(period,epoch,width))) or period<=0 or epoch<0 or not (0.005<=width<=0.14):
        raise ValueError('Require finite positive period, nonnegative epoch, 0.005–0.14 transit phase width')
    if len(bins)<24:
        raise ValueError('At least 24 bins required')
    visits = sorted(set(v.visit for v in bins))
    # Visit ordering is fixed before analysis. With one visit, no independent holdout exists.
    by_visit = {v:[b for b in bins if b.visit==v] for v in visits}
    folds=[]
    for v in visits:
        part = _summary(by_visit[v],period,epoch,width)
        folds.append({'visit':v,**part})
    pooled = _summary(bins,period,epoch,width)
    controls = [
        {'phase_offset_cycles': shift, **_summary(bins,period,epoch+shift*period,width)}
        for shift in (0.25,0.5)
    ]
    assessed=[x for x in folds if x['status']=='evaluated']
    support = (len(visits)>=2 and len(assessed)>=2 and pooled['status']=='evaluated' and
               pooled['depth_fraction']>0 and pooled.get('heuristic_z',0)>=5 and
               all(x['depth_fraction']>0 and x.get('heuristic_z',0)>=2 for x in assessed))
    strong_control = any(c['status']=='evaluated' and c['depth_fraction'] >= pooled['depth_fraction']*.75 for c in controls) if pooled['status']=='evaluated' and pooled['depth_fraction'] > 0 else False
    verdict = ('repeatable-dip-for-independent-review' if support and not strong_control else 'not-verified')
    if len(assessed)<2:
        verdict='insufficient-independent-visits'
    if strong_control:
        verdict='phase-placebo-also-dips'
    return _safe_json({
        'target':str(target)[:120], 'verdict':verdict, 'source':source or {'origin':'unverified in-memory samples'},
        'input':{'bins':len(bins),'visits':len(visits),'period_days':period,'epoch_days':epoch,'width_fraction':width,
                 'time_reference':'Must match ephemeris time frame; e.g. BJD_TDB vs spacecraft mission elapsed time'},
        'pooled':pooled, 'independent_visits':folds, 'placebo_phases':controls,
        'interpretation': 'A repeatable phase-associated X-ray deficit is a candidate for expert follow-up, NOT proof of an exoplanet, atmosphere, new object, or new physics.',
        'limits': ['Approximate Poisson errors assume independent bins and correctly scaled source/background extraction.',
                   'Instrument GTIs, barycentric corrections, energy-dependent response, pileup, flares and stellar coronal structure are NOT calibrated here.',
                   'A pooled heuristic z>=5 and >=2 in two independent visits are screening thresholds, NOT scientific significance levels.',
                   'Heuristic z scores are NOT calibrated discovery significances; trials factors, red noise, systematic errors and model selection remain.',
                   'A prespecified ephemeris, independent observatories, withheld visits and instrument-specific reduction are needed.']
    })


def analyze_file(path, period_days, epoch_days, *, width_fraction=.08, target='unlabeled target'):
    p=Path(path)
    if p.suffix.lower() in ('.fits','.fit','.fts'):
        bins,source=read_prepared_fits(p)
    elif p.suffix.lower()=='.csv':
        bins,source=read_counts_csv(p)
    else:
        raise ValueError('Only prepared CSV and FITS light curves are supported')
    return analyze(bins,period_days=period_days,epoch_days=epoch_days,width_fraction=width_fraction,source=source,target=target)


def published_reference():
    optical=PUBLISHED_OPTICAL_DEPTH
    return {'status':'published-aggregate-only', 'target':'HD 189733 b', 'paper':PUBLICATION,
            'reference_url':'https://arxiv.org/abs/1306.2311',
            'optical_transit_depth_fraction':optical,
            'xray_transit_depth_fraction_range':list(PUBLISHED_XRAY_DEPTH_RANGE),
            'effective_radius_ratio_range':[round(math.sqrt(v/optical),4) for v in PUBLISHED_XRAY_DEPTH_RANGE],
            'ephemeris':{'period_days':PERIOD_HD189733_B,'reference_epoch_bjd':EPOCH_HD189733_B},
            'provenance':'Published results are literature aggregates; no original photon/event counts were analyzed.',
            'qualification':'Radius ratio sqrt(depth ratio) assumes simple stellar disk geometry; X-ray emitting corona is structured and this is not a calibrated atmospheric radius.'}


def synthetic_demo(seed=2177, depth=0.09):
    """Reproducible positive and negative controls; NEVER astrophysical data."""
    rng=random.Random(seed)
    samples=[]; null=[]
    period=2.21857312
    for visit in range(6):
        for j in range(70):
            # Each visit spans 0.72 phase around the known mid-transit.
            t=100+visit*period+(j-35)/70*period*0.72
            p=abs(phase_at(t,period,100))
            expected=1250*(1-depth if p <= .08/2 else 1)
            bkg=30
            # Deterministic pseudo-Poisson simulator without scientific inference.
            src=max(0,round(rng.gauss(expected+bkg,math.sqrt(expected+bkg))))
            bg=max(0,round(rng.gauss(bkg, math.sqrt(bkg))))
            null_src=max(0,round(rng.gauss(1250+bkg, math.sqrt(1250+bkg))))
            null_bg=max(0,round(rng.gauss(bkg, math.sqrt(bkg))))
            samples.append(Bin(t,src,bg,100,1,f'visit{visit+1}'))
            null.append(Bin(t,null_src,null_bg,100,1,f'visit{visit+1}'))
    pos=analyze(samples,period_days=period,epoch_days=100,source={'origin':'synthetic-injected-control','seed':seed,'depth':depth},target='SYNTHETIC injected dip')
    neg=analyze(null,period_days=period,epoch_days=100,source={'origin':'synthetic-no-signal-control','seed':seed},target='SYNTHETIC null control')
    return {'kind':'synthetic-software-validation-NOT-astronomical-observation','injected':pos,'null':neg}
