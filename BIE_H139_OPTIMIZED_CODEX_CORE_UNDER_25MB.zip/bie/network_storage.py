"""Voluntary, local-only, standards-based discovery of nearby advertised storage.

No port range scan, subnet sweep, access bypass or credentials. A discovery
result is only a hint; the user must choose/connect a share using their OS.
"""
from __future__ import annotations
import os
import re
import socket
import subprocess
import sys
import time
from urllib.parse import urlsplit

SSDP_GROUP = ("239.255.255.250", 1900)
MSEARCH = ("M-SEARCH * HTTP/1.1\r\nHOST: 239.255.255.250:1900\r\n"
           "MAN: \"ssdp:discover\"\r\nMX: 1\r\nST: ssdp:all\r\n\r\n").encode("ascii")


def _parse_advertisement(payload: bytes, host: str):
    text = payload.decode("iso-8859-1", errors="replace")[:5000]
    props = {}
    for row in text.splitlines()[1:]:
        if ":" in row:
            key, val = row.split(":", 1)
            props[key.strip().lower()] = val.strip()[:400]
    location = props.get("location", "")
    # Only local network advertisements are surfaced: never fetch a URL automatically.
    try:
        host_name = urlsplit(location).hostname if location else None
    except ValueError:
        host_name = None
    return {"type": "UPnP advertisement", "ip": host, "device_type": props.get("st", ""),
            "server": props.get("server", "")[:160], "description_url": location[:300],
            "id": props.get("usn", "")[:200], "advertised_host": host_name or "",
            "share_path": None, "connected": False}


def discover_ssdp(seconds=1.6, socket_factory=socket.socket):
    found = {}
    warning = None
    sock = None
    try:
        sock = socket_factory(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
        sock.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, 1)
        sock.settimeout(.25)
        sock.sendto(MSEARCH, SSDP_GROUP)
        expiry = time.monotonic() + min(max(float(seconds), .2), 3)
        while time.monotonic() < expiry and len(found) < 40:
            try:
                payload, endpoint = sock.recvfrom(8192)
            except socket.timeout:
                continue
            item = _parse_advertisement(payload, endpoint[0])
            key = item["id"] or item["ip"] + item["device_type"]
            found[key] = item
    except OSError as ex:
        warning = "Multicast discovery is unavailable: " + type(ex).__name__
    finally:
        if sock:
            sock.close()
    return list(found.values()), warning


def windows_network_servers():
    """Windows native network browser; no passwords supplied or stored."""
    if sys.platform != "win32":
        return [], None
    try:
        proc = subprocess.run(["net", "view"], timeout=5, capture_output=True, text=True,
                              errors="replace", shell=False)
    except (OSError, subprocess.TimeoutExpired) as ex:
        return [], "Windows net view unavailable: " + type(ex).__name__
    if proc.returncode:
        return [], "Windows network browser did not return a device list; check Network Discovery."
    hosts = sorted(set(re.findall(r"\\\\([A-Za-z0-9][A-Za-z0-9._-]{0,80})", proc.stdout)))
    return ([{"type": "Windows network computer", "name": h, "share_path": "\\\\" + h,
              "connected": False} for h in hosts[:60]], None)


def discover_storage(seconds=1.6):
    """Discover devices only on current LAN. This does not prove they host a share."""
    ssdp, a = discover_ssdp(seconds)
    windows, b = windows_network_servers()
    return {"devices": windows + ssdp, "warnings": [x for x in (a, b) if x],
            "checked": "local LAN advertisements and OS network browser only",
            "caution": "A device is not necessarily storage. Use File Explorer and authorized credentials to access a share; then register the mounted folder with BIE.",
            "no_subnet_scan": True, "no_credentials_collected": True}


def open_in_file_explorer(path):
    """Explicit user click only; asks OS to handle any authentication."""
    if sys.platform != "win32":
        raise OSError("Open share in File Explorer is supported on Windows only")
    if not isinstance(path, str) or not re.fullmatch(r"\\\\[\w.-]{1,100}(?:\\[\w $().-]{1,100})?", path):
        raise ValueError("Provide a Windows share or server in the form \\\\SERVER\\SHARE")
    os.startfile(path)
    return {"requested": path, "status": "opened in Windows File Explorer", "verified_access": False}
