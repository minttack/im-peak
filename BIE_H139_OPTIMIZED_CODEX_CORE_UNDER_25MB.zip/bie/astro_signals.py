"""Read-only light curve *screening* at a user-supplied period and epoch.

This is a deliberately conservative educational check, not a calibrated transit
search or planet detector. Independent photometry and a full systematic-noise
model are necessary before astrophysical interpretation.
"""
from __future__ import annotations

import csv
import math
from pathlib import Path
import statistics


def inspect_curve(path, period_days, epoch_days, width_fraction=0.08):
    period, epoch, width = float(period_days), float(epoch_days), float(width_fraction)
    if not (math.isfinite(period) and period > 0 and math.isfinite(epoch) and 0.001 <= width <= 0.15):
        raise ValueError("Invalid period, epoch or phase width")
    file = Path(path)
    if not file.is_file() or file.stat().st_size > 2_000_000:
        raise ValueError("Choose a local CSV smaller than 2 MB")
    points = []
    with file.open(encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f)
        if not reader.fieldnames or not {"time", "flux"}.issubset(reader.fieldnames):
            raise ValueError("CSV needs headers: time,flux")
        for r in reader:
            if len(points) >= 30_000:
                raise ValueError("Too many observations")
            try:
                t, flux = float(r["time"]), float(r["flux"])
            except (ValueError, TypeError):
                continue
            if math.isfinite(t) and math.isfinite(flux) and flux > 0:
                points.append((t, flux))
    if len(points) < 40:
        return {"verdict": "insufficient-data", "valid_points": len(points)}
    if len(set(t for t, _ in points)) < len(points):
        raise ValueError("Duplicate timestamps; check the observation series")
    points.sort()
    overall_median = statistics.median(v for _, v in points)
    # Only *specified* ephemerides are examined; no search for the most flattering
    # period and no model fitting based on the held-out points.
    groups = {0: {"in": [], "out": [], "cycles": set()}, 1: {"in": [], "out": [], "cycles": set()}}
    for t, flux in points:
        nearest_cycle = int(math.floor((t - epoch) / period + 0.5))
        residual_phase = abs(((t - epoch) / period) - nearest_cycle)
        bucket = groups[nearest_cycle % 2]
        if residual_phase <= width / 2:
            bucket["in"].append(flux / overall_median)
            bucket["cycles"].add(nearest_cycle)
        elif 0.15 <= residual_phase <= 0.45:
            bucket["out"].append(flux / overall_median)
    results = []
    for group_id in (0, 1):
        b = groups[group_id]
        in_flux, out_flux = b["in"], b["out"]
        if len(in_flux) < 5 or len(out_flux) < 15 or len(b["cycles"]) < 2:
            results.append({"holdout_group": group_id, "status": "insufficient-coverage", "transit_samples": len(in_flux), "baseline_samples": len(out_flux), "cycles": len(b["cycles"])})
            continue
        depth = statistics.median(out_flux) - statistics.median(in_flux)
        noise = statistics.stdev(out_flux) if len(out_flux) > 1 else 0.0
        # heuristic SNR, NOT calibrated false-alarm significance
        snr = depth / (max(noise, 1e-7) * math.sqrt(1/len(in_flux) + 1/len(out_flux)))
        results.append({"holdout_group": group_id, "status": "evaluated", "depth_fraction": round(depth, 6),
                        "heuristic_signal_to_noise": round(snr, 3), "transit_samples": len(in_flux),
                        "baseline_samples": len(out_flux), "cycles": len(b["cycles"])})
    verdict = ("repeatable-dip-for-follow-up" if all(v["status"] == "evaluated" and v["depth_fraction"] > 0
                           and v["heuristic_signal_to_noise"] >= 5.0 for v in results)
               else "not-verified")
    return {"verdict": verdict, "valid_points": len(points), "period_days": period, "epoch_days": epoch,
            "holdouts": results, "interpretation": "Educational fixed-ephemeris screen; these heuristic scores are not formal detection significances. Noise correlations, variability, instrument effects or binaries may produce dips. No new planet or life is confirmed.",
            "test": "Repeat with separate nights/instruments, inject negative controls, and obtain independent astronomical validation."}
