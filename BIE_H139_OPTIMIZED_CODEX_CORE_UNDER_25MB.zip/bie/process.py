"""Bounded execution for user-enabled project tests and native voice helpers."""
from __future__ import annotations

import os
from pathlib import Path
import signal
import subprocess
import sys
import threading
import time


def stop_process(proc):
    if proc.poll() is not None:
        return
    if os.name == "nt":
        subprocess.run(["taskkill", "/PID", str(proc.pid), "/T", "/F"],
                       capture_output=True, timeout=10, shell=False)
    else:
        try:
            os.killpg(proc.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
    proc.wait(timeout=10)


def run_tests(root: Path, cancel: threading.Event, timeout=45):
    if not (root / "tests").is_dir() or (root / "tests").is_symlink():
        raise ValueError("Create a tests directory with unittest tests first")
    # This runs project code with the current user's OS permissions. It is opt-in.
    cmd = [sys.executable, "-B", "-m", "unittest", "discover", "-s", "tests", "-v"]
    env = {k: v for k, v in os.environ.items() if k in {"PATH", "SystemRoot", "WINDIR", "TEMP", "TMP", "LANG", "LC_ALL"}}
    env["PYTHONIOENCODING"] = "utf-8"
    proc = subprocess.Popen(cmd, cwd=root, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                            shell=False, start_new_session=os.name != "nt")
    chunks = bytearray()
    overflow = threading.Event()
    def reader():
        while True:
            block = proc.stdout.read(4096)
            if not block:
                return
            if len(chunks) + len(block) > 65536:
                overflow.set()
            chunks.extend(block[:max(0, 65536 - len(chunks))])
    thread = threading.Thread(target=reader, daemon=True)
    thread.start()
    deadline = time.monotonic() + timeout
    reason = None
    while proc.poll() is None:
        if cancel.is_set() or overflow.is_set() or time.monotonic() >= deadline:
            reason = "cancelled" if cancel.is_set() else "output limit" if overflow.is_set() else "timeout"
            stop_process(proc)
            break
        cancel.wait(.05)
    thread.join(timeout=2)
    proc.stdout.close()
    output = chunks.decode("utf-8", "replace")
    # unittest exits zero even when it finds no tests; do not report that as verified behavior.
    import re
    matches = re.findall(r"Ran (\d+) tests? in", output)
    count = int(matches[-1]) if matches else 0
    return {"passed": proc.returncode == 0 and count > 0 and reason is None, "tests": count,
            "exit_code": proc.returncode, "stopped": reason, "output": output,
            "command": "python -B -m unittest discover -s tests -v"}


def speak(message):
    if os.name != "nt":
        raise RuntimeError("Built-in speech output is available on Windows; text works on every platform")
    script = "Add-Type -AssemblyName System.Speech; $s = New-Object System.Speech.Synthesis.SpeechSynthesizer; $s.Speak([Console]::In.ReadToEnd())"
    return subprocess.run(["powershell.exe", "-NoProfile", "-NonInteractive", "-Command", script],
                          input=message[:4000], text=True, capture_output=True, timeout=90, shell=False).returncode


def listen_once():
    if os.name != "nt":
        raise RuntimeError("Built-in microphone input is available on Windows")
    script = """Add-Type -AssemblyName System.Speech
    $r = New-Object System.Speech.Recognition.SpeechRecognitionEngine
    try {
      $r.LoadGrammar((New-Object System.Speech.Recognition.DictationGrammar))
      $r.SetInputToDefaultAudioDevice()
      $x = $r.Recognize([TimeSpan]::FromSeconds(10))
      if ($x) { [Console]::Write($x.Text) }
    } finally { $r.Dispose() }"""
    result = subprocess.run(["powershell.exe", "-NoProfile", "-NonInteractive", "-Command", script],
                            text=True, capture_output=True, timeout=20, shell=False)
    if result.returncode:
        raise RuntimeError("Windows speech recognition is unavailable. Check microphone access and speech language settings.")
    return result.stdout.strip()
