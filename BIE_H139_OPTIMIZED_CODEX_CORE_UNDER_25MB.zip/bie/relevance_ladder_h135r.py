"""H135-R: evidence relevance + guarded portfolio proof ladder. RESEARCH ONLY.

No brokerage SDK, network calls, order execution, automatic promotions, or LLM training.
All signal values and source claims are unverified user/agent input.
"""
from __future__ import annotations
from collections import defaultdict
from datetime import datetime, timedelta, timezone
import hashlib
import json
import math
import random
from pathlib import Path

from .stock_universe_h131 import SEED_STOCKS, BENCHMARKS

SCHEMA = "bie.h135r.relevance.v1"
SECTORS = {ticker: sector for ticker, sector, _ in SEED_STOCKS}
FEATURE_AGE = {"trend": 7, "momentum": 7, "volume": 7, "volatility": 7,
               "liquidity": 7, "fundamentals": 95, "macro": 40,
               "news": 4, "earnings": 95, "sentiment": 4,
               "options": 4, "order_flow": 1, "cross_asset": 7, "short_interest": 40,
               "sector_movement": 7, "economic_calendar": 30, "insider_filings": 95,
               "market_regime": 7, "corporate_actions": 95}
ALLOWED_SOURCES = {"robinhood_mcp", "sec_edgar", "manual_csv", "provider_csv", "synthetic_only"}


def utc(value):
    if not isinstance(value, str) or len(value) > 40:
        raise ValueError("UTC timestamp required")
    dt = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if dt.tzinfo is None or dt.utcoffset() != timedelta(0):
        raise ValueError("UTC timezone required")
    return dt.astimezone(timezone.utc)


def validate(payload):
    if not isinstance(payload, dict) or payload.get("schema") != SCHEMA:
        raise ValueError("Incompatible relevance dataset")
    mode = payload.get("source_mode")
    if mode not in ("synthetic", "historical_user_supplied"):
        raise ValueError("Explicit source_mode required")
    as_of = utc(payload.get("as_of_utc"))
    if as_of > datetime.now(timezone.utc) + timedelta(minutes=5):
        raise ValueError("Future as-of time")
    entries = payload.get("events")
    if not isinstance(entries, list) or not 80 <= len(entries) <= 100000:
        raise ValueError("Need 80..100000 labeled resolved observations")
    events, unique = [], set()
    for i, e in enumerate(entries):
        if not isinstance(e, dict) or e.get("ticker") not in SECTORS:
            raise ValueError(f"Bad stock event {i}")
        ticker = e["ticker"]
        decision = utc(e.get("decision_at_utc"))
        outcome_at = utc(e.get("outcome_at_utc"))
        if not decision < outcome_at <= as_of:
            raise ValueError("Future or unavailable outcome label")
        key = (decision, ticker)
        if key in unique:
            raise ValueError("Duplicate ticker/time observation")
        unique.add(key)
        if type(e.get("target_up_after_costs")) is not bool:
            raise ValueError("Target must be an observed true/false after-cost outcome")
        signals = e.get("signals")
        if not isinstance(signals, dict) or len(signals) > len(FEATURE_AGE):
            raise ValueError("Invalid signals")
        clean = {}
        for field, data in signals.items():
            if field not in FEATURE_AGE or not isinstance(data, dict):
                raise ValueError("Unexpected signal field")
            value = data.get("value")
            if type(value) not in (int, float) or not math.isfinite(value) or not -1 <= value <= 1:
                raise ValueError("Signals must be finite numbers in [-1,1]")
            observed = utc(data.get("observed_at_utc"))
            if observed > decision:
                raise ValueError("Signal uses future information")
            source, reference = data.get("source"), data.get("reference")
            if source not in ALLOWED_SOURCES or not isinstance(reference, str) or not reference.strip() or len(reference) > 250:
                raise ValueError("Signal must have known source and reference")
            if mode == "historical_user_supplied" and source == "synthetic_only":
                raise ValueError("Synthetic signal cannot be labeled historical")
            if decision - observed <= timedelta(days=FEATURE_AGE[field]):
                clean[field] = float(value)
        events.append({"ticker": ticker, "decision": decision, "outcome": outcome_at,
                       "y": int(e["target_up_after_costs"]), "x": clean})
    events.sort(key=lambda e: (e["decision"], e["ticker"]))
    dates = sorted({e["decision"] for e in events})
    if len(dates) < 20:
        raise ValueError("At least 20 distinct event dates needed")
    n = len(dates)
    v_start, h_start = dates[n // 2], dates[(n * 3) // 4]
    train = [e for e in events if e["decision"] < v_start and e["outcome"] < v_start]
    val = [e for e in events if v_start <= e["decision"] < h_start and e["outcome"] < h_start]
    hold = [e for e in events if e["decision"] >= h_start]
    if min(len(train), len(val), len(hold)) < 15:
        raise ValueError("Need sufficient embargoed chronological splits")
    return mode, train, val, hold, {"validation_start": v_start.isoformat(), "holdout_start": h_start.isoformat(),
                                   "train_count": len(train), "validation_count": len(val), "holdout_count": len(hold),
                                   "embargo_discarded": len(events) - len(train) - len(val) - len(hold)}


def brier(rows, fn):
    return sum((fn(row) - row["y"]) ** 2 for row in rows) / len(rows)


def model_for_feature(train, name, prior):
    bins = [(0, 0), (0, 0)]
    for e in train:
        if name in e["x"]:
            index = int(e["x"][name] >= 0)
            hits, size = bins[index]
            bins[index] = hits + e["y"], size + 1
    if min(b[1] for b in bins) < 6:
        return None
    # Shrink towards unconditional prevalence; feature cannot overstate tiny bins.
    probs = [(yes + prior * 12) / (n + 12) for yes, n in bins]
    return lambda row: probs[int(row["x"][name] >= 0)] if name in row["x"] else prior


def analyze(payload, *, paper_budget=1000.0, paper_positions=5):
    if type(paper_budget) not in (int, float) or not math.isfinite(paper_budget) or not 0 < paper_budget <= 1e9:
        raise ValueError("Finite positive hypothetical paper budget required")
    if type(paper_positions) is not int or not 1 <= paper_positions <= 5:
        raise ValueError("1..5 research positions")
    mode, train, val, hold, split = validate(payload)
    prior = (sum(e["y"] for e in train) + 8) / (len(train) + 16)
    baseline = lambda row: prior
    base_val = brier(val, baseline)
    learned = {name: model_for_feature(train, name, prior) for name in FEATURE_AGE}
    learned = {key: model for key, model in learned.items() if model is not None}
    chosen = []
    current = baseline
    current_val = base_val
    # Greedy forward feature selection; validation only, sealed holdout never chooses a feature.
    dev_scores = {}
    for name, model in learned.items():
        dev_scores[name] = {"single_feature_brier": round(brier(val, model), 6),
                            "single_feature_gain_vs_base": round(base_val - brier(val, model), 6),
                            "validation_availability": round(sum(name in e["x"] for e in val) / len(val), 4)}
    while len(chosen) < 3:
        options = []
        for name, model in learned.items():
            if name in chosen:
                continue
            names = chosen + [name]
            candidate = lambda e, nn=names: sum(learned[k](e) for k in nn) / len(nn)
            score = brier(val, candidate)
            options.append((score, name))
        if not options:
            break
        score, best_name = min(options)
        if current_val - score < 0.001:
            break
        chosen.append(best_name)
        current_val = score
        current = lambda e, nn=tuple(chosen): sum(learned[k](e) for k in nn) / len(nn)
    hold_base = brier(hold, baseline)
    hold_relevance = brier(hold, current)
    # Data support and predicted relevance used ONLY in development/validation; never let holdout pick stocks.
    readiness = {}
    for ticker in SECTORS:
        sub = [e for e in val if e["ticker"] == ticker]
        covered = sum(bool(e["x"]) for e in sub) / max(1, len(sub))
        learned_covered = sum(any(key in e["x"] for key in chosen) for e in sub) / max(1, len(sub))
        # Includes predictive gain and quality; score NOT expected return or profitability.
        dev_gain = max(0, base_val - current_val)
        score = round(100 * (0.35 * covered + 0.4 * learned_covered + 0.25 * min(dev_gain / .05, 1)), 1)
        readiness[ticker] = {"research_relevance_score_0_100": score, "signal_coverage": round(covered, 3),
                             "selected_signal_coverage": round(learned_covered, 3), "sector": SECTORS[ticker],
                             "data_verified": False, "buy_recommendation": False}
    ranking = sorted(readiness, key=lambda t: (-readiness[t]["research_relevance_score_0_100"], t))
    selected, sectors = [], defaultdict(int)
    for ticker in ranking:
        sec = SECTORS[ticker]
        if sectors[sec] >= 2 or readiness[ticker]["selected_signal_coverage"] < .5:
            continue
        selected.append(ticker)
        sectors[sec] += 1
        if len(selected) == paper_positions:
            break
    # Paper experiments use diversified SHADOW allocations only. No price, orders or broker actions.
    per_stock = round(float(paper_budget) / max(1, len(selected)), 2) if selected else 0.0
    paper = [{"ticker": t, "hypothetical_dollars": per_stock, "sector": SECTORS[t]} for t in selected]
    if chosen and hold_relevance >= hold_base:
        finding = "Development feature gains did not survive unseen holdout; retain baseline/no-trade."
    elif chosen:
        finding = "Holdout prediction gain observed in this dataset; repeat independent tests before paper-trading claims."
    else:
        finding = "No feature beat the simple baseline in validation; no predictive relevance established."
    monitoring_state = ("HALT_RESEARCH_SIGNALS_REEVALUATE_NEW_DATA" if chosen and hold_relevance >= hold_base
                        else "NO_PREDICTIVE_SIGNAL" if not chosen
                        else "PROVISIONAL_HOLDOUT_GAIN_NOT_TRADING_AUTHORIZATION")
    payload_checksum = hashlib.sha256(json.dumps(payload, sort_keys=True).encode()).hexdigest()
    return {"schema": "bie.h135r.relevance.report.v1", "source_mode": mode,
            "source_authentication": "User/agent source claims have not been independently authenticated",
            "dataset_sha256": payload_checksum, "split": split, "test_misuse_warning": "Do not tune using this sealed holdout",
            "predictive_relevance_validation": {"baseline_brier": round(base_val, 6),
                "candidate_brier": round(current_val, 6), "selected_features": chosen, "feature_diagnostics": dev_scores},
            "sealed_holdout_evaluation": {"baseline_brier": round(hold_base, 6),
                "candidate_brier": round(hold_relevance, 6), "gain": round(hold_base - hold_relevance, 6),
                "holdout_records": len(hold)},
            "stock_research_scores_not_return_forecasts": readiness,
            "diversified_research_list": selected, "benchmarks": list(BENCHMARKS),
            "hypothetical_paper_portfolio": {"capital_assumption_only": float(paper_budget),
                                              "allocation": paper, "no_broker_orders": True},
            "capital_proof_ladder": [
               {"stage": "shadow_paper", "real_money": 0, "permission": "ready_for_offline_simulation"},
               {"stage": "small_experimental_real", "permission": "NOT_GRANTED_requires_real_forward_evidence_and_user_approval",
                "example_limit_per_stock_pct_of_separately_risked_trial_capital": 0.5,
                "example_total_exposure_cap_pct": 2.5},
               {"stage": "larger_purchase", "permission": "NOT_GRANTED_requires_independent_repeat_proof_risk_review_and_new_user_approval"}],
            "promotion_decision": "NO_LIVE_TRADING_AUTHORIZED", "drift_or_failure_response": monitoring_state,
            "next_test": {
               "question": "Which additional *as-of verified* factor improves net-after-cost Brier and paper-trade results on a truly new period?",
               "hypothesis": "Fresh independently timestamped liquidity, news and execution metrics add predictive information beyond selected factors",
               "falsifier": "Fails independent forward holdout or loses after slippage/costs; then do not promote",
               "current_finding": finding},
            "local_model_response": "not_queried", "no_automatic_brokerage_orders": True}


def synthetic(seed=13501, world="causal", days=96):
    if world not in ("causal", "shift", "null") or type(days) is not int or not 40 <= days <= 400:
        raise ValueError("Unsupported synthetic scenario")
    rng = random.Random(seed)
    start = datetime(2025, 1, 1, tzinfo=timezone.utc)
    dates = [start + timedelta(days=day) for day in range(days)]
    data = []
    for i, dt in enumerate(dates):
        for ticker in SECTORS:
            x = rng.choice([-1., 1.]); v = rng.choice([-1., 1.]); noise = rng.uniform(-1, 1)
            sign = x if world == "causal" or (world == "shift" and i < days * .75) else -x if world == "shift" else rng.choice([-1., 1.])
            odds = min(.95, max(.05, .50 + .26 * sign + .08 * v)) if world != "null" else .5
            target = rng.random() < odds
            signals = {name: {"value": value, "observed_at_utc": dt.isoformat(),
                              "source": "synthetic_only", "reference": f"synthetic_seed_{seed}"}
                       for name, value in (("trend", x), ("momentum", v), ("news", noise), ("liquidity", -noise))}
            data.append({"ticker": ticker, "decision_at_utc": dt.isoformat(),
                         "outcome_at_utc": (dt + timedelta(hours=12)).isoformat(),
                         "target_up_after_costs": target, "signals": signals})
    return {"schema": SCHEMA, "source_mode": "synthetic", "as_of_utc": (dates[-1] + timedelta(days=1)).isoformat(),
            "events": data}


def save_new(path: Path, report):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8") as f:
        json.dump(report, f, indent=2)
