from __future__ import annotations

import ast
import difflib
import hashlib
import os
from pathlib import Path
import tempfile
import threading


class Workspace:
    """Path confinement for built-in file tools, not an operating-system sandbox."""
    FORBIDDEN = {".git", ".ssh", ".aws", ".env", ".bie_backups", "__pycache__", "node_modules"}
    MAX_BYTES = 262144

    def __init__(self, root: Path, backup_dir: Path):
        self.root = Path(root).expanduser().resolve()
        self.root.mkdir(parents=True, exist_ok=True)
        self.backups = Path(backup_dir).resolve()
        self.backups.mkdir(parents=True, exist_ok=True)
        self.lock = threading.RLock()

    def path(self, relative, *, directory=False):
        if not isinstance(relative, str) or not relative or len(relative) > 500 or "\\" in relative or ":" in relative or "\x00" in relative:
            raise ValueError("Use a relative project path with forward slashes")
        p = Path(relative)
        if p.is_absolute() or ".." in p.parts or any(x in self.FORBIDDEN or x.startswith('.env.') for x in p.parts):
            raise ValueError("Path is outside permitted project files")
        candidate = self.root / p
        cursor = self.root
        for part in p.parts:
            cursor /= part
            if cursor.is_symlink() or (hasattr(cursor, "is_junction") and cursor.is_junction()):
                raise ValueError("Linked paths are not permitted")
        resolved = candidate.resolve()
        if not resolved.is_relative_to(self.root) or resolved.is_relative_to(self.backups):
            raise ValueError("Path escapes the selected project")
        if not directory and resolved == self.root:
            raise ValueError("A file path is required")
        return resolved

    def listing(self, path="."):
        directory = self.path(path, directory=True)
        if not directory.is_dir():
            raise ValueError("Directory does not exist")
        items = []
        for p in sorted(directory.iterdir(), key=lambda p: (p.is_file(), p.name.casefold())):
            if p.name in self.FORBIDDEN or p.name.startswith('.env.') or p.is_symlink():
                continue
            if len(items) >= 200:
                break
            items.append({"path": p.relative_to(self.root).as_posix(), "type": "directory" if p.is_dir() else "file",
                          "bytes": p.stat().st_size if p.is_file() else None})
        return {"files": items, "limit": 200}

    def read(self, path):
        p = self.path(path)
        if not p.is_file():
            raise FileNotFoundError("File does not exist")
        with p.open("rb") as f:
            body = f.read(self.MAX_BYTES + 1)
        if len(body) > self.MAX_BYTES or b"\x00" in body:
            raise ValueError("Select a UTF-8 text file of at most 256 KiB")
        return {"path": path, "content": body.decode("utf-8"), "sha256": hashlib.sha256(body).hexdigest()}

    def write(self, path, content, expected_sha256=""):
        if not isinstance(content, str) or len(content.encode("utf-8")) > self.MAX_BYTES:
            raise ValueError("One file write is limited to 256 KiB; split the implementation into modules")
        if not isinstance(expected_sha256, str):
            raise ValueError("Expected hash must be a string")
        body = content.encode("utf-8")
        hh = hashlib.sha256(body).hexdigest()
        with self.lock:
            p = self.path(path)
            before = p.read_bytes() if p.exists() else b""
            if len(before) > self.MAX_BYTES:
                raise ValueError("Existing file is too large for this editing tool")
            existing_hash = hashlib.sha256(before).hexdigest() if p.exists() else ""
            if p.exists() and existing_hash == hh:
                return {"path": path, "sha256": hh, "changed": False, "reason": "Content already matches"}
            if existing_hash != expected_sha256:
                raise ValueError("File changed or was not read first; read it again before editing")
            if p.exists():
                (self.backups / existing_hash).write_bytes(before)
            p.parent.mkdir(parents=True, exist_ok=True)
            self.path(path)
            fd, name = tempfile.mkstemp(prefix=".bie-write-", dir=p.parent)
            try:
                with os.fdopen(fd, "wb") as f:
                    f.write(body)
                    f.flush()
                    os.fsync(f.fileno())
                # Check again after preparing the new bytes.
                latest = hashlib.sha256(p.read_bytes()).hexdigest() if p.exists() else ""
                if latest != existing_hash:
                    raise ValueError("File changed during edit; no overwrite performed")
                os.replace(name, p)
            finally:
                if os.path.exists(name):
                    os.unlink(name)
            diff = "\n".join(difflib.unified_diff(before.decode("utf-8", "replace").splitlines(), content.splitlines(),
                                               fromfile=path + " (before)", tofile=path + " (after)", lineterm=""))
        return {"path": path, "sha256": hh, "previous_sha256": existing_hash, "changed": True,
                "bytes": len(body), "diff": diff[:12000], "diff_truncated": len(diff) > 12000}

    def check_python(self, path):
        item = self.read(path)
        try:
            ast.parse(item["content"], filename=path)
        except SyntaxError as ex:
            return {"passed": False, "path": path, "line": ex.lineno, "message": ex.msg,
                    "scope": "syntax only; code was not executed"}
        return {"passed": True, "path": path, "scope": "syntax only; runtime behavior still requires tests"}
