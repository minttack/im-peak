"""H134 Transfer Challenge: finite, auditable *synthetic* learner improvement.

Distinct target from H133's teacher-derived labels. The independent generator
simulates a decision-time observable slippage estimate and separate hidden actual
execution cost. The policy cannot know hidden costs. No live trading, network,
or real-market inferences. One selected policy frozen before sealed evaluation.
"""
from __future__ import annotations
import hashlib
import json
import math
import random
import time
from itertools import product
from .teacher_bloom_h133 import FEATURES, _predict as h133_predict

SCHEMA = 'bie-h134-transfer-v1'
UNIVERSE = ('MSFT', 'AAPL', 'NVDA', 'AMZN', 'GOOGL', 'META', 'JPM', 'XOM', 'WMT', 'JNJ')
DEV_REGIMES = ('calm', 'volatile', 'high_spread', 'source_delay')
HOLDOUT_REGIMES = DEV_REGIMES + ('shock',)
# Freeze before sealed trials: no post-hoc threshold searches using holdouts.
SAMPLE_THRESHOLDS = (30, 50, 80)
SOURCE_AGE_LIMITS = (240, 1440)
COST_MULTIPLIERS = (1.0, 1.5, 2.0)
MIN_BUFFER_BPS = (0, 15, 30, 45)
H133_COMPARATOR = {'required_features': list(FEATURES), 'min_samples': 30, 'min_excess': .01}
STRONG_FIXED_COMPARATOR = {'min_samples': 50, 'max_age_minutes': 1440,
                            'cost_multiplier': 1.5, 'buffer_bps': 30}


def generate(seed: int, n: int, regime: str) -> list[dict]:
    """Fresh simulated data. Label arises from *hidden* actual net cost + source freshness.

    Predictors only see estimates generated before decision. Outcomes contain
    adversarial drift and unobserved execution effects. Never infer profits.
    """
    if not isinstance(seed, int) or seed < 0 or not 100 <= n <= 10000 or regime not in HOLDOUT_REGIMES:
        raise ValueError('invalid synthetic challenge')
    rng = random.Random(f'{SCHEMA}:{seed}:{regime}')
    rows = []
    for i in range(n):
        ticker = UNIVERSE[i % len(UNIVERSE)]
        guards = {f: rng.random() < (.89 if regime != 'source_delay' else .75) for f in FEATURES}
        samples = rng.choice((12, 25, 36, 55, 85, 110, 180, 260))
        age = rng.choice((10, 55, 180, 700, 1200, 2500, 5000))
        # Bps means basis points, not a fractional 0-1 return.
        gross = rng.uniform(-50, 240)
        reported_cost = rng.uniform(2, 28)
        if regime == 'high_spread':
            observed_slippage = rng.uniform(15, 75)
        elif regime in ('volatile', 'shock'):
            observed_slippage = rng.uniform(8, 48)
        else:
            observed_slippage = rng.uniform(2, 20)
        hidden_error = rng.gauss(0, 7 if regime == 'calm' else 19)
        if regime == 'high_spread': hidden_error += rng.uniform(2, 18)
        if regime == 'shock' and rng.random() < .27: hidden_error += rng.uniform(45, 140)
        true_slippage = max(0.0, observed_slippage + hidden_error)
        # Label is *not* a threshold on quoted/existing features: realization depends on
        # hidden execution and an ex-ante non-observable shock. All policies are limited.
        sudden_dislocation = (regime == 'shock' and rng.random() < .045)
        true_net = gross - reported_cost - true_slippage
        valid = (all(guards.values()) and samples >= 50 and age <= 1440 and
                 true_net >= 20 and not sudden_dislocation)
        rows.append({
            'id': f'{regime}:{seed}:{i}', 'ticker': ticker, 'regime': regime,
            'features': guards, 'samples': samples,
            'net_excess': round((gross-reported_cost)/10000, 8),
            'gross_bps': round(gross, 5), 'reported_cost_bps': round(reported_cost, 5),
            'slippage_estimate_bps': round(observed_slippage, 5),
            'source_age_minutes': age,
            'label': bool(valid),
        })
    return rows


def _valid_obs(c: dict) -> bool:
    try:
        if set(FEATURES) - set(c['features']): return False
        if any(c['features'][f] is not True for f in FEATURES): return False
        if type(c['samples']) is not int or type(c['source_age_minutes']) is not int: return False
        if c['samples'] < 0 or c['source_age_minutes'] < 0: return False
        for k in ('gross_bps', 'reported_cost_bps', 'slippage_estimate_bps'):
            if type(c[k]) not in (int, float) or not math.isfinite(c[k]): return False
        if c['reported_cost_bps'] < 0 or c['slippage_estimate_bps'] < 0: return False
        return True
    except (TypeError, KeyError, AttributeError, ValueError):
        return False


def predict(policy: dict, c: dict) -> bool:
    if not _valid_obs(c): return False
    return bool(c['samples'] >= policy['min_samples'] and
                0 <= c['source_age_minutes'] <= policy['max_age_minutes'] and
                c['gross_bps'] - c['reported_cost_bps'] -
                policy['cost_multiplier'] * c['slippage_estimate_bps'] >= policy['buffer_bps'])


def baseline_h133(c: dict) -> bool:
    try:
        return _valid_obs(c) and h133_predict(H133_COMPARATOR, c)
    except (TypeError, ValueError): return False


def metrics(rows: list[dict], fn) -> dict:
    if not rows: raise ValueError('empty case population')
    tp = tn = fp = fn_ = 0
    for c in rows:
        guess, truth = bool(fn(c)), c['label'] is True
        if guess and truth: tp += 1
        elif guess and not truth: fp += 1
        elif not guess and truth: fn_ += 1
        else: tn += 1
    precision = tp/(tp+fp) if tp+fp else 0.
    recall = tp/(tp+fn_) if tp+fn_ else 0.
    fpr = fp/(fp+tn) if fp+tn else 0.
    f05 = (1.25*precision*recall/(.25*precision+recall)) if precision+recall else 0.
    return {'total': len(rows), 'true_accept': tp, 'true_reject': tn,
            'false_accept': fp, 'false_reject': fn_,
            'accepts': tp+fp, 'prevalence': round((tp+fn_)/len(rows), 6),
            'precision': round(precision, 6), 'recall': round(recall, 6),
            'false_positive_rate': round(fpr, 6), 'f05': round(f05, 6),
            'accuracy': round((tp+tn)/len(rows), 6)}


def candidates() -> list[dict]:
    return [dict(zip(('min_samples', 'max_age_minutes', 'cost_multiplier', 'buffer_bps'), values))
            for values in product(SAMPLE_THRESHOLDS, SOURCE_AGE_LIMITS, COST_MULTIPLIERS, MIN_BUFFER_BPS)]


def fingerprint(obj) -> str:
    return hashlib.sha256(json.dumps(obj, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def run(dev_seed: int=71001, holdout_seed: int=81001, *,
        dev_each: int=500, holdout_each: int=500) -> dict:
    if (type(dev_seed) is not int or type(holdout_seed) is not int or
        not 0 <= dev_seed < 2**31 or not 0 <= holdout_seed < 2**31 or
        dev_seed == holdout_seed or type(dev_each) is not int or type(holdout_each) is not int or
        not 100 <= dev_each <= 2000 or not 100 <= holdout_each <= 2000):
        raise ValueError('bounded distinct dev/holdout required')
    start = time.perf_counter()
    dev = [row for i, regime in enumerate(DEV_REGIMES)
           for row in generate(dev_seed+i*137, dev_each, regime)]
    # Strict dev-only selection: the sealed list is not generated until frozen.
    candidates_list = candidates()
    scored_dev = [(metrics(dev, lambda c, p=p: predict(p, c)), p) for p in candidates_list]
    # Explicit recall floor avoids the false success of a policy that rejects every case.
    acceptable = [(s,p) for s,p in scored_dev if s['recall'] >= .20 and s['accepts'] >= 20]
    if not acceptable:
        chosen = dict(STRONG_FIXED_COMPARATOR)
        selection_status = 'no_development_policy_passed_fallback_to_fixed'
    else:
        s, chosen = max(acceptable, key=lambda item: (item[0]['f05'], -item[0]['false_accept'],
                                                          item[0]['recall'], -item[1]['buffer_bps']))
        selection_status = 'dev_selected_frozen'
    # Before any sealed evaluation, run an *independent development-confirmation*
    # partition. Nominal best-score tuning is not sufficient to displace a simple
    # cost-aware rule. Require a material gain with no worse false-positive rate.
    confirmation_seed = (dev_seed + 1_000_003) % (2**31)
    confirmation = [row for i, regime in enumerate(DEV_REGIMES)
                    for row in generate(confirmation_seed + i*149, dev_each, regime)]
    challenger_confirmation = metrics(confirmation, lambda c: predict(chosen, c))
    fixed_confirmation = metrics(confirmation, lambda c: predict(STRONG_FIXED_COMPARATOR, c))
    if selection_status == 'dev_selected_frozen':
        material_gain = (challenger_confirmation['f05'] - fixed_confirmation['f05'] >= .01 and
                         challenger_confirmation['false_positive_rate'] <= fixed_confirmation['false_positive_rate'] and
                         challenger_confirmation['recall'] >= .8*fixed_confirmation['recall'])
        if not material_gain:
            chosen = dict(STRONG_FIXED_COMPARATOR)
            selection_status = 'conservative_fallback_development_confirmation_did_not_support_change'
    frozen = fingerprint(chosen)
    dev_results = {
        'h133': metrics(dev, baseline_h133),
        'fixed_cost_aware': metrics(dev, lambda c: predict(STRONG_FIXED_COMPARATOR,c)),
        'h134': metrics(dev, lambda c: predict(chosen,c)),
    }
    holdout = [row for i, regime in enumerate(HOLDOUT_REGIMES)
               for row in generate(holdout_seed+i*173, holdout_each, regime)]
    methods = {'h133': baseline_h133,
               'fixed_cost_aware': lambda c: predict(STRONG_FIXED_COMPARATOR,c),
               'h134': lambda c: predict(chosen,c),
               'always_abstain': lambda c: False}
    holdout_results = {k:metrics(holdout,v) for k,v in methods.items()}
    regimes = {r:{k:metrics([c for c in holdout if c['regime']==r],v)
                   for k,v in methods.items()} for r in HOLDOUT_REGIMES}
    # More accuracy on teacher-derived examples does not count as generalization.
    base = holdout_results['fixed_cost_aware']; new = holdout_results['h134']
    confirmed = (new['f05'] > base['f05'] and new['recall'] >= .20 and
                 new['false_positive_rate'] <= base['false_positive_rate'])
    if confirmed:
        next_question = ('Can an independent real-market point-in-time data audit replicate the precision gain '
                         'after source-timestamp controls, execution-cost measurement, and a no-trade benchmark?')
    else:
        next_question = ('Which omitted market factor explains the transfer failures, and would measuring it '
                         'improve a preregistered test on a NEW holdout beyond this fixed cost-aware baseline?')
    return {
        'schema': SCHEMA, 'mode':'offline_synthetic_transfer_stress_only',
        'source': 'independent H134 simulated generator, NOT market bars',
        'hypothesis': 'Added decision-time slippage and data-age evidence reduce false acceptance under regime shift.',
        'dev_seed':dev_seed, 'development_confirmation_seed':confirmation_seed, 'holdout_seed':holdout_seed,
        'development_regimes':list(DEV_REGIMES), 'sealed_regimes':list(HOLDOUT_REGIMES),
        'dev_count':len(dev), 'development_confirmation_count':len(confirmation), 'holdout_count':len(holdout),
        'candidate_count':len(candidates_list), 'frozen_policy':chosen,
        'frozen_policy_sha256':frozen, 'selection_status':selection_status,
        'fingerprints':{'dev':fingerprint(dev), 'development_confirmation':fingerprint(confirmation), 'holdout':fingerprint(holdout)},
        'dev_confirmation_challenger':challenger_confirmation,
        'dev_confirmation_fixed':fixed_confirmation,
        'development':dev_results, 'sealed':holdout_results, 'by_regime':regimes,
        'strong_baseline_improved_strict_gate':confirmed,
        'next_question_to_experience':next_question,
        'interpretation':('The tests measure rule-transfer on constructed data only. The teacher model weights '
                          'have NOT been trained. This is NOT a stock price forecast, return, or real trading edge.'),
        'no_broker_calls':True, 'trades_executed':0, 'real_market_proof':False,
        'elapsed_seconds':round(time.perf_counter()-start,5),
    }
