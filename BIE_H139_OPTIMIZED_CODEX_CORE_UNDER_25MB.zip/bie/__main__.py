from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

from .agent import Assistant
from .config import PROFILES, state_root
from .migration import import_v1
from .native import verify_vendor
from .network_storage import discover_storage, open_in_file_explorer
from .public_data import search_public, save_results
from .wifi_lab import WifiLab
from .wifi_discovery import WifiDiscovery
from .wifi_novelty import WifiNovelty
from .exoplanets import ExoplanetLab
from .config import PACKAGE
from .astro_signals import inspect_curve
from .xray_mapping import analyze_file, synthetic_demo, published_reference
from .planet_reconstruction import reconstruct, load_evidence_file, export_reconstruction
from .adaptive_wiggle import DEFAULT_MAP as ADAPTIVE_WIGGLE_DEMO_MAP, plan as adaptive_wiggle_plan
from .growth import GrowthLedger, read_packet
from .evidence_retrieval_h116 import evidence_search
from .learning_accelerator import LearningAccelerator, PROFILES as LEARNING_PROFILES
from .bloom_line_lab import run_study as bloom_line_study
from .bloom_geometry_h114n1 import run_holdout as bloom_rect_holdout, compare_layouts as bloom_rect_compare
from .market_discovery_h129 import evaluate_universe, read_ohlcv, synthetic_universe, ask_local_experience
from .stock_universe_h131 import evaluate as stock_universe_h131, from_file as stock_h131_from_file, template as stock_h131_template, ask_local_experience_universe
from .universe_lab_h132 import battery as h132_battery, audit_csv as h132_audit_csv, analyze as h132_analyze, TICKERS as H132_TICKERS, ask_experience_h132
from .wand_h130 import prepare as prepare_wand_h130, run_codex as run_codex_h130, select_focus as select_focus_h130, default_focus_tasks as wand_focus_tasks
from .teacher_bloom_h133 import starter_lesson as h133_starter, load_lesson as h133_load, study as h133_study, ask_local_experience as h133_ask, save_json_new as h133_save
from .transfer_bloom_h134 import run as h134_transfer
from .relevance_ladder_h135r import analyze as h135r_analyze, synthetic as h135r_synthetic, save_new as h135r_save
from .familiarity_money_h136 import analyze as h136_analyze, synthetic as h136_synthetic, save_new as h136_save
from .accuracy_bloom_h137a import analyze as h137a_analyze, synthetic_study as h137a_study
from .flood_movement_h139 import analyze as h139_analyze, synthetic as h139_synthetic, run_file as h139_file, write_new as h139_write


def main(argv=None):
    parser = argparse.ArgumentParser(description="BIE THRIVES Experience v32 + experimental Adaptive BLOOM Wiggle")
    parser.add_argument("--home", type=Path, default=state_root(), help="Assistant state folder")
    sub = parser.add_subparsers(dest="command")
    sub.add_parser("gui", help="Open the native desktop window")
    for name in ("ask", "enqueue"):
        p = sub.add_parser(name)
        p.add_argument("goal")
        p.add_argument("--project", type=Path)
        p.add_argument("--model", default="qwen2.5:3b")
        p.add_argument("--profile", choices=PROFILES, default="Burst")
        p.add_argument("--read-only", action="store_true")
        p.add_argument("--allow-tests", action="store_true", help="Allow project Python execution with your OS permissions")
    p = sub.add_parser("work", help="Drain already submitted tasks until each completes, waits, or exhausts its budget")
    p.add_argument("--workers", type=int, default=2)
    for name in ("resume", "cancel", "show"):
        p = sub.add_parser(name)
        p.add_argument("task_id")
        if name == "resume":
            p.add_argument("--allow-tests", action="store_true")
    sub.add_parser("tasks")
    sub.add_parser("status")
    sub.add_parser("audit")
    sub.add_parser("verify-vendor")
    p = sub.add_parser("search")
    p.add_argument("query")
    p = sub.add_parser("recall")
    p.add_argument("query", nargs="?", default="")
    p.add_argument("--before", type=int)
    p = sub.add_parser("remember")
    p.add_argument("text")
    p.add_argument("--subject", default="note")
    p.add_argument("--source", default="user")
    p.add_argument("--scope", default="personal")
    p.add_argument("--supersedes")
    p = sub.add_parser("import-v1")
    p.add_argument("database", type=Path)
    p = sub.add_parser("native-goal")
    p.add_argument("query")
    sub.add_parser("knowledge-status", help="Show indexed data sources without accessing the Internet")
    p = sub.add_parser("knowledge-search", help="Search explicitly imported data")
    p.add_argument("query")
    p = sub.add_parser("evidence-search", help="H116 opt-in evidence-weighted retrieval of existing local index; no fact verification")
    p.add_argument("query")
    p.add_argument("--limit", type=int, default=10)
    sub.add_parser("storage-discover", help="Find nearby advertised Wi-Fi/LAN devices; no passwords or port scanning")
    sub.add_parser("storage-list", help="Show registered storage locations")
    p = sub.add_parser("storage-add", help="Register a user-accessible local/NAS/mapped folder")
    p.add_argument("alias")
    p.add_argument("path")
    p = sub.add_parser("storage-remove", help="Forget a registered location; preserves imported research")
    p.add_argument("alias")
    p = sub.add_parser("storage-browse", help="List files at a registered location")
    p.add_argument("alias")
    p.add_argument("--dir", default=".")
    p = sub.add_parser("storage-import", help="Read explicitly selected top-level text data into local search")
    p.add_argument("alias")
    p.add_argument("--dir", default=".")
    p.add_argument("--max-files", type=int, default=50)
    p = sub.add_parser("open-share", help="Open an authorized Windows share in File Explorer for OS sign-in")
    p.add_argument("path")
    p = sub.add_parser("public-search", help="Query public research APIs; no local data is uploaded")
    p.add_argument("provider", choices=("pubmed", "openalex", "crossref", "wikipedia", "worldbank"))
    p.add_argument("query")
    p.add_argument("--limit", type=int, default=5)
    p.add_argument("--save", action="store_true", help="Explicitly save reference metadata to local knowledge index")
    sub.add_parser("wifi-snapshot", help="Explicit read-only Windows Wi-Fi snapshot; records salted measurements locally")
    sub.add_parser("wifi-infer", help="Legacy v27 signal and standard reasoning")
    sub.add_parser("wifi-new-session", help="Mark a new manual experimental session; no automatic measurements")
    sub.add_parser("wifi-discovery", help="Advanced v28 evidence, competing explanations, Wi-Fi capability and prediction checks")
    sub.add_parser("wifi-investigate", help="Take one user-requested Windows snapshot, then review unclassified Wi-Fi metadata")
    sub.add_parser("wifi-novelty", help="Offline evidence-only review of unfamiliar Wi-Fi labels and inconsistencies")
    p = sub.add_parser("wifi-export", help="Write privacy-filtered advanced report JSON to chosen path")
    p.add_argument("output", type=Path)
    sub.add_parser("exo-status", help="Exoplanet observatory status and provenance")
    sub.add_parser("exo-reference", help="Load curated, clearly labeled offline NASA reference examples")
    sub.add_parser("exo-sync", help="Download the latest public NASA exoplanet catalog (network required)")
    p = sub.add_parser("exo-import", help="Import selected NASA-compatible CSV without networking")
    p.add_argument("csv_path", type=Path)
    p = sub.add_parser("exo-search", help="Search exoplanet names and host stars; report distances")
    p.add_argument("phrase", nargs="?", default="")
    p.add_argument("--limit", type=int, default=25)
    p.add_argument("--within-ly", type=float)
    p.add_argument("--screen-only", action="store_true")
    p = sub.add_parser("exo-target", help="Inspect a named planet and create a falsifiable ThoughtPacket")
    p.add_argument("name")
    p = sub.add_parser("exo-between", help="Compute separation between two host-star systems")
    p.add_argument("planet_a")
    p.add_argument("planet_b")
    p = sub.add_parser("exo-export", help="Export current public catalog findings to a new file")
    p.add_argument("output", type=Path)
    p = sub.add_parser("exo-lightcurve", help="Screen user-supplied time,flux CSV for a predefined repeating dip")
    p.add_argument("csv_path", type=Path)
    p.add_argument("--period-days", type=float, required=True)
    p.add_argument("--epoch-days", type=float, required=True)
    sub.add_parser("xray-demo", help="Run seeded synthetic X-ray transit and null control; no sky data")
    sub.add_parser("xray-reference", help="Recalculate published HD 189733 b depth/radius ratio; literature only")
    p = sub.add_parser("xray-analyze", help="Analyze user-reduced, background-corrected X-ray binned CSV or prepared FITS")
    p.add_argument("lightcurve", type=Path)
    p.add_argument("--period-days", type=float, required=True)
    p.add_argument("--epoch-days", type=float, required=True)
    p.add_argument("--width-fraction", type=float, default=.08)
    p.add_argument("--target", default="unlabeled target")
    p.add_argument("--report", type=Path, help="Optional new JSON report file; refuses overwrite")
    p = sub.add_parser("planet-reconstruct", help="Competing, hypothetical climate scenarios for a locally cataloged exoplanet")
    p.add_argument("name", help="Exact planet name in local catalog")
    p.add_argument("--draws", type=int, default=160)
    p.add_argument("--seed", type=int, default=2177)
    p.add_argument("--rotation", choices=("synchronous", "fast_rotating"), default="synchronous")
    p.add_argument("--insolation-relative-sigma", type=float, help="Assumed fractional 1-sigma; not a NASA measurement")
    p.add_argument("--evidence", type=Path, help="Optional user-supplied spectroscopy / stellar X-ray JSON")
    p.add_argument("--report", type=Path, help="New JSON output file; never overwrite")
    sub.add_parser("wiggle-demo", help="Offline obstacle-routing demonstration; no external actions")
    p = sub.add_parser("wiggle-plan", help="Plan a route through a user-supplied grid text file")
    p.add_argument("map_file", type=Path)
    p.add_argument("--initial-budget", type=int, default=8)
    p.add_argument("--max-expansions", type=int, default=4096)
    p = sub.add_parser("growth-predict", help="Freeze a prediction and baseline before measuring its outcome")
    p.add_argument("packet", type=Path)
    p = sub.add_parser("growth-resolve", help="Attach an outcome to an earlier frozen prediction")
    p.add_argument("prediction_id")
    p.add_argument("--outcome", required=True, type=int, choices=(0, 1))
    p.add_argument("--source", required=True)
    p.add_argument("--evidence", type=Path)
    p = sub.add_parser("growth-invalidate", help="Append correction/invalidation without erasing history")
    p.add_argument("prediction_id")
    p.add_argument("--reason", required=True)
    p = sub.add_parser("growth-review", help="Compare a strategy against its predeclared baseline on exact context")
    p.add_argument("domain")
    p.add_argument("context")
    p.add_argument("strategy")
    sub.add_parser("growth-status", help="Status of the separately stored growth ledger")
    sub.add_parser("growth-audit", help="Verify the local growth journal chain")
    sub.add_parser("growth-history", help="Read past project lessons, not prospective experimental evidence")
    p = sub.add_parser("learn-plan", help="Preview limits and workload without using the Internet")
    p.add_argument("manifest", type=Path)
    p.add_argument("--profile", choices=("Auto", *LEARNING_PROFILES), default="Auto")
    p.add_argument("--max-jobs", type=int)
    p.add_argument("--start-at", type=int, help="Override automatic progress cursor; 0 intentionally starts over")
    p = sub.add_parser("learn-run", help="Manually index public API references under bounded limits")
    p.add_argument("manifest", type=Path)
    p.add_argument("--profile", choices=("Auto", *LEARNING_PROFILES), default="Auto")
    p.add_argument("--max-jobs", type=int)
    p.add_argument("--start-at", type=int, help="Override automatic progress cursor; 0 intentionally starts over")
    p.add_argument("--confirm-network", action="store_true", help="Explicitly approve outgoing public search queries and saving references")
    sub.add_parser("learn-status", help="Show local learning-run counters and speed profiles")
    p = sub.add_parser("bloom-line-lab", help="Offline original H114 geometry and source-integrity study")
    p.add_argument("--quick", action="store_true")
    p.add_argument("--report", type=Path, help="Write a new report; never overwrite")
    p = sub.add_parser("bloom-rectangle", help="Offline viewport-clipped Wiggle vs straight/hex controls")
    p.add_argument("--width", type=int, default=480)
    p.add_argument("--height", type=int, default=128)
    p.add_argument("--radius", type=float, default=8.)
    p.add_argument("--amplitude", type=float, default=32.)
    p.add_argument("--cycles", type=float, default=5.)
    p = sub.add_parser("bloom-next-cycle", help="Run frozen independent H114-N1 geometry holdout")
    p.add_argument("--report", type=Path, help="Write new report; never overwrite")
    p = sub.add_parser("market-h129-demo", help="Offline synthetic stock discovery and after-each-test self-questions; NO trading")
    p.add_argument("--world", choices=("switching", "trend", "noise", "downtrend"), default="switching")
    p.add_argument("--seed", type=int, default=2177)
    p.add_argument("--report", type=Path)
    p.add_argument("--ask-local-model", action="store_true", help="Ask configured local Ollama for one next experiment")
    p.add_argument("--model", default="qwen2.5:3b")
    p = sub.add_parser("market-h129-evaluate", help="Offline validation/holdout on explicit OHLCV CSV; NO trading")
    p.add_argument("csv_path", type=Path)
    p.add_argument("--cost-bps", type=float, default=15.0)
    p.add_argument("--report", type=Path)
    p.add_argument("--ask-local-model", action="store_true")
    p.add_argument("--model", default="qwen2.5:3b")
    p = sub.add_parser("wand-h130", help="Prepare a Codex research Wand task; opt-in bounded Codex, no broker access")
    p.add_argument("--report", type=Path, help="Existing H129 JSON report; else create synthetic demo first")
    p.add_argument("--run-dir", type=Path, required=True, help="Must be a new/empty folder; preserves evidence")
    p.add_argument("--focus-seconds", type=int, default=60, help="Assumed focus-planning budget")
    p.add_argument("--invoke-codex", action="store_true", help="Optional Codex source edit/test attempt. Never invoke broker MCP")
    p.add_argument("--ask-experience", action="store_true", help="Try actually asking local BIE/Ollama for next test and compute-time idea")
    p.add_argument("--model", default="qwen2.5:3b")
    p.add_argument("--max-attempts", type=int, default=2)
    p.add_argument("--attempt-seconds", type=int, default=120)
    p = sub.add_parser("wand-h130-focus", help="Dry-run priority scheduling; conceptual, NOT time dilation")
    p.add_argument("--budget", type=int, default=60)
    p = sub.add_parser("stock-h131", help="Rank stock research candidates ONLY from timestamped local evidence; never trade")
    p.add_argument("--evidence", type=Path, help="Optional normalized JSON produced via read-only Codex/Robinhood/SEC research")
    p.add_argument("--top", type=int, default=5, help="Maximum data-qualified diversified research shortlist")
    p.add_argument("--ask-experience", action="store_true", help="Ask running local BIE/Ollama for a hypothesis, if available; does NOT change scores")
    p.add_argument("--model", default="qwen2.5:3b")
    p.add_argument("--report", type=Path, help="Create new, immutable JSON result")
    p = sub.add_parser("stock-h131-template", help="Export evidence schema for Codex data collection")
    p.add_argument("--output", type=Path, required=True)
    p = sub.add_parser("universe-h132-battery", help="Ten-stock multi-regime synthetic benchmark, NO live trading")
    p.add_argument("--report", type=Path, help="Create-only result JSON")
    p.add_argument("--size", type=int, default=300)
    p.add_argument("--ask-experience", action="store_true", help="Query installed local BIE model if running")
    p.add_argument("--model", default="qwen2.5:3b")
    p = sub.add_parser("universe-h132-csv", help="Predeclared ten-stock+SPY/QQQ backtest from local CSV, NO live trading")
    p.add_argument("csv_path", type=Path)
    p.add_argument("--as-of", type=str, required=True, help="Date knowledge cutoff YYYY-MM-DD")
    p.add_argument("--evidence", type=Path, help="Optional H131 research coverage JSON")
    p.add_argument("--report", type=Path, help="Create-only result JSON")
    p.add_argument("--cost-bps", type=float, default=15.0)
    p.add_argument("--ask-experience", action="store_true", help="Query installed local BIE model if running")
    p.add_argument("--model", default="qwen2.5:3b")
    p = sub.add_parser("teacher-h133-create", help="Export an authentic ChatGPT-authored teaching packet; no networking")
    p.add_argument("--output", type=Path, required=True)
    p = sub.add_parser("teacher-h133-study", help="Learn a bounded policy from a teacher packet and test on fresh synthetic holdout")
    p.add_argument("--lesson", type=Path, required=True)
    p.add_argument("--report", type=Path)
    p.add_argument("--dev-seed", type=int, default=202617)
    p.add_argument("--holdout-seed", type=int, default=908173)
    p.add_argument("--ask-experience", action="store_true", help="Ask a real running local BIE model if available")
    p.add_argument("--model", default="qwen2.5:3b")
    p = sub.add_parser("transfer-h134", help="Fresh synthetic teacher-transfer/adversarial cost challenge, no trading")
    p.add_argument("--dev-seed", type=int, default=71001)
    p.add_argument("--holdout-seed", type=int, default=81001)
    p.add_argument("--dev-each", type=int, default=500)
    p.add_argument("--holdout-each", type=int, default=500)
    p.add_argument("--report", type=Path, help="Create-only report; never silently overwrite")
    p.add_argument("--ask-experience", action="store_true", help="Optional actual local Ollama reply, not invented")
    p.add_argument("--model", default="qwen2.5:3b")
    p = sub.add_parser("relevance-h135r-demo", help="Synthetic feature-relevance, diversifying shadow paper ladder; no real trades")
    p.add_argument("--seed", type=int, default=13501)
    p.add_argument("--world", choices=("causal", "shift", "null"), default="causal")
    p.add_argument("--report", type=Path)
    p.add_argument("--ask-experience", action="store_true")
    p.add_argument("--model", default="qwen2.5:3b")
    p = sub.add_parser("relevance-h135r-file", help="Evaluate supplied point-in-time signal/outcome JSON; no broker access")
    p.add_argument("dataset", type=Path)
    p.add_argument("--report", type=Path)
    p.add_argument("--ask-experience", action="store_true")
    p.add_argument("--model", default="qwen2.5:3b")
    p = sub.add_parser('familiarity-h136-demo', help='Offline synthetic familiarity, PnL feedback and drift guard; never trades')
    p.add_argument('--world', choices=('familiarity_signal','familiarity_trap','attention_only','null','thin_liquidity'), default='familiarity_signal')
    p.add_argument('--seed',type=int,default=13601)
    p.add_argument('--days',type=int,default=160)
    p.add_argument('--ask-experience',action='store_true',help='Ask actually running local model; report unavailable honestly')
    p.add_argument('--model',default='qwen2.5:3b')
    p.add_argument('--report',type=Path)
    p = sub.add_parser('familiarity-h136-file', help='Evaluate point-in-time local snapshots from JSON, shadow only')
    p.add_argument('dataset',type=Path)
    p.add_argument('--ask-experience',action='store_true',help='Ask locally running BIE model if available')
    p.add_argument('--model',default='qwen2.5:3b')
    p.add_argument('--report',type=Path)
    p = sub.add_parser('accuracy-h137a-demo', help='Offline Accuracy-concept feedback versus baselines and sham; no real trade')
    p.add_argument('--world',choices=('familiarity_signal','familiarity_trap','attention_only','null','thin_liquidity'),default='familiarity_trap')
    p.add_argument('--seed',type=int,default=33701)
    p.add_argument('--days',type=int,default=104)
    p.add_argument('--report',type=Path)
    p = sub.add_parser('accuracy-h137a-file', help='Read-only H136 schema point-in-time data; no brokerage access')
    p.add_argument('dataset',type=Path)
    p.add_argument('--report',type=Path)
    p = sub.add_parser("flood-h139-demo",help="Offline Flood Movement market research DEMO; no brokerage access")
    p.add_argument("--world", choices=("flow","reversal","null","illiquid"), default="flow")
    p.add_argument("--seed", type=int, default=13901)
    p.add_argument("--days", type=int, default=260)
    p.add_argument("--report",type=Path)
    p.add_argument("--ask-experience",action="store_true",help="Ask genuine local BIE model if running; no fabricated reply")
    p.add_argument("--model",default="qwen2.5:3b")
    p = sub.add_parser("flood-h139-file",help="Evaluate point-in-time user-provided stock history JSON; NO order access")
    p.add_argument("dataset",type=Path)
    p.add_argument("--report",type=Path)
    p.add_argument("--ask-experience",action="store_true")
    p.add_argument("--model",default="qwen2.5:3b")
    args = parser.parse_args(argv)
    try:
        if args.command in ("flood-h139-demo","flood-h139-file"):
            result=h139_analyze(h139_synthetic(seed=args.seed,world=args.world,days=args.days)) if args.command=="flood-h139-demo" else h139_file(args.dataset)
            if args.ask_experience:
                result["local_model_response"]=h133_ask({"next_test":result["thought_packet"],
                  "holdout":result["holdout_evaluation"],"source_mode":result["source_mode"],
                  "instruction":"Propose one falsifiable next test, include a simpler control, refuse real-money orders"},args.model)
            if args.report:
                h139_write(args.report,result)
                print(json.dumps({"saved":str(args.report),"selected":result["research_stocks_selected"],
                    "frozen_model":result["selected_model_frozen_before_holdout"],
                    "virtual_return_pct":result["paper_portfolio"]["virtual_return_pct"],
                    "broker_orders":0},indent=2))
            else:print(json.dumps(result,indent=2))
            return 0
        if args.command in ('accuracy-h137a-demo','accuracy-h137a-file'):
            if args.command=='accuracy-h137a-demo':
                data = h136_synthetic(args.seed,args.world,args.days)
            else:
                if not args.dataset.is_file() or args.dataset.stat().st_size>50000000:
                    raise ValueError('Missing/oversize point-in-time market file')
                data=json.loads(args.dataset.read_text(encoding='utf-8'))
            result=h137a_analyze(data)
            if args.report:
                with args.report.open('x',encoding='utf-8') as fp:
                    json.dump(result,fp,indent=2)
                print(json.dumps({'report':str(args.report),'accuracy_cost':result['comparison']['accuracy_cost'],
                       'original_glyph_benefit':'NOT TESTED - authentic image unavailable'}))
            else:
                print(json.dumps(result,indent=2))
            return 0
        if args.command in ('familiarity-h136-demo', 'familiarity-h136-file'):
            if args.command == 'familiarity-h136-demo':
                data = h136_synthetic(args.seed,args.world,args.days)
            else:
                if not args.dataset.is_file() or args.dataset.stat().st_size>50000000:
                    raise ValueError('Missing/oversize local market data JSON')
                data = json.loads(args.dataset.read_text(encoding='utf-8'))
            result = h136_analyze(data)
            if args.ask_experience:
                result['local_model_response'] = h133_ask({
                   'H136_next_question':result['next_test'],
                   'holdout':result['holdout_probability_diagnostic'],
                   'paper':result['paper_portfolio'],
                   'source_mode':result['source_mode'],
                   'important_limit':'Familiarity can represent bias, not knowledge; cash is a permissible answer',
                   'request':'Propose a NEW falsifiable approach and a control with reproducible tests, without promising profit or using broker orders'
                },args.model)
            if args.report:
                h136_save(args.report,result)
                print(json.dumps({'report':str(args.report),'policy':result['pre_holdout_policy_selection']['selected'],
                                  'shadow':result['paper_portfolio']['drift_guard_precommitted'],
                                  'no_real_orders':True}))
            else:
                print(json.dumps(result,indent=2))
            return 0
        if args.command in ("relevance-h135r-demo", "relevance-h135r-file"):
            if args.command == "relevance-h135r-demo":
                dataset = h135r_synthetic(seed=args.seed, world=args.world)
            else:
                if not args.dataset.is_file() or args.dataset.stat().st_size > 50000000:
                    raise ValueError("Missing or oversized point-in-time input JSON")
                dataset = json.loads(args.dataset.read_text(encoding="utf-8"))
            result = h135r_analyze(dataset)
            if args.ask_experience:
                result["local_model_response"] = h133_ask(result, args.model)
            if args.report:
                h135r_save(args.report, result)
                print(json.dumps({"report": str(args.report), "mode": result["source_mode"],
                                  "promotion": result["promotion_decision"], "holdout": result["sealed_holdout_evaluation"]}))
            else:
                print(json.dumps(result, indent=2))
            return 0
        if args.command == "transfer-h134":
            result = h134_transfer(args.dev_seed, args.holdout_seed, dev_each=args.dev_each,
                                   holdout_each=args.holdout_each)
            if args.ask_experience:
                result["local_experience_status"] = h133_ask(result, args.model)
            if args.report:
                h133_save(args.report, result)
                print(json.dumps({"path":str(args.report), "status":result["selection_status"],
                                  "synthetic_only":True, "real_market_proof":False}))
            else:
                print(json.dumps(result, indent=2))
            return 0
        if args.command == "teacher-h133-create":
            h133_save(args.output, h133_starter())
            print(json.dumps({"status": "teacher_packet_created_not_learned", "path": str(args.output)}))
            return 0
        if args.command == "teacher-h133-study":
            lesson = h133_load(args.lesson)
            result = h133_study(lesson, dev_seed=args.dev_seed, holdout_seed=args.holdout_seed)
            if args.ask_experience:
                result["actual_local_model_reply"] = h133_ask(result, args.model)
            if args.report:
                h133_save(args.report, result)
                print(json.dumps({"status": "synthetic_teacher_policy_test_only", "path": str(args.report),
                                  "passed": result["passed_toy_policy_gate"], "real_market_proof": False}))
            else:
                print(json.dumps(result, indent=2))
            return 0
        if args.command in ("universe-h132-battery", "universe-h132-csv"):
            if args.command == "universe-h132-battery":
                result = h132_battery(size=args.size)
            else:
                from datetime import date as _date
                cutoff = _date.fromisoformat(args.as_of)
                result = h132_audit_csv(args.csv_path, as_of=cutoff,
                                        evidence_path=args.evidence, cost_bps=args.cost_bps)
            if args.ask_experience:
                result["local_experience_proposal"] = ask_experience_h132(result, args.model)
            if args.report:
                args.report.parent.mkdir(parents=True, exist_ok=True)
                with args.report.open("x", encoding="utf-8") as output:
                    json.dump(result, output, indent=2)
                print(json.dumps({"report_file": str(args.report), "mode": result.get("mode", "supplied_csv_research"),
                                  "status": result.get("promotion_status", "synthetic_diagnostics_only")}))
            else:
                print(json.dumps(result, indent=2))
            return 0
        if args.command == "stock-h131-template":
            args.output.parent.mkdir(parents=True, exist_ok=True)
            with args.output.open("x", encoding="utf-8") as file:
                json.dump(stock_h131_template(), file, indent=2)
            print(json.dumps({"status": "template_only_no_evidence", "output": str(args.output)}))
            return 0
        if args.command == "stock-h131":
            output = stock_h131_from_file(args.evidence, top=args.top) if args.evidence else stock_universe_h131(top=args.top)
            if args.ask_experience:
                output["local_model_suggestion"] = ask_local_experience_universe(output, args.model)
            if args.report:
                args.report.parent.mkdir(parents=True, exist_ok=True)
                with args.report.open("x", encoding="utf-8") as file:
                    json.dump(output, file, indent=2)
            print(json.dumps(output, indent=2))
            return 0
        if args.command == "wand-h130-focus":
            print(json.dumps(select_focus_h130(wand_focus_tasks(), args.budget), indent=2))
            return 0
        if args.command == "wand-h130":
            report = args.report
            if report is None:
                # Separate pure synthetic evidence, explicitly never real-market results.
                preview = evaluate_universe(synthetic_universe(2177, world="switching"),
                                            source="H130 synthetic dry run only")
                args.run_dir.mkdir(parents=True, exist_ok=True)
                report = args.run_dir.parent / (args.run_dir.name + "_h129_demo.json")
                with report.open("x", encoding="utf-8") as fp:
                    json.dump(preview, fp, indent=2)
            result = prepare_wand_h130(report, args.run_dir, focus_seconds=args.focus_seconds,
                                      ask_experience=args.ask_experience, local_model=args.model)
            if args.invoke_codex:
                code_result = run_codex_h130(Path(__file__).resolve().parent.parent,
                                              args.run_dir, attempts=args.max_attempts,
                                              seconds_per_attempt=args.attempt_seconds)
                result["codex_run"] = code_result
            print(json.dumps(result, indent=2))
            if args.invoke_codex and result["codex_run"]["status"] != "local_python_tests_passed":
                return 2  # no false success when Codex is missing or tests fail
            return 0
        if args.command in ("market-h129-demo", "market-h129-evaluate"):
            if args.command == "market-h129-demo":
                output = evaluate_universe(synthetic_universe(args.seed, world=args.world),
                                          source=f"synthetic {args.world} seed {args.seed}")
            else:
                output = evaluate_universe(read_ohlcv(args.csv_path),
                                          source=f"user-supplied {args.csv_path.name}", cost_bps=args.cost_bps)
            if args.ask_local_model:
                output["local_model_response"] = ask_local_experience(output, args.model)
            if args.report:
                args.report.parent.mkdir(parents=True, exist_ok=True)
                with args.report.open("x", encoding="utf-8") as stream:
                    json.dump(output,stream,indent=2)
                print(json.dumps({"report_file":str(args.report),"selection":output["selection"],
                                  "next_step":output["next_step"],"discovery_count":output["discovery_count"]},indent=2))
            else:
                print(json.dumps(output,indent=2))
            return 0
        if args.command in ("bloom-line-lab", "bloom-rectangle", "bloom-next-cycle"):
            if args.command == "bloom-line-lab":
                sources = (Path(__file__).with_name("adaptive_wiggle.py"), Path(__file__).with_name("growth.py"))
                result = bloom_line_study(sources, quick=args.quick)
            elif args.command == "bloom-rectangle":
                result = bloom_rect_compare(args.width, args.height, args.radius, args.amplitude, args.cycles)
                result = {k:v for k,v in result.items() if k != "coordinates"}
            else:
                result = bloom_rect_holdout()
            if getattr(args,"report", None) is not None:
                args.report.parent.mkdir(parents=True, exist_ok=True)
                with args.report.open("x", encoding="utf-8") as outf:
                    json.dump(result, outf, indent=2)
                print(json.dumps({"report_file": str(args.report), "status":result.get("status","completed")},indent=2))
            else:
                print(json.dumps(result,indent=2))
            return 0
        app = Assistant(args.home)
        if args.command in (None, "gui"):
            from .gui import Desktop
            Desktop(app).mainloop()
            return 0
        if args.command in ("ask", "enqueue"):
            tid = app.submit(args.goal, workspace=args.project, model=args.model, profile=args.profile,
                             allow_write=not args.read_only, allow_exec=args.allow_tests)
            print("Task:", tid, flush=True)
            if args.command == "enqueue":
                return 0
            def event(kind, data):
                if kind == "text":
                    print(data, end="", flush=True)
                elif kind in ("tool_started", "error"):
                    print("\n" + kind + ": " + json.dumps(data), flush=True)
            result = app.run(tid, on_event=event)
        elif args.command == "work":
            result = app.run_queue(args.workers)
        elif args.command == "resume":
            if args.allow_tests:
                app.store.set_execution(args.task_id, True)
            app.store.resume(args.task_id)
            result = app.run(args.task_id)
        elif args.command == "cancel":
            app.cancel(args.task_id)
            result = app.store.task(args.task_id)
        elif args.command == "show":
            result = app.store.task(args.task_id)
        elif args.command == "tasks":
            result = [{k: t[k] for k in ("id", "goal", "status", "round", "calls")} for t in app.store.tasks()]
        elif args.command == "status":
            result = {"version": "32.0.0 + v34 learning accelerator candidate", "state": str(app.home), "tasks": len(app.store.tasks()),
                      "experience": app.store.performance(), "BIE_history": app.bridge.history()}
        elif args.command == "audit":
            result = app.store.audit()
        elif args.command == "verify-vendor":
            result = verify_vendor()
        elif args.command == "search":
            result = app.bridge.search(args.query)
        elif args.command == "recall":
            result = app.store.recall(args.query, before=args.before)
        elif args.command == "remember":
            result = app.store.remember(args.text, subject=args.subject, source=args.source,
                                        scope=args.scope, supersedes=args.supersedes,
                                        status="corrected" if args.supersedes else "unverified")
        elif args.command == "import-v1":
            result = import_v1(app.store, args.database)
        elif args.command == "native-goal":
            result = app.bridge.goal(args.query)
        elif args.command == "knowledge-status":
            result = app.knowledge.status()
        elif args.command == "knowledge-search":
            result = app.knowledge.search(args.query)
        elif args.command == "evidence-search":
            result = evidence_search(app.knowledge, args.query, limit=args.limit)
        elif args.command == "xray-demo":
            result = synthetic_demo()
        elif args.command == "xray-reference":
            result = published_reference()
        elif args.command == "xray-analyze":
            result = analyze_file(args.lightcurve, args.period_days, args.epoch_days,
                                  width_fraction=args.width_fraction, target=args.target)
            if args.report is not None:
                if args.report.exists():
                    raise ValueError("Refusing to overwrite an existing report")
                args.report.parent.mkdir(parents=True, exist_ok=True)
                with args.report.open("x", encoding="utf-8") as outf:
                    json.dump(result, outf, indent=2)
                result["report_file"] = str(args.report)
        elif args.command == "wiggle-demo":
            result = adaptive_wiggle_plan(ADAPTIVE_WIGGLE_DEMO_MAP)
        elif args.command == "wiggle-plan":
            if args.map_file.stat().st_size > 5000:
                raise ValueError("Grid file too large")
            result = adaptive_wiggle_plan(args.map_file.read_text(encoding="utf-8"),
                initial_budget=args.initial_budget, max_expansions=args.max_expansions)
        elif args.command == "growth-predict":
            result = GrowthLedger(app.home).predict(read_packet(args.packet))
        elif args.command == "growth-resolve":
            result = GrowthLedger(app.home).resolve(args.prediction_id, args.outcome, args.source, args.evidence)
        elif args.command == "growth-invalidate":
            result = GrowthLedger(app.home).invalidate(args.prediction_id, args.reason)
        elif args.command == "growth-review":
            result = GrowthLedger(app.home).review(args.domain, args.context, args.strategy)
        elif args.command == "growth-status":
            result = GrowthLedger(app.home).status()
        elif args.command == "growth-audit":
            result = GrowthLedger(app.home).audit()
        elif args.command == "growth-history":
            result = GrowthLedger.history_cards()
        elif args.command == "learn-plan":
            result = LearningAccelerator(app.home).plan(args.manifest, args.profile, args.max_jobs, args.start_at)
        elif args.command == "learn-run":
            result = LearningAccelerator(app.home).run(args.manifest, profile=args.profile,
                     max_jobs=args.max_jobs, start_at=args.start_at, confirmed=args.confirm_network)
        elif args.command == "learn-status":
            result = LearningAccelerator(app.home).status()
        elif args.command == "planet-reconstruct":
            result = reconstruct(args.name, ExoplanetLab(app.home), draws=args.draws, seed=args.seed,
                evidence=load_evidence_file(args.evidence) if args.evidence else None,
                rotation=args.rotation, assumed_insolation_relative_error=args.insolation_relative_sigma)
            if args.report:
                result["export"] = export_reconstruction(result, args.report)
        elif args.command == "exo-status":
            result = ExoplanetLab(app.home).status()
        elif args.command == "exo-reference":
            result = ExoplanetLab(app.home).import_csv((PACKAGE / "examples" / "NASA_REFERENCE_EXAMPLES.csv").read_bytes(), kind="reference_examples", source="BIE bundled curated NASA reference examples; not a live TAP snapshot")
        elif args.command == "exo-sync":
            result = ExoplanetLab(app.home).sync()
        elif args.command == "exo-import":
            result = ExoplanetLab(app.home).import_csv(args.csv_path.read_bytes(), source=str(args.csv_path.resolve()))
        elif args.command == "exo-search":
            result = ExoplanetLab(app.home).search(args.phrase, limit=args.limit, max_distance_ly=args.within_ly, screen_only=args.screen_only)
        elif args.command == "exo-target":
            result = ExoplanetLab(app.home).target(args.name)
        elif args.command == "exo-between":
            result = ExoplanetLab(app.home).between(args.planet_a, args.planet_b)
        elif args.command == "exo-export":
            result = ExoplanetLab(app.home).export(args.output)
        elif args.command == "exo-lightcurve":
            result = inspect_curve(args.csv_path, args.period_days, args.epoch_days)
        elif args.command == "wifi-snapshot":
            result = WifiLab(app.home).snapshot()
        elif args.command == "wifi-infer":
            result = WifiLab(app.home).analyze()
        elif args.command == "wifi-new-session":
            result = WifiLab(app.home).new_session()
        elif args.command == "wifi-discovery":
            result = WifiDiscovery(app.home).report()
        elif args.command == "wifi-investigate":
            result = WifiNovelty(app.home).observe_and_report()
        elif args.command == "wifi-novelty":
            result = WifiNovelty(app.home).report()
        elif args.command == "wifi-export":
            report = WifiDiscovery(app.home).report()
            # Deliberately exports derived, pseudonymized evidence, not raw network names.
            if args.output.exists():
                raise ValueError("Destination exists; select a new filename to avoid overwriting data")
            args.output.parent.mkdir(parents=True, exist_ok=True)
            with args.output.open("x", encoding="utf-8") as f:
                json.dump(report, f, indent=2, ensure_ascii=False)
            result = {"saved": True, "path": str(args.output), "privacy": report.get("privacy") }
        elif args.command == "storage-discover":
            result = discover_storage()
        elif args.command == "storage-list":
            result = app.knowledge.storage()
        elif args.command == "storage-add":
            result = app.knowledge.register_storage(args.alias, args.path)
        elif args.command == "storage-remove":
            result = app.knowledge.remove_storage(args.alias)
        elif args.command == "storage-browse":
            result = app.knowledge.browse(args.alias, args.dir)
        elif args.command == "storage-import":
            result = app.knowledge.import_storage(args.alias, args.dir, args.max_files)
        elif args.command == "open-share":
            result = open_in_file_explorer(args.path)
        elif args.command == "public-search":
            result = search_public(args.provider, args.query, args.limit)
            if args.save:
                result["saved_refs"] = save_results(app.knowledge, result)
                result["saved"] = True
        else:
            raise ValueError("Unknown command")
        if isinstance(result, dict) and "checkpoint" in result:
            result = {k: v for k, v in result.items() if k not in {"checkpoint", "owner", "lease"}}
        print("\n" + json.dumps(result, indent=2, ensure_ascii=False))
        if isinstance(result, dict) and (result.get("passed") is False or result.get("status") in {"failed", "waiting", "paused", "cancelled"}):
            return 2
        return 0
    except KeyboardInterrupt:
        print("\nStopped. A running task will become resumable after its lease expires.", file=sys.stderr)
        return 130
    except Exception as ex:
        print("BIE: " + str(ex), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
