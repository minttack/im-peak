"""Native Tk interface. All widget access stays on the main UI thread."""
from __future__ import annotations

import json
from pathlib import Path
import queue
import threading
import time

from .config import PROFILES
from .migration import import_v1
from .model import Ollama
from .process import listen_once, speak
from .network_storage import discover_storage, open_in_file_explorer
from .public_data import search_public, save_results
from .wifi_lab import WifiLab
from .wifi_discovery import WifiDiscovery
from .wifi_novelty import WifiNovelty
from .exoplanets import ExoplanetLab
from .config import PACKAGE
from .astro_signals import inspect_curve
from .xray_mapping import analyze_file, synthetic_demo, published_reference
from .planet_reconstruction import reconstruct, load_evidence_file, export_reconstruction
from .adaptive_wiggle import plan as adaptive_wiggle_plan, DEFAULT_MAP as ADAPTIVE_WIGGLE_DEMO_MAP
from .growth import GrowthLedger, read_packet
from .learning_accelerator import LearningAccelerator, PROFILES as LEARNING_PROFILES
from .bloom_geometry_h114n1 import compare_layouts


class Desktop:
    def __init__(self, assistant, root=None):
        import tkinter as tk
        from tkinter import ttk, scrolledtext, filedialog, messagebox
        self.tk, self.ttk = tk, ttk
        self.dialog, self.messagebox = filedialog, messagebox
        self.app = assistant
        self.root = root or tk.Tk()
        self.events = queue.Queue()
        self.active = None
        self.worker = None
        self.last_reply = ""
        self.samples = []
        self.started = None
        self.closed = False
        self.root.title("BIE THRIVES Experience · v34.1 Auto Max Learning candidate")
        self.root.geometry("1180x820")
        self.root.minsize(880, 680)
        bg, card, fg, muted, accent = "#0a111b", "#122031", "#eaf5ff", "#9bb1c8", "#5ae1bb"
        self.bg, self.card, self.fg, self.muted, self.accent = bg, card, fg, muted, accent
        self.root.configure(bg=bg)
        style = ttk.Style(self.root)
        if "clam" in style.theme_names():
            style.theme_use("clam")
        style.configure("TFrame", background=bg)
        style.configure("TLabel", background=bg, foreground=fg, font=("Segoe UI", 10))
        style.configure("TButton", padding=(10, 7), font=("Segoe UI", 10))
        style.configure("TCheckbutton", background=bg, foreground=fg)
        style.configure("Treeview", background=card, foreground=fg, fieldbackground=card, rowheight=28)
        style.configure("Treeview.Heading", background="#20344a", foreground=fg)
        style.configure("TNotebook", background=bg, borderwidth=0)
        style.configure("TNotebook.Tab", padding=(16, 9))

        header = tk.Frame(self.root, bg=bg)
        header.pack(fill="x", padx=22, pady=(18, 12))
        tk.Label(header, text="BIE EXPERIENCE", font=("Segoe UI Semibold", 22), fg=accent, bg=bg).pack(side="left")
        tk.Label(header, text="ASSISTANT v32  /  AUTO MAX + BLOOM GEOMETRY v34.2 CANDIDATE", font=("Segoe UI", 10), fg=muted, bg=bg).pack(side="right")
        settings = ttk.Frame(self.root)
        settings.pack(fill="x", padx=22)
        self.model = tk.StringVar(value="qwen2.5:3b")
        self.profile = tk.StringVar(value="Burst")
        self.project = tk.StringVar(value=str(assistant.home / "projects" / "default"))
        self.allow_write = tk.BooleanVar(value=True)
        self.allow_exec = tk.BooleanVar(value=False)
        ttk.Label(settings, text="Model").grid(row=0, column=0, sticky="w")
        self.models = ttk.Combobox(settings, textvariable=self.model, width=23)
        self.models.grid(row=0, column=1, padx=(8, 10))
        ttk.Button(settings, text="Find models", command=self.find_models).grid(row=0, column=2)
        ttk.Label(settings, text="Work budget").grid(row=0, column=3, padx=(18, 8))
        ttk.Combobox(settings, textvariable=self.profile, values=list(PROFILES), state="readonly", width=12).grid(row=0, column=4)
        ttk.Checkbutton(settings, text="Allow project edits", variable=self.allow_write).grid(row=0, column=5, padx=(18, 4))
        ttk.Checkbutton(settings, text="Run project tests", variable=self.allow_exec,
                        command=self.execution_changed).grid(row=0, column=6, padx=4)
        project_row = ttk.Frame(self.root)
        project_row.pack(fill="x", padx=22, pady=(10, 12))
        ttk.Label(project_row, text="Project").pack(side="left")
        ttk.Entry(project_row, textvariable=self.project).pack(side="left", fill="x", expand=True, padx=8)
        ttk.Button(project_row, text="Choose folder", command=self.choose_project).pack(side="left")

        self.tabs = ttk.Notebook(self.root)
        self.tabs.pack(fill="both", expand=True, padx=22)
        chat_frame, task_frame, memory_frame, experience_frame, data_frame, wifi_frame, exo_frame, xray_frame, recon_frame, wiggle_frame, growth_frame, learn_frame, geometry_frame = [ttk.Frame(self.tabs) for _ in range(13)]
        for widget, title in zip((chat_frame, task_frame, memory_frame, experience_frame, data_frame, wifi_frame, exo_frame, xray_frame, recon_frame, wiggle_frame, growth_frame, learn_frame, geometry_frame), ("Conversation", "Tasks", "Memory", "Experience", "Data & Wi-Fi Storage", "Wi-Fi Wiggle Lab", "BLOOM · Exoplanets", "BLOOM · X-ray Lab", "BLOOM · Reconstruction", "BLOOM · Adaptive Wiggle", "BIE · Growth Lab", "BIE · Learning Accelerator", "BLOOM · Geometry")):
            self.tabs.add(widget, text=title)
        # Optional diagram layout only: no code execution or main memory mutation.
        # Selecting a layout does not make it faster; standard 2D controls stay visible.
        self.geometry_viewport = (480, 128)
        row = ttk.Frame(geometry_frame)
        row.pack(fill="x", padx=12, pady=8)
        ttk.Label(row, text="Bloom node diagram (experimental; offline; no AI performance claim)").pack(side="left")
        ttk.Button(row, text="Compare layouts", command=self.compare_bloom_geometry).pack(side="left", padx=15)
        self.geometry_status = ttk.Label(geometry_frame, text="Run a collision-checked layout comparison. Wiggle is opt-in, never a code compression default.")
        self.geometry_status.pack(fill="x", padx=12)
        self.geometry_canvas = tk.Canvas(geometry_frame, width=980, height=440, bg="#101c2b", highlightthickness=0)
        self.geometry_canvas.pack(fill="both", expand=True, padx=12, pady=12)
        self.chat = scrolledtext.ScrolledText(chat_frame, wrap="word", bg=card, fg=fg, insertbackground=fg,
                                             font=("Segoe UI", 11), relief="flat", padx=16, pady=12, state="disabled")
        self.chat.pack(fill="both", expand=True)
        self.chat.tag_configure("heading", foreground=accent, font=("Segoe UI Semibold", 11))
        self.chat.tag_configure("error", foreground="#ffb19f")
        self.append("BIE", "Ready. Search and memory work offline. Select an installed local model for chat and coding.\nBurst allows up to 32 model rounds, 64 tool calls and 15 minutes per run. Resume keeps your progress.")

        self.task_tree = ttk.Treeview(task_frame, columns=("state", "rounds", "calls", "goal"), show="headings", selectmode="browse")
        for key, title, width in (("state", "State", 100), ("rounds", "Rounds", 60), ("calls", "Tools", 60), ("goal", "Goal", 650)):
            self.task_tree.heading(key, text=title)
            self.task_tree.column(key, width=width, stretch=key == "goal")
        self.task_tree.pack(fill="both", expand=True)
        task_controls = ttk.Frame(task_frame)
        task_controls.pack(fill="x", pady=8)
        ttk.Button(task_controls, text="Resume selected", command=self.resume_task).pack(side="left")
        ttk.Button(task_controls, text="Cancel selected", command=self.cancel_selected).pack(side="left", padx=8)
        ttk.Button(task_controls, text="View result", command=self.view_task).pack(side="left")

        memory_controls = ttk.Frame(memory_frame)
        memory_controls.pack(fill="x", pady=8)
        self.memory_query = tk.StringVar()
        ttk.Entry(memory_controls, textvariable=self.memory_query).pack(side="left", fill="x", expand=True)
        ttk.Button(memory_controls, text="Recall", command=self.recall).pack(side="left", padx=8)
        ttk.Button(memory_controls, text="Import v1 history", command=self.import_history).pack(side="left")
        self.memory_view = scrolledtext.ScrolledText(memory_frame, wrap="word", bg=card, fg=fg, font=("Consolas", 10), relief="flat")
        self.memory_view.pack(fill="both", expand=True)
        self.memory_view.configure(state="disabled")

        self.experience_view = scrolledtext.ScrolledText(experience_frame, wrap="word", bg=card, fg=fg, font=("Consolas", 10), relief="flat")
        self.experience_view.pack(fill="both", expand=True)
        self.experience_view.configure(state="disabled")
        exp_controls = ttk.Frame(experience_frame)
        exp_controls.pack(fill="x", pady=8)
        ttk.Button(exp_controls, text="Measure / audit", command=self.audit).pack(side="left")
        ttk.Button(exp_controls, text="Original BIE history", command=self.history).pack(side="left", padx=8)

        # User-directed growth experiments, not automatic model retraining.
        self.growth = GrowthLedger(assistant.home)
        self.growth_id = tk.StringVar()
        self.growth_source = tk.StringVar(value="manual observation")
        self.growth_outcome = tk.StringVar(value="1")
        self.growth_domain = tk.StringVar(value="")
        self.growth_context = tk.StringVar(value="")
        self.growth_strategy = tk.StringVar(value="")
        tk.Label(growth_frame, text=(
            "Memory -> Prediction -> Test -> Evidence -> Verification -> Correction. "
            "Freeze a prediction BEFORE the test, then record a binary outcome. "
            "This lab compares Brier scores to a predeclared baseline, preserves negative results "
            "and never changes model weights or permits actions. User-provided evidence is unverified."),
            bg=bg, fg=muted, wraplength=1000, justify="left").pack(fill="x", pady=(12, 8))
        grow_row = ttk.Frame(growth_frame)
        grow_row.pack(fill="x", pady=5)
        ttk.Button(grow_row, text="Record prediction from JSON", command=self.growth_predict).pack(side="left")
        ttk.Button(grow_row, text="Ledger status", command=self.growth_status).pack(side="left", padx=5)
        ttk.Button(grow_row, text="Verify journal", command=self.growth_audit).pack(side="left", padx=5)
        ttk.Button(grow_row, text="Previous project lessons", command=self.growth_history).pack(side="left", padx=5)
        grow_row2 = ttk.Frame(growth_frame)
        grow_row2.pack(fill="x", pady=5)
        ttk.Label(grow_row2, text="Prediction ID").pack(side="left")
        ttk.Entry(grow_row2, width=34, textvariable=self.growth_id).pack(side="left", padx=6)
        ttk.Label(grow_row2, text="Observed outcome").pack(side="left")
        ttk.Combobox(grow_row2, textvariable=self.growth_outcome, values=("0", "1"), width=3,
                     state="readonly").pack(side="left", padx=6)
        ttk.Label(grow_row2, text="Source label").pack(side="left")
        ttk.Entry(grow_row2, textvariable=self.growth_source, width=20).pack(side="left", padx=6)
        ttk.Button(grow_row2, text="Record outcome", command=self.growth_resolve).pack(side="left")
        grow_row3 = ttk.Frame(growth_frame)
        grow_row3.pack(fill="x", pady=5)
        for lbl, val, w in (("Domain", self.growth_domain, 16), ("Context", self.growth_context, 16),
                            ("Strategy", self.growth_strategy, 16)):
            ttk.Label(grow_row3, text=lbl).pack(side="left", padx=4)
            ttk.Entry(grow_row3, textvariable=val, width=w).pack(side="left", padx=5)
        ttk.Button(grow_row3, text="Review vs baseline", command=self.growth_review).pack(side="left", padx=8)
        self.growth_view = scrolledtext.ScrolledText(growth_frame, wrap="word", bg=card, fg=fg,
                                                    font=("Consolas", 10), relief="flat")
        self.growth_view.pack(fill="both", expand=True, pady=(8, 0))
        self.growth_view.configure(state="disabled")

        # Controlled public research batch import: only explicitly selected manifest and consent.
        self.learning = LearningAccelerator(assistant.home)
        self.learn_manifest = tk.StringVar()
        self.learn_profile = tk.StringVar(value="Auto")
        self.learn_running = False
        tk.Label(learn_frame, text=(
            "FASTER INDEXING, NOT INFINITE KNOWLEDGE. Choose public research queries, preview budgets, "
            "then explicitly approve Internet access. Records are unverified reference metadata, "
            "not full articles or retrained neural-network weights. Speed depends on providers, hardware and evidence quality."),
            bg=bg, fg=muted, wraplength=970, justify="left").pack(fill="x", pady=(12,8))
        learn_row = ttk.Frame(learn_frame)
        learn_row.pack(fill="x", pady=5)
        ttk.Label(learn_row, text="Query manifest").pack(side="left")
        ttk.Entry(learn_row, textvariable=self.learn_manifest).pack(side="left", fill="x", expand=True, padx=8)
        ttk.Button(learn_row, text="Choose JSON", command=self.learn_choose).pack(side="left")
        learn_settings = ttk.Frame(learn_frame)
        learn_settings.pack(fill="x", pady=5)
        ttk.Label(learn_settings, text="Learning profile (Auto aims at MaximumSafe)").pack(side="left")
        ttk.Combobox(learn_settings, textvariable=self.learn_profile,
                     values=("Auto", *LEARNING_PROFILES), state="readonly", width=16).pack(side="left", padx=8)
        ttk.Button(learn_settings, text="Preview no network", command=self.learn_preview).pack(side="left", padx=4)
        self.learn_start_button = ttk.Button(learn_settings, text="Approve & run online import", command=self.learn_run)
        self.learn_start_button.pack(side="left", padx=4)
        ttk.Button(learn_settings, text="View measured history", command=self.learn_status).pack(side="left", padx=4)
        self.learn_view = scrolledtext.ScrolledText(learn_frame, wrap="word", bg=card, fg=fg,
                                                   font=("Consolas", 10), relief="flat")
        self.learn_view.pack(fill="both", expand=True, pady=(8, 0))
        self.learn_view.configure(state="disabled")

        # Data never becomes searchable until the user explicitly registers and imports it.
        self.storage_alias = tk.StringVar(value="my-nas")
        self.storage_path = tk.StringVar()
        self.data_query = tk.StringVar()
        self.public_source = tk.StringVar(value="pubmed")
        self.public_last = None
        help_text = ("Find nearby LAN devices (discovery only), then open an authorized share through Windows. "
                     "Register a folder you can access. Importing supported text files is separate and opt-in; "
                     "BIE never asks for your Wi-Fi/NAS password or scans other networks.")
        tk.Label(data_frame, text=help_text, bg=bg, fg=muted, wraplength=1000, justify="left",
                 font=("Segoe UI", 10)).pack(fill="x", pady=(12, 9))
        discover_row = ttk.Frame(data_frame)
        discover_row.pack(fill="x", pady=4)
        ttk.Button(discover_row, text="Find devices on my Wi-Fi", command=self.discover_storage).pack(side="left")
        ttk.Button(discover_row, text="Open share in File Explorer", command=self.open_share).pack(side="left", padx=8)
        ttk.Button(discover_row, text="List registered storage", command=self.list_storage).pack(side="left")
        register_row = ttk.Frame(data_frame)
        register_row.pack(fill="x", pady=6)
        ttk.Label(register_row, text="Name").pack(side="left")
        ttk.Entry(register_row, textvariable=self.storage_alias, width=16).pack(side="left", padx=(6, 12))
        ttk.Label(register_row, text="Folder or network path").pack(side="left")
        ttk.Entry(register_row, textvariable=self.storage_path).pack(side="left", fill="x", expand=True, padx=8)
        ttk.Button(register_row, text="Browse", command=self.choose_storage).pack(side="left")
        ttk.Button(register_row, text="Register", command=self.add_storage).pack(side="left", padx=(8, 0))
        search_row = ttk.Frame(data_frame)
        search_row.pack(fill="x", pady=6)
        ttk.Button(search_row, text="Import top-level text files", command=self.import_storage).pack(side="left")
        ttk.Button(search_row, text="Browse files", command=self.browse_storage).pack(side="left", padx=8)
        ttk.Label(search_row, text="Search knowledge / public research").pack(side="left", padx=(16, 5))
        ttk.Entry(search_row, textvariable=self.data_query).pack(side="left", fill="x", expand=True)
        ttk.Button(search_row, text="Search local", command=self.search_knowledge).pack(side="left", padx=6)
        public_row = ttk.Frame(data_frame)
        public_row.pack(fill="x", pady=5)
        ttk.Combobox(public_row, values=("pubmed", "openalex", "crossref", "wikipedia", "worldbank"), textvariable=self.public_source,
                     state="readonly", width=15).pack(side="left")
        ttk.Button(public_row, text="Search public API", command=self.search_public).pack(side="left", padx=8)
        ttk.Button(public_row, text="Save last reference results", command=self.save_public).pack(side="left")
        self.data_view = scrolledtext.ScrolledText(data_frame, wrap="word", bg=card, fg=fg,
                                                   font=("Consolas", 10), relief="flat")
        self.data_view.pack(fill="both", expand=True, pady=(8, 0))
        self.data_view.configure(state="disabled")

        # The Wi-Fi lab only reads Windows' own current radio reports. Users must
        # explicitly request snapshots; no periodic background scans take place.
        self.wifi_lab = WifiLab(assistant.home)
        self.wifi_discovery = WifiDiscovery(assistant.home)
        self.wifi_novelty = WifiNovelty(assistant.home)
        wifi_intro = ("BIE 29: investigate unfamiliar WLAN metadata → compare competing explanations → inspect evidence → test/refute → remember. "
                      "Windows Wi-Fi reports may require Location permission. Signal wiggles or Wi-Fi 7 advertisements do NOT demonstrate "
                      "greater throughput, unauthorized access, new physics, or a previously unknown wireless protocol.")
        tk.Label(wifi_frame, text=wifi_intro, bg=bg, fg=muted,
                 wraplength=1000, justify="left").pack(fill="x", pady=(12, 10))
        wifi_controls = ttk.Frame(wifi_frame)
        wifi_controls.pack(fill="x", pady=(0, 10))
        ttk.Button(wifi_controls, text="Snapshot current Wi-Fi", command=self.wifi_snapshot).pack(side="left")
        ttk.Button(wifi_controls, text="Compare & infer", command=self.wifi_infer).pack(side="left", padx=5)
        ttk.Button(wifi_controls, text="Advanced discovery", command=self.wifi_advanced).pack(side="left", padx=5)
        ttk.Button(wifi_controls, text="Investigate unfamiliar Wi-Fi", command=self.wifi_novelty_scan).pack(side="left", padx=5)
        ttk.Button(wifi_controls, text="New test session", command=self.wifi_session).pack(side="left", padx=5)
        ttk.Button(wifi_controls, text="Export evidence", command=self.wifi_export).pack(side="left", padx=5)
        ttk.Label(wifi_frame, text="User-triggered observations only · No automatic connection, probing or password retrieval.").pack(anchor="w", pady=(0,6))
        self.wifi_view = scrolledtext.ScrolledText(wifi_frame, wrap="word", bg=card, fg=fg,
                                                   font=("Consolas", 10), relief="flat")
        self.wifi_view.pack(fill="both", expand=True)
        self.wifi_view.configure(state="disabled")

        # BLOOM observes archived measurements; an explicit NASA sync is needed
        # for public online data. No telescope, biosignature or live sky access.
        self.exo_lab = ExoplanetLab(assistant.home)
        self.exo_query = tk.StringVar()
        self.exo_period = tk.StringVar(value="5")
        self.exo_epoch = tk.StringVar(value="0")
        intro = ("BLOOM × BIE: Exoplanet Observatory. Load the NASA composite catalog to measure host-star distances, "
                 "compare planets and generate evidence-driven hypotheses. This is archived astronomical data, "
                 "NOT real-time telescope imaging and NOT proof of extraterrestrial life.")
        tk.Label(exo_frame, text=intro, bg=bg, fg=muted, wraplength=1000, justify="left").pack(fill="x", pady=(12, 8))
        exo_controls = ttk.Frame(exo_frame)
        exo_controls.pack(fill="x", pady=5)
        ttk.Button(exo_controls, text="Offline examples", command=self.exo_reference).pack(side="left", padx=(0, 8))
        ttk.Button(exo_controls, text="Sync NASA catalog", command=self.exo_sync).pack(side="left", padx=(0, 8))
        ttk.Button(exo_controls, text="Import CSV", command=self.exo_import).pack(side="left", padx=5)
        ttk.Button(exo_controls, text="Nearest planets", command=self.exo_nearest).pack(side="left", padx=5)
        ttk.Button(exo_controls, text="Research status", command=self.exo_status).pack(side="left", padx=5)
        ttk.Button(exo_controls, text="Export report", command=self.exo_export).pack(side="left", padx=5)
        exo_find = ttk.Frame(exo_frame)
        exo_find.pack(fill="x", pady=6)
        ttk.Label(exo_find, text="Planet or star:").pack(side="left", padx=(0, 7))
        ttk.Entry(exo_find, textvariable=self.exo_query).pack(side="left", fill="x", expand=True)
        ttk.Button(exo_find, text="Search", command=self.exo_search).pack(side="left", padx=7)
        ttk.Button(exo_find, text="Analyze named planet", command=self.exo_target).pack(side="left")
        lc = ttk.Frame(exo_frame)
        lc.pack(fill="x", pady=(6, 8))
        ttk.Label(lc, text="Light curve: supplied time,flux CSV · period (days)").pack(side="left")
        ttk.Entry(lc, textvariable=self.exo_period, width=9).pack(side="left", padx=6)
        ttk.Label(lc, text="epoch (days)").pack(side="left")
        ttk.Entry(lc, textvariable=self.exo_epoch, width=9).pack(side="left", padx=6)
        ttk.Button(lc, text="Evaluate repeating dip", command=self.exo_lightcurve).pack(side="left", padx=5)
        self.exo_view = scrolledtext.ScrolledText(exo_frame, wrap="word", bg=card, fg=fg,
                                                   font=("Consolas", 10), relief="flat")
        self.exo_view.pack(fill="both", expand=True)
        self.exo_view.configure(state="disabled")
        # Independent X-ray transit investigation uses reduced, user-selected files.
        self.xray_last = None
        self.xray_target = tk.StringVar(value="HD 189733 b")
        self.xray_period = tk.StringVar(value="2.21857312")
        self.xray_epoch = tk.StringVar(value="2453988.80261")
        self.xray_width = tk.StringVar(value="0.08")
        tk.Label(xray_frame, text="BLOOM X-ray transit lab · Analyze prepared source/background counts, exposure, motion and fixed ephemerides. No raw photon calibration or live telescope connection.", bg=bg, fg=muted, wraplength=1000, justify="left").pack(fill="x",pady=(12,8))
        xr = ttk.Frame(xray_frame); xr.pack(fill="x",pady=7)
        ttk.Label(xr,text="Target").pack(side="left")
        ttk.Entry(xr,textvariable=self.xray_target,width=19).pack(side="left",padx=5)
        ttk.Label(xr,text="Period (days)").pack(side="left")
        ttk.Entry(xr,textvariable=self.xray_period,width=13).pack(side="left",padx=5)
        ttk.Label(xr,text="Epoch (same as file)").pack(side="left")
        ttk.Entry(xr,textvariable=self.xray_epoch,width=18).pack(side="left",padx=5)
        ttk.Label(xr,text="Width (phase)").pack(side="left")
        ttk.Entry(xr,textvariable=self.xray_width,width=7).pack(side="left",padx=5)
        buttons=ttk.Frame(xray_frame); buttons.pack(fill="x",pady=6)
        ttk.Button(buttons,text="Published HD 189733 b reference",command=self.xray_reference).pack(side="left")
        ttk.Button(buttons,text="Run synthetic + null controls",command=self.xray_demo).pack(side="left",padx=5)
        ttk.Button(buttons,text="Analyze selected X-ray file",command=self.xray_analyze).pack(side="left",padx=5)
        ttk.Button(buttons,text="Export evidence",command=self.xray_export).pack(side="left",padx=5)
        self.xray_view=scrolledtext.ScrolledText(xray_frame,wrap="word",bg=card,fg=fg,font=("Consolas",10),relief="flat")
        self.xray_view.pack(fill="both",expand=True)
        self.xray_view.configure(state="disabled")
        # BLOOM v32: multiple physically conditional climate maps, not observed terrain.
        self.recon_name = tk.StringVar(value="Proxima Cen b")
        self.recon_draws = tk.StringVar(value="160")
        self.recon_rotation = tk.StringVar(value="synchronous")
        self.recon_evidence_path = None
        self.recon_last = None
        tk.Label(recon_frame, text="HYPOTHETICAL planetary environments · simple energy balance, assumed atmospheres and rotation. No actual terrain, oceans, surface life, or inhabitants detected.", bg=bg, fg=muted, wraplength=1000, justify="left").pack(fill="x", pady=(12,9))
        rc = ttk.Frame(recon_frame); rc.pack(fill="x", pady=4)
        ttk.Label(rc, text="Planet").pack(side="left")
        ttk.Entry(rc, textvariable=self.recon_name, width=26).pack(side="left", padx=5)
        ttk.Label(rc, text="Draws / scenario").pack(side="left", padx=(8,3))
        ttk.Entry(rc, textvariable=self.recon_draws, width=7).pack(side="left")
        ttk.Label(rc, text="Rotation hypothesis").pack(side="left", padx=(8,3))
        ttk.Combobox(rc, textvariable=self.recon_rotation, values=("synchronous", "fast_rotating"), state="readonly", width=15).pack(side="left")
        rb = ttk.Frame(recon_frame); rb.pack(fill="x", pady=8)
        ttk.Button(rb, text="Run competing environments", command=self.recon_run).pack(side="left")
        ttk.Button(rb, text="Choose optional evidence JSON", command=self.recon_choose_evidence).pack(side="left", padx=5)
        ttk.Button(rb, text="Export full report", command=self.recon_export).pack(side="left", padx=5)
        ttk.Label(recon_frame, text="Optional evidence must match the planet name and state its source. Spectral labels are not verified; X-ray luminosity is NOT terrain imaging.").pack(anchor="w")
        rc_map=ttk.Frame(recon_frame); rc_map.pack(fill="x", pady=(6,0))
        ttk.Label(rc_map, text="Hypothetical thermal map (K), NOT observed terrain:").pack(side="left")
        self.recon_scenario = tk.StringVar(value="earthlike_assumed")
        self.recon_selector = ttk.Combobox(rc_map, state="readonly", width=21, values=("airless_rock", "thin_atmosphere", "earthlike_assumed", "dense_greenhouse", "ice_rich_assumed"), textvariable=self.recon_scenario)
        self.recon_selector.pack(side="left", padx=7)
        self.recon_selector.bind("<<ComboboxSelected>>", lambda _ev: self.recon_draw_map())
        self.recon_map = tk.Canvas(recon_frame, width=720, height=216, bg=card, highlightthickness=0)
        self.recon_map.pack(fill="x", pady=(4,2))
        self.recon_map.create_text(320,90, text="Run competing environments to generate conditional temperature maps", fill=fg)
        self.recon_view = scrolledtext.ScrolledText(recon_frame, wrap="word", bg=card, fg=fg, font=("Consolas",10), relief="flat")
        self.recon_view.pack(fill="both", expand=True, pady=(8,0))
        self.recon_view.configure(state="disabled")
        # Adaptive Wiggle operates only on an editable local text map. No network,
        # system commands, physical movement, or access to user project files.
        tk.Label(wiggle_frame, text="ADAPTIVE BLOOM WIGGLE · experimental obstacle planner · # blocked, . free, S start, G goal, 1-9 terrain costs. Read-only simulation.", bg=bg, fg=muted, wraplength=1000, justify="left").pack(fill="x", pady=(12, 8))
        self.wiggle_map = scrolledtext.ScrolledText(wiggle_frame, height=9, wrap="none", bg=card, fg=fg, insertbackground=fg, font=("Consolas", 13))
        self.wiggle_map.pack(fill="x", pady=(4, 8))
        self.wiggle_map.insert("1.0", ADAPTIVE_WIGGLE_DEMO_MAP)
        controls_w = ttk.Frame(wiggle_frame); controls_w.pack(fill="x", pady=8)
        ttk.Button(controls_w, text="Find optimal detour", command=self.wiggle_run).pack(side="left")
        ttk.Button(controls_w, text="Reset example", command=self.wiggle_reset).pack(side="left", padx=8)
        self.wiggle_view = scrolledtext.ScrolledText(wiggle_frame, wrap="word", bg=card, fg=fg, font=("Consolas", 10), relief="flat")
        self.wiggle_view.pack(fill="both", expand=True)
        self.wiggle_view.configure(state="disabled")
        self.background("exo_results", self.exo_lab.status)

        self.prompt = tk.Text(self.root, height=4, wrap="word", bg="#192c40", fg=fg, insertbackground=accent,
                              font=("Segoe UI", 11), relief="flat", padx=12, pady=10)
        self.prompt.pack(fill="x", padx=22, pady=(12, 8))
        controls = ttk.Frame(self.root)
        controls.pack(fill="x", padx=22)
        self.start_button = ttk.Button(controls, text="Start task  ↵", command=self.start)
        self.start_button.pack(side="left")
        for title, action in (("Stop", self.stop), ("Search BIE", self.search), ("Remember", self.remember),
                              ("Microphone", self.microphone), ("Speak reply", self.speech)):
            ttk.Button(controls, text=title, command=action).pack(side="left", padx=(7, 0))
        self.prompt.bind("<Control-Return>", lambda e: (self.start(), "break")[1])
        self.root.bind("<Escape>", lambda e: self.stop())
        footer = ttk.Frame(self.root)
        footer.pack(fill="x", padx=22, pady=(8, 12))
        self.status = tk.StringVar(value="Idle · local memory ready")
        ttk.Label(footer, textvariable=self.status).pack(side="left", fill="x", expand=True)
        self.rate = tk.StringVar(value="")
        ttk.Label(footer, textvariable=self.rate).pack(side="left", padx=8)
        self.spark = tk.Canvas(footer, width=150, height=28, bg=bg, highlightthickness=0)
        self.spark.pack(side="right")
        self.refresh_tasks()
        self.root.after(80, self.poll)
        self.root.protocol("WM_DELETE_WINDOW", self.close)
        self.prompt.focus_set()

    def compare_bloom_geometry(self):
        """Show actual validated coordinate layouts, with fair fixed-area control."""
        try:
            result = compare_layouts(480,128,8,32,5)
            canvas = self.geometry_canvas
            canvas.delete("all")
            labels = [("wiggle", "Wiggle", "#73c1fe"),
                      ("hex", "Hexagonal grid", "#f2b76c")]
            for i,(key,title,color) in enumerate(labels):
                yshift = 24 + i*215
                canvas.create_text(10,yshift,anchor="w",fill="#e8f4ff",text=f"{title}: {result['counts'][key]}  nodes (fixed 480 x 128 viewport)")
                for x,y in result["coordinates"][key]:
                    canvas.create_oval(10+x-8, yshift+18+y-8, 10+x+8, yshift+18+y+8,
                                       fill="", outline=color, width=1)
            self.geometry_status.configure(text=(
                f"Collision checked: {result['integrity_pass']} | Wiggle {result['counts']['wiggle']} "
                f"vs hex {result['counts']['hex']} | ratio {result['wiggle_vs_hex_ratio']:.3f} | "
                "Runtime memory/code untouched"))
        except Exception as exc:
            self.geometry_status.configure(text="Layout error: "+str(exc))

    def append(self, title, value, error=False):
        self.chat.configure(state="normal")
        if title:
            self.chat.insert("end", "\n" + title + "\n", "heading")
        self.chat.insert("end", str(value), "error" if error else ())
        self.chat.see("end")
        self.chat.configure(state="disabled")

    def background(self, name, operation):
        def runner():
            try:
                self.events.put((name, operation()))
            except Exception as ex:
                self.events.put(("error", str(ex)))
        threading.Thread(target=runner, daemon=True).start()

    def learn_choose(self):
        path = self.dialog.askopenfilename(title="Select explicitly authored public research query JSON",
                                           filetypes=[("JSON", "*.json")])
        if path:
            self.learn_manifest.set(path)

    def learn_preview(self):
        try:
            self.display_json(self.learn_view, self.learning.plan(self.learn_manifest.get(), self.learn_profile.get()))
        except Exception as ex:
            self.messagebox.showerror("BIE Learning Accelerator", str(ex))

    def learn_status(self):
        self.display_json(self.learn_view, self.learning.status())

    def learn_run(self):
        try:
            report = self.learning.plan(self.learn_manifest.get(), self.learn_profile.get())
        except Exception as ex:
            self.messagebox.showerror("BIE Learning Accelerator", str(ex))
            return
        if self.learn_running:
            return
        if not report["jobs_this_run"]:
            self.messagebox.showinfo("Batch finished", "All queries in this file have already been processed. Add new queries to the JSON file to continue.")
            return
        if not self.messagebox.askyesno("Approve public research access?",
               f"Send {report['jobs_this_run']} publicly authored search queries to approved public APIs, "
               "then store unverified reference titles/links locally? This is not model training and does not "
               "grant Internet access to other agent tools."):
            return
        self.learn_running = True
        self.learn_start_button.configure(state="disabled")
        self.status.set("BIE Learning Accelerator: running explicit public research batch")
        path, profile = self.learn_manifest.get(), self.learn_profile.get()
        self.background("learning_results", lambda: self.learning.run(path, profile=profile, confirmed=True))

    def growth_action(self, action):
        try:
            self.display_json(self.growth_view, action())
        except Exception as ex:
            self.messagebox.showerror("BIE Growth Lab", str(ex))

    def growth_predict(self):
        path = self.dialog.askopenfilename(title="Choose a prediction JSON BEFORE the test",
                                            filetypes=[("JSON", "*.json")])
        if path:
            def record():
                result = self.growth.predict(read_packet(path))
                self.growth_id.set(result["id"])
                return result
            self.growth_action(record)

    def growth_resolve(self):
        self.growth_action(lambda: self.growth.resolve(self.growth_id.get(), int(self.growth_outcome.get()),
                                                      self.growth_source.get()))

    def growth_review(self):
        self.growth_action(lambda: self.growth.review(self.growth_domain.get(),
            self.growth_context.get(), self.growth_strategy.get()))

    def growth_status(self):
        self.growth_action(self.growth.status)

    def growth_audit(self):
        self.growth_action(self.growth.audit)

    def growth_history(self):
        self.growth_action(self.growth.history_cards)

    def wiggle_run(self):
        grid = self.wiggle_map.get("1.0", "end-1c")
        self.background("wiggle_results", lambda: adaptive_wiggle_plan(grid))

    def wiggle_reset(self):
        self.wiggle_map.delete("1.0", "end")
        self.wiggle_map.insert("1.0", ADAPTIVE_WIGGLE_DEMO_MAP)

    def choose_project(self):
        selected = self.dialog.askdirectory(title="Select BIE's working project")
        if selected:
            self.project.set(selected)

    def choose_storage(self):
        path = self.dialog.askdirectory(title="Choose your NAS drive or authorized shared folder")
        if path:
            self.storage_path.set(path)

    def discover_storage(self):
        self.status.set("Checking advertised devices on this local network (no passwords or share access)")
        self.background("data_results", discover_storage)

    def open_share(self):
        path = self.storage_path.get().strip()
        if not path:
            self.messagebox.showinfo("Enter share", "Enter a Windows network path like \\\\SERVER\\SHARE in the folder field.")
            return
        self.background("data_results", lambda: open_in_file_explorer(path))

    def add_storage(self):
        name, path = self.storage_alias.get().strip(), self.storage_path.get().strip()
        if not name or not path:
            self.messagebox.showinfo("Choose storage", "Set a name and an accessible folder path first.")
            return
        self.background("data_results", lambda: self.app.knowledge.register_storage(name, path))

    def list_storage(self):
        self.background("data_results", self.app.knowledge.status)

    def browse_storage(self):
        alias = self.storage_alias.get().strip()
        self.background("data_results", lambda: self.app.knowledge.browse(alias))

    def import_storage(self):
        alias = self.storage_alias.get().strip()
        if not self.messagebox.askyesno("Import files into BIE memory?",
                    "Read and index up to 50 top-level TXT, MD, CSV, TSV, JSON or JSONL files from this registered folder? "
                    "Review the folder first: these may include sensitive content. No files are uploaded."):
            return
        self.background("data_results", lambda: self.app.knowledge.import_storage(alias, max_files=50))

    def search_knowledge(self):
        query = self.data_query.get().strip()
        if query:
            self.background("data_results", lambda: self.app.knowledge.search(query))

    def search_public(self):
        query = self.data_query.get().strip()
        if not query:
            self.messagebox.showinfo("Research phrase", "Enter a public research search phrase first.")
            return
        provider = self.public_source.get()
        self.background("public_results", lambda: search_public(provider, query))

    def save_public(self):
        if self.public_last is None:
            self.messagebox.showinfo("No results", "Search a public service before saving reference metadata.")
            return
        if not self.messagebox.askyesno("Save references locally?", "Index the latest public titles, links and metadata in BIE's local knowledge database?"):
            return
        self.background("data_results", lambda: save_results(self.app.knowledge, self.public_last))

    def wifi_snapshot(self):
        self.status.set("Reading local Windows Wi-Fi reports by explicit request")
        self.background("wifi_results", self.wifi_lab.snapshot)

    def wifi_infer(self):
        self.background("wifi_results", self.wifi_lab.analyze)

    def wifi_advanced(self):
        self.background("wifi_results", self.wifi_discovery.report)

    def wifi_novelty_scan(self):
        """One explicitly requested, read-only Windows WLAN observation."""
        self.status.set("Reviewing unfamiliar Wi-Fi reports (no network connection)")
        self.background("wifi_results", self.wifi_novelty.observe_and_report)

    def wifi_session(self):
        if not self.messagebox.askyesno("New measurement session?", "Mark a new session boundary for manually collected observations? This does not run a Wi-Fi scan or prove independent replication."):
            return
        self.background("wifi_results", self.wifi_lab.new_session)

    def wifi_export(self):
        path = self.dialog.asksaveasfilename(title="Save pseudonymous Wi-Fi evidence", defaultextension=".json", filetypes=[("JSON", "*.json")])
        if not path:
            return
        if Path(path).exists():
            self.messagebox.showwarning("Choose a new filename", "The destination already exists. No data was overwritten.")
            return
        def save():
            report = self.wifi_discovery.report()
            with open(path, "x", encoding="utf-8") as f:
                json.dump(report, f, ensure_ascii=False, indent=2)
            return {"saved": True, "report": str(path), "privacy": report.get("privacy")}
        self.background("wifi_results", save)

    def recon_choose_evidence(self):
        path = self.dialog.askopenfilename(title="Select optional unverified astronomical evidence JSON", filetypes=[("JSON", "*.json")])
        if path:
            self.recon_evidence_path = path
            self.status.set("BLOOM: selected additional evidence JSON; not independently verified")

    def recon_run(self):
        name = self.recon_name.get().strip()
        def run():
            result = reconstruct(name, self.exo_lab, draws=int(self.recon_draws.get()),
                        rotation=self.recon_rotation.get(),
                        evidence=load_evidence_file(self.recon_evidence_path) if self.recon_evidence_path else None)
            self.recon_last = result
            return result
        self.background("recon_results", run)

    def recon_draw_map(self):
        """Render illustrative local calculation on Tk; no actual planet image."""
        c = self.recon_map
        c.delete("all")
        if not self.recon_last:
            return
        scene = next((r for r in self.recon_last["results"] if r["scenario"] == self.recon_scenario.get()), None)
        if scene is None:
            return
        values = scene["illustrative_grid"]["surface_temperature_proxy_k"]
        cols, rows, tile = 36, 18, 10
        def color(t):
            # Fixed absolute Kelvin scale: dark blue (<150), cyan (~250), gold (~350), orange (>450).
            stops = ((100,(26,33,92)),(180,(40,100,183)),(250,(52,178,191)),(300,(247,208,92)),(370,(235,117,44)),(450,(179,46,41)))
            if t <= 100: rgb = stops[0][1]
            elif t >= 450: rgb = stops[-1][1]
            else:
                for (p0,r0),(p1,r1) in zip(stops,stops[1:]):
                    if p0 <= t <= p1:
                        a=(t-p0)/(p1-p0)
                        rgb=tuple(int(v+(w-v)*a) for v,w in zip(r0,r1))
                        break
            return "#%02x%02x%02x" % rgb
        x0,y0=18,8
        for j,row in enumerate(values):
            for i,t in enumerate(row):
                c.create_rectangle(x0+i*tile,y0+j*tile,x0+(i+1)*tile,y0+(j+1)*tile,fill=color(t),outline="")
        c.create_rectangle(x0,y0,x0+36*tile,y0+18*tile,outline="#eaf5ff")
        c.create_text(x0+390,y0+15, text="Assumed scenario: "+self.recon_scenario.get(),anchor="w",fill=self.fg,font=("Consolas",10))
        c.create_text(x0+390,y0+45, text="Dark blue <150 K; cyan ~250 K; orange >370 K",anchor="w",fill=self.muted)
        c.create_text(x0+390,y0+75,text="Not actual surface photography / topography",anchor="w",fill=self.fg)
        c.create_text(x0+390,y0+105,text="No detection of oceans, cities, or inhabitants",anchor="w",fill=self.fg)

    def recon_export(self):
        if not self.recon_last:
            self.messagebox.showinfo("Nothing to export", "Run a reconstruction first")
            return
        path = self.dialog.asksaveasfilename(title="Export hypothetical planet reconstruction", defaultextension=".json", filetypes=[("JSON", "*.json")])
        if path:
            self.background("recon_results", lambda: export_reconstruction(self.recon_last, path))

    def xray_reference(self):
        self.background("xray_results", published_reference)

    def xray_demo(self):
        self.background("xray_results", synthetic_demo)

    def xray_analyze(self):
        path = self.dialog.askopenfilename(title="Select already reduced, background-measured X-ray bins",
               filetypes=[("Prepared X-ray light curves", "*.csv *.fits *.fit *.fts")])
        if not path:
            return
        if not self.messagebox.askyesno("Analyze selected local file?",
                "This reads the selected prepared measurements locally. A transit inference requires correctly reduced instrument data, source/background regions and synchronized time references. Continue?"):
            return
        def run():
            report=analyze_file(path, self.xray_period.get(), self.xray_epoch.get(),
                                width_fraction=self.xray_width.get(), target=self.xray_target.get())
            self.xray_last=report
            return report
        self.background("xray_results", run)

    def xray_export(self):
        if not self.xray_last:
            self.messagebox.showinfo("No measurements", "Analyze a file before exporting an evidence report")
            return
        path = self.dialog.asksaveasfilename(title="Export evidence (new file only)", defaultextension=".json",
                                             filetypes=[("JSON", "*.json")])
        if not path:
            return
        if Path(path).exists():
            self.messagebox.showwarning("Destination exists", "Choose a new filename; evidence exports never overwrite")
            return
        def save():
            with open(path,"x",encoding="utf-8") as f:
                json.dump(self.xray_last,f,indent=2,ensure_ascii=False)
            return {"saved": path, "kind":"read-only evidence report"}
        self.background("xray_results",save)

    def exo_reference(self):
        if self.messagebox.askyesno("Use curated examples?", "Replace current catalog with 3 illustrative NASA-referenced planets? These are NOT a live NASA composite archive snapshot."):
            self.background("exo_results", lambda: self.exo_lab.import_csv((PACKAGE / "examples" / "NASA_REFERENCE_EXAMPLES.csv").read_bytes(), kind="reference_examples", source="Bundled curated NASA reference examples — not current archive sync"))

    def exo_sync(self):
        if not self.messagebox.askyesno("Download NASA exoplanet catalog?",
                    "Contact NASA Exoplanet Archive over HTTPS and replace BIE's local public-planet catalog with the latest available snapshot? No local files are uploaded."):
            return
        self.status.set("Downloading public NASA catalog; existing local data is preserved on failure")
        self.background("exo_results", self.exo_lab.sync)

    def exo_import(self):
        path = self.dialog.askopenfilename(title="Select NASA-compatible exoplanet catalog CSV", filetypes=[("CSV", "*.csv")])
        if path and self.messagebox.askyesno("Replace exoplanet catalog?", "Import this CSV as user-supplied data? Provenance will be labeled unverified, not live NASA."):
            self.background("exo_results", lambda: self.exo_lab.import_csv(Path(path).read_bytes(), source=str(path)))

    def exo_nearest(self):
        self.background("exo_results", lambda: self.exo_lab.search(limit=30))

    def exo_status(self):
        # BLOOM v32: multiple physically conditional climate maps, not observed terrain.
        self.recon_name = tk.StringVar(value="Proxima Cen b")
        self.recon_draws = tk.StringVar(value="160")
        self.recon_rotation = tk.StringVar(value="synchronous")
        self.recon_evidence_path = None
        self.recon_last = None
        tk.Label(recon_frame, text="HYPOTHETICAL planetary environments · simple energy balance, assumed atmospheres and rotation. No actual terrain, oceans, surface life, or inhabitants detected.", bg=bg, fg=muted, wraplength=1000, justify="left").pack(fill="x", pady=(12,9))
        rc = ttk.Frame(recon_frame); rc.pack(fill="x", pady=4)
        ttk.Label(rc, text="Planet").pack(side="left")
        ttk.Entry(rc, textvariable=self.recon_name, width=26).pack(side="left", padx=5)
        ttk.Label(rc, text="Draws / scenario").pack(side="left", padx=(8,3))
        ttk.Entry(rc, textvariable=self.recon_draws, width=7).pack(side="left")
        ttk.Label(rc, text="Rotation hypothesis").pack(side="left", padx=(8,3))
        ttk.Combobox(rc, textvariable=self.recon_rotation, values=("synchronous", "fast_rotating"), state="readonly", width=15).pack(side="left")
        rb = ttk.Frame(recon_frame); rb.pack(fill="x", pady=8)
        ttk.Button(rb, text="Run competing environments", command=self.recon_run).pack(side="left")
        ttk.Button(rb, text="Choose optional evidence JSON", command=self.recon_choose_evidence).pack(side="left", padx=5)
        ttk.Button(rb, text="Export full report", command=self.recon_export).pack(side="left", padx=5)
        ttk.Label(recon_frame, text="Optional evidence must match the planet name and state its source. Spectral labels are not verified; X-ray luminosity is NOT terrain imaging.").pack(anchor="w")
        rc_map=ttk.Frame(recon_frame); rc_map.pack(fill="x", pady=(6,0))
        ttk.Label(rc_map, text="Hypothetical thermal map (K), NOT observed terrain:").pack(side="left")
        self.recon_scenario = tk.StringVar(value="earthlike_assumed")
        self.recon_selector = ttk.Combobox(rc_map, state="readonly", width=21, values=("airless_rock", "thin_atmosphere", "earthlike_assumed", "dense_greenhouse", "ice_rich_assumed"), textvariable=self.recon_scenario)
        self.recon_selector.pack(side="left", padx=7)
        self.recon_selector.bind("<<ComboboxSelected>>", lambda _ev: self.recon_draw_map())
        self.recon_map = tk.Canvas(recon_frame, width=720, height=216, bg=card, highlightthickness=0)
        self.recon_map.pack(fill="x", pady=(4,2))
        self.recon_map.create_text(320,90, text="Run competing environments to generate conditional temperature maps", fill=fg)
        self.recon_view = scrolledtext.ScrolledText(recon_frame, wrap="word", bg=card, fg=fg, font=("Consolas",10), relief="flat")
        self.recon_view.pack(fill="both", expand=True, pady=(8,0))
        self.recon_view.configure(state="disabled")
        # Adaptive Wiggle operates only on an editable local text map. No network,
        # system commands, physical movement, or access to user project files.
        tk.Label(wiggle_frame, text="ADAPTIVE BLOOM WIGGLE · experimental obstacle planner · # blocked, . free, S start, G goal, 1-9 terrain costs. Read-only simulation.", bg=bg, fg=muted, wraplength=1000, justify="left").pack(fill="x", pady=(12, 8))
        self.wiggle_map = scrolledtext.ScrolledText(wiggle_frame, height=9, wrap="none", bg=card, fg=fg, insertbackground=fg, font=("Consolas", 13))
        self.wiggle_map.pack(fill="x", pady=(4, 8))
        self.wiggle_map.insert("1.0", ADAPTIVE_WIGGLE_DEMO_MAP)
        controls_w = ttk.Frame(wiggle_frame); controls_w.pack(fill="x", pady=8)
        ttk.Button(controls_w, text="Find optimal detour", command=self.wiggle_run).pack(side="left")
        ttk.Button(controls_w, text="Reset example", command=self.wiggle_reset).pack(side="left", padx=8)
        self.wiggle_view = scrolledtext.ScrolledText(wiggle_frame, wrap="word", bg=card, fg=fg, font=("Consolas", 10), relief="flat")
        self.wiggle_view.pack(fill="both", expand=True)
        self.wiggle_view.configure(state="disabled")
        self.background("exo_results", self.exo_lab.status)

    def exo_search(self):
        value = self.exo_query.get().strip()
        self.background("exo_results", lambda: self.exo_lab.search(value, limit=50))

    def exo_target(self):
        value = self.exo_query.get().strip()
        if not value:
            self.messagebox.showinfo("Planet name", "Enter a specific planet name, such as TOI-700 d")
            return
        self.background("exo_results", lambda: self.exo_lab.target(value))

    def exo_export(self):
        path = self.dialog.asksaveasfilename(title="Export public astronomical findings", defaultextension=".json", filetypes=[("JSON", "*.json")])
        if path:
            self.background("exo_results", lambda: self.exo_lab.export(path))

    def exo_lightcurve(self):
        path = self.dialog.askopenfilename(title="Choose user-supplied light curve", filetypes=[("CSV", "*.csv")])
        if path:
            self.background("exo_results", lambda: inspect_curve(path, self.exo_period.get(), self.exo_epoch.get()))

    def execution_changed(self):
        if self.allow_exec.get() and not self.messagebox.askyesno("Run project Python tests?", "Tests execute Python with your Windows user permissions. Enable this only for a project you trust. Allow for new tasks?"):
            self.allow_exec.set(False)

    def start(self):
        if self.worker and self.worker.is_alive():
            self.status.set("Finish or stop the active task before starting another in this window.")
            return
        goal = self.prompt.get("1.0", "end").strip()
        if not goal:
            return
        try:
            tid = self.app.submit(goal, workspace=self.project.get(), model=self.model.get(), profile=self.profile.get(),
                                  allow_write=self.allow_write.get(), allow_exec=self.allow_exec.get())
        except Exception as ex:
            self.append("Needs attention", str(ex), True)
            return
        self.prompt.delete("1.0", "end")
        self.append("YOU", goal)
        self.append("BIE", "")
        self.launch(tid)

    def launch(self, tid):
        self.active = tid
        self.started = time.monotonic()
        self.start_button.configure(state="disabled")
        def runner():
            try:
                result = self.app.run(tid, on_event=lambda kind, data: self.events.put((kind, data)))
                self.events.put(("result", result))
            except Exception as ex:
                self.events.put(("error", str(ex)))
            finally:
                self.events.put(("idle", None))
        self.worker = threading.Thread(target=runner, daemon=True)
        self.worker.start()

    def stop(self):
        if self.active:
            self.app.cancel(self.active)
            self.status.set("Stopping at the next tool boundary; local model reads can take up to 30 seconds.")

    def selected(self):
        chosen = self.task_tree.selection()
        return chosen[0] if chosen else None

    def resume_task(self):
        if self.worker and self.worker.is_alive():
            return
        tid = self.selected()
        if tid:
            try:
                if self.allow_exec.get():
                    self.app.store.set_execution(tid, True)
                self.app.store.resume(tid)
                self.tabs.select(0)
                self.append("BIE", "Resuming saved task.\n")
                self.launch(tid)
            except Exception as ex:
                self.append("Needs attention", str(ex), True)

    def cancel_selected(self):
        tid = self.selected()
        if tid:
            self.app.cancel(tid)
            self.refresh_tasks()

    def view_task(self):
        tid = self.selected()
        if tid:
            task = self.app.store.task(tid)
            self.append("SAVED TASK · " + task["status"], task["output"] or task["error"] or task["goal"])
            self.tabs.select(0)

    def find_models(self):
        model = self.model.get()
        self.background("models", lambda: Ollama(model).models())

    def search(self):
        query = self.prompt.get("1.0", "end").strip()
        if query:
            self.background("search_results", lambda: self.app.bridge.search(query))

    def remember(self):
        body = self.prompt.get("1.0", "end").strip()
        if body:
            try:
                self.app.store.remember(body)
                self.append("MEMORY", "Saved as a user note with source and uncertainty.\n")
            except Exception as ex:
                self.append("Needs attention", str(ex), True)

    def recall(self):
        query = self.memory_query.get()
        self.background("memory_results", lambda: self.app.store.recall(query, limit=30))

    def import_history(self):
        source = self.dialog.askopenfilename(title="Select Desktop v1 conversation database", filetypes=[("SQLite", "*.sqlite3")])
        if source:
            self.background("import_result", lambda: import_v1(self.app.store, source))

    def audit(self):
        self.background("experience", lambda: {"assistant_integrity": self.app.store.audit(), "measured_tools": self.app.store.performance()})

    def history(self):
        self.background("experience", self.app.bridge.history)

    def microphone(self):
        self.status.set("Listening once. Review the transcript before starting a task.")
        self.background("transcript", listen_once)

    def speech(self):
        if self.last_reply:
            value = self.last_reply
            self.background("spoken", lambda: speak(value))

    def display_json(self, widget, value):
        widget.configure(state="normal")
        widget.delete("1.0", "end")
        widget.insert("end", json.dumps(value, ensure_ascii=False, indent=2))
        widget.configure(state="disabled")

    def refresh_tasks(self):
        selected = self.selected()
        for ident in self.task_tree.get_children():
            self.task_tree.delete(ident)
        for item in self.app.store.tasks():
            self.task_tree.insert("", "end", iid=item["id"], values=(item["status"], item["round"], item["calls"], item["goal"][:130]))
        if selected and self.task_tree.exists(selected):
            self.task_tree.selection_set(selected)

    def poll(self):
        if self.closed:
            return
        try:
            for _ in range(100):
                kind, data = self.events.get_nowait()
                if kind == "text":
                    self.append(None, data)
                elif kind == "error":
                    self.append("Needs attention", data + "\n", True)
                    if self.learn_running:
                        self.learn_running = False
                        self.learn_start_button.configure(state="normal")
                    self.status.set(str(data)[:110])
                elif kind == "tool_started":
                    self.status.set("Working · " + data["name"])
                elif kind == "tool_finished":
                    self.append("TOOL · " + data["tool"], json.dumps(data, ensure_ascii=False)[:1800] + "\n")
                    self.refresh_tasks()
                elif kind == "model_metrics":
                    self.samples.append(float(data.get("elapsed_ms", 0)))
                    self.samples = self.samples[-40:]
                    self.draw_spark()
                    duration, tokens = data.get("eval_duration_ns"), data.get("output_tokens")
                    if duration and tokens and duration > 0:
                        self.rate.set(f"{tokens / duration * 1e9:.1f} tokens/s · model reported")
                elif kind == "models":
                    self.models.configure(values=data)
                    if data and self.model.get() not in data:
                        self.model.set(data[0])
                    self.status.set(f"{len(data)} local models available")
                elif kind == "transcript":
                    self.prompt.insert("end", data)
                    self.status.set("Transcript ready to review" if data else "No speech recognized")
                elif kind == "memory_results":
                    self.display_json(self.memory_view, data)
                elif kind == "experience":
                    self.display_json(self.experience_view, data)
                elif kind == "data_results":
                    self.display_json(self.data_view, data)
                    self.status.set("Data / Wi-Fi operation complete; read results for actual connectivity")
                elif kind == "xray_results":
                    self.display_json(self.xray_view, data)
                    self.status.set("BLOOM X-ray: local evidence and provisional inferences; not a verified astronomical discovery")
                elif kind == "learning_results":
                    self.display_json(self.learn_view, data)
                    self.learn_running = False
                    self.learn_start_button.configure(state="normal")
                    self.status.set(f"Indexed {data['new_references']} new unverified references; no AI model training")
                elif kind == "wiggle_results":
                    self.display_json(self.wiggle_view, data)
                    self.status.set("Adaptive Wiggle: local bounded planning simulation; no actions executed")
                elif kind == "adaptive_wiggle":
                    self.status.set("Adaptive Wiggle: repeated tool error, requesting alternative strategy")
                elif kind == "recon_results":
                    # Display the scenario summaries without flooding the window with 3,240 grid points.
                    view = {k:v for k,v in data.items() if k != "results"} if isinstance(data,dict) else data
                    if isinstance(data, dict) and "results" in data:
                        view["results"] = [{k:v for k,v in r.items() if k != "illustrative_grid"} for r in data["results"]]
                        view["map_notice"] = "Full 18×36 hypothetical thermal maps are available in Export full report"
                    self.display_json(self.recon_view, view)
                    self.recon_draw_map()
                    self.status.set("BLOOM reconstruction: conditional models only; not mapped terrain or atmosphere detection")
                elif kind == "exo_results":
                    self.display_json(self.exo_view, data)
                    self.status.set("BLOOM exoplanets: archival evidence and provisional hypotheses")
                elif kind == "wifi_results":
                    self.display_json(self.wifi_view, data)
                    self.status.set("Wi-Fi lab: observations and provisional inferences; see evidence limits")
                elif kind == "public_results":
                    self.public_last = data
                    self.display_json(self.data_view, data)
                    self.status.set(f"{data['count']} public research references found; not saved unless you click Save")
                elif kind in {"search_results", "import_result"}:
                    self.append("BIE", json.dumps(data, ensure_ascii=False, indent=2))
                elif kind == "result" and data:
                    self.last_reply = data["output"]
                    if "Observed verification:" in self.last_reply:
                        self.append("VERIFICATION", self.last_reply.split("Observed verification:", 1)[1] + "\n")
                    self.status.set(f"{data['status'].capitalize()} · {data['round']} model rounds · {data['calls']} tool calls")
                elif kind == "idle":
                    self.active = None
                    self.start_button.configure(state="normal")
                    self.refresh_tasks()
        except queue.Empty:
            pass
        self.root.after(80, self.poll)

    def draw_spark(self):
        self.spark.delete("all")
        if len(self.samples) > 1:
            ceiling = max(1, max(self.samples))
            points = [(5 + i * 140 / (len(self.samples)-1), 25 - value / ceiling * 22) for i, value in enumerate(self.samples)]
            self.spark.create_line(*[v for point in points for v in point], fill=self.accent, width=2)
        else:
            self.spark.create_text(75, 14, text="model latency", fill=self.muted, font=("Segoe UI", 8))

    def close(self):
        self.stop()
        self.closed = True
        self.root.destroy()

    def mainloop(self):
        self.root.mainloop()
