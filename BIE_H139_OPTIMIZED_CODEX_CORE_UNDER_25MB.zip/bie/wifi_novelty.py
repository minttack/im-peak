"""BIE v29: passive investigation of unfamiliar WLAN *reports*, not unknown RF.

Rules: observation != physical discovery; OS metadata is not raw spectrum data.
No active wireless connection/probe, password access, host enumeration, or transmission.
Every candidate has explanations, counterevidence and a reproducible next test.
"""
from __future__ import annotations
from collections import defaultdict
from contextlib import closing
from datetime import datetime
import hashlib
import json
import re
import sqlite3
from .wifi_lab import WifiLab, _RADIO_ORDER


_UNCLASSIFIED = {"", "unknown", "n/a", "not available", "unspecified", "-", "none"}


def _load(text, typ):
    try:
        value = json.loads(text)
        return value if isinstance(value, typ) else typ()
    except (TypeError, ValueError):
        return typ()


def _valid_time(value):
    if not isinstance(value, str):
        return None
    try:
        dt = datetime.fromisoformat(value.replace("Z", "+00:00"))
        return dt.isoformat() if dt.tzinfo is not None else None
    except ValueError:
        return None


def _normalized_label(value):
    if not isinstance(value, str):
        return ""
    value = value.strip().lower()
    if len(value) > 64 or not re.fullmatch(r"[a-z0-9._ +/()-]*", value):
        return ""  # untrusted/freeform adapter text must not become a reported protocol
    return value


def _case(kind, key, observations, evidence, alternatives, falsifier, test):
    times = {r["time"] for r in observations if r["time"]}
    sessions = {r["session"] for r in observations if r["session"] and r["session"] != "legacy_unlabeled"}
    repeated = len(times) >= 3 and len(sessions) >= 2
    return {
        "case_id": f"{kind}-{hashlib.sha256(key.encode()).hexdigest()[:10]}",
        "indicator": kind, "source": "Locally saved Windows WLAN reports (not raw RF)",
        "evidence": evidence, "eligible_distinct_times": len(times),
        "manually_labeled_sessions": len(sessions),
        "review_status": "repeated_os_reports_unverified" if repeated else "needs_repeated_measurements",
        "supports_new_wifi_protocol": False,
        "alternative_explanations": alternatives,
        "would_contradict": falsifier,
        "next_test": test,
        "confidence": "high_for_recorded_metadata_only" if repeated else "low_single_source",
    }


class WifiNovelty:
    """Review passive snapshots and test unfamiliar WLAN metadata as hypotheses."""
    def __init__(self, home):
        self.lab = WifiLab(home)

    def observe_and_report(self):
        """User-invoked OS snapshot plus report, with no raw SSID/BSSID returned."""
        result = self.lab.snapshot()
        if not result.get("saved"):
            return {"version": 29, "status": "capture_unavailable", "new_protocol_discovered": False,
                    "reason": "Windows WLAN data was unavailable; check adapter, WLAN service and OS permissions.",
                    "next": "Try an authorized snapshot on a Windows PC with Wi-Fi enabled."}
        report = self.report()
        report["capture_saved"] = True
        return report

    def report(self):
        with closing(sqlite3.connect(self.lab.db_path)) as con:
            con.row_factory = sqlite3.Row
            rows = [dict(r) for r in con.execute("SELECT * FROM readings ORDER BY id LIMIT 10000")]
        if not rows:
            return {"version": 29, "status": "no_measurements", "new_protocol_discovered": False,
                    "candidates": [], "next": "On your PC, open Wi-Fi Wiggle Lab and click Investigate unfamiliar Wi-Fi."}
        usable = []
        excluded = 0
        for row in rows:
            aps = _load(row.get("aps_json"), list)
            warnings = _load(row.get("warnings_json"), list)
            tm = _valid_time(row.get("observed_at"))
            if not aps or warnings or not tm:
                excluded += 1
                continue
            safe = []
            for ap in aps[:120]:
                if not isinstance(ap, dict):
                    continue
                aid = ap.get("network_id")
                if not isinstance(aid, str) or not re.fullmatch(r"wifi-[a-f0-9]{14}", aid):
                    continue
                safe.append({"id": aid, "radio": _normalized_label(ap.get("radio")),
                             "generation": ap.get("generation"),
                             "band": _normalized_label(ap.get("band")),
                             "channel": str(ap.get("channel", "")).strip()[:4]})
            if safe:
                usable.append({"time": tm, "session": row.get("session_id") or "legacy_unlabeled", "aps": safe})
            else:
                excluded += 1
        if not usable:
            return {"version": 29, "status": "incomplete_reports", "new_protocol_discovered": False,
                    "snapshots_total": len(rows), "snapshots_excluded": excluded, "candidates": [],
                    "next": "Check Windows Wi-Fi and location permissions. Incomplete reports cannot support a discovery claim."}
        unknown = defaultdict(list)
        impossible = defaultdict(list)
        radios_by_ap = defaultdict(set)
        sightings = defaultdict(set)
        # A repeated AP in one scan counts once per case. Replaying identical
        # timestamps never elevates review confidence.
        for record in usable:
            already_unknown = set()
            already_inconsistent = set()
            for ap in record["aps"]:
                aid, radio = ap["id"], ap["radio"]
                sightings[aid].add(record["time"])
                if radio and radio not in _UNCLASSIFIED:
                    radios_by_ap[aid].add(radio)
                    if radio not in _RADIO_ORDER:
                        key = aid + "|" + radio
                        if key not in already_unknown:
                            unknown[key].append(record)
                            already_unknown.add(key)
                band, channel = ap["band"], ap["channel"]
                if channel.isdecimal() and 1 <= int(channel) <= 233:
                    number = int(channel)
                    incompatible = (("2.4" in band and number > 14) or
                                    ("5 ghz" in band and number < 30))
                    if incompatible:
                        key = aid + "|" + band + "|" + channel
                        if key not in already_inconsistent:
                            impossible[key].append(record)
                            already_inconsistent.add(key)
        cases = []
        for key, records in sorted(unknown.items()):
            # Deliberately do not reveal untrusted raw driver labels or SSIDs.
            cases.append(_case("unrecognized_radio_label", key, records,
                "Windows saved a radio-type label not in the known b/g/a/n/ac/ax/be parser dictionary. This is not proof of a new IEEE standard.",
                ["driver-specific text", "localized/unparseable display", "new standardized label", "malformed or stale WLAN report"],
                "A driver update or an independent receiver identifies it as an established standard or a parsing artifact.",
                "Repeat read-only measurements; check adapter manufacturer's driver, then compare metadata with a second authorized device."))
        for key, records in sorted(impossible.items()):
            cases.append(_case("band_channel_inconsistency", key, records,
                "Windows band label and reported channel appear inconsistent under ordinary WLAN channel numbering.",
                ["localized band text", "driver reporting error", "nonstandard channel rendering", "mixed AP/driver metadata"],
                "Router settings and an independent compatible adapter report normal band/channel mapping.",
                "On a router you control, compare configured band/channel against Windows reports; do not assume exotic radio activity."))
        changed = [(k, v) for k, v in radios_by_ap.items() if len(v) > 1 and len(sightings[k]) >= 2]
        for key, observed in sorted(changed)[:20]:
            matching = [r for r in usable if any(a["id"] == key for a in r["aps"])]
            cases.append(_case("radio_label_changed", key, matching,
                f"One pseudonymous access point has {len(observed)} different saved radio labels over time.",
                ["dual-mode AP", "driver roaming/report inconsistency", "firmware change", "network equipment replacement"],
                "Independent repeat measurements consistently resolve to one ordinary advertised standard.",
                "Compare OS records with your own router's configuration and driver version; a changing label is not a new protocol."))
        # Descriptive intermittent sightings are useful control evidence but
        # explicitly never considered 'novel protocol' signals.
        eligible_times = {r["time"] for r in usable}
        intermittent = sum(1 for v in sightings.values() if 2 <= len(v) < len(eligible_times))
        return {
            "version": 29,
            "status": "review_candidates" if cases else "no_unclassified_metadata_detected",
            "new_protocol_discovered": False,
            "measurement_scope": "Read-only Windows-decoded Wi-Fi metadata; not a radio spectrum sweep and cannot reveal unrecognized RF modulation.",
            "snapshots_total": len(rows), "snapshots_eligible": len(usable), "snapshots_excluded": excluded,
            "distinct_eligible_timestamps": len(eligible_times),
            "manually_labeled_sessions": len({r["session"] for r in usable if r["session"] != "legacy_unlabeled"}),
            "pseudonymous_access_points": len(sightings),
            "intermittently_visible_aps": intermittent,
            "cases_count": len(cases), "candidates": cases[:40],
            "interpretation": "These are hypotheses about existing OS reports, not evidence of unknown networks, hidden storage, Wi-Fi 8 deployment, or new physical technology.",
            "next": "For a truly unknown signal, use appropriately capable legal passive RF hardware, time-stamped measurements, independent instruments, and expert protocol analysis; this Windows app does not supply that hardware.",
            "privacy": "No network names, MAC/BSSIDs, passphrases, connection attempts or packets are included in this report. Pseudonymous case IDs are locally linkable; protect exported files."
        }
