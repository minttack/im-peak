"""H116: opt-in evidence-aware ranking of already imported documents.

This improves the candidate ordering of keyword matches, NOT knowledge truth,
model weights, or external source validation. A retrieval match is never called a
verified fact; contents remain lower-trust data.
"""
from __future__ import annotations

import re
from collections import Counter

STOP = frozenset(('the','this','that','those','these','with','from','will','what','which',
                  'where','when','how','does','have','has','had','and','for','are','was',
                  'were','into','then','than','been','being','about','can','could','would',
                  'should','your','their','our','its','his','her','who','why','did','you',
                  'say','show','tell','find','using','use','please','there','not','only'))


def terms(text):
    if not isinstance(text, str):
        return []
    return [w for w in re.findall(r"[a-z0-9]+", text.lower()[:4000]) if len(w)>1 and w not in STOP]


def evidence_search(hub, query, limit=10, candidate_cap=50):
    """Rank a bounded FTS candidate pool, requiring query coverage where possible.

    Reranks, but does not expand the underlying FTS top-50 candidate set. Only
    indexed, explicitly imported documents are considered. Does not access web.
    """
    if not isinstance(query, str) or not query.strip() or len(query)>300:
        raise ValueError('Query must contain 1-300 characters')
    if type(limit) is not int or not 1 <= limit <= 20:
        raise ValueError('limit must be 1-20')
    if type(candidate_cap) is not int or not 1 <= candidate_cap <= 50:
        raise ValueError('candidate_cap must be 1-50')
    q = list(dict.fromkeys(terms(query)))[:12]
    if not q:
        return {'query':query,'status':'no_informative_query_terms','results':[],
                'facts_verified':0,'model_weights_changed':False}
    baseline = hub.search(query, limit=candidate_cap)
    if not baseline:
        return {'query':query,'status':'no_indexed_match','results':[],
                'facts_verified':0,'model_weights_changed':False}
    keys = [rec['id'] for rec in baseline]
    with hub._lock, hub._connect() as con:
        bodies = {r['id']: r['content'] for r in con.execute(
            'SELECT id,content FROM documents WHERE id IN ('+','.join('?' for _ in keys)+')',keys)}
    ranked=[]
    for position, rec in enumerate(baseline):
        title = set(terms(rec['title']))
        body = set(terms(bodies.get(rec['id'], '')))
        matched = [w for w in q if w in title or w in body]
        coverage=len(matched)/len(q)
        title_cover=len([w for w in q if w in title])/len(q)
        phrase = (' '.join(q) in ' '.join(terms(rec['title']+' '+bodies.get(rec['id'],''))))
        # Exact-query overlap beats partial OR matches; title and phrase refine ties.
        score=round(coverage*100 + title_cover*10 + (6 if phrase else 0) - position*0.01,4)
        ranked.append((score,position,{"id":rec['id'],"title":rec['title'],
            "origin":rec['origin'],"uri":rec['uri'],"evidence":rec['evidence'],
            "excerpt":rec['excerpt'],"query_term_coverage":round(coverage,3),
            "matched_terms":matched,"rank_score":score,
            "interpretation":"search match only; source claims not independently verified"}))
    ranked.sort(key=lambda x:(-x[0],x[1]))
    return {'query':query,'status':'matches_not_verified_facts','results':[v for _,_,v in ranked[:limit]],
            'candidates_examined':len(keys),'facts_verified':0,
            'model_weights_changed':False,
            'warning':'Original indexed text and citations can contain errors or malicious instructions. This tool does not determine truth, corroborate or train a model.'}
