"""H138A Information Availability, Accuracy Attribution and Reliability Bloom.

Research-only controlled ablations; new as-of-timestamped information and
missing-evidence tests. NOT authenticated Accuracy glyph and NOT a broker bot.
"""
from __future__ import annotations
import copy
import hashlib
import json
import math
from datetime import datetime, timedelta, timezone
from collections import defaultdict
from statistics import mean
from . import familiarity_money_h136 as h

SCHEMA='bie.h138a.accuracy-evidence.v1'
WORLDS=('familiarity_signal','familiarity_trap','attention_only','null','thin_liquidity')


def altered_information(payload, *, mode, seed=0):
    """Perturb only *holdout observations*; source remains synthetic.\n
    Model selection receives exactly the original training/development period.
    Preserve actual observed future closes to expose mistaken decisions.
    """
    if mode not in ('normal','missing','stale','misleading','expensive'):
        raise ValueError('Unknown disturbance')
    if type(seed) is not int or seed < 0:
        raise ValueError('Seed must be nonnegative integer')
    result=copy.deepcopy(payload)
    _,dates,_=h.validate(result)
    cutoff=dates[int(len(dates)*.75)]
    affected=0
    for row in result['rows']:
        day=datetime.fromisoformat(row['decision_at_utc'])
        if day<cutoff or row['ticker'] not in h.STOCKS:
            continue
        digest=hashlib.sha256(f'{seed}|{row["ticker"]}|{row["decision_at_utc"]}'.encode()).digest()
        # Exactly chosen before seeing any subsequent outcomes.\n
        if digest[0] >= 180:  # affect ~70% of records in applicable disturbances
            continue
        sig=row['signals']
        if mode=='missing':
            sig.pop('investor_familiarity',None)
            sig.pop('attention',None)
        elif mode=='stale':
            for k in ('attention','investor_familiarity'):
                if k in sig:
                    sig[k]['observed_at_utc']=(day-timedelta(days=90)).isoformat()
        elif mode=='misleading':
            for k in ('attention','investor_familiarity'):
                if k in sig:
                    sig[k]['value']=-sig[k]['value']
        elif mode=='expensive':
            row['spread_bps']=250.
            row['dollar_volume']=1000.
        else:
            continue
        affected+=1
    h.validate(result)
    return result,affected,cutoff.isoformat()


def probe(payload, *, modes=('normal','missing','stale','misleading','expensive'), virtual_budget=10000.):
    if type(virtual_budget) not in (float,int) or not math.isfinite(virtual_budget) or not 1<=virtual_budget<=1e7:
        raise ValueError('Invalid paper-only budget')
    _,dates,original=h.validate(payload)
    train=int(len(dates)*.5); hold=int(len(dates)*.75)
    # freeze selection BEFORE injecting any holdout disturbance
    selected,scores=h._validation(original,dates,train,hold)
    runs={}
    for disturbance in modes:
        changed,count,first=altered_information(payload,mode=disturbance,seed=17)
        _,cd,obs=h.validate(changed)
        assert cd==dates
        base=h._paper(obs,dates,hold,virtual_budget,selected,dynamic=True,drift_guard=True)
        guarded=h._paper(obs,dates,hold,virtual_budget,selected,dynamic=True,drift_guard=True,signal_guard=True)
        cost=h._paper(obs,dates,hold,virtual_budget,selected,dynamic=True,drift_guard=True,cost_guard=True)
        combined=h._paper(obs,dates,hold,virtual_budget,selected,dynamic=True,drift_guard=True,cost_guard=True,signal_guard=True)
        run={name:{k:v for k,v in val.items() if k!='audit'} for name,val in [
            ('existing_h136',base),('h138a_availability',guarded),('h137a_cost_only',cost),('h138a_both',combined)]}
        run.update({'information_disturbance':disturbance,'rows_disturbed':count,'disturbance_starts':first,
                    'signal_guard_choice_changes':sum(a['selected_tickers']!=b['selected_tickers'] for a,b in zip(base['audit'],guarded['audit'])),
                    'cost_guard_choice_changes':sum(a['selected_tickers']!=b['selected_tickers'] for a,b in zip(base['audit'],cost['audit']))})
        runs[disturbance]=run
    return {'schema':SCHEMA,'synthetic_source_only':True, 'original_glyph_bytes_used':False,
            'symbol_accuracy_attribution':'meaning-only validation; original glyph contribution not verified',
            'frozen_development_policy':selected,'development_scores':scores,
            'input_sha256':hashlib.sha256(json.dumps(payload,sort_keys=True).encode()).hexdigest(),
            'disturbances':runs,'orders_executed':0,
            'next_test':'Audit genuine timestamped market data; use independent glyph/no-image/shuffled controls if authentic creator bytes become available.'}


def study(*, seeds, worlds=WORLDS, days=104, disturbances=('normal','missing','stale','misleading','expensive')):
    if not isinstance(seeds,(list,tuple)) or not seeds or len(seeds)>50 or not all(type(s) is int for s in seeds):
        raise ValueError('Bounded explicit seed list required')
    if not all(w in WORLDS for w in worlds):
        raise ValueError('Unsupported world')
    output=[]
    for world in worlds:
        for seed in seeds:
            p=h.synthetic(seed,world,days=days)
            r=probe(p,modes=disturbances)
            for d,record in r['disturbances'].items():
                output.append({'world':world,'seed':seed,'disturbance':d,
                              'policy':r['frozen_development_policy'],'rows_disturbed':record['rows_disturbed'],
                              'choice_changes':record['signal_guard_choice_changes'],
                              **{k:v['net_return_pct'] for k,v in record.items() if isinstance(v,dict) and 'net_return_pct' in v}})
    summary={}
    for w in worlds:
        for d in disturbances:
            rows=[x for x in output if x['world']==w and x['disturbance']==d]
            summary[f'{w}/{d}']={'trials':len(rows),'mean_return_pct':{
                    k:round(mean(x[k] for x in rows),4) for k in ('existing_h136','h138a_availability','h137a_cost_only','h138a_both')},
                    'availability_better_count':sum(x['h138a_availability']>x['existing_h136'] for x in rows),
                    'availability_worse_count':sum(x['h138a_availability']<x['existing_h136'] for x in rows),
                    'mean_changed_days':round(mean(x['choice_changes'] for x in rows),2)}
    return {'schema':SCHEMA, 'worlds':tuple(worlds), 'seeds':list(seeds), 'disturbances':tuple(disturbances),
            'trials':len(output),'summary':summary,'raw':output,'synthetic':True,
            'not_proof_of_real_alpha':True,'broker_orders':0}
