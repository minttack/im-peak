from __future__ import annotations

from dataclasses import asdict, dataclass
import os
from pathlib import Path
import re
import sys

PACKAGE = Path(__file__).resolve().parent.parent


def state_root() -> Path:
    override = os.environ.get("BIE_ASSISTANT_HOME")
    if override:
        return Path(override).expanduser().resolve()
    if sys.platform == "win32":
        return Path(os.environ.get("LOCALAPPDATA", str(Path.home()))) / "BIE_Experience_AI" / "assistant_v25"
    return Path.home() / ".local" / "share" / "bie_experience_ai" / "assistant_v25"


@dataclass(frozen=True)
class Budget:
    rounds: int = 32
    seconds: int = 900
    tool_calls: int = 64
    output_tokens: int = 4096
    context_chars: int = 24000
    model_context: int = 8192

    def __post_init__(self):
        limits = {"rounds": (1, 64), "seconds": (5, 3600), "tool_calls": (1, 128),
                  "output_tokens": (128, 16384), "context_chars": (2000, 64000),
                  "model_context": (2048, 32768)}
        for name, (low, high) in limits.items():
            value = getattr(self, name)
            if type(value) is not int or not low <= value <= high:
                raise ValueError(f"{name} must be an integer from {low} to {high}")

    def to_dict(self):
        return asdict(self)


PROFILES = {
    "Quick": Budget(4, 90, 8, 1024, 8000, 4096),
    "Balanced": Budget(12, 300, 24, 2048, 16000, 8192),
    "Burst": Budget(),
    "Deep": Budget(48, 2400, 96, 8192, 48000, 16384),
}


def valid_model(model: str) -> str:
    if not isinstance(model, str) or not re.fullmatch(r"[a-zA-Z0-9][\w.\-/:]{0,110}", model):
        raise ValueError("Use an installed Ollama model name.")
    return model
