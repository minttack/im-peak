"""Explicit, read-only import of the user's earlier Desktop v1 notes and messages."""
from __future__ import annotations

import hashlib
from pathlib import Path
import sqlite3


def import_v1(store, source):
    path = Path(source).expanduser().resolve()
    if path == store.path or not path.is_file():
        raise ValueError("Select the earlier bie_ai_conversations.sqlite3 file")
    source_hash = hashlib.sha256(path.read_bytes()).hexdigest()
    with store.db() as con:
        previous = con.execute("SELECT count FROM imports WHERE source_hash=?", (source_hash,)).fetchone()
        if previous:
            return {"imported": 0, "already_imported": previous[0]}
    # The old archive's audit implementation is used to verify content before accepting it.
    from .native import original_desktop
    old = original_desktop().ConversationStore.__new__(original_desktop().ConversationStore)
    old.home, old.path = path.parent, path
    audit = old.check_events()
    if not audit.get("passed"):
        raise ValueError("Desktop v1 conversation audit failed; import stopped")
    con = sqlite3.connect(path.as_uri() + "?mode=ro", uri=True)
    try:
        notes = con.execute("SELECT id,created_at,content FROM notes ORDER BY id").fetchall()
        messages = con.execute("SELECT id,role,content,domain FROM messages ORDER BY id").fetchall()
    finally:
        con.close()
    # Each item has a stable source identity so a partially completed import can resume.
    count = 0
    for ident, stamp, body in notes:
        source_id = f"desktop_v1:{source_hash}:note:{ident}"
        with store.db() as check:
            found = check.execute("SELECT 1 FROM memories WHERE source=?", (source_id,)).fetchone()
        if not found:
            store.remember(body, source=source_id, subject="Imported v1 note", status="unverified")
            count += 1
    for ident, role, content, domain in messages:
        imported_task = f"v1-import:{source_hash}:{ident}"
        if not store.recent(imported_task, 1):
            store.message(imported_task, role, content)
            count += 1
    with store.db(write=True) as target:
        store._event(target, "import", source_hash, {"source_name": path.name, "notes": len(notes), "messages": len(messages)})
        target.execute("INSERT OR IGNORE INTO imports VALUES(?,?,?)", (source_hash, path.name, len(notes) + len(messages)))
    return {"imported": count, "old_audit": audit, "source_unchanged": True}
