"""Durable memory, task checkpoints, provenance and chronological receipts.

Each operation owns a connection. BEGIN IMMEDIATE serializes writers across
processes; read transactions see a consistent snapshot. No model weights change.
"""
from __future__ import annotations

from contextlib import contextmanager
import hashlib
import json
import math
from pathlib import Path
import re
import sqlite3
import time
import uuid


def canonical(value) -> str:
    return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":"), allow_nan=False)


def digest(value) -> str:
    return hashlib.sha256(canonical(value).encode()).hexdigest()


def text(value, name, limit, minimum=1):
    if not isinstance(value, str) or not minimum <= len(value.strip()) <= limit:
        raise ValueError(f"{name} must be {minimum}–{limit} characters")
    return value.strip()


class Store:
    def __init__(self, home: Path):
        self.home = Path(home).resolve()
        self.home.mkdir(parents=True, exist_ok=True)
        self.path = self.home / "assistant.sqlite3"
        with self.db(write=True) as con:
            con.executescript("""
                CREATE TABLE IF NOT EXISTS events(
                    seq INTEGER PRIMARY KEY, stamp REAL NOT NULL, kind TEXT NOT NULL,
                    entity TEXT NOT NULL, payload TEXT NOT NULL, prior TEXT NOT NULL, hash TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS memories(
                    id TEXT PRIMARY KEY, scope TEXT NOT NULL, subject TEXT NOT NULL,
                    body TEXT NOT NULL, source TEXT NOT NULL, confidence REAL NOT NULL,
                    status TEXT NOT NULL, created_seq INTEGER NOT NULL, retired_seq INTEGER,
                    supersedes TEXT, content_hash TEXT NOT NULL);
                CREATE INDEX IF NOT EXISTS memory_scope ON memories(scope, created_seq, retired_seq);
                CREATE VIRTUAL TABLE IF NOT EXISTS memory_fts USING fts5(id UNINDEXED, subject, body);
                CREATE TABLE IF NOT EXISTS messages(
                    id TEXT PRIMARY KEY, task_id TEXT NOT NULL, role TEXT NOT NULL,
                    content TEXT NOT NULL, seq INTEGER NOT NULL, content_hash TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS tasks(
                    id TEXT PRIMARY KEY, goal TEXT NOT NULL, workspace TEXT NOT NULL,
                    options TEXT NOT NULL, status TEXT NOT NULL, created REAL NOT NULL,
                    updated REAL NOT NULL, owner TEXT, lease REAL, round INTEGER NOT NULL DEFAULT 0,
                    calls INTEGER NOT NULL DEFAULT 0, checkpoint TEXT NOT NULL DEFAULT '[]',
                    output TEXT NOT NULL DEFAULT '', error TEXT NOT NULL DEFAULT '',
                    cancel INTEGER NOT NULL DEFAULT 0, last_seq INTEGER);
                CREATE INDEX IF NOT EXISTS task_status ON tasks(status, created);
                CREATE TABLE IF NOT EXISTS receipts(
                    id TEXT PRIMARY KEY, task_id TEXT NOT NULL, tool TEXT NOT NULL,
                    args_hash TEXT NOT NULL, ok INTEGER NOT NULL, result TEXT NOT NULL,
                    elapsed_ms REAL NOT NULL, seq INTEGER NOT NULL, result_hash TEXT NOT NULL);
                CREATE INDEX IF NOT EXISTS receipt_tool ON receipts(tool, seq);
                CREATE TABLE IF NOT EXISTS imports(
                    source_hash TEXT PRIMARY KEY, source TEXT NOT NULL, count INTEGER NOT NULL);
            """)

    @contextmanager
    def db(self, write=False):
        con = sqlite3.connect(self.path, timeout=20, isolation_level=None)
        con.row_factory = sqlite3.Row
        con.execute("PRAGMA busy_timeout=20000")
        con.execute("PRAGMA journal_mode=WAL")
        con.execute("PRAGMA synchronous=FULL")
        con.execute("BEGIN IMMEDIATE" if write else "BEGIN")
        try:
            yield con
            con.commit()
        except BaseException:
            con.rollback()
            raise
        finally:
            con.close()

    def _event(self, con, kind, entity, payload):
        last = con.execute("SELECT hash FROM events ORDER BY seq DESC LIMIT 1").fetchone()
        prior = last[0] if last else "GENESIS"
        stamp = time.time()
        hh = digest([stamp, kind, entity, payload, prior])
        cur = con.execute("INSERT INTO events(stamp,kind,entity,payload,prior,hash) VALUES(?,?,?,?,?,?)",
                          (stamp, kind, entity, canonical(payload), prior, hh))
        return cur.lastrowid

    def head(self):
        with self.db() as con:
            return con.execute("SELECT COALESCE(MAX(seq),0) FROM events").fetchone()[0]

    def remember(self, body, *, source="user", scope="personal", subject="note",
                 confidence=0.5, status="unverified", supersedes=None):
        body = text(body, "Memory", 12000)
        source = text(source, "Source", 500)
        scope = text(scope, "Scope", 200)
        subject = text(subject, "Subject", 200)
        if type(confidence) not in (int, float) or not math.isfinite(confidence) or not 0 <= confidence <= 1:
            raise ValueError("Confidence must be finite and between 0 and 1")
        confidence = float(confidence)
        if status not in {"unverified", "hypothesis", "observed", "corrected"}:
            raise ValueError("Invalid evidence status")
        mid = uuid.uuid4().hex
        item = dict(id=mid, scope=scope, subject=subject, body=body, source=source,
                    confidence=confidence, status=status, supersedes=supersedes)
        with self.db(write=True) as con:
            if supersedes:
                old = con.execute("SELECT * FROM memories WHERE id=?", (supersedes,)).fetchone()
                if not old or old["scope"] != scope or old["subject"] != subject or old["retired_seq"]:
                    raise ValueError("Correction must refer to an active memory of the same scope and subject")
            seq = self._event(con, "memory", mid, item)
            con.execute("INSERT INTO memories VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                        (mid, scope, subject, body, source, confidence, status, seq, None, supersedes, digest(item)))
            con.execute("INSERT INTO memory_fts VALUES(?,?,?)", (mid, subject, body))
            if supersedes:
                con.execute("UPDATE memories SET retired_seq=? WHERE id=?", (seq, supersedes))
        return {**item, "created_seq": seq}

    def recall(self, query, *, scope=None, limit=8, before=None):
        if not isinstance(query, str) or len(query) > 12000:
            raise ValueError("Invalid memory query")
        if type(limit) is not int or not 1 <= limit <= 100:
            raise ValueError("Memory limit must be 1–100")
        words = list(dict.fromkeys(re.findall(r"\w+", query, re.UNICODE)))[:24]
        match = " OR ".join('"' + word.replace('"', '""') + '"' for word in words)
        with self.db() as con:
            cutoff = before if before is not None else con.execute("SELECT COALESCE(MAX(seq),0)+1 FROM events").fetchone()[0]
            if type(cutoff) is not int or cutoff < 0:
                raise ValueError("Invalid chronology cutoff")
            args = []
            if match:
                sql = "SELECT m.*, bm25(memory_fts) AS relevance FROM memory_fts JOIN memories m ON m.id=memory_fts.id WHERE memory_fts MATCH ?"
                args.append(match)
            else:
                sql = "SELECT m.*, 0 AS relevance FROM memories m WHERE 1=1"
            sql += " AND m.created_seq < ? AND (m.retired_seq IS NULL OR m.retired_seq >= ?)"
            args.extend((cutoff, cutoff))
            if scope is not None:
                sql += " AND m.scope=?"
                args.append(scope)
            sql += " ORDER BY relevance ASC,m.created_seq DESC LIMIT ?"
            args.append(limit)
            return [dict(r) for r in con.execute(sql, args)]

    def message(self, task_id, role, content):
        if role not in {"user", "assistant", "tool"}:
            raise ValueError("Invalid message role")
        content = text(content, "Message", 150000)
        item = dict(task_id=task_id, role=role, content=content)
        mid = uuid.uuid4().hex
        with self.db(write=True) as con:
            seq = self._event(con, "message", mid, item)
            con.execute("INSERT INTO messages VALUES(?,?,?,?,?,?)", (mid, task_id, role, content, seq, digest(item)))

    def recent(self, task_id=None, limit=20):
        with self.db() as con:
            if task_id:
                rows = con.execute("SELECT * FROM messages WHERE task_id=? ORDER BY seq DESC LIMIT ?", (task_id, limit)).fetchall()
            else:
                rows = con.execute("SELECT * FROM messages ORDER BY seq DESC LIMIT ?", (limit,)).fetchall()
            return [dict(r) for r in rows[::-1]]

    def conversation(self, workspace, limit=8):
        with self.db() as con:
            rows = con.execute("""SELECT m.role,m.content FROM messages m JOIN tasks t ON t.id=m.task_id
                               WHERE t.workspace=? AND m.role IN ('user','assistant')
                               ORDER BY m.seq DESC LIMIT ?""", (str(workspace), limit)).fetchall()
            return [dict(r) for r in rows[::-1]]

    def _task_event(self, con, tid, reason):
        row = dict(con.execute("SELECT * FROM tasks WHERE id=?", (tid,)).fetchone())
        row.pop("last_seq")
        seq = self._event(con, "task", tid, {"reason": reason, "snapshot": row})
        con.execute("UPDATE tasks SET last_seq=? WHERE id=?", (seq, tid))

    def enqueue(self, goal, workspace, options):
        goal = text(goal, "Goal", 24000)
        tid = uuid.uuid4().hex
        stamp = time.time()
        with self.db(write=True) as con:
            con.execute("INSERT INTO tasks(id,goal,workspace,options,status,created,updated) VALUES(?,?,?,?,?,?,?)",
                        (tid, goal, str(Path(workspace).resolve()), canonical(options), "queued", stamp, stamp))
            self._task_event(con, tid, "created")
        return tid

    def task(self, tid):
        with self.db() as con:
            row = con.execute("SELECT * FROM tasks WHERE id=?", (tid,)).fetchone()
            if not row:
                raise KeyError("Unknown task")
            return dict(row)

    def tasks(self, limit=100):
        with self.db() as con:
            return [dict(r) for r in con.execute("SELECT * FROM tasks ORDER BY created DESC LIMIT ?", (limit,))]

    def claim(self, *, task_id=None, lease_seconds=60):
        owner = uuid.uuid4().hex
        stamp = time.time()
        with self.db(write=True) as con:
            expired = con.execute("SELECT id FROM tasks WHERE status='running' AND lease<?", (stamp,)).fetchall()
            for r in expired:
                con.execute("UPDATE tasks SET status='paused',owner=NULL,lease=NULL,updated=?,error=? WHERE id=?",
                            (stamp, "Interrupted worker; resume explicitly from the saved checkpoint.", r[0]))
                self._task_event(con, r[0], "expired lease; no automatic side-effect replay")
            sql = """SELECT t.* FROM tasks t WHERE t.status='queued' AND t.cancel=0
                     AND NOT EXISTS (SELECT 1 FROM tasks other WHERE other.workspace=t.workspace AND other.status='running')"""
            args = []
            if task_id:
                sql += " AND t.id=?"
                args.append(task_id)
            row = con.execute(sql + " ORDER BY t.created LIMIT 1", args).fetchone()
            if not row:
                return None
            con.execute("UPDATE tasks SET status='running',owner=?,lease=?,updated=?,error='' WHERE id=?",
                        (owner, stamp + lease_seconds, stamp, row["id"]))
            self._task_event(con, row["id"], "claimed")
            return dict(con.execute("SELECT * FROM tasks WHERE id=?", (row["id"],)).fetchone())

    def renew(self, tid, owner, lease_seconds=60):
        with self.db(write=True) as con:
            cur = con.execute("UPDATE tasks SET lease=? WHERE id=? AND owner=? AND status='running'",
                              (time.time() + lease_seconds, tid, owner))
            # Heartbeats are volatile coordination fields, excluded from stable snapshot audit.
            return cur.rowcount == 1

    def checkpoint(self, tid, owner, *, messages, round_number, calls, status="running", output="", error=""):
        if status not in {"running", "paused", "waiting", "done", "failed", "cancelled"}:
            raise ValueError("Invalid task status")
        with self.db(write=True) as con:
            row = con.execute("SELECT * FROM tasks WHERE id=?", (tid,)).fetchone()
            if not row or row["owner"] != owner or row["status"] != "running":
                raise RuntimeError("Worker no longer owns this task")
            con.execute("""UPDATE tasks SET checkpoint=?,round=?,calls=?,status=?,output=?,error=?,updated=?,
                         owner=?,lease=? WHERE id=?""",
                        (canonical(messages), round_number, calls, status, output, error, time.time(),
                         owner if status == "running" else None, row["lease"] if status == "running" else None, tid))
            self._task_event(con, tid, "checkpoint")

    def resume(self, tid):
        with self.db(write=True) as con:
            row = con.execute("SELECT status FROM tasks WHERE id=?", (tid,)).fetchone()
            if not row or row[0] not in {"paused", "failed", "waiting", "cancelled"}:
                raise ValueError("Only paused, failed, waiting or cancelled tasks can resume")
            con.execute("UPDATE tasks SET status='queued',cancel=0,error='',updated=? WHERE id=?", (time.time(), tid))
            self._task_event(con, tid, "resumed")

    def set_execution(self, tid, enabled):
        if type(enabled) is not bool:
            raise ValueError("Execution capability must be a boolean")
        with self.db(write=True) as con:
            row = con.execute("SELECT options,status FROM tasks WHERE id=?", (tid,)).fetchone()
            if not row or row["status"] not in {"waiting", "paused", "failed", "cancelled", "queued"}:
                raise ValueError("Cannot change capabilities of an active or completed task")
            options = json.loads(row["options"])
            options["allow_exec"] = enabled
            con.execute("UPDATE tasks SET options=?,updated=? WHERE id=?", (canonical(options), time.time(), tid))
            self._task_event(con, tid, "user changed project execution capability")

    def cancel(self, tid):
        with self.db(write=True) as con:
            row = con.execute("SELECT status FROM tasks WHERE id=?", (tid,)).fetchone()
            if not row:
                raise KeyError("Unknown task")
            if row[0] in {"done", "failed", "cancelled"}:
                return
            status = "running" if row[0] == "running" else "cancelled"
            con.execute("UPDATE tasks SET cancel=1,status=?,updated=? WHERE id=?", (status, time.time(), tid))
            self._task_event(con, tid, "cancel requested")

    def receipt(self, call_id, task_id, tool, args, result, elapsed_ms, ok):
        if type(elapsed_ms) not in (int, float) or not math.isfinite(elapsed_ms) or elapsed_ms < 0:
            raise ValueError("Elapsed time must be finite and nonnegative")
        elapsed_ms = float(elapsed_ms)
        item = dict(task_id=task_id, tool=tool, args_hash=digest(args), ok=int(ok),
                    result=result, elapsed_ms=elapsed_ms)
        with self.db(write=True) as con:
            seq = self._event(con, "tool", call_id, item)
            con.execute("INSERT INTO receipts VALUES(?,?,?,?,?,?,?,?,?)",
                        (call_id, task_id, tool, item["args_hash"], int(ok), canonical(result), elapsed_ms, seq, digest(item)))

    def prior_receipt(self, call_id, tool, args):
        with self.db() as con:
            row = con.execute("SELECT * FROM receipts WHERE id=?", (call_id,)).fetchone()
            if not row:
                return None
            if row["tool"] != tool or row["args_hash"] != digest(args):
                raise ValueError("Action identifier reused with different arguments")
            return json.loads(row["result"])

    def performance(self, limit=200):
        with self.db() as con:
            rows = [dict(r) for r in con.execute("SELECT tool,ok,elapsed_ms,seq FROM receipts ORDER BY seq DESC LIMIT ?", (limit,))]
        groups = {}
        for r in rows:
            group = groups.setdefault(r["tool"], {"calls": 0, "passed": 0, "elapsed_ms": []})
            group["calls"] += 1
            group["passed"] += r["ok"]
            group["elapsed_ms"].append(r["elapsed_ms"])
        for g in groups.values():
            vals = sorted(g.pop("elapsed_ms"))
            g["median_ms"] = vals[len(vals) // 2]
            g["p95_ms"] = vals[min(len(vals) - 1, math.ceil(len(vals) * .95) - 1)]
        return {"tools": groups, "recent": rows, "scope": "measured local tool calls; not GPU or model intelligence"}

    def experience(self, workspace, before=None):
        with self.db() as con:
            cutoff = self.head() + 1 if before is None else before
            rows = con.execute("""SELECT r.tool,r.ok,r.elapsed_ms,r.seq,r.result FROM receipts r
                               JOIN tasks t ON t.id=r.task_id WHERE t.workspace=? AND r.seq<?
                               ORDER BY r.seq DESC LIMIT 30""", (str(workspace), cutoff)).fetchall()
        outcomes = {}
        for r in rows:
            item = outcomes.setdefault(r["tool"], {"observations": 0, "failures": 0, "durations_ms": [], "latest_error": None})
            item["observations"] += 1
            item["failures"] += not r["ok"]
            item["durations_ms"].append(r["elapsed_ms"])
            if not r["ok"] and item["latest_error"] is None:
                result = json.loads(r["result"])
                item["latest_error"] = str(result.get("error", result.get("data", {})))[:300]
        for item in outcomes.values():
            values = sorted(item.pop("durations_ms"))
            item["predicted_ms_from_recent_median"] = values[len(values)//2]
        return {"project_scoped_tool_outcomes": outcomes, "before_event": cutoff,
                "uncertainty": "Sparse local observations; do not generalize across projects, models or machines."}

    def audit(self):
        with self.db() as con:
            prev = "GENESIS"
            count = 0
            for row in con.execute("SELECT * FROM events ORDER BY seq"):
                count += 1
                payload = json.loads(row["payload"])
                if row["seq"] != count or row["prior"] != prev or row["hash"] != digest([row["stamp"], row["kind"], row["entity"], payload, prev]):
                    return {"passed": False, "reason": "Event chain changed", "at": row["seq"]}
                prev = row["hash"]
            for table, kind, seq_field in (("memories", "memory", "created_seq"), ("messages", "message", "seq"), ("receipts", "tool", "seq")):
                for row in con.execute(f"SELECT * FROM {table}"):
                    event = con.execute("SELECT * FROM events WHERE seq=?", (row[seq_field],)).fetchone()
                    if not event or event["kind"] != kind or event["entity"] != row["id"]:
                        return {"passed": False, "reason": f"Untracked {table} row"}
                    payload = json.loads(event["payload"])
                    if kind == "memory":
                        current = {k: row[k] for k in ("id", "scope", "subject", "body", "source", "confidence", "status", "supersedes")}
                        expected_retirement = con.execute("SELECT MIN(created_seq) FROM memories WHERE supersedes=?", (row["id"],)).fetchone()[0]
                        if row["retired_seq"] != expected_retirement:
                            return {"passed": False, "reason": "Memory correction history changed"}
                    elif kind == "message":
                        current = {k: row[k] for k in ("task_id", "role", "content")}
                    else:
                        current = {k: row[k] for k in ("task_id", "tool", "args_hash", "ok", "elapsed_ms")}
                        current["result"] = json.loads(row["result"])
                    field = "result_hash" if kind == "tool" else "content_hash"
                    if current != payload or digest(current) != row[field]:
                        return {"passed": False, "reason": f"Modified {table} content"}
                if con.execute(f"SELECT count(*) FROM {table}").fetchone()[0] != con.execute("SELECT count(*) FROM events WHERE kind=?", (kind,)).fetchone()[0]:
                    return {"passed": False, "reason": f"Missing {table} row"}
            for row in con.execute("SELECT * FROM tasks"):
                event = con.execute("SELECT payload FROM events WHERE seq=? AND entity=? AND kind='task'", (row["last_seq"], row["id"])).fetchone()
                if not event:
                    return {"passed": False, "reason": "Task has no snapshot"}
                current = dict(row)
                current.pop("last_seq")
                expected = json.loads(event[0])["snapshot"]
                current.pop("lease")
                expected.pop("lease")
                if current != expected:
                    return {"passed": False, "reason": "Task checkpoint changed"}
            if con.execute("SELECT count(*) FROM tasks").fetchone()[0] != con.execute("SELECT count(DISTINCT entity) FROM events WHERE kind='task'").fetchone()[0]:
                return {"passed": False, "reason": "Missing task row"}
            fts_rows = con.execute("SELECT id,subject,body FROM memory_fts ORDER BY id").fetchall()
            mem_rows = con.execute("SELECT id,subject,body FROM memories ORDER BY id").fetchall()
            if [tuple(r) for r in fts_rows] != [tuple(r) for r in mem_rows]:
                return {"passed": False, "reason": "Memory index mismatch"}
        return {"passed": True, "events": count, "head": prev,
                "limitation": "Local hash chains are not signatures and cannot defeat rewriting the entire database."}
