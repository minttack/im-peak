"""BIE THRIVES Growth Ledger: explicit, precommitted, evidence-weighted learning.

No network, model-weight edits, automatic experiments, permission changes or
hidden promotions. All reported results remain user-supplied evidence until
independently checked. SQLite journal is append-only at the application layer.
"""
from __future__ import annotations

from contextlib import contextmanager
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import random
import sqlite3
import uuid


def canonical(obj):
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False)


def digest(s):
    return hashlib.sha256(s.encode("utf-8")).hexdigest()


def checked_string(v, name, length=300):
    if not isinstance(v, str) or not v.strip() or len(v) > length or "\x00" in v:
        raise ValueError(f"{name} must be nonempty plain text <= {length} characters")
    return v.strip()


def probability(v, name):
    if isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v) or not 0 <= v <= 1:
        raise ValueError(f"{name} must be a probability between 0 and 1")
    return float(v)


def read_packet(path):
    path = Path(path)
    if not path.is_file() or path.stat().st_size > 16384:
        raise ValueError("Prediction JSON must be an existing file <= 16 KiB")
    obj = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(obj, dict):
        raise ValueError("Prediction JSON must be an object")
    return obj


class GrowthLedger:
    """A separate journal under BIE's existing --home folder; no old DB migration."""

    def __init__(self, home):
        self.home = Path(home).expanduser().resolve()
        self.home.mkdir(parents=True, exist_ok=True)
        self.database = self.home / "growth_ledger_v33.sqlite3"
        with self._db() as db:
            db.execute("""CREATE TABLE IF NOT EXISTS growth_events (
                seq INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT NOT NULL,
                ident TEXT NOT NULL, payload TEXT NOT NULL,
                prior_hash TEXT NOT NULL, event_hash TEXT NOT NULL,
                recorded_utc TEXT NOT NULL)""")
            db.execute("CREATE INDEX IF NOT EXISTS idx_growth_ident ON growth_events(ident)")

    @contextmanager
    def _db(self):
        db = sqlite3.connect(self.database, timeout=15)
        db.execute("PRAGMA busy_timeout=15000")
        try:
            yield db
            db.commit()
        except BaseException:
            db.rollback()
            raise
        finally:
            db.close()

    @staticmethod
    def _events(db):
        return db.execute("SELECT seq, kind, ident, payload, prior_hash, event_hash, recorded_utc FROM growth_events ORDER BY seq").fetchall()

    @staticmethod
    def _state(rows):
        state = {}
        for _, kind, ident, body, _, _, _ in rows:
            payload = json.loads(body)
            if kind == "prediction":
                if ident in state:
                    raise ValueError("Duplicate prediction in journal")
                state[ident] = {"id": ident, **payload, "resolution": None, "invalidated": False}
            elif kind == "resolution":
                if ident not in state or state[ident]["resolution"] is not None:
                    raise ValueError("Orphan/duplicate resolution")
                state[ident]["resolution"] = payload
            elif kind == "invalidate":
                if ident not in state or state[ident]["invalidated"]:
                    raise ValueError("Orphan/duplicate invalidation")
                state[ident]["invalidated"] = True
                state[ident]["invalid_reason"] = payload["reason"]
            else:
                raise ValueError("Unknown growth event")
        return state

    @staticmethod
    def _audit_rows(rows):
        prior = "0" * 64
        last_seq = 0
        for seq, kind, ident, body, prior_hash, event_hash, stamp in rows:
            if seq <= last_seq or prior_hash != prior:
                return {"passed": False, "reason": f"Broken chain at event {seq}"}
            expected = digest(canonical({"seq": seq, "kind": kind, "id": ident,
                                         "payload": json.loads(body), "prior": prior, "utc": stamp}))
            if event_hash != expected:
                return {"passed": False, "reason": f"Changed record at event {seq}"}
            prior, last_seq = event_hash, seq
        try:
            GrowthLedger._state(rows)
        except (ValueError, KeyError, TypeError) as ex:
            return {"passed": False, "reason": str(ex)}
        return {"passed": True, "events": len(rows), "tip_sha256": prior,
                "limitation": "Hash chain detects changes to retained events without recomputing the chain, not suffix truncation; not a secure external timestamp or independent verification"}

    def audit(self):
        with self._db() as db:
            return self._audit_rows(self._events(db))

    def _append(self, kind, ident, payload, *, can_append):
        with self._db() as db:
            db.execute("BEGIN IMMEDIATE")
            rows = self._events(db)
            audit = self._audit_rows(rows)
            if not audit["passed"]:
                raise ValueError("Growth journal audit failed: " + audit["reason"])
            state = self._state(rows)
            can_append(state)
            now = datetime.now(timezone.utc).isoformat()
            prior = rows[-1][5] if rows else "0" * 64
            sequence = rows[-1][0] + 1 if rows else 1
            hash_value = digest(canonical({"seq": sequence, "kind": kind, "id": ident,
                                           "payload": payload, "prior": prior, "utc": now}))
            db.execute("INSERT INTO growth_events(seq, kind, ident, payload, prior_hash, event_hash, recorded_utc) VALUES(?,?,?,?,?,?,?)",
                       (sequence, kind, ident, canonical(payload), prior, hash_value, now))
            return {"id": ident, "event_seq": sequence, "event_sha256": hash_value,
                    "status": "recorded", "claim_validation": "not independently verified"}

    def predict(self, packet):
        """Precommit a prediction *before* the experiment/observation is recorded."""
        if not isinstance(packet, dict):
            raise ValueError("Packet must be a JSON object")
        fields = {key: checked_string(packet.get(key), key, 1200 if key in ("prediction", "source") else 160)
                  for key in ("domain", "context", "strategy", "prediction", "source")}
        fields["probability"] = probability(packet.get("probability"), "probability")
        fields["baseline_probability"] = probability(packet.get("baseline_probability"), "baseline_probability")
        # CHANCE is the list of possibilities; PROBABILITY quantifies one binary event.
        chance_space = packet.get("chance_space", ["event occurs", "event does not occur"])
        if (not isinstance(chance_space, list) or not 2 <= len(chance_space) <= 8):
            raise ValueError("chance_space must contain 2-8 alternatives")
        fields["chance_space"] = [checked_string(x, "possibility", 200) for x in chance_space]
        fields["flux_alternative"] = checked_string(packet.get("flux_alternative", "Baseline or another mechanism"), "flux_alternative", 600)
        fields["verifier_plan"] = checked_string(packet.get("verifier_plan"), "verifier_plan", 1200)
        fields["goal"] = checked_string(packet.get("goal"), "goal", 600)
        fields["uncertainty"] = checked_string(packet.get("uncertainty"), "uncertainty", 600)
        fields["anchor"] = checked_string(packet.get("anchor"), "anchor", 600)
        # A random, frozen holdout allocation made at precommit; users can still select cases.
        ident = uuid.uuid4().hex
        fields["partition"] = "holdout" if int(digest(ident)[:8], 16) % 5 == 0 else "development"
        fields["source_kind"] = "user_supplied_unverified"
        return self._append("prediction", ident, fields, can_append=lambda s: None)

    def resolve(self, ident, outcome, source, evidence_file=None):
        ident = checked_string(ident, "id", 100)
        source = checked_string(source, "outcome_source", 600)
        if type(outcome) is not int or outcome not in (0, 1):
            raise ValueError("Outcome must be 0 or 1")
        evidence = None
        if evidence_file is not None:
            path = Path(evidence_file)
            if not path.is_file() or not 0 <= path.stat().st_size <= 10_000_000:
                raise ValueError("Evidence must be a local file <= 10 MB")
            evidence = {"sha256": hashlib.sha256(path.read_bytes()).hexdigest(), "bytes": path.stat().st_size,
                        "path_label": path.name, "claim": "hash recorded; content not validated"}
        body = {"outcome": outcome, "outcome_source": source, "evidence": evidence,
                "verification": "user_reported_even_if_file_hash_present"}
        def guard(state):
            if ident not in state or state[ident]["resolution"] is not None or state[ident]["invalidated"]:
                raise ValueError("Unknown, already resolved, or invalidated prediction")
        return self._append("resolution", ident, body, can_append=guard)

    def invalidate(self, ident, reason):
        ident = checked_string(ident, "id", 100)
        reason = checked_string(reason, "reason", 600)
        def guard(state):
            if ident not in state or state[ident]["invalidated"]:
                raise ValueError("Unknown or already invalidated prediction")
        return self._append("invalidate", ident, {"reason": reason}, can_append=guard)

    def cases(self):
        with self._db() as db:
            rows = self._events(db)
        audit = self._audit_rows(rows)
        if not audit["passed"]:
            raise ValueError("Growth journal audit failed: " + audit["reason"])
        return list(self._state(rows).values())

    def status(self):
        cases = self.cases()
        return {"version": "v33-candidate", "predictions": len(cases),
                "resolved": sum(x["resolution"] is not None for x in cases),
                "invalidated": sum(x["invalidated"] for x in cases),
                "open": sum(x["resolution"] is None and not x["invalidated"] for x in cases),
                "audit": self.audit(), "automatic_model_updates": False, "automatic_action_permissions": False}

    def review(self, domain, context, strategy):
        domain = checked_string(domain, "domain")
        context = checked_string(context, "context")
        strategy = checked_string(strategy, "strategy")
        rows = [r for r in self.cases() if not r["invalidated"] and r["resolution"] is not None
                and (r["domain"], r["context"], r["strategy"]) == (domain, context, strategy)]
        improvements = [(r["baseline_probability"] - r["resolution"]["outcome"]) ** 2 -
                        (r["probability"] - r["resolution"]["outcome"]) ** 2 for r in rows]
        hold = [d for r, d in zip(rows, improvements) if r["partition"] == "holdout"]
        labels = {r["resolution"]["outcome_source"] for r in rows}
        mean = sum(improvements) / len(improvements) if improvements else None
        h_mean = sum(hold) / len(hold) if hold else None
        ci = None
        if len(hold) >= 4:
            rng = random.Random(2177)
            boot = sorted(sum(rng.choice(hold) for _ in hold) / len(hold) for _ in range(1500))
            ci = [round(boot[74], 6), round(boot[1424], 6)]
        support = len(rows) >= 12 and len(hold) >= 4 and len(labels) >= 2 and ci is not None and ci[0] > 0
        return {"domain": domain, "context": context, "strategy": strategy,
                "matched_resolved_cases": len(rows), "holdout_cases": len(hold),
                "distinct_outcome_source_labels": len(labels),
                "all_mean_brier_improvement_vs_baseline": None if mean is None else round(mean, 6),
                "holdout_mean_brier_improvement": None if h_mean is None else round(h_mean, 6),
                "holdout_bootstrap_interval_descriptive": ci,
                "gate": "candidate_for_external_replication" if support else "insufficient_or_contradictory",
                "promoted": False,
                "limitations": "Retrospective user-entered outcomes and user-selected cases may be biased; the split is only a local software control, not an independent prospective holdout. Never auto-transfer to another context, alter weights, or claim scientific validation."}

    @staticmethod
    def history_cards(goal=""):
        """Bundled retrospective research hints, never counted as prospective results."""
        from .config import PACKAGE
        path = PACKAGE / "examples" / "GROWTH_CONTINUITY_CARDS.json"
        cards = json.loads(path.read_text(encoding="utf-8"))["cards"]
        if goal and goal.strip().casefold() not in {"all", "history", "learning", "what have we learned"}:
            terms = set(goal.casefold().split())
            cards = [c for c in cards if any(t in terms for t in c["domain"].casefold().split())]
        return {"status": "retrospective_unverified_handoff_not_training_data",
                "cards": cards[:7], "auto_integration": False}

    def context_for_goal(self, goal):
        if not isinstance(goal, str):
            return []
        tokens = set(goal.casefold().split())
        if not tokens:
            return []
        groups = sorted({(r["domain"], r["context"], r["strategy"])
                         for r in self.cases()
                         if len(r["domain"]) >= 3 and r["domain"].casefold() in goal.casefold()})
        return [{"reference_only": True, **self.review(*g)} for g in groups[:3]]

    def overview(self):
        cases = self.cases()
        groups = sorted({(r["domain"], r["context"], r["strategy"]) for r in cases})
        return {"counts": self.status(), "comparisons": [self.review(*group) for group in groups[:30]],
                "display_limit": 30, "evidence_trust": "unverified until separately checked"}
