"""H132 auditable paper research on H131's ten-stock universe.

Explicitly NOT a broker, investment adviser, self-modifying LLM or market-price
provider. Synthetic scenarios are diagnostic only. Stock/strategy frozen from
validation by H129 before holdout; never optimize based on the holdout.
"""
from __future__ import annotations
from datetime import date, datetime, timedelta, timezone
import hashlib
import json
import math
from pathlib import Path
import random

from .market_discovery_h129 import Bar, read_ohlcv, evaluate_universe, evaluate as evaluate_strategy, _utility
from .stock_universe_h131 import SEED_STOCKS, BENCHMARKS, from_file as stock_coverage_from_file

SCHEMA = 'bie-universe-experience-h132.1'
TICKERS = tuple(t for t, _, _ in SEED_STOCKS)
WORLDS = ('trend', 'downtrend', 'noise', 'rotation', 'shock')
RESEARCH_LIMIT = 5
COST_BPS = 15.0


def synthetic_world(seed: int, world: str, *, size: int = 300):
    """Simulated correlated yet imperfect daily OHLCV; NEVER price evidence.

    World/seed settings are controls, not optimized to make BIE win.
    """
    if type(seed) is not int or seed < 1 or seed > 10_000_000:
        raise ValueError('seed out of bounded range')
    if world not in WORLDS or size < 180 or size > 1500:
        raise ValueError('world/size unsupported')
    universe = {}
    factor = random.Random(seed * 19 + 47)
    market_shocks = [factor.gauss(0, .008) for _ in range(size)]
    d0 = date(2024, 1, 2)
    for j, ticker in enumerate(TICKERS + BENCHMARKS):
        rng = random.Random(seed * 31 + j * 7919)
        x, bars = 70.0 + 9 * j, []
        for i in range(size):
            if world == 'trend':
                drift = .0008 if j % 3 else .0003
            elif world == 'downtrend':
                drift = -.0011 if j % 3 else -.0005
            elif world == 'rotation':
                drift = (.0013 if j % 2 else -.0005) * (1 if i < int(size*.7) else -1)
            else:
                drift = 0.0
            common = .6 * market_shocks[i]
            shock = rng.gauss(0, .008 if ticker in BENCHMARKS else .012)
            if world == 'shock' and i in (int(size*.55), int(size*.81)):
                shock -= .13
            ret = max(-.20, min(.20, drift + common + shock))
            opening = max(.05, x * (1 + ret))
            closing = max(.05, opening * (1 + rng.gauss(0, .003)))
            high = max(opening, closing) * 1.004
            low = min(opening, closing) * .996
            bars.append(Bar(d0 + timedelta(days=i), ticker, opening, high, low, closing,
                            100_000 + rng.randrange(20_000)))
            x = closing
        universe[ticker] = bars
    return universe


def _market_baselines(all_bars, ticker, market, cost_bps):
    target = all_bars[ticker]
    other = all_bars.get(market)
    if other is None:
        return {'status': 'missing_benchmark', 'ticker': market}
    if len(other) != len(target) or any(a.timestamp != b.timestamp for a, b in zip(other, target)):
        raise ValueError('Benchmark calendars differ; refuse misaligned comparison')
    start = int(len(target)*.78)
    result = evaluate_strategy(other, 'buy_hold', start, len(other)-1, cost_bps)
    return {'status': 'computed', 'ticker': market, 'holdout_buy_hold': result}


def analyze(universe, *, source='synthetic_only', cost_bps=COST_BPS, evidence_path=None, as_of=None):
    if type(universe) is not dict or not all(t in universe for t in TICKERS):
        raise ValueError('Require ALL ten predefined research tickers')
    if type(cost_bps) not in (int, float) or not math.isfinite(cost_bps) or not 0 <= cost_bps <= 1000:
        raise ValueError('Invalid research cost')
    if source != 'synthetic_only' and evidence_path is None:
        coverage = {'status': 'unverified_stock_data_coverage',
                    'detail': 'No H131 timestamped evidence file; performance exploration only'}
    elif evidence_path is not None:
        coverage_report = stock_coverage_from_file(Path(evidence_path), top=RESEARCH_LIMIT)
        coverage = {'status': 'supplied_evidence_not_independently_verified',
                    'selected_research_watchlist': coverage_report['selected_research_watchlist'],
                    'quality_scores_not_profit_forecasts': {
                        c['ticker']: c['data_quality_score_0_100'] for c in coverage_report['candidates']},
                    'source_warning': coverage_report['source_verification']}
    else:
        coverage = {'status': 'synthetic_only_no_data_quality_claim'}
    if as_of is not None:
        if not isinstance(as_of, date) or isinstance(as_of, datetime):
            raise ValueError('as_of must be a YYYY-MM-DD date')
        if as_of > datetime.now(timezone.utc).date():
            raise ValueError('Future as_of date')
        if any(bar.timestamp > as_of for seq in universe.values() for bar in seq):
            raise ValueError('Future bar relative to declared data cutoff')
    for ticker, seq in universe.items():
        if any(a.timestamp >= b.timestamp for a,b in zip(seq, seq[1:])):
            raise ValueError(f'Unsorted/duplicate {ticker} prices')
    # Benchmarks withheld from candidate selection; merely measured on same untouched window.
    study = evaluate_universe({t:universe[t] for t in TICKERS}, source=source, cost_bps=cost_bps)
    winner = study['selection']
    baseline_spy = _market_baselines(universe, winner['ticker'], 'SPY', cost_bps)
    baseline_qqq = _market_baselines(universe, winner['ticker'], 'QQQ', cost_bps)
    comparable = {'own_stock_buy_hold': winner['holdout_buy_hold']['total_return']}
    if baseline_spy['status'] == 'computed':
        comparable['SPY_buy_hold'] = baseline_spy['holdout_buy_hold']['total_return']
    if baseline_qqq['status'] == 'computed':
        comparable['QQQ_buy_hold'] = baseline_qqq['holdout_buy_hold']['total_return']
    hold_return = winner['holdout_metrics']['total_return']
    beat = {name: bool(hold_return > value) for name, value in comparable.items()}
    # First report results, THEN ask what can disprove/probe next, never tune on holdout.
    if not all(beat.values()):
        proposal = {
            'question': 'Why did the validation-selected approach fail at least one baseline?',
            'hypothesis': 'Recent historical patterns may not persist across regimes or cover trading costs',
            'next_test': 'Freeze a new candidate on fresh development data, then test on a NEW future window',
            'falsifier': 'The new candidate has no consistent risk-adjusted advantage against simple baselines',
        }
    else:
        proposal = {
            'question': 'Was the apparent win just favorable randomness or multiple testing?',
            'hypothesis': 'Improved risk-adjusted excess return might transfer to truly unseen market days',
            'next_test': 'Prospective forward paper-trading with identical costs and benchmark comparisons',
            'falsifier': 'Forward results lose their advantage or exceed the predefined drawdown cap',
        }
    # A SHA digest of the exact input bars helps identify old or reused data.
    fingerprint = hashlib.sha256(json.dumps(
        [[t, [[b.timestamp.isoformat(), b.open, b.high, b.low, b.close, b.volume]
              for b in universe[t]]] for t in sorted(universe)], separators=(',', ':')).encode()).hexdigest()
    return {
        'schema': SCHEMA, 'source': source,
        'source_claim': 'Synthetic simulation' if source == 'synthetic_only' else 'User/Codex-supplied unverified historical prices',
        'data_fingerprint_sha256': fingerprint,
        'research_universe': list(TICKERS), 'benchmarks': list(BENCHMARKS),
        'data_coverage': coverage,
        'winner_chosen_without_holdout': {'ticker': winner['ticker'], 'strategy': winner['strategy'],
                                          'validation_utility': winner['validation_utility']},
        'holdout_selected': winner['holdout_metrics'], 'holdout_same_stock_buy_hold': winner['holdout_buy_hold'],
        'holdout_SPY': baseline_spy, 'holdout_QQQ': baseline_qqq,
        'holdout_beat_baselines': beat,
        'development_experiments': study['discovery_count'] - 1,
        'self_questions': len(study['discoveries']),
        'latest_next_experiment': proposal,
        'promotion_status': 'RESEARCH_ONLY — no Robinhood orders, no proven live edge',
        'warnings': [
            'BIE model is not retrained or autonomous in this test; deterministic strategy search.',
            'Holdout results are diagnostics, NOT permission to tune and repeatedly reuse that holdout.',
            'Out-of-sample data of a backtest is not prospective live/paper proof.',
            'Synthetic samples cannot demonstrate a profitable financial model.',
            'Scores of information abundance are not returns or buy recommendations.',
        ],
        'no_live_orders': True,
    }


def audit_csv(csv_path: Path, *, as_of: date, evidence_path=None, cost_bps=COST_BPS):
    if as_of is None:
        raise ValueError('Explicit as-of date required for actual price files')
    by = read_ohlcv(csv_path)
    return analyze(by, source=f'user_supplied_csv:{Path(csv_path).name}',
                   as_of=as_of, evidence_path=evidence_path, cost_bps=cost_bps)


def battery(*, seeds=(7301, 7302), worlds=WORLDS, cost_bps=COST_BPS, size=300):
    if len(seeds) > 10 or not seeds or len(worlds) > 5 or not worlds:
        raise ValueError('bounded seeds/worlds only')
    records = []
    for world in worlds:
        for seed in seeds:
            result = analyze(synthetic_world(seed, world, size=size),
                             source='synthetic_only', cost_bps=cost_bps)
            return_ = result['holdout_selected']['total_return']
            comparisons = result['holdout_beat_baselines']
            records.append({
                'world': world, 'seed': seed,
                'ticker': result['winner_chosen_without_holdout']['ticker'],
                'strategy': result['winner_chosen_without_holdout']['strategy'],
                'holdout_return': return_,
                'holdout_max_drawdown': result['holdout_selected']['max_drawdown'],
                'holdout_spy_return': result['holdout_SPY']['holdout_buy_hold']['total_return'],
                'holdout_qqq_return': result['holdout_QQQ']['holdout_buy_hold']['total_return'],
                'beat_all_three': all(comparisons.values()),
                'beat_spy': comparisons['SPY_buy_hold'],
                'positive_net_return': return_ > 0,
                'next_question': result['latest_next_experiment']['question'],
                'data_fingerprint_sha256': result['data_fingerprint_sha256'],
            })
    return {
        'schema': SCHEMA, 'mode': 'PREDECLARED_SYNTHETIC_BATTERY_ONLY',
        'scenario_count': len(records), 'candidate_stocks': list(TICKERS),
        'positive_net_returns': sum(x['positive_net_return'] for x in records),
        'beat_spy': sum(x['beat_spy'] for x in records),
        'beat_all_three': sum(x['beat_all_three'] for x in records),
        'records': records,
        'best_possible_claim': 'This checks software robustness in synthetic markets, NOT profitable real-stock prediction',
        'time_experiment': 'Measure wall-clock runtime externally; no claim of spacetime alteration.',
        'next_experiment': 'Import point-in-time evidence and actual OHLCV for all ten stocks and SPY/QQQ; then prospectively paper-trade a frozen policy.',
        'no_live_orders': True,
    }


def ask_experience_h132(result, model='qwen2.5:3b'):
    """Opt-in actual local BIE model question. Never claim a reply if unavailable."""
    from threading import Event
    from types import SimpleNamespace
    from .model import Ollama, ModelUnavailable
    import time
    compact = {
        'result_type': result.get('mode', 'one_supplied_market_backtest'),
        'world_count': result.get('scenario_count'),
        'beat_spy': result.get('beat_spy'),
        'beat_all_three': result.get('beat_all_three'),
        'selected': result.get('winner_chosen_without_holdout'),
        'holdout_beat_baselines': result.get('holdout_beat_baselines'),
        'next_experiment': result.get('next_experiment', result.get('latest_next_experiment')),
    }
    prompt = (
        'You are the LOCAL BIE THRIVES Experience model, NOT a brokerage agent. '
        'The user wants you to reach your strongest tested research capabilities. '
        'Given the following UNTRUSTED test summary, state 1) what failed, '
        '2) your best new falsifiable research hypothesis, 3) a independent control, '
        '4) what data would prove you wrong, 5) what to do within a 60-second '
        'attention budget. Do not claim real market profit, knowledge you have not '
        'observed, ability to alter physical time, or place orders. '
        'Never tune on previously opened holdouts.\n' + json.dumps(compact, sort_keys=True)[:2900]
    )
    try:
        result_, timing = Ollama(model).reply(
            [{'role':'user', 'content':prompt}], [],
            SimpleNamespace(model_context=4096, output_tokens=400),
            Event(), lambda _: None, time.monotonic()+16)
        return {'status':'local_model_replied', 'model':model,
                'proposal_unverified':result_['content'][:3000], 'timing':timing}
    except (ModelUnavailable, OSError, TimeoutError) as exc:
        return {'status':'local_model_unavailable', 'model':model,
                'reason':str(exc)[:180], 'next_experiment_fallback':'Evidence-defined falsifiable next experiment; no invented model answer'}
