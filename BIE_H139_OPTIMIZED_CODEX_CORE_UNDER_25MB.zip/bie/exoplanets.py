"""BLOOM Exoplanet Observatory: archival astronomy + falsifiable interpretation.

NASA Exoplanet Archive TAP data is public; this module does not interact with
telescopes, observe extraterrestrial life, or infer habitability from distance.
Uses only the Python standard library. All remote access requires explicit sync.
"""
from __future__ import annotations

import csv
from contextlib import contextmanager
from datetime import datetime, timezone
import hashlib
import io
import json
import math
from pathlib import Path
import sqlite3
from urllib.parse import urlencode
from urllib.request import Request, urlopen

PARSEC_LIGHT_YEARS = 3.261563777
NASA_TAP = "https://exoplanetarchive.ipac.caltech.edu/TAP/sync"
DATASET = "pscomppars"
COLUMNS = ("pl_name", "hostname", "sy_dist", "sy_disterr1", "sy_disterr2", "pl_rade",
           "pl_radeerr1", "pl_radeerr2", "pl_bmasse", "pl_insol", "pl_eqt", "pl_orbper",
           "pl_orbsmax", "discoverymethod", "disc_year", "ra", "dec")
ADQL = "select " + ",".join(COLUMNS) + " from " + DATASET
SOURCE_DOC = "https://exoplanetarchive.ipac.caltech.edu/docs/TAP/usingTAP.html"
MAX_DOWNLOAD_BYTES = 12_000_000
MAX_PLANETS = 30_000


def utc_now():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def numeric(value, *, positive=False):
    if value is None or str(value).strip().lower() in ("", "nan", "null", "none", "--"):
        return None
    try:
        num = float(value)
    except (ValueError, TypeError, OverflowError):
        return None
    if not math.isfinite(num) or (positive and num <= 0):
        return None
    return num


def _planet_from_csv(row):
    name = str(row.get("pl_name") or "").strip()
    if not (1 <= len(name) <= 170):
        return None
    p = {k: str(row.get(k) or "").strip()[:250] for k in COLUMNS}
    p["pl_name"] = name
    p["hostname"] = str(row.get("hostname") or "").strip()[:170]
    # Invalid bounds must not be mistaken for real positive values.
    for k in ("sy_dist", "pl_rade", "pl_bmasse", "pl_insol", "pl_eqt", "pl_orbper", "pl_orbsmax"):
        p[k] = numeric(row.get(k), positive=True)
    for k in ("sy_disterr1", "sy_disterr2", "pl_radeerr1", "pl_radeerr2", "ra", "dec"):
        p[k] = numeric(row.get(k))
    if p["ra"] is not None and not (0 <= p["ra"] < 360):
        p["ra"] = None
    if p["dec"] is not None and not (-90 <= p["dec"] <= 90):
        p["dec"] = None
    return p


def parse_archive_csv(content):
    if isinstance(content, str):
        content = content.encode("utf-8")
    if len(content) > MAX_DOWNLOAD_BYTES:
        raise ValueError("Catalog exceeds configured download limit")
    try:
        text = content.decode("utf-8-sig")
    except UnicodeDecodeError as exc:
        raise ValueError("Archive response is not UTF-8 CSV") from exc
    reader = csv.DictReader(io.StringIO(text, newline=""))
    if not reader.fieldnames or not set(COLUMNS).issubset(set(reader.fieldnames)):
        raise ValueError("Unrecognized catalog schema; refusing to replace existing records")
    out = []
    seen = set()
    for item in reader:
        if len(out) >= MAX_PLANETS:
            raise ValueError("Catalog row limit exceeded")
        if None in item:
            raise ValueError("Malformed CSV row")
        row = _planet_from_csv(item)
        if row is not None and row["pl_name"] not in seen:
            out.append(row)
            seen.add(row["pl_name"])
    if not out:
        raise ValueError("Empty or invalid catalog; previous records remain unchanged")
    return out


def _distance_uncertainty(row):
    # NASA err2 is a negative offset; report absolute component magnitudes.
    errs = [abs(x) for x in (row.get("sy_disterr1"), row.get("sy_disterr2")) if x is not None]
    return max(errs) * PARSEC_LIGHT_YEARS if errs else None


def _screen(row):
    """Loose illustrative observability screen; not a habitable-zone model."""
    radius, flux = row.get("pl_rade"), row.get("pl_insol")
    if radius is None or flux is None:
        return "insufficient-data"
    if 0.7 <= radius <= 1.8 and 0.25 <= flux <= 2.0:
        return "follow-up-screen"
    return "outside-screen"


def public_fields(row):
    result = dict(row)
    dist = row.get("sy_dist")
    result["distance_light_years"] = round(dist * PARSEC_LIGHT_YEARS, 3) if dist is not None else None
    unc = _distance_uncertainty(row)
    result["distance_uncertainty_ly"] = round(unc, 3) if unc is not None else None
    result["screen"] = _screen(row)
    result["life_detected"] = None  # no inference possible from this catalog
    return result


class ExoplanetLab:
    def __init__(self, home):
        self.base = Path(home) / "bloom_exoplanets"
        self.base.mkdir(parents=True, exist_ok=True)
        self.db_path = self.base / "catalog.sqlite3"
        with self._db() as conn:
            conn.execute("CREATE TABLE IF NOT EXISTS snapshots (id INTEGER PRIMARY KEY AUTOINCREMENT, fetched_at TEXT NOT NULL, kind TEXT NOT NULL, source_url TEXT NOT NULL, sha256 TEXT NOT NULL, count INTEGER NOT NULL)")
            conn.execute("CREATE TABLE IF NOT EXISTS planets (name TEXT PRIMARY KEY, snapshot_id INTEGER NOT NULL, data TEXT NOT NULL)")

    @contextmanager
    def _db(self):
        connection = sqlite3.connect(self.db_path, timeout=10)
        connection.row_factory = sqlite3.Row
        try:
            with connection:
                yield connection
        finally:
            connection.close()

    def import_csv(self, content, *, kind="manual_csv", source="local_user_selected"):
        if kind not in ("manual_csv", "nasa_tap", "reference_examples"):
            raise ValueError("Invalid provenance mode")
        if not isinstance(content, bytes):
            content = content.encode("utf-8")
        rows = parse_archive_csv(content)
        digest = hashlib.sha256(content).hexdigest()
        with self._db() as conn:
            conn.execute("BEGIN IMMEDIATE")
            cur = conn.execute("INSERT INTO snapshots (fetched_at,kind,source_url,sha256,count) VALUES(?,?,?,?,?)",
                               (utc_now(), kind, source[:700], digest, len(rows)))
            snapshot_id = cur.lastrowid
            # Atomic replace: old catalog kept if schema validation or database update fails.
            conn.execute("DELETE FROM planets")
            conn.executemany("INSERT INTO planets(name,snapshot_id,data) VALUES(?,?,?)",
                             [(r["pl_name"], snapshot_id, json.dumps(r, ensure_ascii=False, sort_keys=True)) for r in rows])
        return {"source_kind": kind, "source": source, "imported": len(rows), "snapshot_id": snapshot_id,
                "sha256": digest, "research_status": "NASA archival records" if kind == "nasa_tap" else "not independently verified against live NASA archive"}

    def sync(self, *, fetch=None):
        """Explicit network request. Inject fetch only for offline tests."""
        url = NASA_TAP + "?" + urlencode({"query": ADQL, "format": "csv"})
        if fetch is None:
            def fetch(u):
                request = Request(u, headers={"User-Agent": "BIE-THRIVES-Exoplanets/30 (research client)", "Accept": "text/csv"})
                with urlopen(request, timeout=25) as response:
                    if not response.geturl().startswith("https://exoplanetarchive.ipac.caltech.edu/"):
                        raise ValueError("Unexpected archive redirect")
                    return response.read(MAX_DOWNLOAD_BYTES + 1)
        content = fetch(url)
        if isinstance(content, str):
            content = content.encode("utf-8")
        if len(content) > MAX_DOWNLOAD_BYTES:
            raise ValueError("Exoplanet catalog exceeds safety size limit")
        result = self.import_csv(content, kind="nasa_tap", source=url)
        result["note"] = "Catalog rows are composite reported parameters, not direct telescope images or evidence of life."
        return result

    def status(self):
        with self._db() as db:
            row = db.execute("SELECT * FROM snapshots ORDER BY id DESC LIMIT 1").fetchone()
            n = db.execute("SELECT COUNT(*) FROM planets").fetchone()[0]
        return {"project": "BLOOM × BIE THRIVES", "records": n, "snapshot": dict(row) if row else None,
                "source_documentation": SOURCE_DOC,
                "capabilities": ["public NASA TAP catalog sync", "planet distance/light-time", "stellar 3D separation", "evidence screens", "hypothesis packets", "archival comparison"],
                "limitations": ["no direct telescope", "no autonomous exoplanet confirmation", "no life detection", "no real-time imaging"]}

    def _rows(self):
        with self._db() as db:
            return [json.loads(r[0]) for r in db.execute("SELECT data FROM planets")]

    def search(self, phrase="", *, limit=25, max_distance_ly=None, screen_only=False, sort="distance"):
        limit = max(1, min(200, int(limit)))
        if sort not in ("distance", "name", "radius"):
            raise ValueError("Invalid sort")
        match = phrase.lower().strip()
        result = []
        for p in self._rows():
            row = public_fields(p)
            if match and match not in p["pl_name"].lower() and match not in p["hostname"].lower():
                continue
            if max_distance_ly is not None and (row["distance_light_years"] is None or row["distance_light_years"] > max_distance_ly):
                continue
            if screen_only and row["screen"] != "follow-up-screen":
                continue
            result.append(row)
        if sort == "distance":
            result.sort(key=lambda v: (v["distance_light_years"] is None, v["distance_light_years"] or float("inf"), v["pl_name"]))
        elif sort == "radius":
            result.sort(key=lambda v: (v["pl_rade"] is None, v["pl_rade"] if v["pl_rade"] is not None else float("inf")))
        else:
            result.sort(key=lambda v: v["pl_name"].lower())
        return {"query": phrase, "filters": {"max_distance_ly": max_distance_ly, "screen_only": screen_only, "sort": sort},
                "matches": len(result), "returned": result[:limit], "screen_disclaimer": "0.7–1.8 Earth radii and 0.25–2 Earth insolation are exploratory thresholds, not proof of habitability or life."}

    def target(self, name):
        with self._db() as db:
            match = db.execute("SELECT p.data,s.kind,s.fetched_at,s.source_url,s.sha256 FROM planets p JOIN snapshots s ON p.snapshot_id=s.id WHERE lower(p.name)=lower(?)", (name,)).fetchone()
        if not match:
            return {"found": False, "name": name, "next_step": "Run exo-sync for NASA data or check spelling."}
        p = public_fields(json.loads(match["data"]))
        checks = [
            {"source": "NASA composite planetary archive" if match["kind"] == "nasa_tap" else "imported catalog, unverified", "observation": "Host system distance, when supplied", "support": p["distance_light_years"] is not None},
            {"source": "planetary parameters", "observation": "Measured/reported radius and stellar insolation", "support": p["pl_rade"] is not None and p["pl_insol"] is not None},
        ]
        alternatives = ["Surface conditions may differ because of atmosphere, albedo, rotation and geology", "Missing or model-dependent measurements can change the classification", "A host-star distance is not the planet's orbital distance"]
        return {"found": True, "planet": p, "source_kind": match["kind"], "snapshot_at": match["fetched_at"], "source_url": match["source_url"], "snapshot_sha256": match["sha256"],
                "thoughtpacket": {"goal": "Examine an exoplanet using verifiable public measurements", "checks": checks,
                    "hypothesis": "Candidate warrants environmental follow-up" if p["screen"] == "follow-up-screen" else "Existing information does not pass the exploratory follow-up screen",
                    "alternatives": alternatives,
                    "uncertainty": "Unspecified for missing values; uncertainty in individual catalog measurements is not a calibrated probability of life",
                    "confidence": "reported catalog data" if match["kind"] == "nasa_tap" else "unverified import",
                    "next_test": "Compare independent measurements or obtain time-resolved spectra and validated stellar parameters",
                    "verdict": "No inference of life, breathable air, liquid water, or direct image"}}

    def between(self, first, second):
        p1 = self.target(first)
        p2 = self.target(second)
        if not (p1["found"] and p2["found"]):
            return {"error": "Planet name not found", "first_found": p1["found"], "second_found": p2["found"]}
        a, b = p1["planet"], p2["planet"]
        vals = [a.get(k) for k in ("sy_dist", "ra", "dec")] + [b.get(k) for k in ("sy_dist", "ra", "dec")]
        if None in vals:
            return {"planet_a": first, "planet_b": second, "stellar_separation_ly": None, "reason": "Distance and both equatorial coordinates required"}
        da, ra_a, dec_a, db, ra_b, dec_b = vals
        a_ra,a_dec,b_ra,b_dec = map(math.radians,(ra_a,dec_a,ra_b,dec_b))
        cos_angle = math.sin(a_dec)*math.sin(b_dec)+math.cos(a_dec)*math.cos(b_dec)*math.cos(a_ra-b_ra)
        gap_pc = math.sqrt(max(0.0, da*da+db*db-2*da*db*max(-1.0,min(1.0,cos_angle))))
        return {"planet_a": first, "planet_b": second, "host_star_system_separation_ly": round(gap_pc*PARSEC_LIGHT_YEARS, 3),
                "distance_difference_from_earth_ly": round(abs(da-db)*PARSEC_LIGHT_YEARS, 3),
                "note": "Approximate present-day Euclidean separation of host stars inferred from sky coordinates/distances; not a navigational trajectory or planet-to-planet orbital separation."}

    def export(self, output):
        path = Path(output)
        if path.exists():
            raise FileExistsError("Choose a new file; refusing to overwrite an existing report")
        path.parent.mkdir(parents=True, exist_ok=True)
        content = {"generated_at": utc_now(), "status": self.status(), "nearest": self.search(limit=30),
                   "research_boundary": "A catalog does not provide new observational detection or life evidence"}
        with path.open("x", encoding="utf-8") as f:
            json.dump(content, f, indent=2, ensure_ascii=False)
        return {"saved": str(path), "records_in_report": len(content["nearest"]["returned"])}
