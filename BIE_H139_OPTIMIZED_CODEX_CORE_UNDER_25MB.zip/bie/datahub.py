"""BIE 26 additive knowledge hub: explicit local imports, trustworthy provenance, bounded search.

Data from a document or remote endpoint is *never* an instruction or permission.
No folder is indexed without an explicit import, and no public endpoint sees local text.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from contextlib import contextmanager
import csv
import hashlib
import io
import json
import os
from pathlib import Path
import re
import sqlite3
import threading

EXTENSIONS = frozenset({".txt", ".md", ".markdown", ".csv", ".tsv", ".json", ".jsonl"})
BLOCKED_PARTS = frozenset({".git", ".ssh", ".aws", ".azure", ".config", ".venv", "venv", "node_modules", "__pycache__", "secrets", "credentials", "private", "backups"})
BLOCKED_NAMES = (".env", "password", "passwd", "secret", "credential", "token", "id_rsa", "id_ed25519", "key.pem", "wallet.dat", "keystore")
MAX_BYTES = 2_000_000
MAX_IMPORT = 200


def utc():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def clean_text(content: str, limit=120_000) -> str:
    if not isinstance(content, str):
        raise ValueError("Document text must be a string")
    return content[:limit].replace("\x00", "")


def safe_content_path(path: Path, root: Path) -> bool:
    """Deny symlink files and any paths with credentials-like names."""
    try:
        if path.is_symlink() or not path.is_file() or path.stat().st_size > MAX_BYTES:
            return False
        relative = path.relative_to(root)
        if any(part.casefold() in BLOCKED_PARTS for part in relative.parts[:-1]):
            return False
        lower = path.name.casefold()
        if (path.suffix.casefold() not in EXTENSIONS or lower.startswith(".") or
                any(word in lower for word in BLOCKED_NAMES)):
            return False
        return True
    except (OSError, ValueError):
        return False


@dataclass(frozen=True)
class StorageEntry:
    alias: str
    path: str
    kind: str


class KnowledgeHub:
    def __init__(self, home):
        self.home = Path(home).resolve()
        self.home.mkdir(parents=True, exist_ok=True)
        self.db = self.home / "knowledge.sqlite3"
        self._lock = threading.RLock()
        with self._connect() as con:
            con.executescript("""
                PRAGMA journal_mode=WAL;
                CREATE TABLE IF NOT EXISTS storage (
                    alias TEXT PRIMARY KEY COLLATE NOCASE,
                    path TEXT NOT NULL UNIQUE,
                    kind TEXT NOT NULL,
                    added_at TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS documents (
                    id TEXT PRIMARY KEY, origin TEXT NOT NULL, title TEXT NOT NULL,
                    uri TEXT NOT NULL, content TEXT NOT NULL, sha256 TEXT NOT NULL,
                    category TEXT NOT NULL, acquired_at TEXT NOT NULL,
                    evidence TEXT NOT NULL DEFAULT 'unverified');
                CREATE INDEX IF NOT EXISTS by_origin ON documents(origin);
                CREATE INDEX IF NOT EXISTS by_uri ON documents(uri);
                CREATE VIRTUAL TABLE IF NOT EXISTS documents_fts USING fts5(
                    title, content, content='documents', content_rowid='rowid');
                CREATE TRIGGER IF NOT EXISTS doc_ai AFTER INSERT ON documents BEGIN
                    INSERT INTO documents_fts(rowid,title,content) VALUES(new.rowid,new.title,new.content);
                END;
                CREATE TRIGGER IF NOT EXISTS doc_ad AFTER DELETE ON documents BEGIN
                    INSERT INTO documents_fts(documents_fts,rowid,title,content)
                    VALUES('delete',old.rowid,old.title,old.content);
                END;
                CREATE TRIGGER IF NOT EXISTS doc_au AFTER UPDATE ON documents BEGIN
                    INSERT INTO documents_fts(documents_fts,rowid,title,content)
                    VALUES('delete',old.rowid,old.title,old.content);
                    INSERT INTO documents_fts(rowid,title,content) VALUES(new.rowid,new.title,new.content);
                END;
            """)

    @contextmanager
    def _connect(self):
        con = sqlite3.connect(str(self.db), timeout=8)
        con.row_factory = sqlite3.Row
        con.execute("PRAGMA busy_timeout=8000")
        try:
            yield con
            con.commit()
        except Exception:
            con.rollback()
            raise
        finally:
            con.close()

    def register_storage(self, alias: str, path: str):
        """Registers an already reachable *user-selected* folder; no password bypass/mount."""
        if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9 _.-]{0,49}", alias or ""):
            raise ValueError("Storage name must be 1–50 letters, numbers, spaces, dots, dashes or underscores")
        if not isinstance(path, str) or not path.strip():
            raise ValueError("Provide a path to a folder you own or have permission to access")
        folder = Path(path).expanduser()
        if not folder.is_dir():
            raise ValueError("Storage is not accessible. Connect it through Windows File Explorer first, then retry")
        if folder.is_symlink():
            raise ValueError("Do not register a symbolic-link directory")
        folder = folder.resolve()
        if folder == folder.parent or folder == Path.home().resolve():
            raise ValueError("Choose a specific folder/share, not a whole drive or home directory")
        if folder == self.home or self.home.is_relative_to(folder) or folder.is_relative_to(self.home):
            raise ValueError("Do not register the BIE internal state directory")
        kind = "network" if str(path).startswith(("\\\\", "//")) else "mounted-folder"
        with self._lock, self._connect() as con:
            con.execute("INSERT INTO storage(alias,path,kind,added_at) VALUES(?,?,?,?) "
                        "ON CONFLICT(alias) DO UPDATE SET path=excluded.path,kind=excluded.kind,added_at=excluded.added_at",
                        (alias.strip(), str(folder), kind, utc()))
        return {"name": alias.strip(), "path": str(folder), "kind": kind,
                "notice": "Folder registered read-only for listing/import. No files indexed yet."}

    def remove_storage(self, alias):
        with self._lock, self._connect() as con:
            n = con.execute("DELETE FROM storage WHERE alias=?", (alias,)).rowcount
        return {"removed": bool(n), "indexed_documents_remain": True}

    def storage(self):
        with self._connect() as con:
            return [dict(x) for x in con.execute("SELECT alias,path,kind,added_at FROM storage ORDER BY alias")]

    def _root(self, alias):
        with self._connect() as con:
            row = con.execute("SELECT path FROM storage WHERE alias=?", (alias,)).fetchone()
        if row is None:
            raise ValueError("Unknown storage alias: " + alias)
        root = Path(row["path"])
        if not root.is_dir():
            raise ValueError("Storage is offline or no longer accessible")
        return root

    def browse(self, alias, relative=".", limit=100):
        root = self._root(alias)
        target = (root / relative)
        if any(p == ".." for p in Path(relative).parts) or target.is_symlink():
            raise ValueError("Directory traversal and symlinks are prohibited")
        target = target.resolve()
        if not target.is_relative_to(root.resolve()) or not target.is_dir():
            raise ValueError("Path must be a directory inside registered storage")
        items = []
        for entry in sorted(target.iterdir(), key=lambda e: e.name.casefold()):
            if len(items) >= min(max(int(limit), 1), 200):
                break
            if entry.is_symlink() or entry.name.startswith("."):
                continue
            if entry.name.casefold() in BLOCKED_PARTS or any(w in entry.name.casefold() for w in BLOCKED_NAMES):
                continue
            items.append({"name": entry.name, "folder": entry.is_dir(), "path": str(entry.relative_to(root))})
        return {"alias": alias, "directory": str(target.relative_to(root)), "items": items}

    def put(self, *, origin, title, uri, content, category, evidence="unverified"):
        if not origin or not uri or not title:
            raise ValueError("Document provenance fields are required")
        body = clean_text(content)
        digest = hashlib.sha256(body.encode("utf-8")).hexdigest()
        key = hashlib.sha256((origin + "\n" + uri).encode()).hexdigest()
        with self._lock, self._connect() as con:
            con.execute("""INSERT INTO documents(id,origin,title,uri,content,sha256,category,acquired_at,evidence)
                VALUES (?,?,?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET
                title=excluded.title,content=excluded.content,sha256=excluded.sha256,
                acquired_at=excluded.acquired_at,evidence=excluded.evidence""",
                (key, origin, title[:250], uri[:1024], body, digest, category, utc(), evidence))
        return {"id": key, "sha256": digest, "title": title[:250], "source": origin, "bytes": len(body.encode())}

    def import_storage(self, alias, relative=".", max_files=50):
        root = self._root(alias)
        relative_path = Path(relative)
        if ".." in relative_path.parts:
            raise ValueError("Parent directory traversal is prohibited")
        start = root / relative_path
        if start.is_symlink() or not start.resolve().is_relative_to(root.resolve()):
            raise ValueError("Path must be inside the registered storage")
        if not start.exists():
            raise ValueError("Specified path does not exist")
        max_files = min(max(int(max_files), 1), MAX_IMPORT)
        imported, skipped, scanned = [], 0, 0
        def candidate_files():
            if start.is_file():
                yield start
            else:
                # Top level only by default: deeper directories must be explicitly selected.
                yield from sorted(start.iterdir(), key=lambda p: p.name.casefold())
        for file in candidate_files():
            if len(imported) >= max_files:
                break
            scanned += 1
            if not safe_content_path(file, root):
                skipped += 1
                continue
            try:
                raw = file.read_bytes()
                body = raw.decode("utf-8-sig")
                if file.suffix.lower() in {".csv", ".tsv"}:
                    # CSV is text, not executable spreadsheet formulas. No evaluation.
                    reader = csv.reader(io.StringIO(body), delimiter="\t" if file.suffix.lower() == ".tsv" else ",")
                    body = "\n".join(" | ".join(row[:40]) for _, row in zip(range(1000), reader))
                result = self.put(origin="storage:" + alias, title=file.name,
                                  uri="file:" + str(file.relative_to(root)), content=body,
                                  category="local-file")
                imported.append(result)
            except (OSError, UnicodeError, csv.Error, ValueError):
                skipped += 1
        return {"source": alias, "imported": len(imported), "skipped": skipped,
                "scanned": scanned, "documents": imported[:20],
                "note": "Only explicitly selected top-level files are imported; no subfolders or credentials scanned."}

    def search(self, query, limit=10):
        words = re.findall(r"[\w-]{2,}", (query or "")[:300], flags=re.UNICODE)[:12]
        if not words:
            return []
        expression = " OR ".join('"' + w.replace('"', '') + '"' for w in words)
        with self._lock, self._connect() as con:
            rows = con.execute("""SELECT d.id,d.title,d.origin,d.uri,d.category,d.acquired_at,d.sha256,d.evidence,
                  snippet(documents_fts,1,'[',']',' … ',18) AS excerpt, bm25(documents_fts) AS rank
                  FROM documents_fts JOIN documents d ON d.rowid=documents_fts.rowid
                  WHERE documents_fts MATCH ? ORDER BY rank LIMIT ?""",
                (expression, min(max(int(limit), 1), 50))).fetchall()
        return [dict(row) for row in rows]

    def status(self):
        with self._connect() as con:
            n = con.execute("SELECT count(*) FROM documents").fetchone()[0]
            origins = [dict(x) for x in con.execute("SELECT origin,COUNT(*) AS count FROM documents GROUP BY origin ORDER BY count DESC")]
        return {"documents": n, "sources": origins, "storage": self.storage(),
                "data_path": str(self.db), "model_training": False,
                "network_access": "manual on explicit request"}
