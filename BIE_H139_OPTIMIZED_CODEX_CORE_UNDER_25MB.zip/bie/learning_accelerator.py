"""BIE v34: explicit, bounded public-reference learning accelerator.

This indexes provenance-rich *reference metadata*, NOT truths, model weights or
claims of having learned facts. No autonomous crawling, no hidden background jobs.
Data from public APIs remains untrusted input, never permissions or instructions.
"""
from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import asdict, dataclass
from contextlib import closing
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sqlite3
import threading
import time
from urllib.parse import urlsplit
import uuid

from .datahub import KnowledgeHub
from .public_data import ENDPOINTS, search_public

MAX_MANIFEST_BYTES = 1_000_000
MAX_MANIFEST_JOBS = 2000


def _utc():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


@dataclass(frozen=True)
class LearnProfile:
    max_queries: int
    max_results_per_query: int
    workers: int
    min_query_spacing_seconds: float
    time_budget_seconds: int

    def to_dict(self):
        return asdict(self)


# Auto aims for MaximumSafe, but climbs only after healthy, novel results.
# This is a finite public-API workload target, not an infinite learning rate.
AUTO_TARGET = "MaximumSafe"
AUTO_MIN_COMPLETED_TO_SCALE = 10
AUTO_MIN_NOVELTY_FRACTION = 0.40
AUTO_MAX_SCALE_FAILURE_FRACTION = 0.05
PROFILES = {
    "Evidence": LearnProfile(10, 5, 1, 2.0, 120),
    "Balanced": LearnProfile(40, 10, 2, 1.2, 300),
    "Accelerated": LearnProfile(150, 10, 3, 0.75, 600),
    "MaximumSafe": LearnProfile(300, 10, 4, 0.6, 900),
}


class RateGate:
    """Paces per-job dispatch; provider API calls inside each job may vary."""
    def __init__(self, spacing):
        self.spacing = spacing
        self.lock = threading.Lock()
        self.next_time = 0.0

    def wait(self):
        with self.lock:
            now = time.monotonic()
            delay = max(0.0, self.next_time - now)
            if delay:
                time.sleep(delay)
            self.next_time = time.monotonic() + self.spacing


def read_jobs(path):
    file = Path(path)
    if not file.is_file() or file.stat().st_size > MAX_MANIFEST_BYTES:
        raise ValueError("Select a JSON file no larger than 1 MB")
    obj = json.loads(file.read_text(encoding="utf-8"))
    if not isinstance(obj, dict) or not isinstance(obj.get("jobs"), list):
        raise ValueError('Manifest requires {"jobs": [{"provider": "...", "query": "..."}]}')
    if len(obj["jobs"]) > MAX_MANIFEST_JOBS:
        raise ValueError("Maximum 2,000 manually specified queries per manifest")
    unique, seen = [], set()
    for item in obj["jobs"]:
        if not isinstance(item, dict):
            raise ValueError("Each query must be an object")
        provider, query, limit = item.get("provider"), item.get("query"), item.get("limit", 10)
        if provider not in ENDPOINTS or not isinstance(query, str) or not 1 <= len(query.strip()) <= 300:
            raise ValueError("Use supported public API provider and nonempty query of at most 300 characters")
        if type(limit) is not int or not 1 <= limit <= 10:
            raise ValueError("Per-query limit must be an integer from 1 to 10")
        key = (provider, query.strip().casefold())
        if key in seen:
            continue
        seen.add(key)
        unique.append({"provider": provider, "query": query.strip(), "limit": limit})
    if not unique:
        raise ValueError("At least one distinct query is required")
    digest = hashlib.sha256(file.read_bytes()).hexdigest()
    return {"jobs": unique, "repeated_queries_omitted": len(obj["jobs"]) - len(unique),
            "manifest_sha256": digest, "manifest_size": file.stat().st_size}


class LearningAccelerator:
    def __init__(self, home):
        self.home = Path(home).expanduser().resolve()
        self.home.mkdir(parents=True, exist_ok=True)
        self.runs_db = self.home / "learning_runs_v34.sqlite3"
        with closing(sqlite3.connect(str(self.runs_db), timeout=15)) as con:
            con.execute("""CREATE TABLE IF NOT EXISTS learning_runs (
                run_id TEXT PRIMARY KEY, started_at TEXT NOT NULL,
                finished_at TEXT NOT NULL, profile TEXT NOT NULL,
                manifest_sha256 TEXT NOT NULL, report TEXT NOT NULL)""")

    def status(self):
        with closing(sqlite3.connect(str(self.runs_db), timeout=15)) as con:
            n = con.execute("SELECT COUNT(*) FROM learning_runs").fetchone()[0]
            rows = con.execute("SELECT report FROM learning_runs ORDER BY rowid DESC LIMIT 5").fetchall()
        return {"recorded_runs": n, "recent_runs": [json.loads(r[0]) for r in rows],
                "default_profile": "Auto", "auto_target": AUTO_TARGET,
                "auto_next_selected_profile": self._choose_profile("Auto"),
                "auto_policy": "Step Balanced -> Accelerated -> MaximumSafe after >=10 jobs, <=5% failures and >=40% novel references; back off on failures",
                "profiles": {k: p.to_dict() for k, p in PROFILES.items()},
                "meaning": "Indexed external references are unverified metadata, not facts learned or model-weight updates",
                "internet_use": "manual opt-in only"}

    def _choose_profile(self, requested):
        if requested in PROFILES:
            return requested
        if requested != "Auto":
            raise ValueError("Profile must be Auto, Evidence, Balanced, Accelerated or MaximumSafe")
        with closing(sqlite3.connect(str(self.runs_db))) as con:
            row = con.execute("SELECT report FROM learning_runs ORDER BY rowid DESC LIMIT 1").fetchone()
        if row is None:
            return "Balanced"  # measured warm-up before scaling
        previous = json.loads(row[0])
        current = previous.get("selected_profile", "Balanced")
        if current not in PROFILES:
            current = "Balanced"
        completed = max(0, int(previous.get("completed_jobs", 0)))
        failed = max(0, int(previous.get("failed_jobs", 0)))
        total = completed + failed
        seen = max(0, int(previous.get("references_seen", 0)))
        novel = max(0, int(previous.get("new_references", 0)))
        failures = failed / total if total else 1.0
        order = ("Evidence", "Balanced", "Accelerated", AUTO_TARGET)
        current_index = order.index(current)
        # Provider trouble triggers a fast slowdown, not an endless retry loop.
        if failures > 0.20:
            return "Evidence"
        if failures > AUTO_MAX_SCALE_FAILURE_FRACTION:
            return order[max(0, current_index - 1)]
        # Empty/cached/duplicate-heavy batches do not justify scaling workload.
        healthy = (completed >= AUTO_MIN_COMPLETED_TO_SCALE
                   and seen > 0
                   and novel / seen >= AUTO_MIN_NOVELTY_FRACTION)
        if healthy:
            return order[min(len(order) - 1, max(1, current_index + 1))]
        return current

    def plan(self, manifest, profile="Auto", max_jobs=None, start_at=None):
        parsed = read_jobs(manifest)
        selected = self._choose_profile(profile)
        policy = PROFILES[selected]
        cap = policy.max_queries
        if max_jobs is not None:
            if type(max_jobs) is not int or not 1 <= max_jobs <= cap:
                raise ValueError(f"max_jobs must be between 1 and {cap} for {selected}")
            cap = max_jobs
        if start_at is None:
            with closing(sqlite3.connect(str(self.runs_db))) as con:
                row = con.execute("SELECT report FROM learning_runs WHERE manifest_sha256=? "
                                  "ORDER BY rowid DESC LIMIT 1", (parsed["manifest_sha256"],)).fetchone()
            offset = int(json.loads(row[0]).get("next_job_index", 0)) if row else 0
        else:
            if type(start_at) is not int or not 0 <= start_at <= len(parsed["jobs"]):
                raise ValueError("start_at must be between 0 and the number of unique queries")
            offset = start_at
        selected_jobs = parsed["jobs"][offset:offset+cap]
        return {"requested_profile": profile, "selected_profile": selected,
                "auto_target": AUTO_TARGET if profile == "Auto" else None,
                "start_job_index": offset, "next_job_index": offset + len(selected_jobs),
                "settings": policy.to_dict(), "jobs_in_manifest": len(parsed["jobs"]),
                "jobs_this_run": len(selected_jobs), "jobs_remaining": len(parsed["jobs"]) - offset - len(selected_jobs),
                "duplicate_queries_skipped": parsed["repeated_queries_omitted"],
                "max_references_this_run": sum(min(p["limit"], policy.max_results_per_query) for p in selected_jobs),
                "manifest_sha256": parsed["manifest_sha256"],
                "network_requests_this_command": 0,
                "requires_manual_confirmation": True,
                "scope": "Approved public API reference metadata only; no websites crawled or facts validated",
                "model_weight_training": False}

    def run(self, manifest, *, profile="Auto", max_jobs=None, start_at=None, confirmed=False,
            fetch=None, pace=True):
        if not confirmed:
            raise PermissionError("Explicit network-import confirmation required; preview with learn-plan")
        preview = self.plan(manifest, profile, max_jobs, start_at)
        if not preview["jobs_this_run"]:
            raise ValueError("All manifest queries already processed. Supply start_at=0 for an intentional refresh, or add new queries.")
        parsed = read_jobs(manifest)
        profile_name = preview["selected_profile"]
        policy = PROFILES[profile_name]
        jobs = parsed["jobs"][preview["start_job_index"]:preview["next_job_index"]]
        if fetch is None:
            fetch = search_public
        gate = RateGate(policy.min_query_spacing_seconds)
        started = _utc()
        begin = time.monotonic()
        deadline = begin + policy.time_budget_seconds

        def worker(index, job):
            if time.monotonic() >= deadline:
                return {"index": index, "ok": False, "message": "Run time budget exhausted", "deadline": True, "job": job}
            if pace:
                gate.wait()
            if time.monotonic() >= deadline:
                return {"index": index, "ok": False, "message": "Run time budget exhausted", "deadline": True, "job": job}
            try:
                value = fetch(job["provider"], job["query"], min(job["limit"], policy.max_results_per_query))
                if value.get("provider") != job["provider"] or not isinstance(value.get("records"), list):
                    raise ValueError("Invalid provider response shape")
                return {"index": index, "ok": True, "records": value["records"][:min(job["limit"], policy.max_results_per_query)], "job": job}
            except Exception as ex:
                return {"index": index, "ok": False, "message": f"{type(ex).__name__}: {str(ex)[:160]}", "job": job}

        received = []
        # Only this manual invocation can enqueue these calls; no recurring scheduler.
        with ThreadPoolExecutor(max_workers=policy.workers) as executor:
            futures = [executor.submit(worker, i, j) for i, j in
                       enumerate(jobs, start=preview["start_job_index"])]
            for future in as_completed(futures):
                received.append(future.result())
        received.sort(key=lambda r: r["index"])
        # Resume from the first unprocessed job if the time budget interrupts a batch.
        # Later concurrently completed jobs may be rechecked, but dedup avoids double counting.
        next_index = min((r["index"] for r in received if r.get("deadline")),
                         default=preview["next_job_index"])

        hub = KnowledgeHub(self.home)
        new, updated, duplicates, bad_records, scanned = 0, 0, 0, 0, 0
        errors = []
        seen = set()
        seen_uris = set()
        # Index sequentially; source identifiers and existing hashes control novelty.
        # An identifier is a reference, NOT a verified knowledge unit.
        for result in received:
            if not result["ok"]:
                errors.append({"provider": result["job"]["provider"], "query": result["job"]["query"],
                               "reason": result["message"]})
                continue
            for rec in result["records"]:
                scanned += 1
                if not isinstance(rec, dict):
                    bad_records += 1
                    continue
                uri = rec.get("url")
                title = rec.get("title")
                if not isinstance(uri, str) or not isinstance(title, str) or not title.strip():
                    bad_records += 1
                    continue
                link = urlsplit(uri)
                if link.scheme != "https" or not link.hostname or link.username or link.password:
                    bad_records += 1
                    continue
                origin = "api:" + result["job"]["provider"]
                key = hashlib.sha256((origin + "\n" + uri).encode()).hexdigest()
                if key in seen or uri in seen_uris:
                    duplicates += 1
                    continue
                seen.add(key)
                seen_uris.add(uri)
                with hub._lock, hub._connect() as con:
                    identical_url = con.execute("SELECT id FROM documents WHERE uri=? AND id<>? LIMIT 1",
                                                (uri, key)).fetchone()
                if identical_url is not None:
                    duplicates += 1
                    continue
                content = json.dumps({"title": title[:250], "year": rec.get("year"),
                    "description": str(rec.get("description") or "")[:500],
                    "identifier": str(rec.get("identifier") or "")[:200]}, ensure_ascii=False, default=str)
                digest = hashlib.sha256(content.encode("utf-8")).hexdigest()
                with hub._lock, hub._connect() as con:
                    old = con.execute("SELECT sha256 FROM documents WHERE id=?", (key,)).fetchone()
                if old is not None and old[0] == digest:
                    duplicates += 1
                    continue
                hub.put(origin=origin, title=title, uri=uri, content=content,
                        category="public-reference", evidence="external-source-unverified")
                if old:
                    updated += 1
                else:
                    new += 1

        elapsed = round(time.monotonic() - begin, 3)
        report = {"run_id": str(uuid.uuid4()), "started_at": started, "finished_at": _utc(),
                  "selected_profile": profile_name, "manifest_sha256": preview["manifest_sha256"],
                  "completed_jobs": sum(r["ok"] for r in received),
                  "failed_jobs": sum(not r["ok"] for r in received),
                  "jobs_remaining_in_manifest": len(parsed["jobs"]) - next_index,
                  "start_job_index": preview["start_job_index"], "next_job_index": next_index,
                  "references_seen": scanned, "new_references": new,
                  "changed_existing_references": updated, "duplicate_references": duplicates,
                  "invalid_references": bad_records, "elapsed_seconds": elapsed,
                  "new_references_per_second": round(new / max(.001, elapsed), 4),
                  "failures": errors[:20], "sources": "public API result metadata; not the full articles",
                  "knowledge_verified": 0, "model_weights_changed": False,
                  "notes": "New references are not new proven facts. Respect provider terms/rate limits; use multiple batches."}
        with closing(sqlite3.connect(str(self.runs_db), timeout=15)) as con:
            with con:
                con.execute("INSERT INTO learning_runs VALUES(?,?,?,?,?,?)",
                            (report["run_id"], started, report["finished_at"], profile_name,
                             report["manifest_sha256"], json.dumps(report, ensure_ascii=False)))
        return report
