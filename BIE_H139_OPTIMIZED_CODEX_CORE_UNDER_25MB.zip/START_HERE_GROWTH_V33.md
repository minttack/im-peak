# BIE THRIVES Experience — v33 Growth Lab integration candidate

**Creator: the user.** This is a tested additive candidate built from the retrieved *v32 + Adaptive Bloom Wiggle* full-source tree. It is **not** a synchronized update to an existing Windows installation, nor a claim that BIE retrains its base model or has become conscious. Unchanged inherited components and research archives are included intact.

## What changed

- Added a native `BIE · Growth Lab` desktop tab where you can import a user-authored frozen prediction JSON, later attach a binary outcome, review context-specific performance against its prespecified baseline, and verify the journal. The UI offers a read-only **Previous project lessons** viewer.
- Added `bie/growth.py`: durable append-only-at-app-level SQLite event journal in the **same existing `--home` folder** but in a **new database** `growth_ledger_v33.sqlite3`. Timestamps, event hashes, immutable earlier predictions, outcome evidence hashes, and explicit invalidation events preserve corrections without erasing contradictory reports.
- Added CLI commands `growth-predict`, `growth-resolve`, `growth-review`, `growth-invalidate`, `growth-status`, `growth-audit`, and `growth-history`.
- Added **read-only** assistant tools `growth_history`, `growth_status`, `growth_review`, plus goal-matched advisory context. The assistant cannot create predictions, enter outcomes, change model weights, promote a policy, or grant permissions through these tools.
- Bundled read-only retrospective research handoff cards for BIE cognitive architecture, negative transfer, network Wiggle, route Wiggle, Bitcoin H105–H110, astronomical reconstruction and IRL game coordination. These are **not** scored as prospective trials or independently verified facts.

## BIE's intended growth loop

**ANCHOR:** define claim, source, evidence, uncertainty, constraints and baseline. **FLUX / GENERATOR:** list plausible alternatives. **Chance** represents the possible outcomes; **probability** is the precommitted numeric belief. **FOCUS:** define a bounded prospective test. **ACTION:** run the test only with separate user authorization and allowed tools. **VERIFIER:** attach evidence and check a held-out comparison. **CORRECTION:** invalidate misleading records transparently. **MEMORY:** retain wins, failures and context boundaries.

A Brier score is the squared error of a probabilistic binary prediction. Positive `baseline_brier - candidate_brier` means better performance *for the entered cases*. A descriptive local bootstrap and preassigned 20% holdout partition help reveal overfitting, but **this is not sealed independent science**: the user chooses which cases to enter and the reported outcome/source. Even a positive threshold only returns `candidate_for_external_replication`, never an automatic promotion or proof.

## Windows: easiest approach

1. Extract the FULL SOURCE ZIP to a **new** folder beside (not over) your prior BIE installation.
2. Requires Python 3.10+ with Tkinter. Double-click `START_BIE.bat`. Existing Ollama setup only matters if you want chat/coding; the Growth Lab works offline without an LLM.
3. Open **BIE · Growth Lab**. Use **Previous project lessons** to inspect prior reported findings.
4. Before a NEW experiment, copy `examples/GROWTH_PREDICTION_TEMPLATE.json` to your documents, fill in your own predeclared probabilities, baselines, uncertainty, verifier plan, and context, then import using **Record prediction from JSON**.
5. After collecting the outcome, enter its prediction ID and 0/1 with a meaningful source label; choose **Record outcome**. You can review the exact domain + context + strategy against its frozen baseline.

**The retrieved prior BIE v32 and its state are not overwritten.** Full source uses the same default state path so your existing BIE history can be read, but back up your existing state first if you value it. For full isolation, use `--home C:\path\to\NEW_BIE_TEST_STATE` *before* a CLI command.

## CLI example

```powershell
py -3 -m bie --home C:\BIE_Test growth-predict examples\GROWTH_PREDICTION_TEMPLATE.json
# Copy the returned prediction ID, perform your independent test, then:
py -3 -m bie --home C:\BIE_Test growth-resolve YOUR_ID --outcome 1 --source "test log 2026-10-15" --evidence C:\path\to\result.json
py -3 -m bie --home C:\BIE_Test growth-review "BIE problem solving" "fresh synthetic obstacle maps, same size and costs" "candidate policy A"
py -3 -m bie --home C:\BIE_Test growth-audit
py -3 -m bie --home C:\BIE_Test growth-history
py -3 -m unittest discover -s tests -v
py -3 -m bie verify-vendor
```

Outcomes and source labels alone are not independently validated. An attached evidence file records its SHA-256 and length, not the truth of its assertions. Predictions must be committed *before* the result is known to be prospective. Historical observations should stay in the retrospective lesson cards, not be re-entered as if precommitted.

## What was verified

The retrieved v32 + Wiggle baseline full ZIP SHA-256 is `aad4cde50fedb7394e049299cf60854cc9dcb4c87f285210d59542e5858f7cc6`. All baseline files apart from the four intentionally modified Python files are retained byte-identical in this candidate. `SOURCE_SHA256_MANIFEST_GROWTH_V33.json` and `reports/growth_v33_integration.json` give file-level continuity. See `reports/growth_v33_tests.log` for local tests.

**Limitations:** native Windows GUI and user data migration were not tested; desktop GUI was smoke-tested on a virtual Linux display. Hash chain is not externally anchored, does not detect end truncation, and an attacker who recomputes hashes could defeat it. This build does not download chat history from ChatGPT or silently synchronize parallel project branches. The original v32 historical hashes are not used as the current candidate's tree hash.
