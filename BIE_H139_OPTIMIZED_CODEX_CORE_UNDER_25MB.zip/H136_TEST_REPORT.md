# H136 · Money Feedback and Familiarity Bloom — Test Report

**October 17, 2026**. Isolated research candidate based on H135-R (not merged into the latest unified branch or installed on Windows).

## Audited software checks

- **444/444** Python tests passed (411 inherited + **33 H136 additions**).
- **11/11** source vendor integrity checks passed; all new tests are offline.
- H135-R full ZIP SHA-256: `cdfc66af82cfb62d5d28ec97e0ef62a8d1813d24e754c307a3920f31ee54d67e`.
- `python -m bie familiarity-h136-demo` CLI passed; `--ask-experience` returned `local_model_unavailable` with no invented BIE answer.
- No Robinhood connector authenticated and **no real trade or order request**.

## Independent synthetic stress sweep

**80 separately seeded runs**: five artificial market types × 16 seeds 53601–53616 × 112 daily snapshots × 12 ticker streams (10 research equities plus synthetic SPY/QQQ). Every market level and signal is fabricated; simulated days are calendar days, not actual trading sessions. These are not real-money returns or live predictions.

| Synthetic world | Avg paper-feedback return | Avg feedback + drift guard | Avg fixed-size rule | Mean holdout Brier gain vs prior | Times drift improved feedback |
|---|---:|---:|---:|---:|---:|
| Familiarity signal artificially stable | +5.387% | +5.387% | +5.387% | +0.05895 | 0/16 |
| Familiarity reversal after training | -6.111% | -1.859% | -10.772% | -0.18783 | 16/16 |
| Market attention artificially useful | +6.581% | +6.581% | +6.581% | +0.10246 | 0/16 |
| No useful signal (null) | +0.000% | +0.000% | +0.000% | +0.00000 | 0/16 |
| Familiarity with poor liquidity | -0.486% | -0.486% | -0.499% | +0.10649 | 0/16 |

All paper computations start from **$10,000 in fictional cash**, cap normal exposure at 30% total and 10% per name, and allocate across up to three sectors. This is not a recommended real-money size or portfolio.

## What was measured

- Investor familiarity: timestamped, sourced **proxy** of public familiarity/attention, not people’s private opinions or a claim of trading expertise.
- BIE pattern familiarity: similarities to **already resolved** market observations, never future outcomes.
- Return prediction: development-selection Brier scoring on historical labels, holdout Brier only for evaluation.
- Money feedback: realized virtual P&L, trade costs, cumulative equity, drawdown, last-five paper returns and position exposure. These adjust risk only; recent profit is NOT used to predict next return.
- Liquidity and investment size: hypothetical spread + fixed cost + participation penalty; higher paper size raises the cost assumed for the same daily volume.
- Counterfactuals: no feedback, predeclared forecast-drift abstention, price-only trend, reckless profit-chasing negative control, and synthetic SPY/QQQ buy-and-hold.

## Failure evidence that must be retained

- Familiarity reversals are a failure mode. Drift prevention reduces some simulated losses but cannot infer when the real market will shift.
- Thin liquidity can make a high-quality direction predictor lose money net of simulated trading costs.
- The profit-chase variant can look especially profitable in favorable **programmed** markets, and perform much worse in reversed or illiquid environments. This is not evidence supporting big purchases.
- The null-world no-trade outcome results from a simplified planted null; it is not proof of perfect real-world false-positive filtering.
- We did not authenticate as-of stock data, verify brokerage fills, account for real tax consequences, handle real split/adjusted close feeds, model trading halts or real order book market impact, or collect real investor-familiarity observations.
- Source labels on imported data are declarations, not proof. The public attention/familiarity research literature contains both bias and information explanations; do not assume either universally.

## Result and next objective

**PASS** isolated deterministic research experiment, software checks and audited synthetic controls. **NOT PASSED / NOT TESTED** general intelligence learning, BIE local-model answering, real trading advantage, BIE-Robinhood connection, and any live trading scale-up.

**BIE next self-question:** “Which as-of investor-attention or familiar-pattern observation actually improves forward after-cost results beyond price-only and cash benchmarks across regime changes, and how can I detect failure before risk increases?”

Required next work: genuine point-in-time adjusted price/volume/spread input, strict session calendar, real independent benchmarks, source provenance, no-look-ahead walk-forward tests, prospective paper orders with fill assumptions, and independent confirmation. No real purchases without explicit separate authorization.

## Codex and Windows

1. Extract isolated full-source ZIP to a new folder on Windows. Double-click `TEST_AND_PLAN_H136.bat`.
2. Open the extracted folder in Codex. Read `AGENTS.md`, `CODEX_NEXT_TASK_H136.md`, and `START_HERE_H136.md`.
3. If and only if user authorizes an external-agent read-only connection, collect non-sensitive as-of Robinhood market information for `familiarity-h136-file`. Keep brokerage-order actions disconnected/forbidden.

### Scientific context and risk literature
- Chague, Giovannetti & Paiva (2026), *Familiarity breeds day trade*, Journal of Banking & Finance: https://doi.org/10.1016/j.jbankfin.2026.107651
- *Geography of Investor Attention*, Review of Corporate Finance Studies: https://academic.oup.com/rcfs/article/14/3/752/7700738
- Investor.gov, extended-hours trading risks: https://www.investor.gov/introduction-investing/general-resources/news-alerts/alerts-bulletins/investor-bulletins-42
