# BIE THRIVES Experience · H131 Stock Evidence Coverage Bloom

October 17, 2026 — **isolated offline research candidate derived from H130**; NOT merged with later unified BIE or installed on user's computer. It does not own brokerage credentials, fetch live prices, rank current returns, or execute orders.

## What it does
- Seeds 10 well-documented U.S. large-cap company stocks: MSFT, AAPL, NVDA, AMZN, GOOGL, META, JPM, XOM, WMT, JNJ. SPY/QQQ are benchmark context, not selected stocks.
- Scores nine specific **data coverage** attributes from fresh, properly timestamped, user/Codex-supplied market observations, giving 0–100 research-data quality, source provenance and missing/stale fields. This score is NOT a prediction of future returns or a buy signal.
- Enforces mandatory daily-history, recent-bar, sufficient dollar liquidity, financial filings and tradability gates, plus minimum 70 coverage score and max two stocks per sector.
- Explicitly declines to issue a ranked winner when no measured evidence is present. Returns provisional seed list with `unverified_data_coverage` status.
- After each evaluation asks itself one falsifiable missing-data hypothesis and next source check. Optional --ask-experience calls a *real running* local BIE/Ollama model for one unverified proposal; it cannot change the deterministic ranking and absence is labeled as such.
- No account access, live orders, broker actions, data downloads, or profitable-trading claims in the Python module.

## Use on Windows
1. Extract the **H131 full-source ZIP** to a separate folder, avoiding overwriting your active BIE installation.
2. With Python installed, double-click `SCAN_STOCKS_H131.bat`. Initially it can show only unranked provisional seed stocks.
3. Connect Codex interactively to official Robinhood MCP (after reviewing Robinhood permissions), and give Codex `CODEX_STOCK_DATA_REQUEST_H131.md`. It describes an exact **read-only** collection task; never give it permission to trade.
4. Codex collects permissible read results into `stock_evidence_h131.json` in the H131 root. Review collected sources and dates yourself. The evidence scorer cannot independently authenticate claimed input references.
5. Run the batch file again or `py -3 -m bie stock-h131 --evidence stock_evidence_h131.json --top 5 --report h131_result.json` to rank only qualifying research candidates.
6. Optional: `py -3 -m bie stock-h131 --evidence stock_evidence_h131.json --ask-experience` to ask a running local BIE model for the next source/discovery proposal. It will say unavailable if offline.
7. Run `py -3 -m unittest tests.test_stock_universe_h131 -v` to verify behavior. Before actual paper trading, gather data for non-selected stocks to avoid survivorship/selection bias and test against SPY/QQQ and simple baselines on future data.

## Robinhood MCP instructions
Official: https://robinhood.com/us/en/support/articles/onboarding-an-external-agent/
`codex mcp add robinhood-trading --url https://agent.robinhood.com/mcp/trading`
Follow the Robinhood authentication steps for a dedicated agentic account. If using MCP even for read-only research, inspect its permissions, since the broader service can also support live orders. **Keep all trade approvals enabled**. The Codex collection prompt forbids orders, but a prompt alone is not a hard technical block on a separately connected broker.

Robinhood tool descriptions: https://robinhood.com/us/en/support/articles/trading-with-your-agent/
SEC EDGAR official: https://www.sec.gov/search-filings/edgar-application-programming-interfaces

## Measured output must not be confused with profitability
`research_ready: true` means enough observed input data under provisional thresholds—not a favorable outlook. `selected_research_watchlist` is for human-reviewed monitoring and paper study. Model advice is unverified until tested. Always preserve observed input records as of a real time and do not reuse holdouts for tuning.

## Limits and next real experiment
The current H131 scoring weights and gates are developer-defined *hypotheses*. Challenge them against alternatives in time-safe independent datasets and run prospective paper trading before granting authority over orders. The deterministic scoring is not a substitute for the local language model and does not prove machine self-improvement. Missing Robinhood API schema arguments must be resolved by Codex from the actual connected MCP before calling. The user's local Windows environment remains untouched.
