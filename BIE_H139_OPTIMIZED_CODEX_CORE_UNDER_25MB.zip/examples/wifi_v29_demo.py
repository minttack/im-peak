"""Fictional WLAN observations; this is NOT a field discovery."""
from datetime import datetime, timedelta, timezone
from pathlib import Path
from tempfile import TemporaryDirectory
import json
from bie.wifi_lab import WifiLab, parse_networks
from bie.wifi_novelty import WifiNovelty
with TemporaryDirectory() as d:
    lab = WifiLab(Path(d))
    for i in range(4):
        if i == 2: lab.new_session()
        aps = parse_networks("""SSID 1 : EXAMPLE-ONLY
  BSSID 1 : aa:bb:cc:dd:ee:01
    Signal : 65%
    Radio type : 802.11bn
    Band : 5 GHz
    Channel : 36
""")
        lab.snapshot({"ok": True, "captured_at": (datetime(2026, 10, 15, tzinfo=timezone.utc)+timedelta(minutes=i)).isoformat(), "connection": {}, "access_points": aps, "adapter": {"supported_radios": ["802.11be"]}, "warnings": []})
    print(json.dumps({"synthetic_demonstration_only": True, "result": WifiNovelty(d).report()}, indent=2))
