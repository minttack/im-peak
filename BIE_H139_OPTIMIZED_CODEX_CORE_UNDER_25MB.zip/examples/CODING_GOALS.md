# Goals to try in an empty project

Start with a small complete task so the selected local model's reliability is visible.

1. “Create a Python module that reads an expenses CSV, validates nonnegative decimal amounts, and prints totals by category. Write unittest coverage for malformed rows, exact decimal totals and an empty file. Run the tests.”
2. “Inspect the project. Identify one reproducible bug, write a regression test, implement a minimal fix, and report the before/after test evidence.”
3. “Build a local JSON task tracker with add, list and complete commands. Use atomic saves. Test a restart, duplicate completion, malformed data and an unknown ID.”

Select **Run project tests** for actual execution. An unconnected or weak local model may need a smaller task or clearer instructions; the app reports provider failures and keeps checkpoints rather than pretending it worked.
