# V31 SYNTHETIC X-ray observations — NOT astronomy data

These CSVs are created deterministically from invented Poisson-like counts, for the sole purpose of testing the new analysis engine. `INJECTED` contains a nominal 9% dip at period 2.21857312 days and epoch 100 in arbitrary day units. `NULL` has no intentional dip. The signal-to-noise is intentionally very high, unlike many real Chandra transit observations. They do not reproduce any actual NASA telescope event list and they cannot support an astronomical discovery.

Real processed source and background counts should be exported to this format with **the same barycentric time system as the ephemeris**, visit identifier for independently obtained observations, correct exposure after good-time filtering, correct source/background extraction-area scaling and calibrated instrument settings.

Raw Chandra ACIS event files are NOT supported directly. Reduce them with official CIAO or other instrument-specific software first. The software is a screening tool, not a certified telescope calibration pipeline.
