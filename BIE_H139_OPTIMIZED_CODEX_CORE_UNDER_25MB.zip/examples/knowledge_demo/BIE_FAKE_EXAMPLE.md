# Example knowledge only — not real research

Example: an imaginary local Wi-Fi NAS named DEMO-NAS. It contains notes, project logs, and files shared with permission.

ThoughtPacket: source=demonstration; relevance=storage walkthrough; confidence=0 (fictional); uncertainty=complete; action=demonstrate a search after importing this folder.
