"""Synthetic demonstration only: generated APs, no physical observations."""
from pathlib import Path
import json
import tempfile
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from bie.wifi_lab import WifiLab, parse_networks
from bie.wifi_discovery import WifiDiscovery

fake_networks = '''SSID 1 : TEST-SYNTHETIC
BSSID 1 : 00:00:00:00:00:11
 Signal : 60%
 Radio type : 802.11ax
 Band : 5 GHz
 Channel : 36
SSID 2 : TEST-UNAVAILABLE
BSSID 1 : 00:00:00:00:00:12
 Signal : 80%
 Radio type : 802.11be
 Band : 5 GHz
 Channel : 149
'''
with tempfile.TemporaryDirectory() as temp:
    lab = WifiLab(Path(temp))
    for idx, signal in enumerate([40, 50, 48, 60, 55, 59, 66, 50, 70, 62, 72, 75, 61]):
        if idx == 7:
            lab.new_session()
        lab.snapshot({"ok": True,
            "captured_at": f"2026-10-15T08:{idx:02d}:00+00:00",
            "connection": {"ssid": "TEST-SYNTHETIC", "signal_pct": signal, "radio": "802.11ax", "band": "5 GHz", "channel": "36"},
            "access_points": parse_networks(fake_networks),
            "adapter": {"supported_radios": ["802.11ax"]}, "warnings": []})
    result = WifiDiscovery(Path(temp)).report()
    print("SYNTHETIC TEST DATA — NOT A PHYSICAL WI-FI DISCOVERY")
    print(json.dumps({k: result[k] for k in ("status", "sample_summary", "signal_model", "thought_packets")}, indent=2))
