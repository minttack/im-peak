@echo off
setlocal
cd /d "%~dp0"
where codex >nul 2>&1
if errorlevel 1 (
  echo Codex CLI is not installed/on PATH. Open the folder in Codex desktop instead,
  echo or install the official Codex CLI and sign in.
  pause
  exit /b 1
)
echo Opening Codex in H139 project folder. Review AGENTS.md first.
echo WARNING: Codex MCP may expose live order tools; keep approvals ON and NEVER use order tools for this project.
cmd /k "cd /d \"%~dp0\" && codex"
