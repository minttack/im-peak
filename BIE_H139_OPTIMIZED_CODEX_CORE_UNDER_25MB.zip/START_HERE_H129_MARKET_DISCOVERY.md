# BIE THRIVES Experience — H129 Market Discovery Bloom

**Date:** 2026-10-17 (research candidate). **Status:** Offline experimental add-on to recovered H116 source; **NOT** a BIE Windows installation, guaranteed moneymaker, live trading bot, TradingView-connected tool, or replacement for the newer unified branches.

## The creator's goal

A continuously learning research agent that asks itself, after **each** experiment and discovery, "What is the most useful next step toward making the creator's long-standing stock-trading AI dream real? What would falsify my idea?", then uses measured evidence to choose another bounded test.

This is a legitimate technical goal, but no experiment can guarantee 100% trading win rate or profitability. **100% unit-test pass is not 100% trading accuracy.**

## What is implemented and what isn't

- **Implemented:** a read-only offline OHLCV CSV importer with size, ticker, chronology, duplicate and OHLC validity checks; 11 predeclared research strategies including cash and buy/hold; development-only adaptive candidate ordering; a single validation-selected stock/strategy; a partition isolated from selection; transaction cost approximation; a post-test ThoughtPacket after every strategy experiment; explicit testable falsifiers and next candidates; reports with honest failure labels.
- **Implemented:** optional **actual** local Ollama question, using the existing BIE local-model transport. This is an advisory, one-time post-run follow-up only; the default experiment-selection engine is transparent deterministic code. If Ollama is not running, it says so. It does not claim a local model already answered.
- **Not implemented:** real-world data sourcing, TradingView Pine Script or API bridge, real-time broker integration, portfolio optimization, news/fundamental data, AI weight training, autonomous generation of novel indicators, or automatic continuous execution. It does not actually place orders. Do not use its reported simulated selections for trades.
- No prior BIE version is silently upgraded or deleted. This is an isolated branch against recovered H116, not a merge of H119/H125/H128 or the newer unified source.

## How to run

From the folder containing this `bie` package:

```bat
py -3 -m bie market-h129-demo --world switching --seed 2177 --report demo.json
py -3 -m bie market-h129-demo --world noise --seed 111
py -3 -m bie market-h129-evaluate "C:\\path\\to\\your_ohlcv.csv" --cost-bps 15 --report stock_research.json
py -3 -m bie market-h129-demo --ask-local-model --model qwen2.5:3b
py -3 -m unittest discover -s tests
py -3 -m bie verify-vendor
```

Input CSV header:

```
date,ticker,open,high,low,close,volume
```

ISO dates ascending within each ticker. At least 160 bars per ticker; same dates for all tickers. Prices should reflect comparable corporate actions; this prototype does not adjust splits/dividends. Maximum 1.6 MB and 20,000 total rows. Imported data is user-provided and **not independently authenticated**.

## Evidence as of Oct 17

- **271/271 Python unit tests pass**, including 26 new H129 tests, on isolated Linux source. BIE bundled 11/11 vendor hashes checked.
- **120/120 synthetic stress tasks executed**, 30 predeclared seeds each for noise, downtrend, trend, switching. Selected strategy beat buy-and-hold in **36/120** trials, and made a positive holdout return in **38/120**. Those are not independent real-market trials and do not prove or disprove profitable deployment.
- In one illustrative switching seed (2177), validation showed 8/8 positive exposed days (100%), but frozen holdout 4/8 (50%) and **-12.908 percentage points** versus the buy-and-hold return over the same holdout. Even apparently perfect validation can fail. These are *positive days when exposed*, not closed-trade win rates.
- The attempted local model request on this runtime returned **local_model_unavailable**. There is therefore no claimed actual local BIE model answer; the included conditional dream response is a *developer-authored goal prompt* and deterministic candidate planning output.

## Next independent Direction Bloom

Acquire a legitimate, survivorship-aware and split-adjusted historical market dataset with source timestamps. Design a precommitted, regime-aware strategy with cash and buy-and-hold controls, trading friction and a completely new untouched evaluation period, then conduct prospective paper trading for several months. Only consider changes that survive those controls. Never optimize repeatedly on the same final holdout and still call it 'unseen'.
