# H131 Codex task policy — BIE Evidence Coverage Bloom

Read START_HERE_H131_STOCK_SELECTION.md and CODEX_STOCK_DATA_REQUEST_H131.md. The user asks BIE to select information-rich stocks itself; selection must be grounded in timestamped source facts, not LLM intuition. Do not invent metrics. Ask BIE for its next falsifiable evidence gap after each evaluation. Use the stock-h131 CLI, not order functions, for this task.

Research and coding are authorized; live broker account trades, account mutation, personal credentials, and unattended brokerage operations are NOT. A Robinhood MCP connection has many capabilities; for this research use read-only market tools, keep trading outside this coding workflow, and preserve a human approval boundary. Do not train/tune on holdout data, optimize a 100% win-rate, or rephrase the same request until it returns a desired result.
