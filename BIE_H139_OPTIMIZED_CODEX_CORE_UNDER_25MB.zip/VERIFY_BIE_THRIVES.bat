@echo off
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 (
  python -m unittest discover -s tests -v
  python -m bie verify-vendor
) else (
  py -3 -m unittest discover -s tests -v
  py -3 -m bie verify-vendor
)
pause
