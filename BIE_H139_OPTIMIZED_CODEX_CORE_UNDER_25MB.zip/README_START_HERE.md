# CURRENT RELEASE: BLOOM × BIE THRIVES v32

Read `README_BIE_BLOOM_RECONSTRUCTION_V32.md` for the new Computational Planet Reconstruction tab and commands. Earlier documentation below is preserved for historical continuity.

---

# BIE Experience Assistant 25

An integrated local assistant upgrade built on your existing BIE Desktop v1 and BIE Experience v24. It adds a native desktop workbench, persistent memory and conversation continuity, a resumable agent loop, project coding tools, real test execution, and measured experience feedback. Language generation comes from a local model you install with Ollama.

## Start on Windows

1. Install Python **3.10 or newer**, including Tkinter and the Python launcher, from [python.org](https://www.python.org/downloads/windows/).
2. Install/start [Ollama](https://ollama.com/download/windows). If you already use BIE Desktop v1, keep your installed model. `ollama list` shows available names. The inherited default is `qwen2.5:3b`; if needed, run `ollama pull qwen2.5:3b` once. A larger model is not automatically faster or better on your hardware.
3. Extract the **entire ZIP** into a normal folder. Double-click **START_BIE.bat**.
4. Choose your project folder, click **Find models**, and enter a concrete goal. Click **Start task**, or press **Ctrl+Enter**.

No pip packages are required for the assistant. Linux needs the OS's Tkinter package for the GUI; terminal commands work without a display. Run `sh START_BIE.sh` on Linux/macOS. Windows speech features require the system speech components and microphone access.

Example goal:

> Build a Python command-line task tracker in this project. Support add, list, and complete; persist tasks to JSON with atomic saves. Write meaningful unittest tests, check the code, and report the observed result.

Enable **Run project tests** if you want BIE to execute the project's Python tests. This runs code with your user permissions, so use a project you trust. Project file editing and test execution are separate choices. Offline **Search BIE**, **Remember**, **Memory**, and **Experience** work without an LLM.

## Work budget

**Burst is selected by default.** Budgets apply to each run; Resume grants another run using the existing checkpoint.

| Profile | Model rounds | Tool calls | Wall-time budget | Requested output tokens per model response |
|---|---:|---:|---:|---:|
| Quick | 4 | 8 | 90 seconds | 1,024 |
| Balanced | 12 | 24 | 5 minutes | 2,048 |
| Burst | 32 | 64 | 15 minutes | 4,096 |

The app pauses when the budget is exhausted. Select the task under **Tasks → Resume selected** to continue. These are bounded per-run budgets, not a promise to finish any project in that time. Running tools stop at their own boundaries; model socket waits can take up to 30 seconds, project tests up to 45 seconds, and the inherited BIE processor has its original per-command timeouts.

There is no 150,000,000-line setting. This app cannot change ChatGPT's output limit, your model's context limit, or your PC's compute capacity. It creates useful modules across multiple saved steps. Code volume, model speed and task correctness are different measurements.

## What the upgrade actually does

- **Persistent memory:** SQLite full-text search across all saved notes, with source, confidence, status, scope, chronology and correction links. Earlier statements remain available for historical replay; an explicit correction retires the old statement for current recall. Unresolved conflicting notes remain separate.
- **Continuity:** recent conversation from the same project and relevant saved memory are included in the next task. Earlier Desktop v1 notes and messages can be imported without altering that database. Imported transcripts stay available through the history API; imported notes participate in recall.
- **Experience:** previous tool outcomes for the same project inform the next model prompt. Recent median tool latency, failures and error details are retained. This is retrieval and outcome feedback, not training model weights or proving a superior reasoning algorithm.
- **Coding:** inspect project files, write complete modules, require the current content hash before overwrites, keep old bytes as backups, check Python syntax without executing it, and optionally run unittest. Changes are verified against written bytes. Failed checks feed a correction round. The final task record includes an application-generated verification footer.
- **Autonomous work:** an LLM can call the registered tools across multiple rounds. Checkpoints survive restarts. Expired worker leases become paused tasks; incomplete work is not silently rerun. Action receipts prevent repeating a completed tool action when its result was saved before an interrupted checkpoint. A crash before a receipt can still leave an uncertain external effect; non-idempotent native goals require inspection in that case.
- **Performance display:** the small line shows observed model response latency. Tokens/second uses the local model's reported counters. The Experience tab reports measured tool latency and outcome counts. It does not display invented GPU utilization or “intelligence percent.”
- **Voice:** the Windows microphone button captures one utterance into the input box for review. Speak reply uses Windows speech synthesis. These Windows paths were implemented but not exercised in the Linux build environment.

## Integrated tools

`memory_recall`, `memory_note`, `bie_search`, `bie_history`, `bie_goal`, `project_list`, `project_read`, `project_write`, `python_check`, `python_tests`, `experience_status`.

Tool names and arguments are validated before execution. The model cannot add tools, enable test execution, select a different project root, or run an arbitrary shell command. File tools block traversal, symbolic links and common secret/configuration paths. This is a file-tool boundary, **not an OS sandbox** for enabled project tests. External apps and ChatGPT `@` connectors are not automatically connected to this local program.

## Original BIE continuity

- `vendor/desktop_v1/bie_ai.py` and its complete original v8 archive are byte-identical to the recovered Desktop v1 release. Original tests are included unchanged.
- `vendor/v24/` contains the unchanged v24 experience module, policy tests, research results and the latest saved BIE SQLite checkpoint. Retrieval reads this database in read-only mode: **62 sources, 345 original processor events, 6 v24 evidence packets**.
- `bie_goal` calls the original v8 objective processor through the original desktop adapter. It uses a separate working copy under the new assistant state directory. Its new goal events are not injected into the frozen v24 checkpoint.
- The v24 failed policy-promotion result remains a failed result. Its synthetic device experiments do not grant a physical GPU speed claim or a general intelligence claim.
- Exact parent hashes and the eleven bundled unchanged parent files are listed in `PROVENANCE.json`. This is an additive assistant release; it does not rewrite the earlier saved release packages.

## Persistent state and backup

Windows: `%LOCALAPPDATA%\BIE_Experience_AI\assistant_v25\`

Linux/macOS: `~/.local/share/bie_experience_ai/assistant_v25/`

Override with `BIE_ASSISTANT_HOME` or `python -m bie --home <folder> ...`.

The state directory contains `assistant.sqlite3`, project file backups, optional native BIE working state, and the default project. Back up the whole directory **while BIE is closed**, including any SQLite WAL files. A new task never gains access to the assistant's state merely by following instructions in a retrieved document.

To import old notes, choose **Memory → Import v1 history** and select the earlier `%LOCALAPPDATA%\BIE_Experience_AI\bie_ai_conversations.sqlite3`. Import verifies the old audit first, records its provenance, and skips an identical completed import.

## Terminal use

Run from the extracted release directory:

```text
python -m bie search "intelligence accuracy"
python -m bie remember "Use meaningful tests for BIE changes" --subject coding
python -m bie recall "coding"
python -m bie ask "Inspect this project and suggest a repair" --project C:/Projects/MyApp --read-only
python -m bie ask "Implement the agreed repair and test it" --project C:/Projects/MyApp --allow-tests
python -m bie tasks
python -m bie resume TASK_ID
python -m bie resume TASK_ID --allow-tests
python -m bie cancel TASK_ID
python -m bie audit
python -m bie verify-vendor
```

To correct a saved note, take its ID from `recall`, keep the same subject and scope, and run:

```text
python -m bie remember "Updated observation" --subject coding --supersedes MEMORY_ID
```

Use `enqueue` instead of `ask` to queue work. `python -m bie work --workers 2` drains submitted tasks while that process is running. Up to four workers are supported; only one may edit the same project at a time. This queue is not a cloud scheduler and does not keep running after the program exits.

## Verification and limits

See `RELEASE_REPORT.md` and the raw reports. Tests exercise real files, SQLite, cross-process claims, local HTTP protocol transport, the original BIE objective processor, and actual Python project tests. Scripted model responses are explicitly test fixtures. No live LLM, GPU, Windows microphone, or native desktop rendering was available in the build host. Local model quality and hardware performance still need measurement on your computer.

The native window's code compiles, but its layout needs a Windows display smoke test. For the shortest deployment check: launch the window, use Search BIE, save/recall a note, find your local model, run the example in an empty project, stop/resume a task, and try microphone/speech if wanted.

Reproduce core checks:

```text
python -m unittest discover -s tests -v
python BENCHMARK.py
```

The benchmark uses synthetic unique-key notes and a full-scan comparator; it measures retrieval, not LLM intelligence. The supplied Dimensions publication count and eight author-year references were not independently verified; the first linked record was inaccessible during this build. Implementation did not assume those claims were validated. The local transport follows the [official Ollama chat API](https://docs.ollama.com/api/chat).
