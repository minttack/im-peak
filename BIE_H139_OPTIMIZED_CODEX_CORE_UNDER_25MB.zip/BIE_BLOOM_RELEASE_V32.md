# BIE × BLOOM v32 — Computational Planet Reconstruction

**Release status:** Runnable, locally verified research model. **NOT** a new planet discovery, terrain scan or probability-of-life model.

- Owner-originated BIE/BLOOM project continued from verified v31 full-source parent.
- Adds `bie/planet_reconstruction.py`: five seeded, transparent temperature-map ensembles, per-scenario conditional spread, deterministic 18×36 maps and energy check.
- Adds archive-backed `planet-reconstruct` CLI, read-only `astro_reconstruct` assistant tool and a native BLOOM Reconstruction tab with a selectable temperature-map visualization.
- Optionally reads user-chosen source-labeled X-ray luminosity/spectrum JSON; x-rays diluted by 4πr² are *orbital exposure only*, not surface dose or calibrated atmospheric survival.
- Source catalog values, uncertainty assumptions and absent evidence remain visible; fails closed if stellar insolation is missing.
- Strictly labels maps as hypothetical; cannot see real geography or people.
- Reproducibility tests, virtual-display smoke and 11-file inherited vendor check included. No changes to bundled BIE research memory.

**Start:** `START_BIE.bat` → BLOOM · Exoplanets → Offline examples → BLOOM · Reconstruction → Run competing environments.

**Report:** `reports/v32_proxima_hypothetical_reconstruction.json` is an *offline reference sample*, not fresh astronomical measurements.
