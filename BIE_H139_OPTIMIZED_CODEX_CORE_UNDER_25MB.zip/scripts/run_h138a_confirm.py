"""Frozen confirmation across new seeds; paper-only and zero glyph attribution."""
import json
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor, as_completed
from statistics import mean
from bie import familiarity_money_h136 as h
from bie import accuracy_evidence_h138a as a
WORLD=a.WORLDS
SEED=tuple((88201,))
MODES=('missing','misleading','expensive')
def one(x):
 w,s=x
 result=a.probe(h.synthetic(s,w,days=90),modes=MODES)
 return [{'world':w,'seed':s,'mode':k,'model':result['frozen_development_policy'], 'disturbed_rows':v['rows_disturbed'],'changed':v['signal_guard_choice_changes'],
          'results':{z:{'return':q['net_return_pct'],'drawdown':q['max_drawdown_pct'],'trades':q['paper_rebalance_trades']} for z,q in v.items() if isinstance(q,dict) and 'net_return_pct' in q}} for k,v in result['disturbances'].items()]
if __name__=='__main__':
 tasks=[(w,s) for w in WORLD for s in SEED]
 rows=[]
 with ProcessPoolExecutor(max_workers=1) as pool:
  for f in as_completed([pool.submit(one,t) for t in tasks]):
   a=f.result();rows.extend(a);print('completed',a[0]['world'],a[0]['seed'],flush=True)
 rows.sort(key=lambda x:(WORLD.index(x['world']),x['seed'],MODES.index(x['mode'])))
 summary={}
 for w in WORLD:
  for m in MODES:
   group=[r for r in rows if r['world']==w and r['mode']==m]
   keys=tuple(group[0]['results'])
   summary[f'{w}/{m}']={'n':len(group),'mean_return':{k:round(mean(r['results'][k]['return'] for r in group),4) for k in keys},
      'mean_drawdown':{k:round(mean(r['results'][k]['drawdown'] for r in group),4) for k in keys},
      'signal_guard_better':sum(r['results']['h138a_availability']['return']>r['results']['existing_h136']['return'] for r in group),
      'signal_guard_worse':sum(r['results']['h138a_availability']['return']<r['results']['existing_h136']['return'] for r in group),
      'mean_changed_days':round(mean(r['changed'] for r in group),3)}
 out={'schema':'bie.h138a.confirm.v1','seeds':list(SEED),'worlds':WORLD,'disturbances':MODES,
      'world_seed_pairs':len(tasks),'cases':len(rows),'synthetic_only':True,'original_glyph_used':False,'orders':0,'summary':summary,'records':rows}
 dest=Path('reports/H138A_FROZEN_CONFIRM.json')
 if dest.exists():raise ValueError('Refusing to replace sealed report')
 dest.write_text(json.dumps(out,indent=2),encoding='utf-8')
 print('FINISHED',len(rows),str(dest))
