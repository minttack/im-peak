# BIE Growth — evidence-oriented upgrade rationale

The creator's design was already rich in symbols, alternatives, memory and research applications. The missing operational link is **prospective calibration**: can a frozen hypothesis with a probability beat a baseline on *new* data, and can the system detect where transfer stops working?

The Growth Ledger turns that question into a measurable, conservative software feature. It is deliberately separate from the Bitcoin miner, IRL game, astronomical model, Wi-Fi investigation and older local assistant memory. Each can supply experiments, but none is automatically promoted merely because another branch reported success.

## ANCHOR / FLUX / GENERATOR / VERIFIER / MEMORY implementation

- **ANCHOR:** every prediction contains goal, evidence source, domain/context, explicit baseline, verifier plan and uncertainty. Previous entries are never silently edited.
- **FLUX:** each packet declares an alternative explanation and enumerates at least two outcomes (`chance_space`).
- **GENERATOR:** the owner proposes the tested strategy; no software-generated claim counts as verified evidence.
- **Probability:** a bounded [0,1] forecast for a binary event; it is not a measure of the entire chance space.
- **VERIFIER:** independent read-only comparison on the *same* domain, context and strategy, with a small context-local holdout plus a descriptive bootstrap interval.
- **Correction / MEMORY:** append an invalidation event when a case was mislabeled or assumptions changed; negative results remain in the journal.

## Known weaknesses / explicit exclusions

1. A random local holdout assignment is not a sealed, independent dataset. A source label is not an independent source identity. Do not call a result reproduced until independent data and oracle checks establish it.
2. Differences in environment invalidate automatic transfer. A synthetic gain in a familiar task can be a loss after a change. Preserve negative cases and compare per context.
3. A hash chain protects against accidental content changes in retained rows; it does not prevent deliberate rewritten history, missing final rows or malicious local database edits.
4. 'Wiggle' is a metaphor for bounded search-budget escalation. It is not a new physical mechanism and cannot by itself bypass SHA-256d security.
5. AI model weights, installed apps, remote storage, tools, permissions and network activity remain unchanged unless separately and explicitly changed by the owner.

## Independent replication needed next

Choose one genuine BIE decision policy, predefine binary success and a conventional baseline, generate a prospective series of unseen tasks, record probabilities before outcomes, use identical task streams and preserve full controls. Then rerun the same fixed analysis on an independently collected untouched confirmation set. Require useful effect size, error bars, calibration, negative-transfer safeguards, and a practical latency/cost budget before integrating strategy changes into the assistant's default behavior.
