@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>&1
if %errorlevel%==0 (set "PY=py -3") else (set "PY=python")
echo BIE H139 OPTIMIZED - offline research tests only.
echo No Robinhood connection, funding or real orders.
%PY% -m unittest tests.test_flood_movement_h139 -v
if errorlevel 1 (echo ERROR: Focused tests FAILED. & pause & exit /b 1)
if exist "vendor\desktop_v1\ORIGINAL_BIE_V8_UNMODIFIED.zip" (
 echo Full original vendor archive found. Checking vendor hashes...
 %PY% -m bie verify-vendor
 if errorlevel 1 (echo ERROR: vendor check FAILED. & pause & exit /b 1)
) else (
 echo NOTICE: Historical vendor archive excluded to save space.
 echo Vendor verification NOT EXECUTED. Use optional legacy packs to restore it.
)
echo Focused tests completed successfully. This is not a real trading validation.
pause
