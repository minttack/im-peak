# BIE THRIVES Experience v34.1 — Auto, aiming at MaximumSafe

**Creator:** user. **Release:** locally tested source candidate, not installed on user's Windows PC. Builds on v34 Learning Accelerator without removing previous code or historic data.

## Default settings

- GUI defaults to `Auto`. CLI `learn-run` and `learn-plan` likewise default to `Auto`.
- Auto **target** = `MaximumSafe`, the largest *bounded* v34 public-reference import profile (up to 300 queries per approved batch, 10 references/query, 4 concurrent query jobs, minimum 0.6 seconds between starting queries, 900-second run budget).
- Auto starts at `Balanced` for an evidence-backed warm-up. A successful batch of at least **10 completed queries**, **40% novel reference metadata** and **no more than 5% failed queries** advances one step: `Balanced → Accelerated → MaximumSafe`. It stays at MaximumSafe while measured batches are healthy. A batch with >5% query failures backs off a level; >20% sends Auto to `Evidence`.
- Small, duplicate-heavy, or low-novelty batches do **not** trigger speed escalation. The algorithm reads the most recent recorded batch summary, not your model's thinking speed. This is an adjustable heuristic and does not guarantee higher useful learning throughput.
- Provider request ceilings, terms, temporary bans, actual network performance, and local resource constraints may require smaller batches. Never bypass restrictions or run automatic infinite loops.
- Source titles/links remain **unverified metadata**—not full articles, reliable facts, training of neural weights, or evidence of self-improving intelligence.
- Network import always requires **explicit approval for each batch**. No background process is installed.

## Start

1. Unzip the **FULL SOURCE** ZIP to its own new folder. Keep the prior v34 installation separately; use an isolated `--home` initially if you want a clean safety test.
2. Run `START_BIE.bat`, open `BIE · Learning Accelerator`; the profile defaults to `Auto` and the label explains its target.
3. Select `examples/LEARNING_AUTO_MAX_V34_1_EXAMPLE.json`, choose `Preview no network` and inspect queries, providers and budgets.
4. When you are ready to make one public reference import, click `Approve & run online import` and confirm. The first run will be `Balanced` (the example has 24 unique jobs); subsequent runs require additional distinct queries in a new file to evaluate further step-ups.
5. View the measured history. You may always select `Evidence`, `Balanced`, `Accelerated`, or `MaximumSafe` manually; `Auto` learns its rate from prior run reports, not from speculation.

Command line (inside unpacked source; internet run only with explicit flag):

```powershell
py -3 -m bie --home C:\BIE_Test learn-plan examples\LEARNING_AUTO_MAX_V34_1_EXAMPLE.json --profile Auto
py -3 -m bie --home C:\BIE_Test learn-run examples\LEARNING_AUTO_MAX_V34_1_EXAMPLE.json --profile Auto --confirm-network
py -3 -m bie --home C:\BIE_Test learn-status
py -3 -m unittest discover -s tests -v
```

## Verification and limitations

A local offline unit-test suite checks the speed governor (ramp to maximum, step-down on failure, no upshift on repeats), source selection, manual permission, and existing BIE behavior. Historical vendor archives and v34 files are left intact in this candidate; their hashes are recorded in the release manifest. This is **not** a live speed benchmark or proof of 100 million verified facts learned. No remote PC settings were changed.
