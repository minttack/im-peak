# BIE THRIVES Experience · H133 Teacher–Learner Bloom

**Date:** October 17, 2026. **Status:** isolated offline research candidate from existing H132 source. NOT the installed Windows or newest unified BIE project. No Robinhood session, real market data, live order, or independent LLM reply.

## Proven code behavior
- **361/361 Python unit tests passed** (345 inherited including H132 + **16** teacher-specific).
- **11/11 vendor hash/integrity checks passed.**
- Optional genuine local Ollama/BIE model ask returned `local_model_unavailable`; the program does not impersonate a model or pretend to have trained model weights.
- ChatGPT-authored bounded teacher lesson `teacher_lesson_h133.json` guides a learned policy (min sample count, min net excess, four evidence guards). Candidate selected on development-only synthetic cases; holdout used only after freezing SHA256 choice.
- One seeded holdout: 240 synthetic evidence-classification examples; learned-policy 236/240 (98.33%), false accepts **4**, positive-return-only baseline 125/240 (52.08%), false accepts **115**.
- 50 independently seeded synthetic holdouts of 240 cases each = **12,000 toy examples**. Mean learned-policy accuracy **97.67%** (range 95%–99.58%); simple positive-return-only policy mean **51.13%**. Toy gate passed 50/50. Mean false accepts **5.6/240**, vs simple baseline **117.3/240**. Each holdout introduces latent simulated execution friction invisible to the learned policy.

## Crucial interpretation
This is a policy-selection and evidence-verification *software research exercise*, **not** learning the underlying market, not reinforcement learning a neural model, not real ChatGPT-to-BIE API transfer, not a demonstrated investment edge, and not an argument that perfect or absolute intelligence has been achieved. Training and evaluation labels come from a toy rubric authored for the test. Repeated use of these toy holdouts must not be called genuine prospective market confirmation. No task authorizes real-money trades.

## Next scientific milestones
1. Start the actual BIE Ollama model on the Windows PC and collect its own next-experiment proposal with verified provenance, not an invented response.
2. Add a consent-based teacher-message interface (user-provided ChatGPT packets or explicitly configured official model API) with privacy, usage limits, source/correction ledger and independent hallucination checks; do not send secrets.
3. Implement harder natural language/market-data reasoning challenges in which correct labels come from independent external observations rather than the same synthetic rubric used to train the policy.
4. Check BIE's proposed improvements against unchanged simple controls, fresh chronological holdouts, realistic transaction costs, risk constraints, and forward paper-trading records. Every discovery should generate an explicit falsifiable next experiment.
5. Compare *verified discoveries per actual wall-clock second* to a fixed baseline. Computing smarter is measurable; literal time dilation by software is not established.

## Recommended Windows/Codex handoff
Extract the `H133_FULL_SOURCE` ZIP into an **isolated** folder. Double-click `TEACH_BIE_H133.bat`, then open the folder in Codex and instruct it to read `CODEX_NEXT_TASK_H133.md`. If `--ask-experience` reports unavailable, install and run your BIE local Ollama model. Keep any Robinhood MCP agent disabled for unattended code writing.
