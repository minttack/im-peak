@echo off
setlocal
cd /d "%~dp0"
echo H138A targeted Accuracy / familiarity tests (paper-only)
py -3 -m unittest tests.test_accuracy_evidence_h138a tests.test_accuracy_bloom_h137a -q
if errorlevel 1 exit /b %errorlevel%
py -3 -m unittest tests.test_familiarity_money_h136 tests.test_relevance_ladder_h135r -q
if errorlevel 1 exit /b %errorlevel%
py -3 -m bie verify-vendor
if errorlevel 1 exit /b %errorlevel%
echo Saved historical confirmation: reports\H138A_FROZEN_CONFIRM.json
echo No Robinhood orders were placed.
pause
