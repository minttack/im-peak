@echo off
setlocal
cd /d "%~dp0"
echo =====================================================
echo BIE Experience H132 - offline ten-stock research tests
echo NO ROBINHOOD ORDERS. NO BROKER ACCESS.
echo =====================================================
where py >nul 2>&1
if errorlevel 1 (
 echo Python launcher not found. Install Python 3 for Windows and retry.
 pause
 exit /b 2
)
py -3 -m unittest discover -s tests -p "test_*.py"
if errorlevel 1 (
 echo FAILURE: Python suite did NOT pass. Do not promote this candidate.
 pause
 exit /b 1
)
py -3 -m bie verify-vendor
if errorlevel 1 (
 echo FAILURE: vendor source hash check failed.
 pause
 exit /b 1
)
if not exist reports mkdir reports
set OUT=reports\H132_SYNTHETIC_%RANDOM%_%RANDOM%.json
py -3 -m bie universe-h132-battery --report "%OUT%"
if errorlevel 1 (
 echo FAILURE: benchmark did not complete.
 pause
 exit /b 1
)
echo.
echo Software checks completed. New SYNTHETIC report: %OUT%
echo NOT a live trading recommendation. See CODEX_FIRST_TASK_H132.md.
pause
