# BIE H137A — Accuracy Attribution & Verification Bloom

October 17, 2026. Offline, experimental extension of the **H136 Money/Familiarity** research branch. **Do not install over a newer unified source.** No live brokerage calls or real orders; not an independently deployed BIE model.

## What it does

- Adds `bie/accuracy_bloom_h137a.py` and 23 dedicated acceptance tests.
- Uses the original Accuracy symbol's **concept** as a test/check/correct workflow, NOT as a market feature extracted from the creator's drawing.
- Compares raw H136 forecasting, causal error-feedback, feedback + modeled high-cost avoidance, and an uninformative sham feedback control.
- Reports percentage of held-out paper-trading days where feedback/cost safeguards changed a selection; provenance explicitly says the change did NOT come from glyph pixels.
- Logs market-data knowledge cutoff, pre-holdout policy, calibration (Brier/ECE), confident wrong calls, virtual dollar P&L, drawdown, modelled costs and decisions.
- Enforces chronology: at day t, only outcomes resolved through day t-1 can change the day-t decision; seeded negative and mutation tests.

## Start Windows / Codex

Extract complete source to a NEW folder. Install Python 3.10+; open that folder in Codex. Use `TEST_ACCURACY_H137A.bat` or:

```bat
py -3 -m unittest discover -s tests -q
py -3 -m bie verify-vendor
py -3 -m bie accuracy-h137a-demo --world familiarity_trap --seed 33701 --days 104 --report reports\accuracy_demo.json
```

For supplied, independently verified **as-of** dataset in the compatible H136 schema:

```bat
py -3 -m bie accuracy-h137a-file path\to\h136_data.json --report reports\supplied_accuracy.json
```

Do not name synthetic JSON files 'historical' by changing `source_mode`; labeled source text is not data-origin authentication.

## Test results

Development (40 simulated worlds, 8 seeds each × five regimes): tried an initial estimated-return gate, which mistakenly rejected profitable trades. Modified to consider a cost rejection only if **modeled** cost exceeded 50 basis points AND the pre-holdout expected gross return estimate failed cost+10bps. Then froze it.

100 independent synthetic confirmation worlds (20 new seeds × five worlds, 104 synthetic days each), 18 additional stress variants and 60 fresh direct H136-versus-overlay comparisons were evaluated. See `H137A_TEST_REPORT.md` and `H137A_FROZEN_CONFIRMATION.json` for both improvements and failures. No gains claimed from actual Accuracy glyph geometry. The original drawing is absent from this research source; a full image/no-image randomized-profile ablation must be run in the separate glyph-preserving project.

## What to do next (Codex)

Follow `CODEX_NEXT_TASK_H137A.md`. Prioritize authentic original Accuracy source recovery and hash validation, keep unmodified glyph bytes, then compare *image features* against meaning-only, no-image, shuffled and random inputs under equal compute and chronological sealed holds. For a real stock performance claim: first acquire verified exchange prices, real source timestamps, realistic executions and forward-paper outcomes. No user-money deployment or order automation from H137A results.
