# BIE THRIVES — H116 Maximum Verified Intelligence Research Cycle

**Decision: HOLD the new reranker as a performance improvement, PASS as a read-only additive experiment.**

**Parent**: v34.2 Auto Max + H114 Bloom geometry. No changes to user's Windows machine, state, models, or existing ZIP. This is a candidate tree (not a promoted production release).

## Strongest proposed improvement

A **question-driven evidence gate**: (1) identify unanswered, important questions, (2) allocate bounded research queries to sources that may resolve them, (3) require independently checkable supporting citations, (4) detect disagreement and abstain when unresolved, (5) preserve corrections, and (6) use sealed unfamiliar questions to decide whether to keep any change.

This is a hypothesis. Metadata indexing and title overlap are not learning intelligence. The current Auto/MaximumSafe profile improves the *quantity of reference lookups*, not the count of verified facts. Its novelty thresholds are about reference identifiers, not semantic novelty or truth.

## Actual BIE native run (isolated scratch, no Ollama)

`python -m bie --home <new empty scratch folder> native-goal "..."`

The installed source-backed native processor completed four bounded tasks: memory search, inherited claim review, source integrity and evidence synthesis. Verified 61 native source files' integrity. It retrieved one inherited synthetic reasoning ThoughtPacket, and two previously REJECTED candidate policies (one negative-transfer loss and one unconvincing win). No autonomous source selection, new open-web acquisition, model weight changes or model-backed freeform solution occurred. Read `reports/H116_NATIVE_BIE_RESPONSE.json` for exact details.

## Implemented H116 opt-in experiment

- `bie/evidence_retrieval_h116.py`: reranks the top 50 existing FTS5 keyword-search candidates by query-term coverage with a modest title/phrase term. It returns the original citation URL and evidence label, refuses blank/out-of-bounds requests, and explicitly marks **zero facts verified**. No internet access; no autonomous tasks; no writes to stored knowledge.
- `python -m bie --home <your-state-path> evidence-search "topic terms"` is an opt-in standalone CLI.
- The read-only assistant tool `evidence_search` is available to your local model-backed BIE assistant. It does not replace existing `knowledge_search`.
- Old Auto Max, vendor code, Growth Ledger, and Bloom H114 behavior are untouched.

## Frozen synthetic holdout: no gain

Before running the comparison, `examples/H116_HOLDOUT_PRECOMMIT.json` was created and SHA256 recorded (`6319859196d3c5ed7487c0a070de311d9325819099bbc32c4b6e31069fc49478`). It contains 30 synthetic BIE-software-related passages, 20 hand-labeled retrieval questions and three insertion shuffles (60 paired trials). No live questions or model were used; the experiment measures **gold reference retrieved**, not fact correctness.

| Primary measure | Default FTS5 OR BM25 | H116 reranker |
|---|---:|---:|
| Gold source ranked first | 60/60 | 60/60 |
| Gold source in top 3 | 60/60 | 60/60 |
| Aggregate local retrieval time | 40.232 ms | 72.279 ms |
| Verified knowledge units | 0 | 0 |

H116 incurred about 1.80x retrieval time on this small local test without improving source recall. Timings are not stable CPU-hour or end-to-end user tests; the two methods perform different work and timing is not pre-normalized by compute. **Do not call this an intelligence increase.**

## Next cycle required (H117 proposed; not yet run)

1. Freeze 100+ novel research questions across multiple areas, including contradictions, missing information, multi-hop source support and source abstention; use at least two independent blinded reviewers for factual answer keys.
2. Match current BIE v34.2 against a question-driven *selective-acquisition + citation-verification* challenger. Keep Ollama model, compute budget, source permissions and web-query budget identical.
3. Prefer sources with genuine independent provenance, not two mirrors of one record. Keep conflicts unresolved instead of fabricating confidence.
4. Measure grounded correctness and error/unsupported-claim rate, citation-link integrity, abstention calibration, task completion time, unique citations and cost. Include negative-transfer tests.
5. Predeclare a meaningful improvement threshold (e.g. >=5 percentage points verified correctness at comparable cost) and no significant worsening of unsupported claims or security failures. Preserve the baseline if this fails.

**Safety**: all internet data remain untrusted; assistant source text is never an instruction; never elevate permissions, bypass publisher rates/terms, crawl endlessly or rewrite BIE program without explicit human review, backup and regression validation.

## Local checks

- `python -m unittest discover -s tests`: **245/245 passed** (237 inherited + 8 H116).
- `python -m bie verify-vendor`: **11/11 passed**.
- `python studies/h116_benchmark.py examples/H116_HOLDOUT_PRECOMMIT.json`: reproduces synthetic paired cases.
- Current user's real BIE state, internet quality and local Ollama were not accessed or tested here.
