@echo off
setlocal
cd /d "%~dp0"
where codex >nul 2>&1
if errorlevel 1 (
 echo Codex CLI not found. Install Node.js and run: npm install -g @openai/codex
 echo Alternatively open this folder with the official Codex app for Windows.
 echo Codex will see AGENTS.md; read CODEX_FIRST_TASK_H132.md first.
 pause
 exit /b 2
)
echo BIE research project. Read AGENTS.md and CODEX_FIRST_TASK_H132.md.
echo This command does NOT connect Robinhood or run any trades.
codex
