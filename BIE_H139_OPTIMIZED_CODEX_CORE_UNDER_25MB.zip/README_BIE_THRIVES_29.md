# BIE THRIVES Experience v29 — Investigate Unfamiliar Wi-Fi

**Status:** functional local Windows evidence-analysis upgrade, verified with synthetic Wi-Fi observations. **No new real-world wireless network, radio protocol, or user-device measurement has been discovered in this build environment.**

## What is new

- Added **Investigate unfamiliar Wi-Fi** to the Wi-Fi Wiggle Lab tab. Clicking the button **once** reads a snapshot from the Windows Wi-Fi reporting commands and analyzes it. No automatic connection, port probing, password extraction, transmission or background scans.
- CLI: `python -m bie wifi-investigate` explicitly collects one snapshot; `python -m bie wifi-novelty` safely reexamines existing local observations without new collection.
- Compares Windows-provided radio-type labels against ordinary 802.11a/b/g/n/ac/ax/be values. Unknown string labels are **candidate metadata anomalies, not identified new physical standards**.
- Finds clearly inconsistent band/channel claims and changes of reported radio type for the same pseudonymous access point. Controls track intermittent visibility and whether the OS actually provided enough data.
- Each case gives its evidence, competing hypotheses, a refutation and a permitted next measurement. Promotion requires at least 3 distinct timestamps and 2 manually marked sessions merely to reach **repeated, unverified OS report** status. A new protocol is **never** automatically established by OS metadata.
- Output removes SSIDs, BSSIDs, passwords, raw unknown radio labels and other personal Wi-Fi identifiers. Case IDs are persistent pseudonymous links within this local database and should still be kept private.
- All v28 code, bundled project history, vendor BIE engines, and existing research datasets are preserved. Existing `wifi_wiggle.sqlite3` is **not** overwritten or migrated by this module.

## Start on Windows

1. Unzip `BIE_THRIVES_Experience_v29_FULL_SOURCE_20261015.zip` into a fresh folder. Install Python 3 if necessary.
2. Double-click `START_BIE.bat`. The existing BIE assistant opens.
3. Open **Wi-Fi Wiggle Lab** and click **Investigate unfamiliar Wi-Fi**. This initiates exactly one OS-permitted observation.
4. Click **New test session** to label a separate observation series. Repeat deliberate observations at different times and under controlled positions. Case review is based on the saved observations.
5. For an offline analysis without a new scan, use `py -3 -m bie wifi-novelty` in the extracted project folder.
6. For automated checks run `CHECK_BIE.bat`. When Windows blocks WLAN details, check that your WLAN adapter is enabled and that location/privacy settings allow nearby Wi-Fi results. BIE cannot override Windows permission controls.

## What it can and cannot detect

Windows `netsh wlan show networks mode=bssid` reports nearby networks **decoded by the current adapter and driver**, including their signal/channel/radio type. It is not a calibrated spectrum analyzer, does not monitor arbitrary frequencies, cannot identify an unknown modulation, and cannot prove Wi-Fi 8 exists at a particular location. A true claim of a new RF technology would require appropriate frequency-compatible passive radio hardware, independent replication, protocol analysis and laboratory verification.

**Hardware scope:** the user's Windows adapter and permissions determine which bands, APs and fields can be reported. Finding an advertised network is not permission to connect. This lab performs no network association or password retrieval.

**Interpretation examples:**
- 802.11be appears in a Windows report: known Wi-Fi 7 advertisement, not a discovery of new Wi-Fi.
- 802.11bn appears as a freeform driver label: unrecognized by this parser; may be a driver string or future convention. Requires separate independent investigation, not proof of Wi-Fi 8.
- An AP appears and disappears: may result from interference, roaming, scanning schedule, movement or range; not evidence for a new protocol.

## Validation

The inherited v28 test suite had 90 tests. v29 adds 18 synthetic anomaly and privacy tests; run `python -m unittest discover -s tests -v`. The continuity report verifies the complete v28 archive's files were preserved, and vendor research files are byte-for-byte unchanged. This is **software verification**, not a field test of RF sensing. See `reports/v29_full_tests.log` and `reports/v29_parent_continuity.json`.

## Reliable technical references

- Microsoft Learn: https://learn.microsoft.com/en-us/troubleshoot/windows-client/networking/wireless-network-connectivity-issues-troubleshooting
- Microsoft Learn netsh WLAN: https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/netsh-wlan
- IEEE working group standards timeline: https://www.ieee802.org/11/Reports/802.11_Timelines.htm
