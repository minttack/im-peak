# H135-R · Relevance + Proof Before Capital

Unreleased isolated research candidate based on H134; no changes to active Windows installation.

1. Extract this ZIP into a new folder; do not overwrite another BIE version.
2. Double-click `TEST_AND_PLAN_H135R.bat` to verify code and run synthetic stable, reversal and noise demos.
3. Start Codex CLI or Windows Codex in THIS folder; read `AGENTS.md`, `CODEX_NEXT_TASK_H135R.md`.
4. Connect Robinhood MCP only on your own machine, authenticated by you. External MCP agents can trade: turn Robinhood trade approvals **ON** first and request read-only market-data access only. This research code never sends brokerage orders.
5. Give Codex a read-only exported point-in-time market dataset meeting the documented schema. Use `python -m bie relevance-h135r-file DATASET.json --ask-experience --report reports/new.json`. Codex must calculate verifiable after-cost outcomes, not invent them.
6. Verify factors on new future periods; test a diversified shadow portfolio with no real capital; request separate review if ever considering tiny purchases, and a further review before any larger amounts.

No profitable stock strategy, real-time Robinhood integration, 24/7 runner, network data adapter, autonomous model training, or reliable generalization has been demonstrated. A research score out of 100 is NOT a profit prediction. Synthetic favorable gains collapse under regime reversal.
