@echo off
setlocal
cd /d "%~dp0"
if exist "stock_evidence_h131.json" (
  py -3 -m bie stock-h131 --evidence stock_evidence_h131.json
) else (
  echo BIE H131: No timestamped Robinhood or SEC evidence imported.
  echo Showing provisional research candidates only. NOT stock buy recommendations.
  py -3 -m bie stock-h131
  echo.
  echo To rank real evidence, give Codex CODEX_STOCK_DATA_REQUEST_H131.md
  echo Ask it to create stock_evidence_h131.json in this folder without making any trades.
)
pause
