# BIE THRIVES Experience v28 — Advanced Wireless Discovery and Reasoning

**Build date:** 2026-10-15  |  **Status:** Tested local software upgrade; no real user-device measurements performed.

## What v28 actually does

BIE v28 extends the preserved v27 Wi-Fi Wiggle Lab with `bie/wifi_discovery.py`, an explainable offline analysis module. It reads only the local, pseudonymized v27/v28 SQLite evidence database, gathered via the operating system's own existing Windows WLAN reporting commands after an explicit button or CLI invocation.

1. **Observation history:** Track pseudonymous AP sightings across individually initiated snapshots; reveal newly observed or no-longer-observed AP reports, and distinguish missing data from evidence of absence.
2. **Wireless capability leads:** Compare advertised `802.11be` / Wi-Fi 7, `802.11ax` / Wi-Fi 6/6E and other reported radio types to adapter driver-reported supported standards. An advertised AP is neither proven accessible nor faster.
3. **Channel and band summary:** Show counts of *advertised* AP entries per reported band/channel. This is **not** a spectrum analyzer, wireless channel-airtime measurement, Wi-Fi 8 detector, or authorization check.
4. **If → then → alternatives → contradiction → test:** Each ThoughtPacket includes its observation, source, inference, competing causes, a refutation and a next permitted measurement.
5. **Prediction challenge:** Fixed forward-time holdout comparing `last_value`, `rolling_median_3` and predeclared `wiggle_gradient`. Report mean absolute errors and approximate exploratory paired-block-resampling intervals; require multiple manually marked sessions and non-duplicate timestamps before even provisional evidence. No predicted amplification of actual signal or throughput.
6. **Manual session and export:** Start a test session without scanning and export the *derived* evidence as JSON with no SSID/BSSID/credential fields. SQLite migration preserves existing v27 readings and privacy salt. Reports contain locally stable pseudonymous IDs (keep exports private).
7. **CLI + GUI:** `wifi-new-session`, `wifi-discovery`, `wifi-export newfile.json` plus three new buttons on the Wi-Fi Wiggle Lab tab. v27 commands remain.

## Verification and source continuity

- Automated Python standard-library tests: **90 passed** (74 inherited v27 + 16 v28); see `reports/v28_test_results.log`. The tests use synthetic radio fixtures, including adversarial alternating patterns, incomplete observations, legacy schema migration and no-future-data forecasts.
- Desktop smoke: Tkinter launched under virtual X display; verified all three v28 buttons exist and final tab can be selected, with a captured screenshot (`reports/v28_desktop_smoke.png`). **Not** tested on real Windows Wi-Fi hardware.
- Nested original BIE v8 reference archive and all existing v24 experimental research records retained **byte-exactly**; see `reports/v28_continuity.json` and `SOURCE_SHA256_MANIFEST_V28.json`.
- Original v27 `RELEASE_MANIFEST`, test logs and source manifests are historical records; they document v27, not the altered v28 files.

## What this does not do

BIE has not accessed a live radio from this container, connected to a Wi-Fi network, bypassed credentials, penetrated another device, used any advanced radio-frequency receiver, inferred an unknown protocol, measured actual throughput/latency, or established novel physical effects from the Wiggle idea. A hypothesis may be useful even when not confirmed, but never replaces a measurement. Wireless quality is physical-layer/environment dependent and cannot be raised merely by inference.

## Documentation

Read `README_BIE_THRIVES_28.md`; for an offline, clearly fictional demonstration run `python examples/wifi_v28_demo.py` from the project root. The v26/v27 source docs remain for inherited functions.

Reference for read-only OS source fields: Microsoft Learn, [Wireless network connectivity issues troubleshooting](https://learn.microsoft.com/en-us/troubleshoot/windows-client/networking/wireless-network-connectivity-issues-troubleshooting), describing the BSSID/signal/channel/radio-type data emitted by `netsh wlan show networks mode=bssid`.
