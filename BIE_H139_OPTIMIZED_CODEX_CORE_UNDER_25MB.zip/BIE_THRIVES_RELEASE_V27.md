# BIE THRIVES v27 — Evidence Report (2026-10-15)

Status: **additive, locally verified Wi-Fi inference lab**. No automatic system access. No unsupported claims of inventing or discovering a previously unknown wireless protocol.

## Source continuity

Parent: BIE THRIVES Experience v26 complete source (ZIP retained separately). BIE v25 assistant, v24 research data, original BIE v8 source reference, and v26 data integrations remain bundled and unchanged aside from three intended entrypoint/UI/version files. New modules live at `bie/wifi_lab.py` and `tests/test_wifi_lab.py`. Parent v26 documents/reports remain historical and unmodified.

## Operational changes

1. New **Wi-Fi Wiggle Lab** graphical tab, manual snapshot button, compare/infer button and evidence display.
2. Read-only, bounded Windows `netsh wlan show` commands (interface, nearby networks, drivers). No credentials, no scanning unrelated devices, no automatic joining.
3. `802.11ax` / Wi-Fi 6E and `802.11be` / Wi-Fi 7 parsing, with adapter-support checks and missing-information handling.
4. Separate SQLite evidence file containing salted pseudonyms and numeric measurements; no raw SSIDs or BSSIDs persisted.
5. Testable *if → then → evidence → counterexample → next test* chains; explicitly unconfirmed causes, no claims about actual throughput, MLO, radio power or Wi-Fi 8 availability.
6. Nine-sample threshold for simple chronological holdout predictive comparison; baseline last-observation predictor vs Wiggle adaptive candidate, no automatic promotion.
7. CLI additions: `wifi-snapshot`, `wifi-infer`. v26 commands unchanged.

## Verification

See `reports/v27_full_tests.log`, `reports/v27_gui_smoke.txt`, `reports/v27_vendor_integrity.json` and `reports/v27_parent_continuity.json`. Windows radio access unverified in this Linux execution environment; all nearby AP fixtures are synthetic.

## Known limitations and possible next independent tests

Test in the user's Windows environment with explicit OS Location permission where required. Take many real snapshots across multiple time windows. Separately measure packet loss, actual throughput and jitter of an **authorized** connection; control for device motion, router distance, channel occupancy and time of day. Challenge hypothesized improvement with negative controls and unrelated environments. Never generalize from a synthetic gain to physical discovery.
