# BLOOM × BIE THRIVES Experience v30 — Exoplanet Observatory

Creator: user-originated BLOOM + BIE THRIVES Experience project. This package is an additive upgrade of the recovered, source-bearing BIE THRIVES v29. It **does not** establish artificial omnipotence or new physics.

## What actually works

- Original assistant, memories, experience, Wi-Fi research, registered storage and all v29 vendor files remain bundled.
- A seventh Tk desktop tab, **BLOOM · Exoplanets**, opens and uses public NASA Exoplanet Archive TAP `pscomppars` (planetary-systems composite parameters) when you explicitly click **Sync NASA catalog**.
- Scientific catalog columns include planet and host name, stellar distance and positive/negative distance errors, orbital period/separation, reported planetary mass/radius/insolation/equilibrium temperature, discovery method, date and sky position where published.
- Convert parsecs into light-years using 1 pc = 3.261563777 ly. **Distance is to the planetary host system**, not the orbital radius.
- Look up individual planets, produce evidence-based ThoughtPackets (measurement / hypothesis / competing explanations / next test), list nearest systems, apply an explicitly exploratory Earth-sized/irradiance screen, calculate approximate 3D host-star distances when both targets have sky coordinates.
- Load a three-planet **offline curated reference example** for testing when internet is not available. These values mix NASA references and are *not a live NASA composite catalog snapshot*.
- Test a user-supplied `time,flux` CSV with a specified *known* trial period and epoch for an independently replicated repeating dip across parity-split transit cycles. This is an educational screening tool, not a calibrated astronomical discovery pipeline.
- Ask the BIE assistant about an *already loaded catalog*: it has read-only `astro_status`, `astro_search`, `astro_target`, and `astro_between` tools. No local model is shipped; this requires your installed Ollama model.
- Export source-stamped findings as JSON; older files are never overwritten unless an explicit import replaces the *exoplanet-only catalog*.

## Windows quick start

1. Extract the **FULL SOURCE** ZIP to your own folder (do not run it inside the ZIP).
2. Install Python 3.10+ and make sure Tkinter is available. Run `START_BIE.bat`.
3. Open **BLOOM · Exoplanets**.
4. For an immediate local example, click **Offline examples** and confirm. This replaces the exoplanet-only dataset with 3 curated examples; it does **not** overwrite original BIE memory.
5. Click **Nearest planets**. Enter `TRAPPIST-1 e` and click **Analyze named planet**.
6. For the current public catalog, click **Sync NASA catalog** and confirm. NASA must be reachable via HTTPS. Wait for a success response before claiming current records; failed downloads preserve old records.
7. Optional: supply your own authorized `time,flux` CSV and corresponding period and epoch, then **Evaluate repeating dip**.

### Applying UPDATE ONLY to v29

This update does **not** include the original BIE engine or vendors. Make a backup of your extracted v29 project folder. Extract the update ZIP separately, enter its `BIE_THRIVES_Experience_v30` directory, and copy **its contents**, including `bie/`, `tests/`, `examples/`, and new reports, **into the root of your extracted v29 project**, merging folders and replacing the five named code files. Do not delete older files. Alternatively, use the full source ZIP (recommended). The update package is not a separate standalone program.

No NASA account or API key required for the published TAP endpoint. The live API is not accessed automatically; the current runtime cannot reach the public internet, so a real online sync has **NOT been verified here**.

## Command line

From the extracted project folder:

```powershell
py -3 -m bie exo-status
py -3 -m bie exo-reference
py -3 -m bie exo-search "" --limit 15
py -3 -m bie exo-target "TRAPPIST-1 e"
py -3 -m bie exo-sync
py -3 -m bie exo-search "" --within-ly 50 --screen-only
py -3 -m bie exo-between "Proxima Cen b" "TRAPPIST-1 e"
py -3 -m bie exo-export bloom_findings.json
py -3 -m bie exo-lightcurve my_curve.csv --period-days 9.20754 --epoch-days 0
py -3 -m unittest discover -s tests
py -3 -m bie verify-vendor
```

`exo-between` returns no 3D separation for catalog rows missing RA/Dec; the curated offline examples intentionally omit RA/Dec. The `exo-lightcurve` epoch must use the **same time units/reference frame** as the CSV.

## Source provenance

NASA TAP documentation: https://exoplanetarchive.ipac.caltech.edu/docs/TAP/usingTAP.html

NASA pscomppars column documentation: https://exoplanetarchive.ipac.caltech.edu/docs/API_PS_columns.html

Reference examples: `examples/NASA_REFERENCE_EXAMPLES.csv` and `examples/NASA_REFERENCE_EXAMPLES_SOURCES.json`. These are for demonstration only; sync NASA for a current machine-readable catalog.

This app does not use NASA credentials or private accounts, nor does it collect wireless or radio signals from distant stars. No telescope is controlled. A transit in supplied data does not by itself confirm an exoplanet, a habitable environment, or life. Photometric uncertainties, stellar activity, binaries, systematic noise and false-positive analysis require separate specialist work.

## BIE reasoning limits

- `follow-up-screen`: approximately 0.7–1.8 Earth radii *and* 0.25–2 Earth insolation. These intentionally broad, uncalibrated cutoffs are **not** a scientifically derived habitable zone model and **not** a probability of habitability.
- Distances and derived light-times inherit NASA/source measurement provenance; missing uncertainties stay missing.
- Direct images, atmospheric spectra, raw telescope pixels, radio SETI signatures and direct biosignature measurements **are not part of this build**.
- The local LLM can hallucinate; the catalog results and source stamps should take precedence.

## Release verification

- Original v29 package retained for reference in the user's library; this release does not overwrite it.
- 130/130 Python unittests passed in this container, including 108 inherited tests, 19 new exoplanet and light-curve tests, 3 new assistant integration tests.
- 11/11 original vendor hashes verified byte-for-byte.
- The actual Tk interface opened in Xvfb; screenshot available in `reports/v30_desktop_smoke.png`.
- Live NASA catalog download **not tested** due to lack of network access in this session.
