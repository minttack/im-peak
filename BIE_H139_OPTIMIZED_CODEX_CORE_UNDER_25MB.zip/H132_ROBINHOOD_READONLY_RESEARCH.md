# Codex + Robinhood: read-only public stock research (H132)

## Connection (user-controlled)
- **Codex app on Windows:** Settings → MCP servers → Streamable HTTP → `https://agent.robinhood.com/mcp/trading`.
- **Codex CLI on Windows:** `codex mcp add robinhood-trading --url https://agent.robinhood.com/mcp/trading`, then in Codex run `/mcp`, select `robinhood-trading`, and authenticate.
- A dedicated Robinhood MCP account may be required. **External agent trade approvals default OFF**, so turn them ON under Robinhood Agent Settings → connected agent → Safety Controls before granting access. Prompt restrictions are not a technical substitute for approvals.
- Official docs: https://robinhood.com/us/en/support/articles/onboarding-an-external-agent/ and https://robinhood.com/us/en/support/articles/trading-with-your-agent/

## Authorized data-read scope only (when user consents)
Use actual tool names and their documented argument schemas from the connected MCP. When available: `get_equity_historicals`, `get_equity_fundamentals`, `get_financials`, `get_equity_technical_indicators`, `get_earnings_results`, `get_equity_news`, `get_sec_filing_index`, `get_sec_filing`, `get_sec_filing_facts`, `get_equity_quotes`, `get_equity_tradability`, `get_index_historicals`.

Gather daily OHLCV for precisely: MSFT AAPL NVDA AMZN GOOGL META JPM XOM WMT JNJ SPY QQQ. At least 180 synchronized daily bars per ticker (prefer 2+ years where service/history permits). Preserve a provenance record: ticker, retrieval UTC, earliest/latest bar, exchange/adjustment basis, source name, missing rows, corporate actions, and any time-window limits. Capture filing dates AS AVAILABLE at the time; never use publication later than simulated decision date.

CSV schema: `date,ticker,open,high,low,close,volume` with symbols grouped and dates strictly increasing; skip no data silently. Point-in-time H131 coverage: see `CODEX_STOCK_DATA_REQUEST_H131.md` for schema and nine fields. No fabricated prices. Don't save brokerage account numbers, balances, transactions or sensitive tokens in research outputs.

## Disallowed
Do not use `review_equity_order`, `place_equity_order`, `cancel_equity_order`, crypto/option orders, withdrawals, transfers, agent setting changes, or any portfolio mutation. Do not automatically fund or schedule trades. This research package never requires access to private account data.

## After collecting
`py -3 -m bie stock-h131 --evidence stock_evidence_h131.json --report reports/H131_real_new.json`
`py -3 -m bie universe-h132-csv stock_ohlcv_h132.csv --as-of YYYY-MM-DD --evidence stock_evidence_h131.json --report reports/H132_real_new.json`
If source has fewer than ten stocks or mismatched calendars, report an **incomplete/unusable** dataset instead of fabricating data.
