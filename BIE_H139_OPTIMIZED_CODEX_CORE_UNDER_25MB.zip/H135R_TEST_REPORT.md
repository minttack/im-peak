# BIE THRIVES Experience · H135-R Market Relevance and Proof Ladder

**Date:** October 17, 2026. **Status:** new isolated offline research candidate derived from H134; not integrated with the user's newest unified mainline or installed on Windows.

## Deliverables and verification
- New `bie/relevance_ladder_h135r.py`, CLI `relevance-h135r-demo` / `relevance-h135r-file`, `TEST_AND_PLAN_H135R.bat`, Codex instructions and 25 new automated tests.
- **411/411** inherited + new Python tests passed (386 inherited, 25 new).
- **11/11** vendor hashes passed and parent code preserved.
- A configured real local BIE/Ollama (`qwen2.5:3b`) was queried and returned `local_model_unavailable`; no self-described independent BIE thought is fabricated.
- No Robinhood authentication, account reading, webhook, trader daemon, live purchase, or order attempted. Capital ladder forbids all orders.

## Research methods
- Restrict input to 10 provisional stocks and point-in-time signal labels with source refs, observed timestamps, decision time, resolved outcome time, and after-cost binary outcomes supplied by caller.
- Score indicator relevance using **incremental Brier score gain on chronological validation**, then audit frozen selected features on untouched holdout. A separate 0–100 research relevance score includes development data coverage and relevance; this is **NOT** a profit forecast or recommendation.
- Enforce chronology and target-resolution embargo; reject duplicate data, unsupported/NaN features, future information, invalid provenance, and unrealistic paper budgets. Stale features are ignored.
- Up to five *shadow-only* paper positions diversified with a max of two stocks in one sector. The illustrative paper budget is \$1,000 **virtual dollars**; user has specified no real risk budget.
- Separate research/paper, hypothetical micro-live proposal (0.5% each, 2.5% total of independently authorized experimental capital as ILLUSTRATIVE cap), and larger-purchase stage. Both live phases are **NOT GRANTED** and cannot auto-promote; human review is required at each step.
- Continue every loop with falsifiable question; holdout is consumed after each evaluation, never used to select features or tune weights.

## Fresh experimental synthetic stress — 180 distinct runs
| Synthetic world | Runs | Mean holdout Brier gain over unconditional baseline | Runs beating baseline |
|---|---:|---:|---:|
| Stable causal indicator relation | 60 | +0.067641 | 60/60 |
| Reversed indicator relation | 60 | -0.173916 | 0/60 |
| Pure null / uninformative inputs | 60 | -0.000292 | 4/60 |

**Critical result:** the learner works in deliberately favorable synthetic worlds but FAILS on all 60 tested market-reversal worlds. Null-world occasional wins are expected from noise. This does **not** demonstrate genuine stock-trading alpha, expected returns, or improved intelligence. The H134 independent transfer failures are retained too.

## Known limitations and next test
- Signal values must currently be normalized and supplied in a local JSON by Codex/user. Real-time adapters, split/corporate-action processing, trustworthy point-in-time EDGAR/Robinhood ingestion, slippage reconstruction, and forward-trade audit are **not** implemented.
- Imported source tags are declarations, not authenticated proof. Predicted positive-after-cost direction is not return magnitude or portfolio cash P&L; the nominal allocation is a paper planning instrument, NOT a backtested strategy.
- H135-R is a bounded binned-feature learner, **not neural-weight training**. Selecting features is based on development outcomes. BIE's configured local reasoning model did not answer in this environment.
- **Next hypothesis:** detect feature-relation drift from pre-registered rolling out-of-sample residuals, use bounded model reset/no-trade, and outperform naive locked baseline under *new* shifted regimes. Do not retune the 180 consumed worlds into fresh confirmation evidence.
- Only after real, independently verified, as-of historical data + substantial prospective paper-trading with transaction costs, SPY/QQQ/cash/stock-buy-hold baselines, drawdown checks, and user-approved risk caps should any limited live trade even be considered. No automatic large purchases.

## Running on Windows
1. Extract the full-source ZIP into **a new isolated folder**.
2. Double-click `TEST_AND_PLAN_H135R.bat`; it runs tests, vendor integrity and three **synthetic** scenario demos.
3. Open the extracted folder in Codex (Windows GUI or CLI), read `AGENTS.md` and `CODEX_NEXT_TASK_H135R.md`.
4. Optionally connect official Robinhood Trading MCP yourself, after turning on external-agent trade approvals. Codex uses market data reads only. For real data, prepare rigorously time-aligned labels and call `python -m bie relevance-h135r-file <input.json>`.

Robinhood authoritative setup: https://robinhood.com/us/en/support/articles/onboarding-an-external-agent/ . External-agent approvals default OFF per https://robinhood.com/us/en/support/articles/trading-with-your-agent/ .
