$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$parts = Join-Path $root 'legacy_parts'
$dest = Join-Path $root 'vendor\desktop_v1\ORIGINAL_BIE_V8_UNMODIFIED.zip'
$want = 'eabaa057a42a6905f768c9d01306e82ef3b309612c524fa5118a6f1853cdf79a'.ToUpperInvariant()
$names = 1..4 | ForEach-Object { 'LEGACY_V8_PART_{0:D2}_OF_04.bin' -f $_ }
foreach ($name in $names) {
  $path = Join-Path $parts $name
  if (-not (Test-Path -LiteralPath $path)) { throw "Missing part: $path" }
}
[System.IO.Directory]::CreateDirectory((Split-Path -Parent $dest)) | Out-Null
$temp = "$dest.restoring"
try {
  $output = [System.IO.File]::Create($temp)
  try {
    foreach ($name in $names) {
      $input = [System.IO.File]::OpenRead((Join-Path $parts $name))
      try { $input.CopyTo($output) } finally { $input.Dispose() }
    }
  } finally { $output.Dispose() }
  $actual = (Get-FileHash -LiteralPath $temp -Algorithm SHA256).Hash
  if ($actual -ne $want) { throw "SHA-256 MISMATCH. Refusing to install reconstructed historical archive." }
  Move-Item -LiteralPath $temp -Destination $dest -Force
  Write-Host 'SUCCESS: Original BIE v8 vendor archive restored and SHA-256 verified.' -ForegroundColor Green
  Write-Host 'You can now run FLOOD_TEST_H139.bat with the full vendor files present.'
} finally { if (Test-Path -LiteralPath $temp) { Remove-Item -LiteralPath $temp -Force } }
