@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 (
 echo Python 3 and its py launcher are required.
 pause
 exit /b 2
)
echo ===== H136 tests: no Robinhood account or live orders =====
py -3 -m unittest discover -s tests -p "test_*.py"
if errorlevel 1 goto fail
py -3 -m bie verify-vendor
if errorlevel 1 goto fail
if not exist reports mkdir reports
for %%W in (familiarity_signal familiarity_trap attention_only null thin_liquidity) do (
 echo === Synthetic world: %%W ===
 py -3 -m bie familiarity-h136-demo --world %%W --report reports\h136_%%W.json
 if errorlevel 1 goto fail
)
echo.
echo H136 software checks and offline world demos completed.
echo Synthetic only. No market-performance claim. No Robinhood trade.
echo Now open Codex and read CODEX_NEXT_TASK_H136.md.
pause
exit /b 0
:fail
echo FAILED. Do not promote candidate; save error evidence and repair.
pause
exit /b 1
