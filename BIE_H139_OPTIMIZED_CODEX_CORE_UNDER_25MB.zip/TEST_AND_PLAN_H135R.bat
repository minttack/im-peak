@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 (
 echo Python 3 with the py launcher is required.
 pause
 exit /b 2
)
echo ===== H135-R source and integrity tests =====
py -3 -m unittest discover -s tests -p "test_*.py"
if errorlevel 1 goto fail
py -3 -m bie verify-vendor
if errorlevel 1 goto fail
if not exist reports mkdir reports
py -3 -m bie relevance-h135r-demo --world causal
if errorlevel 1 goto fail
py -3 -m bie relevance-h135r-demo --world shift
if errorlevel 1 goto fail
py -3 -m bie relevance-h135r-demo --world null
if errorlevel 1 goto fail
echo.
echo Test demonstration completed. THESE ARE SYNTHETIC scenarios, no trading.
echo Open this folder in Codex and read CODEX_NEXT_TASK_H135R.md.
pause
exit /b 0
:fail
echo A test failed. Inspect the above report. Do not claim completion.
pause
exit /b 1
