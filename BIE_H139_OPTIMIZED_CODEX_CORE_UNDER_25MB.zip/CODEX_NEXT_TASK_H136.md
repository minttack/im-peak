# BIE THRIVES Experience · H136 Codex research handoff

## What the user asked for
Remember **how P&L, drawdowns, virtual position size and liquidity change decisions** and investigate **familiarity** from two different perspectives: (1) investor familiarity/attention with companies, as a public and timestamped *proxy*, and (2) BIE's familiarity with similar historical market patterns. Rank what actually improves predictions and simulated dollar outcomes after costs. Never treat fame or profits so far as reliable proof of future performance.

## Existing code and run commands
- Current H136 source: `bie/familiarity_money_h136.py`.
- Previous H135-R feature relevance: `bie/relevance_ladder_h135r.py`; do not overwrite or conflate its synthetic Brier experiments with real price returns.
- Tests: `python -m unittest discover -s tests -p 'test_*.py'`.
- Integrity: `python -m bie verify-vendor`.
- Five synthetic worlds: `python -m bie familiarity-h136-demo --world familiarity_signal` (also `familiarity_trap`, `attention_only`, `null`, `thin_liquidity`).
- Supplied *point-in-time real-data format* (not necessarily source authenticated): `python -m bie familiarity-h136-file <input.json> --report <new-file.json>`.
- One-click Windows: `TEST_AND_PLAN_H136.bat`.

## Mission to complete in Codex
1. Inspect authentic input fields and the actual published Robinhood/SEC data that are **available at a given historical as-of timestamp**, not today's revised fields. Treat unverified investor attention/familiarity signals as absent. Keep authentication and broker permissions user-controlled.
2. Build read-only ingestion for user-provided SPY, QQQ, and current ten-stock daily adjusted prices; time-stamp data and handle splits, dividends, halts, business dates, missing data, bid-ask assumptions and source lineage. The current synthetic day sequence includes weekends and therefore must never be presented as actual exchange sessions.
3. Improve one hypothesis at a time: whether investor attention/familiarity and BIE's historical pattern analogies add independent forward value over price-only/cash/SPY/QQQ after turnover, costs, spreads, estimated participation, and drawdown.
4. Use a **chronological development/validation/sealed holdout**, paired baselines and null/permuted controls, and a subsequent untouched prospective paper period. Time-of-availability is the hard boundary. Never retune on reported sealed holdout outcomes; use a new period for each new candidate. Report unfavorable results.
5. Compare *risk-only* dollar feedback controls, fixed sizing, profit chasing (negative control), and drift-triggered abstention. User must explicitly approve any separate broker trial and any later scale-up. NEVER place orders, enable automatic trading, submit draft orders, or access private account information without a separate explicit direction.
6. Attempt to ask running BIE local model for its falsifiable next question, but report `local_model_unavailable` if missing. Do not invent an answer or let the model assert market facts without source verification.
7. Create a repeatable evidence report: provenance, holdout P&L, transaction costs, max drawdown, equity path, stock/sector concentrations, calibration and significance uncertainty. Compare to simple strategies, not just the H136 code.
8. Implement a bounded reversible candidate in a separate branch. Rerun inherited tests. If it fails, record the failure and propose another **different** hypothesis; don't reword a failing claim until it appears successful.

## What H136 explicitly does NOT prove
- No direct Robinhood connection, orders, or real trading performance.
- User's original symbolic intelligent learning system is not independently confirmed by the H136 rules.
- Synthetic worlds encode known signal relationships; strong synthetic results are not forecasts of public stock prices.
- Virtual slippage and *market impact* are assumptions, not measured actual price impact; micro-size real trades do not provide proof of scalable size.
- Investor familiarity can reflect biased attention rather than information. No invasive tracking of individuals, private behavior, or supposedly privileged insight.

## Research question BIE should ask itself next
"Which of my assumptions about familiarity, how money changes my future exposure, and how my orders affect prices survived fresh evidence? What contradictory evidence appeared, what simpler control wins, and what new observation could falsify my next idea?"
