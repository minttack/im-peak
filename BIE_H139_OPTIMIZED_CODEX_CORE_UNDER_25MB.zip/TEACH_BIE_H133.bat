@echo off
setlocal
cd /d "%~dp0"
set "RUN=H133_RUN_%RANDOM%_%RANDOM%"
mkdir "%RUN%" || exit /b 2
where py >nul 2>&1
if %errorlevel%==0 (
  set "PY=py -3"
) else (
  set "PY=python"
)
echo BIE Experience Teacher-Learner Bloom [OFFLINE RESEARCH; NO TRADES]
%PY% -m bie teacher-h133-study --lesson teacher_lesson_h133.json --report "%RUN%\teacher_result.json" --ask-experience
if errorlevel 1 (
  echo The teacher test failed. Evidence was NOT promoted.
  pause
  exit /b 1
)
%PY% -m unittest -q tests.test_teacher_bloom_h133
if errorlevel 1 (
  echo Teacher unit tests failed.
  pause
  exit /b 1
)
echo.
echo Results stored under %RUN%\teacher_result.json
echo Synthetic policy learning only. No live stock edge proven.
pause
endlocal
