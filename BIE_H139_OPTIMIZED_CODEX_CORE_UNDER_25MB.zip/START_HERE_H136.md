# START HERE · H136 Familiarity and Money Feedback Bloom

**Research candidate ONLY**, inherited from H135-R. Windows and Codex-ready source, not a direct connection to a running BIE model or Robinhood account. This version is not installed in the user's current Windows environment and may diverge from later unified branches.

1. Unzip the **full source** into a fresh folder on Windows.
2. Run `TEST_AND_PLAN_H136.bat`. It runs all Python tests, source-integrity verification and five synthetic simulations. A failed test means the candidate is not verified.
3. Open the folder in Codex. Start from `AGENTS.md` and `CODEX_NEXT_TASK_H136.md`.
4. If you already separately authorized Robinhood's Codex MCP, use **read-only market observations**. Do not submit orders. Set external-agent trade approvals **on** before allowing account access and review actual scope and permissions yourself.
5. Run an as-of-data investigation with `python -m bie familiarity-h136-file <your_data.json> --report <new_output.json>` only after reliable fields exist. Changing the JSON's `source_mode` does not authenticate its content.

The virtual experiment starts at a hypothetical $10,000 (not actual available capital), normally caps exposure at 30% across at most 3 sectors, and tests P&L feedback and a drift guard that can stop simulated positions. Separate `profit_chase_negative_control` is intentionally reckless and must NEVER be treated as an authorization to leverage or increase exposure. It is a paper-only stress comparator.

Investor familiarity is a measured public proxy (if one exists); BIE's own 'familiarity' is similarity to *already observed* earlier market patterns. Both can be wrong or coincidental. Capital sizing cannot justify a predicted future stock rise. Larger real purchases require an independent future decision and new user approval, even if a synthetic score looks extraordinary.

Read `H136_TEST_REPORT.md` for actual results and limitations.
