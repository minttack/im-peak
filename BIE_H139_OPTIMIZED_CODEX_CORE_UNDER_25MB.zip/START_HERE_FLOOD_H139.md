# BIE THRIVES Experience — FLOOD MOVEMENT H139

**Status:** isolated research candidate; NOT installed on user's Windows; NOT connected to Robinhood; NO real-market edge established; NEVER submits orders. Based on actual available H138A research source, preserves historical H129–H138A code and reports where available. The newer independent unified BIE line may need manual reconciliation.

## The one-tap path on Windows

1. Extract the complete ZIP to a **new folder**, not on top of an existing BIE installation. Python 3.10+ is required; existing BIE libraries may require additional dependencies.
2. Double-click **`FLOOD_START_H139.bat`** for a clearly labeled synthetic price/flow demonstration; `FLOOD_TEST_H139.bat` runs new checks. Nothing connects to Robinhood.
3. Open the extracted folder in **Codex desktop on Windows**, or run `OPEN_CODEX_H139.bat` if Codex CLI is installed, or in PowerShell run `codex` after `cd` to the folder. The local project `AGENTS.md` and `CODEX_FIRST_TASK_FLOOD_H139.md` carry the project constraints and next job.
4. To collect real historic data, authorize only Robinhood *read* tools. See `ROBINHOOD_CODEX_READ_ONLY_H139.md`. Bring back a reviewed, timestamped market file to analyze with `python -m bie flood-h139-file reviewed_market_h139.json --report reports/my_real_flood_01.json` (new filename required).
5. If you run a local BIE/Ollama model, add `--ask-experience` to solicit a real next-test proposal. Otherwise response is `local_model_unavailable`, not an invented conversation with BIE.

## What "FLOOD MOVEMENT" means here

An experimental measure of price pressure and comparative participation (close location, relative volume, range, price momentum, SPY-relative motion, historical pattern familiarity, optional timestamped investor attention). This is **not** proof of actual institutional order flow, hidden investor intent, clairvoyance, or guaranteed price direction. We measure information relevance via incremental Brier-score change on validation and future chronological holdouts.

## Market learning lifecycle

Observation -> source/time audit -> train-only ranked universe -> train weights -> validation model selection -> sealed holdout -> virtual positions at NEXT trading session's open, close same session -> virtual dollar P&L, fees/spread and drawdown -> compare cash/SPY/QQQ -> ThoughtPacket -> newly falsifiable next hypothesis. Never let holdout tune the policy. The first ten research names: MSFT, AAPL, NVDA, AMZN, GOOGL, META, JPM, XOM, WMT, JNJ, plus SPY/QQQ for comparison. This list is not a buy recommendation. H139 ranks availability/liquidity on the training period and selects up to five cross-sector names.

### Financial decision boundary

All allocations are VIRTUAL, starting at $10,000, maximum 10% per name and 30% total of virtual equity. These are experiment configurations, **not** proposed live-account percentages. H139 has no broker SDK, broker write functions, credentials, funding logic, or automatic position-promotion feature. Do not connect it to an unrestricted execution agent. Even if future paper outcomes are favorable, larger purchases need separately approved financial risk limits, extensive prospective evidence and per-order user permission.

### Limitations to preserve

- The historic prices in the offline demo are intentionally synthetic. No SEC filings, corporate actions, order books, or news have been fetched in this environment.
- BIE's original creator-drawn Accuracy symbol is **not used** by this stock decision engine. Generic error correction is not a verified glyph-derived advantage. Do not fabricate original symbol images.
- BIE's actual language model and Codex were not running in the originating sandbox. Programmatic next-question prompts are not proof of self-consciousness or general independent learning.
- Broker as-of timestamps must be checked; revised financial data can leak future information. Spread assumptions aren't authenticated fills. The SPY/QQQ comparison uses the same 30% *intraday* next-open-to-close exposure and is not buy-and-hold.
- An external Robinhood MCP agent can access sensitive account data and may expose order tools even when prompted to be read-only. Broker account authentication is user-controlled. Turn **Trade approvals ON if available** for external-agent MCP accounts before connecting (they default OFF; rollout may mean the option is not available to you). If no approval switch, avoid connecting the order-capable MCP and use a separately reviewed data export instead. These prompts aren't a hard technical permission boundary; review each tool call.
- Synthetic accuracy/returns must NEVER be confused with live-market predictive performance. Work with 1+ years of as-of real market observations where feasible, then forward paper evidence.

## Research commands

```powershell
py -3 -m unittest tests.test_flood_movement_h139 -v
py -3 -m bie verify-vendor
py -3 -m bie flood-h139-demo --world flow --report reports/new_h139_flow.json
py -3 -m bie flood-h139-demo --world reversal --report reports/new_h139_reversal.json
py -3 -m bie flood-h139-demo --world null --report reports/new_h139_null.json
py -3 -m bie flood-h139-demo --world illiquid --report reports/new_h139_illiquid.json
py -3 -m bie flood-h139-file reviewed_market_h139.json --report reports/real_h139.json --ask-experience
```

Output never overwrites an existing path. Use a new name each time. Inability to run Codex, a local model, Robinhood or real data MUST be reported rather than called success.
