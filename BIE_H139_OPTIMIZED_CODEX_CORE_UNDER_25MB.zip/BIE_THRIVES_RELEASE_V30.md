# v30 release evidence — BLOOM Exoplanet Observatory

**Build:** 2026-10-15. **Parent:** user-owned BIE THRIVES Experience v29 source ZIP.

- Added: `bie/exoplanets.py`, `bie/astro_signals.py`, seven-tab desktop integration, `exo-*` CLI actions, assistant read-only astronomy tools, reference data/provenance, tests.
- Inherited BIE files retained. Historic v29 manifests are left intact as historical records; see `SOURCE_SHA256_MANIFEST_V30.json` for current-file hashes.
- The NASA TAP API uses a public `pscomppars` catalog: reported data, not direct observation.
- No claim of omnipotence, newfound exoplanet, telescope access, extraterrestrial life, or real-time scientific discovery.
- Live catalog is not bundled as an authenticated current NASA snapshot; user must explicitly sync NASA from a networked machine.
