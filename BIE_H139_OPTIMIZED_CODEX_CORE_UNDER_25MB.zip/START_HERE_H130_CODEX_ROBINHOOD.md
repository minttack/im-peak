# BIE THRIVES Experience — H130 Codex Wand + official Robinhood pathway

## Important identity and scope
- H130 is an **isolated candidate derived from H129**, itself derived from the authentic archived H116 parent. It is NOT merged into newer unified BIE versions nor installed on your computer.
- No BIE local LLM or Codex CLI is running in the delivery environment. Local CLI invocation is optional; it cannot claim a real response from either tool until they actually run.
- This program never reads your Robinhood account or executes Robinhood orders; it prepares and optionally runs local Codex coding tasks. It does not guarantee profits or fully accomplish a loosely defined goal on one click.

## One-tap use on Windows
1. Unzip H130 FULL_SOURCE to its own folder. Do not overwrite your installed BIE or mix with a different version.
2. Install Codex CLI and sign in according to official OpenAI Codex docs, and have Python installed.
3. Double-click `WAND_START.bat`. It asks the configured local BIE/Ollama model when available (or labels it unavailable), generates a new mission/evidence directory and, if `codex` is available, executes up to **two** bounded Codex source-development attempts under `--sandbox workspace-write`.
4. It runs an independent existing Python unittest suite after Codex. Passing unit tests does **not** prove a profitable trading strategy or correct all possible code behavior.
5. For a dry run without Codex: `py -3 -m bie wand-h130 --run-dir wand_runs\first_dry_run`
6. To test your own H129 evidence: `py -3 -m bie wand-h130 --report C:\path\to\h129_result.json --run-dir wand_runs\actual_csv_review`
7. To run the new local isolated tests: `py -3 -m unittest tests.test_wand_h130 -v`

## Official Robinhood MCP configuration (SEPARATE from unattended Wand)
Robinhood publishes instructions for Codex CLI:
`codex mcp add robinhood-trading --url https://agent.robinhood.com/mcp/trading`
Then launch Codex interactively, open `/mcp`, select Robinhood and authenticate. Robinhood may prompt you to open a dedicated Agentic/MCP account. **Keep Robinhood Trade Approvals ON**. Ask Codex to *read* account information and propose paper trades first, with no live buy/sell calls. H130 automated WAND research must not invoke Robinhood MCP.

Sources:
https://robinhood.com/us/en/support/articles/onboarding-an-external-agent/
https://robinhood.com/us/en/support/articles/trading-with-your-agent/
https://developers.openai.com/blog/codex-as-a-platform

## Two distinct pathways
**Path 1: Build and verify** — BIE H129 proposals -> H130 task/focus planner -> Codex edits/tests -> separate verification -> logs -> next falsifiable hypothesis. No live trading.
**Path 2: Controlled Robinhood read-only exploration** — human launches Codex with authenticated Robinhood MCP and uses documented read APIs; trade approvals remain enabled. Neither unattended Wand nor a source file should silently convert Path 1 into Path 2.

## Working with failures
Diagnose error traces, isolate which assumption failed, create different hypotheses, rerun bounded tests and keep failures. Do not reword the same investment prompt until it produces a desired answer. Do not repeatedly peek at a frozen market holdout until it becomes training data. Fresh forward data is required for new performance evidence.

## The 'space-time curve' intuition
Computers cannot speed themselves up by bending spacetime through software. The testable engineering interpretation is using scarce wall-clock time better: scheduler priority, caching, early stop, incremental tests, parallel work if independent, model selection and profiling. H130 `select_focus` is an illustrative priority scheduler using **assumed** information gain. It does not prove runtime acceleration.

## Next engineering milestones
1. Reconcile with user's most recent unified BIE code before promotion.
2. Validate a point-in-time market data feed (adjustments, look-ahead, delistings, timestamps, slippage).
3. Run untouched walk-forward periods and prospective paper trading, comparing baselines.
4. Benchmark full system throughput and budgets.
5. Only after evidence + user decision, design broker order permissions with explicit sizing/kill switch and account safeguards.

Optional direct test of model response: `py -3 -m bie wand-h130 --ask-experience --run-dir wand_runs\model_trial`. If no BIE model runs locally, the output truthfully says unavailable.
