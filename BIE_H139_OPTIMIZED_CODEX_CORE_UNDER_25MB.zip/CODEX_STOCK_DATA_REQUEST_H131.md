# Codex → BIE H131 Stock Universe Selection (read-only)

**Goal:** Build `stock_evidence_h131.json` from Robinhood Trading MCP **read-only** tool responses and separately, where appropriate, official SEC public filings. The goal is research-data coverage, **not** picking a winning trade. Never run an order tool, access funding actions, or use account/portfolio/private tools. Never access a user's private holdings. No trading calls, no watchlist mutation without user confirmation.

**Authorized instruments:** MSFT, AAPL, NVDA, AMZN, GOOGL, META, JPM, XOM, WMT, JNJ. Benchmark context only: SPY and QQQ.

**Only permitted Robinhood MCP reads** (use exact tools if available; determine schema from the connected server): `get_equity_historicals`, `get_equity_fundamentals`, `get_financials`, `get_equity_technical_indicators`, `get_earnings_results`, `get_earnings_calendar`, `get_equity_news`, `get_sec_filing_index`, `get_sec_filing_facts`, `get_equity_quotes`, `get_equity_tradability`, and optionally `get_equity_price_book` (up to four symbols per request). Some derived fields may require calculations over actual returned bars or best bid/ask levels. If a tool is unavailable, leave the metric **missing**. Do not fill values from generic model knowledge.

**Metric mapping:**
- `daily_bars_1y`: COUNT of daily OHLCV records within the trailing year that pass OHLCV validation, not an estimate.
- `last_bar_date`: session date of newest actually observed daily OHLCV bar.
- `median_dollar_volume_20d`: median of 20 full daily `close * volume` observations (approximation, label computation in reference).
- `quoted_spread_bps`: 10,000 × (`ask-bid`) / midpoint for a *current* positive bid/ask, if accessible and timestamped.
- `quarterly_filing_count`: number of quarterly financial reports in latest rolling ~12-18 months with returned financial data (up to 6). Do not assume four.
- `latest_filing_date`: latest verified SEC filing date available through filing tools.
- `earnings_dates_count_1y`: number of earnings results/calendar events in the trailing year actually returned.
- `recent_news_items_30d`: number of distinct ticker-specific, dated news reports seen over trailing 30 days in returned data. It is a data-availability measure, NOT positive sentiment.
- `tradable`: boolean returned by `get_equity_tradability` for the exact symbol.

**Strict point-in-time rules:** Record actual collection time `observed_at_utc` (UTC with `Z`), nonfuture `as_of_utc`, `ticker`, `metric`, `value`, `source` (`robinhood_mcp` or `sec_edgar`), and a compact grounded `reference` naming the exact tool and dated evidence. Every metric must be traceable. NEVER use future information when retrospectively assessing a stock. Do not include account numbers or personal data. No metric values should be fabricated, guessed, or silently imputed. If the source fails, omit the metric and write a data gap in a separate research note.

Use `python -m bie stock-h131-template --output stock_schema_reference.json` for metric names and structure. Output JSON exact top-level: `{ "schema": "bie-stock-evidence-h131.1", "as_of_utc": "2026-...Z", "observations": [...] }`, with each observation following the `example_observation` in template. Do not include the example observation itself in the evidence file.

Run `python -m bie stock-h131 --evidence stock_evidence_h131.json --report h131_ranked_result.json` and `python -m unittest tests.test_stock_universe_h131 -v`. Return data-qualified research watchlist, scored missing data, failures, sources, and next experiment. If no candidate qualifies, return an empty list; do **not** prompt repeatedly to fabricate a favorable result.

**Not authorized:** `place_equity_order`, `review_equity_order`, `cancel_equity_order`, live brokerage orders, account credential requests, automated order execution, unattended trading, or inferring profitable trading performance from data availability.
