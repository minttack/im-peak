# BIE THRIVES Experience — H114 Bloom/Wiggle Code-Line Integrity Lab

**State:** additive, opt-in experimental candidate on v33 Growth source. **Not a production promotion.**

Parent archive SHA-256: `fd953d320e4bd99f4ebecfa92cde9db9466127b84169d3c5a9682b48791f198c`
Original v33 unchanged entries: **158/158**. Only existing file changed: `bie/__main__.py` (adds opt-in `bloom-line-lab` CLI before Assistant initialization); new module + new tests + evidence report. Parent user source ZIP never overwritten. No shared remote repository or user's Windows installation is changed.

## Question tested
1. Should code itself follow the Wiggle, i.e., should original program bytes be placed in Wiggle-order labeled Bloom packets rather than conventional contiguous layout?
2. How closely can circular Bloom symbols fit along a horizontal line or wiggling curve **without disk intersections or source-content loss**?
3. Can we squeeze the waveform vertically while retaining its original shape?

These are operational interpretations, **not** proof about cognition, universal improvement, compiler design or physical waves. This curve is a center-enveloped sinusoidal test model; do **not** describe it as reproducing the exact HFW04 implementation. Bloom nodes are circular labeled objects, not neural cells or cosmic objects.

## Frozen controls + scope
- 960-pixel width; circle radii 8/12/16px in design and 6–24px seeded random confirmation. Amplitudes 0/8/24/48px in design and 0–72px fresh; periods 1/3/7/13 or 0.2–17; center envelope on/off; phase 0 or random. Horizontal sample resolution 0.5px.
- Conventional flat one-row, naïve equal arc-length and all-prior-disks clearance-checked first-fit. The safe first-fit method is **not proven optimal** and uses extra CPU. All-pairs checks include nonadjacent Blooms.
- Original source code is NOT executed in reordered form. Code is split into indexed 128-byte packets, optionally reordered by Wiggle coordinate, compressed, and reconstructed before any hypothetical execution. Source SHA-256 must match.
- Validation is local CPU-only, offline, and bounded. Fixed seed 20261015; no live sensors, model retraining, crypto hash-speed assumptions, user state reads or cryptocurrency reward claims.

## Executed geometry results
| Metric | Design grid | Fresh seeded confirmation |
|---|---:|---:|
| Cases | 96 | 120 |
| Exact pairwise no-overlap verified | 96 / 96 | 120 / 120 |
| Safe layout higher/equal/lower count than straight | 39/57/0 | 101/16/3 |
| Naïve arc cases with collisions | 42 | 105 |
| Median increase in horizontal-span capacity | 0.0% | 18.52% |
| Median relative 2D bounding-footprint density | 0.5202 | 0.4557 |
| Cases more efficient per bounding-box area | 0 | 0 |

Best among these samples: **215 intact Blooms vs 65 straight** in 960 horizontal pixels (r≈7.5px), minimum horizontal center spacing 2.5px but center Euclidean clearance positive; the Wiggle uses ~120px extra vertical center-span. Its Blooms per rectangular footprint area are **only ~0.367×** the straight control. 0/216 cases improved the area-density proxy. Thus a capacity gain in *horizontal projection* is NOT a gain in true 2D packing efficiency.

When all centers lie on a straight line, the hard condition for nonoverlapping circles with common radius r is **adjacent center spacing ≥ 2r**. More aggressive straight-line packing necessarily overlaps unless symbols shrink or information is represented differently. The safe first-fit is limited by sampling grid resolution and need not be globally densest.

## Source byte tests (real v33 code files)
| File | Source bytes | Direct zlib | Indexed linear zlib | Indexed Wiggle zlib | Indexed random zlib |
|---|---:|---:|---:|---:|---:|
| `adaptive_wiggle.py` | 8038 | 2990 | 3368 | 3408 | 3407 |
| `growth.py` | 14120 | 4489 | 5107 | 5187 | 5229 |

**All encoded sources reconstructed byte-for-byte**, including original SHA-256. No evidence that Wiggle ordering makes code smaller or executes it more efficiently. Source zlib without packet tags is smaller; tagged Wiggle also compressed slightly worse than tagged linear in both cases. Decoder timing is a noisy virtual test-host microbenchmark, **not** real end-to-end BIE speed evidence.

## Compaction / shape integrity
Vertical squeezing factors tested: 1, 0.75, 0.5, 0.25, 0.1, 0. At factor 0.5 the sampled curve can move by 23.91px, and at factor 0 it flattens (up to 47.82px displacement). Keeping the untouched shape recipe enables rendering exactly the original reference geometry on reconstruction; without original metadata, flattening loses shape. The displayed waveform is not physically preserved by squeezing.

## Promotion decision
**HOLD** default activation. No realistic user-world tasks or native Windows measurements, no evidence of improved BIE thinking, memory, Bitcoin mining, compilation, code-execution speed, or broad system performance. Geometry correctness on this finite grid passed; general guarantees require analysis for arbitrary shapes and radii. Next stage is external measurements of real application tasks with net task completion time and integrity controls.

## How to use — full source candidate
Extract the full-source H114 ZIP to a new directory. Python 3.10+ required; no third-party dependency for lab. From its root:
```powershell
py -3 -m bie bloom-line-lab --quick
py -3 -m bie bloom-line-lab --report H114_MY_RESULTS.json
py -3 -m unittest discover -s tests -v
```
The `bloom-line-lab` command DOES NOT create the main Assistant instance and does not access or write BIE state. `--report` explicitly creates a **new** report and refuses overwrite. Other pre-existing BIE commands can have their original state behavior and require the same care they always have.

## Updating an existing pristine v33, alternatively
Extract the *UPDATE-ONLY* ZIP somewhere else. First dry run, then apply only after reviewing:
```powershell
py -3 APPLY_BLOOM_LINE_H114.py "C:\path\to\BIE_THRIVES_Experience_v33_Growth_Candidate"
py -3 APPLY_BLOOM_LINE_H114.py "C:\path\to\BIE_THRIVES_Experience_v33_Growth_Candidate" --apply
```
Updater refuses modified parent CLI and conflicting new files. It makes a timestamp-independent `.H114_ORIGINAL` backup before replacing the CLI; never touches existing state database. If another update has changed `__main__.py`, do NOT force this overlay: use the full-source H114 ZIP alongside your existing install.

## Reproducibility and evidence
`reports/H114_RESULTS.json` contains all 216 geometry rows, code hashes and compression sizes; `reports/H114_GEOMETRY_PREVIEW.png` draws tested layouts. `reports/H114_REGRESSION_EXCEPT_SLOW_GROWTH.txt` records **200/200** passing tests outside `test_growth_v33`; `reports/H114_GROWTH_EXCEPT_SLOW.txt` records **11/11** additional Growth tests. The single existing `test_negative_transfer_separated_by_context` was **not completed**: the full suite timed out on it after 200 seconds, and it was excluded from the bounded regression. `reports/H114_VENDOR_VERIFY.txt` records original native vendor verification passed. No 100%-of-all-regressions claim.
