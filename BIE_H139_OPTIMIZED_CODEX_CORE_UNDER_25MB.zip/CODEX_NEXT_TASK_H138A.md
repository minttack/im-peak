# BIE / Codex H138A handoff — Accuracy and new information

This is an isolated H137A-derived research candidate, not the user's current
Windows install nor latest unified runtime. Run from this extracted folder.

## What was done

H138A recovered authentic H137A source and used earlier findings from H127
(symbol geometry gave zero additional weight in its IID holdout), H135-R
(relevance testing), H136 (strong drift guard, investor familiarity and cost),
and H137A (feedback attribution/cost). It added opt-in `signal_guard` to the
existing `bie.familiarity_money_h136._paper` function and a separate paired
stress harness `bie.accuracy_evidence_h138a` (no API or broker access).

The *original Accuracy PNG is NOT available in this source*. Do not claim
image-derived market learning. This is a test of Accuracy-as-verification only.

## Evidence

- `reports/H138A_FROZEN_CONFIRM.json`: 5 artificial regimes × one new seed
  88201 × three disturbances (missing/misleading/high cost) = 15 paired pilot
  cases; no automatic promotion. The availability guard changed zero choices.
  H137A's older cost screen helped in some simulated high-cost conditions.
- 43 focused Accuracy H137A/H138A tests passed; 58 H135-R/H136-focused tests
  passed; 11 vendor hashes pass.
- An attempted full inherited regression exceeded the allotted runtime and
  MUST NOT be called a full-suite pass.
- The larger 40-world and 20-world sweeps also timed out without sealed
  results; no success rate may be attributed to those unfinished attempts.

## Next research, in order

1. Do not promote H138A's redundant `signal_guard`. Keep existing H136 drift
   behavior as default; guard default flag remains False.
2. Obtain unmodified creator-drawn `accuracy.png` + original file SHA from a
   trusted unified parent, with provenance. Test authentic-geometry and meaning-
   only/no-image/randomized controls on new holdouts, strictly no lookahead.
3. Acquire genuinely observed **as-of** market data and provider-specific
   timestamps for every feature (price, volume, earnings, filings, attention).
   Never treat a fabricated spread/volume value as an actual Robinhood fill.
4. Test whether forecast drift monitoring, reliable source timestamps, and
   cost estimates change risk-adjusted paper results versus H136 default.
   Freeze strategy before untouched holdouts; preserve negative findings.
5. Do not use Robinhood trading-order tools, scaling, or account writes in this
   research loop. If using Codex Robinhood MCP, READ ONLY with explicit scope.

## Commands

    py -3 -m unittest tests.test_accuracy_evidence_h138a tests.test_accuracy_bloom_h137a -q
    py -3 -m unittest tests.test_familiarity_money_h136 tests.test_relevance_ladder_h135r -q
    py -3 -m bie verify-vendor

The frozen report already exists. `scripts/run_h138a_confirm.py` refuses to
overwrite it; to run a new confirmation, use new unexposed seeds and a distinct
output filename, explicitly preregistered before running.
