# BLOOM × BIE THRIVES Experience v32 — Computational Planet Reconstruction

## What this actually does

This **runnable** module extends the preserved v31 BIE assistant with `planet-reconstruct`, a desktop **BLOOM · Reconstruction** tab and the read-only assistant tool `astro_reconstruct`. It explores **five mutually competing climate assumptions** on known planets. It is an exploratory, reproducible **toy spatial energy-balance model** (solar flux, albedo, effective thermal emissivity, assumed horizontal redistribution, rotation, uncertainty sampling); it is **not** a radiative-transfer retrieval, physically calibrated 3-D general circulation model, planetary elevation map, X-ray vision, or evidence of life.

Per planet and scenario, the model creates 18×36 latitude/longitude cells of **hypothetical temperature proxies** (K), 5th/median/95th percentiles for global mean and thermal-band area fractions over seeded parameter draws, a source-aware ThoughtPacket, and optional constrained-input diagnostics. With synchronous rotation, the substellar longitude is defined as 0. The model has no topography or ocean geography. Every surface layer is an assumption-based environmental **possibility**, not a detection.

## Start

1. Install Python 3.10+ with Tkinter on Windows; extract the complete source ZIP and launch `START_BIE.bat`.
2. Open **BLOOM · Exoplanets** and choose **Offline examples** (this overwrites only the local exoplanet catalog snapshot, and asks permission). Alternatively choose **Sync NASA catalog** for a current published catalog; Internet required and explicitly initiated.
3. Open **BLOOM · Reconstruction**, enter `Proxima Cen b`, choose 160 draws and a rotation hypothesis, click **Run competing environments**. The window shows summaries; **Export full report** writes the complete 18×36 arrays to new JSON without overwriting files.
4. Optional: **Choose optional evidence JSON** containing research-source-labeled spectra and a stellar X-ray luminosity. These do not authenticate themselves and will NOT automatically establish climate or terrain. Consult the example schema.

## Commands

From the extracted v32 project directory:

```powershell
py -3 -m bie exo-reference
py -3 -m bie planet-reconstruct "Proxima Cen b" --draws 160 --seed 2177 --report proxima_hypothetical.json
py -3 -m bie planet-reconstruct "Proxima Cen b" --rotation fast_rotating --draws 160
py -3 -m bie planet-reconstruct "Proxima Cen b" --evidence examples/RECON_SYNTHETIC_EVIDENCE_SCHEMA_V32.json --report synthetic_example_results.json
py -3 -m unittest discover -s tests
py -3 -m bie verify-vendor
```

`--home PATH` (before the subcommand) selects a separate user data store. The schema example is **synthetic, not telescope measurements**. Reports preserve numerical inputs, source-provenance labels, scenario priors, limitations and hashes. Existing reports are never overwritten.

## Inputs and method

The existing NASA Exoplanet Archive composite CSV is the primary orbital/stellar source. If a planet lacks reported stellar insolation, reconstruction **fails closed** instead of inventing a value. Where the source lacks an insolation uncertainty column, this implementation explicitly assumes a *10% one-sigma fractional spread* as a sensitivity test (adjustable with `--insolation-relative-sigma`). Atmospheric composition, pressure, clouds, albedo and rotation are not known for Proxima b; five sets of unweighted bounded priors deliberately span very different possibilities. An RV minimum mass is not a directly measured true mass, and catalogued radius may be estimated. The energy balance conserves global absorbed stellar power in an idealized sphere, not atmospheric chemistry.

The optional JSON schema uses:

```json
{
  "planet":"Proxima Cen b",
  "source":"Your independently identified archival observation DOI or clearly SYNTHETIC example",
  "spectrum":[{"species":"CO2","assessment":"inconclusive"}],
  "xray":{"stellar_luminosity_erg_s":1e27}
}
```

X-ray luminosity is converted to **orbital flux** by an inverse-square geometric relation using the published semi-major axis. That is *not* a dose at the surface, atmospheric escape rate or a climate constraint. A reported spectral molecular detection is annotated for qualitative consistency only; no likelihood, molecular abundance, pressure or radiative transfer is calculated. Missing optional evidence is explicitly labeled missing, and user-supplied metadata is always labeled unverified. Dynamic flares, wavelength-dependent absorption and atmospheric retention need future calibrated analysis.

## Limits and decisions

- 18×36 thermal arrays are **imaginary conditional temperatures, not maps of real terrain, cities, oceans, mountains, people, alien life or biosignatures**.
- The fraction between 273–373 K is a purely thermal threshold. Liquid water additionally requires actual water, pressure and chemical conditions, none established here.
- Five scenarios **are not a posterior**. Their apparent agreement or frequency is not the probability of an atmosphere, habitability, or life.
- This simplified thermal map ignores full 3D circulation, rotation-dependent dynamics, topography, greenhouse spectral chemistry, cloud feedback, surface heat capacity, geothermal heat, magnetic shielding, erosion, stellar flares and observational selection.
- Real characterization requires calibrated optical/IR spectra, UV/X-ray time series, validated atmospheric retrieval and properly benchmarked 3D climate models. Uncertainty must be reduced with independent observations and held-out tests.

## Reproducible result (bundled offline reference, NOT live NASA sync)

For Proxima Cen b with 160 seed-2177 draws per scenario, a synchronous idealization yielded model mean temperature proxy medians ~183 K (airless), 212 K (thin), 247 K (Earth-like assumed), 281 K (dense greenhouse), 201 K (ice-rich). These are **illustrative**, not actual measurements or a claim that any scenario is correct. The fresh NASA Archive may report different best-fit values.

## Source references

- NASA Exoplanet Archive TAP: https://exoplanetarchive.ipac.caltech.edu/docs/TAP/usingTAP.html
- Proxima Cen planetary parameters: https://exoplanetarchive.ipac.caltech.edu/cgi-bin/DisplayOverview/nph-DisplayOverview?objname=Proxima+Cen+b
- Galuzzo et al., 3D climate simulation (2021): https://doi.org/10.3847/1538-4357/abdeb4
- NASA exoplanet atmosphere spectroscopy: https://science.nasa.gov/mission/webb/science-overview/science-explainers/what-would-earths-atmosphere-look-like-from-the-james-webb-space-telescope/

## Validation and source continuity

Read `reports/v32_tests.log`, `reports/v32_desktop_smoke.json`, `reports/v32_vendor_verification.json`, `reports/v32_parent_continuity.json`, and `SOURCE_SHA256_MANIFEST_V32.json`. v31 is the recovered parent; full v32 is an additive copy, not a replacement of the earlier BIE engine. The smaller update ZIP is for an already-extracted v31 installation: back up personal data, **copy the ZIP contents into the v31 root** (preserving hierarchy) and keep your local user state separate. The update ZIP does not contain the full vendor engine.
