# BIE THRIVES v29 evidence and integration report

- New module: `bie/wifi_novelty.py` (OS metadata anomaly triage)
- Integrations: CLI (`wifi-investigate`, `wifi-novelty`), GUI button `Investigate unfamiliar Wi-Fi`
- Local data sources: existing user-triggered Windows WLAN snapshots in `wifi_wiggle.sqlite3`
- No new radio hardware, Wi-Fi association, connection automation, public network scanning, credential retrieval, or claim of unknown radio protocol discovery.
- Scope: read-only host Wi-Fi reports and inference. `wifi-investigate` performs a single explicitly triggered measurement on Windows.
- Confidence: even repeated unusual metadata is never promoted to proof of novel Wi-Fi technology.
- Data protection: derived reports intentionally omit local raw network names, BSSIDs and unusual free-form adapter text; pseudonyms remain locally linkable.
- Test suite: 108 Python tests including 18 new v29 tests (all synthetic). Windows Wi-Fi hardware field test still pending.
- Continuity: parent v28 source set entirely preserved; 3 existing files changed deliberately (GUI, CLI, package version).
