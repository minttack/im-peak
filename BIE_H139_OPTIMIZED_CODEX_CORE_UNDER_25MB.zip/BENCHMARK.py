"""Reproducible local retrieval benchmark, not a language-model or GPU benchmark."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import platform
import random
import statistics
import tempfile
import time

from bie.store import Store
from bie.native import original_desktop


def timed(fn):
    start = time.perf_counter_ns()
    result = fn()
    return result, (time.perf_counter_ns() - start) / 1e6


def summary(values):
    vals = sorted(values)
    return {"n": len(vals), "median_ms": statistics.median(vals), "p95_ms": vals[min(len(vals)-1, int(.95*len(vals)))]}


def run(count=5000, queries=100):
    with tempfile.TemporaryDirectory(prefix="bie-benchmark-") as temp:
        root = Path(temp)
        store = Store(root / "v25")
        old = original_desktop().ConversationStore(root / "v1")
        for i in range(count):
            body = f"Fixture record {i}: needle{i:06d} is the unique lookup key for this benchmark observation."
            store.remember(body, subject=f"record {i}", source="synthetic benchmark fixture")
            old.remember(body)
        # Reopen state before querying: retrieval must survive a process-style restart.
        store = Store(root / "v25")
        rng = random.Random(20261015)
        selected = rng.sample(range(count), min(queries, count))
        fast_times, full_times, old_times = [], [], []
        found, full_found, old_found = 0, 0, 0
        rows = []
        for i in selected:
            query = f"needle{i:06d}"
            def full_scan():
                # Same corpus, same literal unique key, independent correct baseline.
                with store.db() as con:
                    records = con.execute("SELECT body FROM memories ORDER BY created_seq DESC").fetchall()
                return [r[0] for r in records if query in r[0]][:8]
            operations = [("indexed", lambda: store.recall(query)), ("all_row_scan", full_scan), ("v1_last200", lambda: old.notes(query))]
            rng.shuffle(operations)
            measurements = {}
            for name, operation in operations:
                result, elapsed = timed(operation)
                measurements[name] = {"found": bool(result), "elapsed_ms": elapsed}
            fast_times.append(measurements["indexed"]["elapsed_ms"])
            full_times.append(measurements["all_row_scan"]["elapsed_ms"])
            old_times.append(measurements["v1_last200"]["elapsed_ms"])
            found += measurements["indexed"]["found"]
            full_found += measurements["all_row_scan"]["found"]
            old_found += measurements["v1_last200"]["found"]
            rows.append({"query": query, **measurements})
        return {"scope": "LOCAL_SQLITE_RETRIEVAL_SYNTHETIC_UNIQUE_KEYS_NO_LLM_NO_GPU",
                "python": platform.python_version(), "platform": platform.platform(), "records": count,
                "seed": 20261015, "queries": len(selected), "indexed": {**summary(fast_times), "found": found},
                "full_scan": {**summary(full_times), "found": full_found},
                "original_v1_last_200": {**summary(old_times), "found": old_found},
                "indexed_vs_correct_full_scan_median_ratio": statistics.median(full_times)/statistics.median(fast_times),
                "memory_audit": store.audit(), "trials": rows,
                "limits": "Warm local synthetic queries. Unique-key recall is not semantic reasoning. Old v1 intentionally only considers its latest 200 notes; coverage comparison is not an equal-work speed comparison. No claim about model speed or your PC."}


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--records", type=int, default=5000)
    parser.add_argument("--queries", type=int, default=100)
    parser.add_argument("--output", type=Path, default=Path("reports/retrieval_benchmark.json"))
    args = parser.parse_args()
    if not 100 <= args.records <= 20000 or not 10 <= args.queries <= 1000:
        parser.error("Use 100–20000 records and 10–1000 queries")
    report = run(args.records, args.queries)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps({k: v for k, v in report.items() if k != "trials"}, indent=2))
