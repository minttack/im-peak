@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 (echo Python launcher not found & pause & exit /b 2)
py -3 -m unittest discover -s tests -q
if errorlevel 1 goto fail
py -3 -m bie verify-vendor
if errorlevel 1 goto fail
if not exist reports mkdir reports
py -3 -m bie accuracy-h137a-demo --world familiarity_trap --seed 33701 --days 104
if errorlevel 1 goto fail
echo H137A software verified on this computer. Synthetic only. No brokerage orders.
echo Open this folder in Codex and read CODEX_NEXT_TASK_H137A.md.
pause
exit /b 0
:fail
echo Failed validation. Do not promote. Save evidence and diagnose.
pause
exit /b 1
