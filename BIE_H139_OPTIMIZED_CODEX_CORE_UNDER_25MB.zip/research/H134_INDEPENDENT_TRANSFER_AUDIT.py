"""Independent synthetic stress generator; deliberately NOT the H134 learner label rule.

Not a backtest and not real stocks. Source-age, latency, liquidity and model misspecification
can differ sharply from the development toy world. Check frozen policy without tuning.
"""
import json
import random
import statistics
from pathlib import Path
from bie.transfer_bloom_h134 import UNIVERSE, FEATURES, STRONG_FIXED_COMPARATOR, predict, baseline_h133, metrics

REGIMES = ('stable', 'stale_source', 'liquidity_halt', 'price_gap', 'independent_noise')


def cases(seed, regime, n=300):
    rng=random.Random(f'external-H134-unguided:{seed}:{regime}')
    out=[]
    for i in range(n):
        guards = {f:(rng.random()<.92) for f in FEATURES}
        age = rng.choice((5,20,45,120,400,600,1200,2500))
        sample = rng.choice((15,35,50,65,100,200))
        cost = rng.uniform(1,32)
        quoted_slippage = rng.uniform(4,35)
        gross = rng.uniform(-30,235)
        additive_hidden = rng.gauss(4,11)
        if regime=='liquidity_halt' and rng.random()<.33: additive_hidden += rng.uniform(70,170)
        if regime=='price_gap' and rng.random()<.29: additive_hidden += rng.uniform(20,130)
        if regime=='independent_noise': additive_hidden += rng.gauss(0,44)
        if regime=='stale_source' and age>120: additive_hidden += rng.uniform(20,75)
        actual_cost = cost + max(0,quoted_slippage+additive_hidden)
        hidden_halt = regime=='liquidity_halt' and rng.random()<.075
        # An intentionally different target definition: stricter timeliness, lower real-edge
        # threshold, extra latent halt factor, imperfect source. No policy sees latent fields.
        truth = bool(all(guards.values()) and sample>=50 and age<=240 and
                     gross-actual_cost>=10 and not hidden_halt)
        c = dict(id=f'{regime}:{seed}:{i}',ticker=UNIVERSE[i%10],features=guards,samples=sample,
                 net_excess=round((gross-cost)/10000,8),
                 gross_bps=round(gross,5),reported_cost_bps=round(cost,5),
                 slippage_estimate_bps=round(quoted_slippage,5),
                 source_age_minutes=age,label=truth,regime=regime)
        if regime=='independent_noise' and rng.random()<.06:
            c['slippage_estimate_bps'] = None  # observed data missing
        out.append(c)
    return out


def audit(nseeds=30, n=300):
    result=[]
    for seed in range(90011,90011+nseeds):
        rows=[r for regime in REGIMES for r in cases(seed,regime,n)]
        old=metrics(rows,baseline_h133)
        improved=metrics(rows,lambda c:predict(STRONG_FIXED_COMPARATOR,c))
        result.append({'seed':seed,'h133':old,'h134_cost_aware':improved})
    def mean(model,key):return round(statistics.mean(r[model][key] for r in result),6)
    return {'schema':'bie-h134-independent-audit.1','generator':'independent_synthetic_alternative_oracle_not_real_market',
            'seeds':nseeds,'cases_per_seed':n*len(REGIMES),'total_cases':n*len(REGIMES)*nseeds,
            'regimes':REGIMES,
            'h133':{k:mean('h133',k) for k in ('precision','recall','false_accept','false_positive_rate','f05')},
            'h134_cost_aware':{k:mean('h134_cost_aware',k) for k in ('precision','recall','false_accept','false_positive_rate','f05')},
            'per_seed_results':result,'real_market_proof':False,'trades_executed':0,
            'limitation':'Alternate toy oracle has different stale-timestamp acceptance and hidden shocks. Unseen tests should not be tuned on repeatedly.'}


if __name__=='__main__':
    p=Path('H134_INDEPENDENT_STRESS_RESULTS.json')
    with p.open('x',encoding='utf-8') as f:json.dump(audit(),f,indent=2)
    print(str(p))
