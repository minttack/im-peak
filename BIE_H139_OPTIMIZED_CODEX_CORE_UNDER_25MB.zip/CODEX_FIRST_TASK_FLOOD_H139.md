# Codex: your first H139 Flood Movement mission

Read `AGENTS.md`, `START_HERE_FLOOD_H139.md`, `CHAT_MASTER_BLUEPRINT_FLOOD_H139.md`, `ROBINHOOD_CODEX_READ_ONLY_H139.md`.

MISSION: Make Experience actively evaluate **whether volume/range flow, historical familiarity, and measured investor attention add predictive information beyond simple price-only and prior-probability baselines**, without hindsight leakage.

1. Preserve the user's whole earlier BIE research line and its negative results. H139 is an isolated source fork. No silent upgrade of Windows mainline.
2. Run `python -m unittest tests.test_flood_movement_h139 -v`, then `python -m unittest discover -s tests -p 'test_*.py'` and `python -m bie verify-vendor`. Report the exact numbers and any timeout.
3. Run each synthetic world (flow/reversal/null/illiquid) on 12 fresh predetermined seeds, keeping source attribution clear. Record whether a model was *selected before the holdout*, Brier improvement, net virtual P&L, and differences vs intraday SPY/QQQ/cash. Do not change thresholds to chase these seeds.
4. Identify missed causal factors or unintended leakage with independent counterfactuals: reorder rows, future-date signals, stale attention, corporate-action discontinuities, missing bars, high spread, noisy data, changed labels. If something fails, preserve it, propose one minimal fix, test fresh seeds.
5. Ask Experience's ACTUAL local model for a falsifiable next hypothesis if available; if not, record `local_model_unavailable` and proceed with deterministic question generation. Do not pretend Codex is Experience speaking.
6. Get real history using only explicitly permissioned read tools if the user authenticates Robinhood. Verify source date and adjusted prices, use JSON format in the data guide. Don't infer historical bid/ask from today's quote. Never retrieve unrelated account balances, PII, positions, or place orders.
7. Build a new evidence ledger with source IDs, first-known timestamps, cost assumptions, selected model, post-outcome corrections, and negative findings. No automatic live trade escalation; paper first.
8. After EACH experiment output a ThoughtPacket: source, relevance gain, confidence, uncertainty, assumptions, contradiction, failure, and one next experiment with a falsifier. Prefer useful evidence per CPU second, not literal spacetime manipulation.

SUCCESS CRITERIA: software tests pass AND the selected policy beats independently controlled baselines on untouched **real** timestamped periods with positive after-cost virtual return, stable calibration, measured drawdown and full provenance. If these conditions are absent, report 'not yet demonstrated' and give the highest-value next test. No 100% win guarantee. Do not convert test results into orders.
