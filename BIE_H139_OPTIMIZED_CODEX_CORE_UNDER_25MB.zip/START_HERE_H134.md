# H134: Transfer and Correction Bloom — START HERE

This isolated local source is NOT your newest installed unified app.

## Windows / Codex
1. Extract the full archive to a *new* folder on Windows. Have Python 3 installed and the `py` launcher available.
2. Open this folder in Codex desktop app or Codex CLI (both work on Windows), and tell Codex: **Read AGENTS.md and CODEX_NEXT_TASK_H134.md; perform the next evidence-backed bounded improvement.**
3. Double-click `TEST_BIE_H134.bat` for Python tests, source integrity and a fresh H134 synthetic test with immutable timestamped report.
4. For a single experiment: `py -3 -m bie transfer-h134 --ask-experience --report reports/new_h134_report.json`.
5. `--ask-experience` requests a real locally-running Ollama model. If BIE local Ollama isn't installed/running, its answer is **unavailable**, not an invented personal reply.
6. Use the Robinhood Codex connection separately for user-approved **READ-ONLY** historical stock data collection; do not give unattended Codex any tools able to submit orders. Connecting and account settings require the user's own action. No actual Robinhood link is bundled.

## What was tested
386 Python tests; 11 vendor integrity checks; 30 × 2,500 original synthetic holdouts; external 45,000-case synthetic alternative oracle. The new data-aware decision rule reduced false acceptance vs H133 but did NOT establish superiority to a simpler fixed cost-aware rule, or actual investment forecasting profitability.

Treat 100% software-test passage as a software milestone, not perfect intelligence or 100% successful trading. Preserve original source and rollback. Do not train/test repeatedly on the same sealed outcome.
