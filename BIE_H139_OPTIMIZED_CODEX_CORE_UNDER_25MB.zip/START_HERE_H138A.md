# BIE H138A (independent offline Accuracy research candidate)

1. Extract this source into its **own folder** on Windows, not over a newer
   installed BIE build. Requires Python 3.10+ and original BIE dependencies.
2. Double-click `TEST_ACCURACY_H138A.bat` for targeted regression tests.
3. Open folder in Codex; read `AGENTS.md`, then `CODEX_NEXT_TASK_H138A.md`.
4. Read `reports/H138A_FROZEN_CONFIRM.json` before proposing next changes.
5. No Robinhood login required or executed. It does not run automatically;
   no future stock prices were retrieved and no trading orders placed.

No 100% market win claim, autonomous LLM learning claim, or use of creator
glyph geometry. Existing strong H136 drift guard remains the default.
