# BIE THRIVES Experience v32 + Adaptive BLOOM Wiggle — integration candidate

**Original BIE THRIVES / BLOOM Experience remains v32.** This additive code candidate introduces an experimental v33 feature, *not* a promoted v33 production release. The original v32 parent source archive was not changed. The `SOURCE_SHA256_MANIFEST_V32.json` file is preserved as a historical v32 record; use the new `SOURCE_SHA256_MANIFEST_ADAPTIVE_WIGGLE.json` to verify this candidate's actual tree.

## Functionality actually integrated

1. **Real BIE local desktop:** an additional `BLOOM · Adaptive Wiggle` tab accepts a simple editable map, shows the greedy control and the adaptive route, and visualizes escalation stages as JSON. It does not alter the Wi-Fi Wiggle lab or X-ray/planet-reconstruction tools.
2. **Real BIE CLI:** `python -m bie wiggle-demo` works offline; `python -m bie wiggle-plan examples/ADAPTIVE_WIGGLE_GRID.txt --initial-budget 8 --max-expansions 4096` accepts an explicitly supplied text file. `python -m bie gui` opens the same BIE window plus the new tab.
3. **Real assistant tool:** `adaptive_wiggle` is available as a **read-only tool** with bounded grid-map input. Its results are tracked in the existing SQLite tool receipt/experience ledger. It requires neither project writes nor Python execution approval.
4. **Real assistant recovery:** after the *second* identical tool failure, runtime provides a high-priority, bounded guidance message telling the assistant to diagnose and try a different authorized path. A *third* identical failure still stops the task. No elevated permissions or repeat-until-success loop.

## How the algorithm works

`S` = start, `G` = goal, `#` = blocked, `.` = free, `1` through `9` = terrain entry cost. Four-direction movement only, up to 64×64 cells. Greedy Manhattan descent is a deliberate weak baseline that can be trapped by a wall. The adaptive planner uses **standard exact A*** with a consistent, admissible Manhattan heuristic, continuing the *same search frontier* across progressively larger expansion budgets. Earlier explored states and failures are retained within that run; expanding the budget is what we call **Wiggle intensification**.

A reached result is guaranteed minimum entry cost *given the declared grid and known costs*, not a novel superior algorithm. If the frontier runs dry the outcome is `unreachable`; if it hits `max_expansions` with work left, the outcome is `budget_exhausted`, with **no invented route** and no optimality claim. The tool neither edits files nor controls robots/vehicles. Evidence from this toy route solver does not establish improvement across arbitrary BIE decision tasks, cryptographic search, Wi-Fi, game AI, or real-world routing.

## Install without losing existing BIE files

**Recommended:** unzip the full-source candidate to a new directory alongside v32. Continue using the existing `--home` state folder (or let the default state path point to the original); don't delete existing storage or databases. On Windows, run `START_BIE.bat` in the candidate directory. Python 3.10+ with Tkinter is required. An optional local Ollama model is needed for BIE coding/chat; the Wiggle demo and UI tab need no model.

**For a current, pristine extracted v32 installation:** use the separate update-only ZIP. Extract the update in a *different* directory, run:

```powershell
py -3 APPLY_ADAPTIVE_WIGGLE_V32.py "C:\path\to\BIE_THRIVES_Experience_v32"  # verify compatibility, no writes
py -3 APPLY_ADAPTIVE_WIGGLE_V32.py "C:\path\to\BIE_THRIVES_Experience_v32" --apply  # backup and apply
```

The updater verifies exact unmodified parent hashes for all changed files, refuses unknown/mismatched modifications and preexisting conflicting new files, and writes backups. It never touches the user's state database or project folder. The full-source ZIP is the simpler choice if you've customized v32 or have any doubts about parent identity.

## Reproduce the checks

```powershell
py -3 -m bie wiggle-demo
py -3 -m bie wiggle-plan examples/ADAPTIVE_WIGGLE_GRID.txt
py -3 -m unittest discover -s tests -v
py -3 -m bie verify-vendor
```

Local evidence: 185/185 Python tests passed (172 inherited + 13 new), seeded randomized route examples were cross-checked against independently implemented Dijkstra, and a Tkinter GUI click passed via a headless Linux display. An actual Windows GUI smoke test, user's BIE state migration, and larger real-task performance studies were **not** executed. No existing Windows installation or authoritative remote repository was modified. This candidate does **not** show that Wiggle beats standard A* or Dijkstra.

## Provenance

Created as requested for the user's **BIE THRIVES Experience** project and Adaptive Bloom Wiggle proposal. `reports/adaptive_wiggle_integration.json` lists parent ZIP hash, modified files, and local test status. The original v32 vendor data (including nested unmodified BIE v8 archive and v24 experiment snapshot) remains byte-identical.
