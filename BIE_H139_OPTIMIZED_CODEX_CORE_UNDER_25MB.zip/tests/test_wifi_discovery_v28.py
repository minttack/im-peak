"""v28 adversarial & continuity tests. All radio observations are SYNTHETIC."""
import json
from pathlib import Path
import sqlite3
import tempfile
import unittest
from unittest.mock import patch
from io import StringIO

from bie.wifi_lab import WifiLab, parse_interfaces, parse_networks, parse_drivers
from bie.wifi_discovery import WifiDiscovery, _predict, _errors, _wilson
from bie.__main__ import main

NEARBY = '''SSID 1 : PRIV-AP-ALPHA
    Authentication : WPA3-Personal
    BSSID 1 : de:ad:be:ef:00:01
        Signal : 68%
        Radio type : 802.11ax
        Band : 6 GHz
        Channel : 37
SSID 2 : PRIV-AP-BETA
    Authentication : WPA2-Personal
    BSSID 1 : de:ad:be:ef:00:02
        Signal : 88%
        Radio type : 802.11be
        Band : 5 GHz
        Channel : 36
    BSSID 2 : de:ad:be:ef:00:03
        Signal : 52%
        Radio type : 802.11be
        Band : 5 GHz
        Channel : 36
'''
NEARBY_NEW = '''SSID 1 : PRIV-AP-ALPHA
BSSID 1 : de:ad:be:ef:00:01
 Signal : 60%
 Radio type : 802.11ax
 Band : 6 GHz
 Channel : 37
SSID 2 : NEW-PRIVATE
BSSID 1 : de:ad:be:ef:00:09
 Signal : 20%
 Radio type : 802.11n
 Band : 2.4 GHz
 Channel : 11
'''


def sample(value=62, networks=NEARBY, warnings=None, time='2026-10-15T08:00:00+00:00', ssid='PRIV-AP-ALPHA'):
    return {'ok': True, 'captured_at': time, 'connection':
            {'ssid': ssid, 'signal_pct': value, 'radio': '802.11ax', 'band': '6 GHz',
             'channel': '37', 'rx_mbps': 900., 'tx_mbps': 800.},
            'access_points': parse_networks(networks),
            'adapter': parse_drivers('Radio types supported : 802.11n 802.11ax'),
            'warnings': warnings or []}


class DiscoveryV28(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.home = Path(self.temp.name)
        self.lab = WifiLab(self.home)
        self.disco = WifiDiscovery(self.home)

    def test_01_no_fake_results_if_no_records(self):
        r = self.disco.report()
        self.assertEqual(r['status'],'no_measurements')
        self.assertNotIn('access_point_count', str(r))

    def test_02_evidence_redaction_and_protocol(self):
        self.lab.snapshot(sample())
        r = self.disco.report()
        self.assertEqual(r['sample_summary']['highest_observed_advertised_generation'],7)
        self.assertEqual(r['sample_summary']['latest_adapter_reported_generation'],6)
        self.assertEqual(r['sample_summary']['local_pseudonymous_aps'],3)
        self.assertEqual(r['latest_reported_channel_counts']['5 GHz / channel 36'],2)
        self.assertEqual(r['latest_reported_channel_counts']['6 GHz / channel 37'],1)
        self.assertIn('adapter_capability_gap',[p['id'] for p in r['thought_packets']])
        content=json.dumps(r)+(self.home/'wifi_wiggle.sqlite3').read_bytes().decode('latin1')
        for secret in ('PRIV-AP-ALPHA', 'PRIV-AP-BETA', 'de:ad:be:ef:00:02', 'NEW-PRIVATE'):
            self.assertNotIn(secret,content)
        self.assertTrue(all('would_contradict' in p and 'source' in p for p in r['thought_packets']))

    def test_03_identifiers_stable_over_new_sessions(self):
        self.lab.snapshot(sample())
        session=self.lab.new_session()
        self.lab.snapshot(sample())
        r=self.disco.report()
        self.assertEqual(r['sample_summary']['session_labels'],2)
        self.assertEqual(r['most_observed_access_points'][0]['seen_snapshots'],2)
        self.assertTrue(session['session_id'].startswith('session-'))

    def test_04_new_visibility_has_alternatives_not_eureka(self):
        self.lab.snapshot(sample(networks=NEARBY))
        self.lab.snapshot(sample(networks=NEARBY_NEW))
        r=self.disco.report()
        self.assertEqual(len(r['change_summary']['newly_visible_local_ids']),1)
        self.assertEqual(len(r['change_summary']['no_longer_visible_local_ids']),2)
        p=next(p for p in r['thought_packets'] if p['id']=='visibility_wiggle')
        self.assertIn('multipath',' '.join(p['alternative_explanations']))
        self.assertEqual(p['classification'],'inference_not_physical_discovery')

    def test_05_incomplete_reading_is_not_absence(self):
        self.lab.snapshot(sample())
        self.lab.snapshot(sample(networks='', warnings=['Windows denied permission']))
        r=self.disco.report()
        self.assertEqual(r['sample_summary']['eligible_ap_snapshots'],1)
        self.assertEqual(r['sample_summary']['excluded_ap_snapshots'],1)
        self.assertEqual(r['change_summary']['newly_visible_local_ids'],[])
        self.assertEqual(r['change_summary']['no_longer_visible_local_ids'],[])
        self.assertNotIn('visibility_wiggle',[p['id'] for p in r['thought_packets']])

    def test_06_missing_radios_no_wifi7_claim(self):
        fake=sample(networks='SSID 1 : not-protocol\nBSSID 1 : 01:01:01:01:01:01\n Signal : 50%')
        fake['adapter']={}
        self.lab.snapshot(fake)
        r=self.disco.report()
        self.assertIsNone(r['sample_summary']['highest_observed_advertised_generation'])
        self.assertFalse(any(p['id']=='observed_wifi7_advertisement' for p in r['thought_packets']))

    def test_07_v27_schema_migrates_and_preserves_readings(self):
        db=self.home/'wifi_wiggle.sqlite3'
        with sqlite3.connect(db) as con:
            con.execute('DROP TABLE readings')
            con.executescript('''CREATE TABLE readings(id INTEGER PRIMARY KEY, observed_at TEXT NOT NULL,connected_id TEXT,signal_pct INTEGER,rx_mbps REAL,tx_mbps REAL, connected_radio TEXT,connected_band TEXT,adapter_json TEXT NOT NULL,aps_json TEXT NOT NULL,warnings_json TEXT NOT NULL);''')
            con.execute('INSERT INTO readings(observed_at,connected_id,signal_pct,rx_mbps,tx_mbps,connected_radio,connected_band,adapter_json,aps_json,warnings_json) VALUES(?,?,?,?,?,?,?,?,?,?)',
                        ('2026-10-14T18:00:00+00:00','old-local-id',43,None,None,'802.11n','2.4 GHz','[]','[]','[]'))
        upgraded=WifiLab(self.home)
        with sqlite3.connect(db) as con:
            self.assertEqual(con.execute('SELECT signal_pct FROM readings').fetchone()[0],43)
            self.assertIn('session_id',{x[1] for x in con.execute('PRAGMA table_info(readings)')})
        upgraded.snapshot(sample())
        self.assertEqual(self.disco.report()['sample_summary']['total_snapshots'],2)

    def test_08_prediction_cannot_use_future(self):
        one=[42,60,55,48,61,69,49,62,50,55,65,53,64,58,66]
        two=one.copy();two[-1]=7
        # earlier predictions independent of future measurement
        errors1=_errors(one)
        errors2=_errors(two)
        for k in errors1:
            self.assertEqual(errors1[k][:-1],errors2[k][:-1])

    def test_09_prediction_stability_baseline_controls(self):
        r=_predict([55]*35,['s1']*15+['s2']*20)
        self.assertEqual(r['mean_absolute_error']['last_value'],0)
        self.assertEqual(r['status'],'not_supported_vs_baseline')
        alternating=_predict([20,90]*18,['s1']*18+['s2']*18)
        self.assertLessEqual(alternating['wiggle_gain_vs_last_value_mae'],0)
        self.assertIn('no look-ahead',r['method'])

    def test_10_sessions_cannot_be_inferred_from_count(self):
        for i in range(32):
            self.lab.snapshot(sample(40+i%20))
        r=self.disco.report()
        self.assertEqual(r['signal_model']['user_labeled_sessions'],1)
        self.assertNotEqual(r['signal_model']['status'],'validated')

    def test_11_new_session_report_long_history(self):
        for i in range(18): self.lab.snapshot(sample(40+i*2))
        self.lab.new_session()
        for i in range(18): self.lab.snapshot(sample(76-i))
        r=self.disco.report()
        self.assertEqual(r['signal_model']['snapshots'],36)
        self.assertEqual(r['signal_model']['user_labeled_sessions'],2)
        self.assertIn('exploratory_block_bootstrap_95_pct_delta',r['signal_model'])
        self.assertEqual(r['signal_model']['timestamp_quality'],'repeated_timestamps')
        self.assertNotEqual(r['signal_model']['status'],'provisional_prediction_signal_needs_external_replication')

    def test_12_confidence_not_truth_frequency(self):
        self.assertEqual(_wilson(1,1)[1],1)
        self.assertLess(_wilson(1,10)[1],1)
        self.assertIsNone(_wilson(0,0))
        self.lab.snapshot(sample())
        self.assertIn('independence assumptions',' '.join(self.disco.report()['limitations']))

    def test_13_repeated_AP_is_not_new_device(self):
        for _ in range(3): self.lab.snapshot(sample())
        r=self.disco.report()
        self.assertEqual(len(r['change_summary']['newly_visible_local_ids']),0)
        self.assertTrue(r['change_summary']['change_is_not_discovery'])

    def test_14_if_change_ap_but_connected_router_unrelated_ignored(self):
        for i in range(6): self.lab.snapshot(sample(40+i,ssid='HOME-A'))
        for i in range(9): self.lab.snapshot(sample(75+i,ssid='HOME-B'))
        r=self.disco.report()
        self.assertEqual(r['signal_model']['have'],9)
        self.assertEqual(r['signal_model']['status'],'insufficient_snapshots')

    def test_15_command_line_report_and_export_no_clobber(self):
        self.lab.snapshot(sample())
        f=self.home/'report.json'
        with patch('sys.stdout',new_callable=StringIO) as stream:
            self.assertEqual(main(['--home',str(self.home),'wifi-export',str(f)]),0)
        data=json.loads(f.read_text())
        self.assertEqual(data['version'],28)
        self.assertNotIn('PRIV-AP-ALPHA',f.read_text())
        with patch('sys.stderr',new_callable=StringIO):
            self.assertEqual(main(['--home',str(self.home),'wifi-export',str(f)]),1)
        self.assertEqual(data,json.loads(f.read_text()))

    def test_16_no_access_method_exposed(self):
        r=self.disco.report()
        self.assertNotIn('credentials',r)
        self.assertEqual(r['status'],'no_measurements')
        for name in ('join','authenticate','brute_force','probe'):
            self.assertFalse(hasattr(self.disco,name))

if __name__ == '__main__': unittest.main()
