import copy
from datetime import datetime, timezone, timedelta
import json
from pathlib import Path
import tempfile
import unittest

from bie.stock_universe_h131 import evaluate, from_file, template, METRICS, SCHEMA, SEED, ask_local_experience_universe
from unittest.mock import patch

NOW = datetime.now(timezone.utc).replace(microsecond=0)
AS_OF = NOW.isoformat().replace('+00:00','Z')


def obs(ticker, metric, value, timestamp=AS_OF):
    return {"ticker": ticker, "metric": metric, "value": value,
            "observed_at_utc": timestamp, "source": "robinhood_mcp",
            "reference": f"synthetic test observation {ticker}/{metric}; NOT actual Robinhood data"}


def full(ticker):
    return [
        obs(ticker,"daily_bars_1y",250),
        obs(ticker,"last_bar_date",(NOW-timedelta(days=1)).date().isoformat()),
        obs(ticker,"median_dollar_volume_20d",125e6),
        obs(ticker,"quoted_spread_bps",5.0),
        obs(ticker,"quarterly_filing_count",5),
        obs(ticker,"latest_filing_date",(NOW-timedelta(days=80)).date().isoformat()),
        obs(ticker,"earnings_dates_count_1y",4),
        obs(ticker,"recent_news_items_30d",20),
        obs(ticker,"tradable",True)
    ]


def packet(*data):
    return {"schema": SCHEMA, "as_of_utc": AS_OF, "observations": [item for block in data for item in block]}


class ResearchUniverseTests(unittest.TestCase):
    def test_only_seed_is_not_falsely_scored(self):
        a = evaluate()
        self.assertEqual(a["mode"],"seed_only_no_live_scan")
        self.assertNotIn("selected_research_watchlist", a)
        self.assertFalse(a["recommended_to_buy"])

    def test_good_validated_stock_is_selected_for_research(self):
        a = evaluate(packet(full("JPM")))
        self.assertEqual(a["selected_research_watchlist"],["JPM"])
        self.assertEqual(a["candidates"][0]["data_quality_score_0_100"],100)

    def test_no_data_is_not_pretended(self):
        a = evaluate(packet([obs("MSFT","tradable",True)]))
        self.assertFalse(a["selected_research_watchlist"])
        self.assertFalse(next(x for x in a["candidates"] if x["ticker"]=="MSFT")["research_ready"])

    def test_data_quality_not_trading_buy_signal(self):
        a = evaluate(packet(full("JPM")))
        self.assertEqual(a["stock_trade_recommendation"][:4], "NONE")
        self.assertEqual(a["candidates"][0]["stock_trade_recommendation"], "NOT_EVALUATED")

    def test_mandatory_dollar_volume_gate(self):
        a = full("XOM")
        next(x for x in a if x["metric"]=="median_dollar_volume_20d")["value"] = 10e6
        ranked = evaluate(packet(a))
        self.assertFalse(ranked["selected_research_watchlist"])

    def test_missing_tradability_gate(self):
        a = [o for o in full("XOM") if o["metric"]!="tradable"]
        self.assertFalse(evaluate(packet(a))["selected_research_watchlist"])

    def test_missing_price_gate(self):
        a = [o for o in full("XOM") if o["metric"]!="daily_bars_1y"]
        self.assertFalse(evaluate(packet(a))["selected_research_watchlist"])

    def test_missing_quarters_gate(self):
        a = [o for o in full("XOM") if o["metric"]!="quarterly_filing_count"]
        self.assertFalse(evaluate(packet(a))["selected_research_watchlist"])

    def test_future_observation_leakage_rejected(self):
        a = full("MSFT"); a[0]["observed_at_utc"]=(NOW+timedelta(days=1)).isoformat().replace('+00:00','Z')
        with self.assertRaisesRegex(ValueError,"future knowledge"):
            evaluate(packet(a))

    def test_future_bar_date_rejected(self):
        a = full("AAPL"); a[1]["value"]=(NOW+timedelta(days=1)).date().isoformat()
        with self.assertRaisesRegex(ValueError,"Future"):
            evaluate(packet(a))

    def test_stale_spread_no_credit(self):
        a = full("JPM")
        x = next(x for x in a if x["metric"]=="quoted_spread_bps")
        x["observed_at_utc"]=(NOW-timedelta(days=45)).isoformat().replace('+00:00','Z')
        q = evaluate(packet(a))["candidates"][0]
        self.assertEqual(q["data_quality_score_0_100"], 90)
        self.assertTrue(any("Stale quoted_spread_bps" in s for s in q["warnings"]))

    def test_stale_tradability_blocks(self):
        a = full("AAPL")
        next(x for x in a if x["metric"]=="tradable")["observed_at_utc"]=(NOW-timedelta(days=20)).isoformat().replace('+00:00','Z')
        self.assertFalse(evaluate(packet(a))["selected_research_watchlist"])

    def test_stale_price_blocks(self):
        a = full("AAPL")
        next(x for x in a if x["metric"]=="last_bar_date")["value"]=(NOW-timedelta(days=12)).date().isoformat()
        self.assertFalse(evaluate(packet(a))["selected_research_watchlist"])

    def test_reject_duplicate_evidence(self):
        a = full("AAPL") + [copy.deepcopy(full("AAPL")[0])]
        with self.assertRaisesRegex(ValueError,"Duplicate"):
            evaluate(packet(a))

    def test_negative_invalid_volume(self):
        a = full("AAPL"); a[2]["value"]=-4
        with self.assertRaisesRegex(ValueError,"nonnegative"):
            evaluate(packet(a))

    def test_boolean_not_integer(self):
        a = full("AAPL"); a[0]["value"] = True
        with self.assertRaises(ValueError):
            evaluate(packet(a))

    def test_nan_rejected(self):
        a = full("AAPL"); a[2]["value"] = float('nan')
        with self.assertRaisesRegex(ValueError,"finite"):
            evaluate(packet(a))

    def test_unsupported_ticker_rejected(self):
        with self.assertRaisesRegex(ValueError,"ticker"):
            evaluate(packet([obs("../../bad", "tradable", True)]))

    def test_unknown_metric_rejected(self):
        with self.assertRaisesRegex(ValueError,"metric/source"):
            evaluate(packet([obs("MSFT", "guaranteed_profit", True)]))

    def test_unknown_source_rejected(self):
        a=full("AAPL"); a[0]["source"]="rumor"
        with self.assertRaisesRegex(ValueError,"metric/source"):
            evaluate(packet(a))

    def test_missing_source_reference_rejected(self):
        a=full("AAPL"); a[0].pop("reference")
        with self.assertRaisesRegex(ValueError,"source reference"):
            evaluate(packet(a))

    def test_sector_cap(self):
        a = evaluate(packet(full("MSFT"),full("AAPL"),full("NVDA"),full("JPM")),top=4)
        self.assertEqual(len(a["selected_research_watchlist"]),3)
        self.assertIn("JPM",a["selected_research_watchlist"])

    def test_rank_by_completeness(self):
        partial = [a for a in full("MSFT") if a["metric"]!="recent_news_items_30d"]
        a = evaluate(packet(full("JPM"),partial),top=2)
        self.assertEqual(a["selected_research_watchlist"][0],"JPM")

    def test_self_question_and_next_experiment(self):
        a = evaluate(packet([obs("AAPL", "tradable", True)]))
        self.assertTrue(a["self_question"])
        self.assertTrue(a["next_experiment"]["metric"])

    def test_invalid_schema_rejected(self):
        with self.assertRaises(ValueError):
            evaluate({"schema":"wrong", "as_of_utc":AS_OF, "observations": full("MSFT")})

    def test_invalid_as_of_rejected(self):
        a = packet(full("MSFT")); a["as_of_utc"]="saturday"
        with self.assertRaises(ValueError):
            evaluate(a)

    def test_future_as_of_rejected(self):
        a = packet(full("MSFT")); a["as_of_utc"]=(NOW+timedelta(days=5)).isoformat().replace('+00:00','Z')
        with self.assertRaises(ValueError):
            evaluate(a)

    def test_reject_empty_evidence(self):
        with self.assertRaises(ValueError):
            evaluate(packet([]))

    def test_bounded_input_file(self):
        with tempfile.TemporaryDirectory() as d:
            path=Path(d)/"x.json"; path.write_bytes(b" " * 1_000_100)
            with self.assertRaises(ValueError):
                from_file(path)

    def test_valid_json_file(self):
        with tempfile.TemporaryDirectory() as d:
            path=Path(d)/"x.json";path.write_text(json.dumps(packet(full("JNJ"))))
            self.assertEqual(from_file(path)["selected_research_watchlist"],["JNJ"])

    def test_template_is_only_template(self):
        t=template()
        self.assertEqual(t["observations"],[])
        self.assertEqual(set(t["permitted_metrics"]),set(METRICS))

    def test_local_bie_fallback_does_not_invent_reply(self):
        from bie.model import ModelUnavailable
        with patch("bie.model.Ollama.reply", side_effect=ModelUnavailable("not connected")):
            r=ask_local_experience_universe(evaluate())
        self.assertEqual(r["status"],"local_bie_model_unavailable")
        self.assertTrue(r["scores_unchanged"])

    def test_local_bie_actual_mock_reply_is_unverified(self):
        with patch("bie.model.Ollama.reply", return_value=({"content":"Try measuring freshness."}, {})):
            r=ask_local_experience_universe(evaluate())
        self.assertEqual(r["status"], "local_bie_model_replied")
        self.assertTrue(r["unverified_proposal_only"])

    def test_benchmarks_not_stock_candidates(self):
        self.assertFalse(set(("SPY", "QQQ")) & set(SEED))


if __name__ == "__main__":
    unittest.main()
