import json
import tempfile
from pathlib import Path
import unittest

from bie.learning_accelerator import LearningAccelerator, read_jobs, PROFILES
from bie.datahub import KnowledgeHub
from bie.config import PROFILES as AGENT_PROFILES


class LearningAcceleratorTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.home = Path(self.temp.name)
        self.jobs = self.home / 'job.json'
        self.jobs.write_text(json.dumps({'jobs':[
            {'provider':'openalex','query':'graph learning','limit':3},
            {'provider':'crossref','query':'uncertainty calibration','limit':2},
        ]}), encoding='utf-8')
        self.engine = LearningAccelerator(self.home)
        self.calls = []

    def fake(self, provider, query, limit):
        self.calls.append((provider,query,limit))
        return {'provider':provider,'records':[
            {'title': f'{provider} {query} {i}', 'url':f'https://example.org/{provider}/{query.replace(" ", "-")}/{i}',
             'identifier':str(i),'description':'unverified test reference'} for i in range(limit)
        ]}

    def test_profile_caps_are_bounded(self):
        self.assertLessEqual(max(p.max_queries for p in PROFILES.values()),300)
        self.assertLessEqual(max(p.workers for p in PROFILES.values()),4)
        self.assertIn('Deep', AGENT_PROFILES)
        self.assertLessEqual(AGENT_PROFILES['Deep'].model_context,32768)

    def test_plan_offline_and_no_imports(self):
        p = self.engine.plan(self.jobs)
        self.assertEqual(p['selected_profile'],'Balanced')
        self.assertEqual(p['network_requests_this_command'],0)
        self.assertFalse(p['model_weight_training'])
        self.assertEqual(KnowledgeHub(self.home).status()['documents'],0)
        self.assertEqual(self.engine.status()['recorded_runs'],0)

    def test_confirmation_required(self):
        with self.assertRaises(PermissionError):
            self.engine.run(self.jobs,fetch=self.fake,pace=False)
        self.assertEqual(self.calls,[])

    def test_add_then_deduplicate(self):
        one=self.engine.run(self.jobs,confirmed=True,fetch=self.fake,pace=False)
        self.assertEqual(one['new_references'],5)
        self.assertEqual(one['references_seen'],5)
        self.assertEqual(one['knowledge_verified'],0)
        two=self.engine.run(self.jobs,confirmed=True,start_at=0,fetch=self.fake,pace=False)
        self.assertEqual(two['new_references'],0)
        self.assertEqual(two['duplicate_references'],5)
        self.assertEqual(KnowledgeHub(self.home).status()['documents'],5)
        self.assertEqual(self.engine.status()['recorded_runs'],2)

    def test_changed_metadata_does_not_count_new_reference(self):
        self.engine.run(self.jobs,confirmed=True,fetch=self.fake,pace=False)
        def changed(provider,query,limit):
            records=self.fake(provider,query,limit)
            for r in records['records']: r['description']='changed external metadata'
            return records
        two=self.engine.run(self.jobs,confirmed=True,start_at=0,fetch=changed,pace=False)
        self.assertEqual(two['new_references'],0)
        self.assertEqual(two['changed_existing_references'],5)

    def test_duplicate_manifest_jobs_and_profile_limit(self):
        jobs=[{'provider':'openalex','query':f'subject {i}'} for i in range(25)]
        jobs.append({'provider':'openalex','query':'Subject 1'})
        self.jobs.write_text(json.dumps({'jobs':jobs}))
        p=self.engine.plan(self.jobs, 'Evidence')
        self.assertEqual(p['duplicate_queries_skipped'],1)
        self.assertEqual(p['jobs_this_run'],10)
        self.assertEqual(p['jobs_remaining'],15)
        with self.assertRaises(ValueError):
            self.engine.plan(self.jobs,'Evidence',max_jobs=11)
        self.assertEqual(self.engine.plan(self.jobs,'Evidence',max_jobs=2)['jobs_this_run'],2)

    def test_unsupported_provider_and_large_file_rejected(self):
        self.jobs.write_text(json.dumps({'jobs':[{'provider':'localhost','query':'secret'}]}))
        with self.assertRaises(ValueError): read_jobs(self.jobs)
        self.jobs.write_text(' ' * 1000001)
        with self.assertRaises(ValueError): read_jobs(self.jobs)

    def test_invalid_url_and_bad_data_skipped(self):
        def fake(provider,query,limit):
            return {'provider':provider,'records':[
                {'title':'bad','url':'file:///etc/passwd'},
                {'title':'good','url':'https://example.net/good'},
                {'title':'bad','url':'http://127.0.0.1/private'},
                {'title':'bad','url':'https://someone:pass@example.org/private'}]}
        r=self.engine.run(self.jobs,confirmed=True,fetch=fake,pace=False)
        self.assertEqual(r['new_references'],1)
        self.assertEqual(r['invalid_references'],3)
        self.assertEqual(r['duplicate_references'],1)

    def test_manual_batches_resume_without_repeating_completed_jobs(self):
        self.jobs.write_text(json.dumps({'jobs':[
            {'provider':'openalex','query':f'subject {i}','limit':1} for i in range(22)]}))
        first=self.engine.run(self.jobs,profile='Evidence',confirmed=True,fetch=self.fake,pace=False)
        self.assertEqual((first['start_job_index'],first['next_job_index']),(0,10))
        second=self.engine.run(self.jobs,profile='Evidence',confirmed=True,fetch=self.fake,pace=False)
        self.assertEqual((second['start_job_index'],second['next_job_index']),(10,20))
        third=self.engine.run(self.jobs,profile='Evidence',confirmed=True,fetch=self.fake,pace=False)
        self.assertEqual((third['start_job_index'],third['next_job_index']),(20,22))
        self.assertEqual(KnowledgeHub(self.home).status()['documents'],22)
        with self.assertRaises(ValueError):
            self.engine.run(self.jobs,profile='Evidence',confirmed=True,fetch=self.fake,pace=False)
        self.assertEqual(self.engine.plan(self.jobs,'Evidence',start_at=0)['start_job_index'],0)

    def test_bad_provider_response_and_errors_reported(self):
        def broken(provider,query,limit):
            if provider == 'openalex': raise OSError('service unavailable')
            return {'provider':'wrong','records':[]}
        r=self.engine.run(self.jobs,confirmed=True,fetch=broken,pace=False)
        self.assertEqual(r['failed_jobs'],2)
        self.assertEqual(r['new_references'],0)
        self.assertEqual(len(r['failures']),2)

    def test_auto_backs_down_after_failures(self):
        def broken(*args): raise RuntimeError('rate-limited')
        self.engine.run(self.jobs,confirmed=True,fetch=broken,pace=False)
        self.assertEqual(self.engine.plan(self.jobs,'Auto')['selected_profile'],'Evidence')

    def test_auto_steps_up_only_after_high_novelty(self):
        self.jobs.write_text(json.dumps({'jobs':[
            {'provider':'openalex','query':f'query {i}','limit':1} for i in range(12)]}))
        self.engine.run(self.jobs, confirmed=True, fetch=self.fake, pace=False)
        self.assertEqual(self.engine.plan(self.jobs,'Auto')['selected_profile'],'Accelerated')

    def test_knowledge_results_are_marked_unverified(self):
        self.engine.run(self.jobs,confirmed=True,fetch=self.fake,pace=False)
        with KnowledgeHub(self.home)._connect() as con:
            evidence = {row[0] for row in con.execute('SELECT evidence FROM documents')}
        self.assertEqual(evidence,{'external-source-unverified'})


if __name__=='__main__': unittest.main()
