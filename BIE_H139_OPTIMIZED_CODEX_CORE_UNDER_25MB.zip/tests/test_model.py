import io
import json
import threading
import time
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from bie.config import PROFILES
from bie.model import Ollama, ModelUnavailable


class Response(io.BytesIO):
    def __enter__(self):
        return self
    def __exit__(self, *args):
        self.close()


class Opener:
    def __init__(self, chunks):
        self.body = b"".join(json.dumps(x).encode() + b"\n" for x in chunks)
        self.request = None
    def open(self, request, timeout):
        self.request = request
        return Response(self.body)


class TransportTests(unittest.TestCase):
    def run_reply(self, chunks):
        opener = Opener(chunks)
        pieces = []
        result = Ollama("qwen2.5:3b", opener).reply([{"role": "user", "content": "hello"}], [],
            PROFILES["Quick"], threading.Event(), pieces.append, time.monotonic() + 5)
        return result, opener, pieces

    def test_streamed_text_and_native_tool_arguments(self):
        result, opener, pieces = self.run_reply([
            {"message": {"content": "Checking "}, "done": False},
            {"message": {"content": "files", "tool_calls": [{"function": {"name": "project_list", "arguments": {"path": "."}}}]},
             "done": True, "eval_count": 7, "eval_duration": 1000000}])
        response, metrics = result
        self.assertEqual(response["content"], "Checking files")
        self.assertEqual(response["tool_calls"][0]["function"]["arguments"], {"path": "."})
        self.assertEqual(metrics["output_tokens"], 7)
        sent = json.loads(opener.request.data)
        self.assertEqual(sent["options"]["num_predict"], PROFILES["Quick"].output_tokens)
        self.assertTrue(sent["stream"])
        self.assertEqual(pieces, ["Checking ", "files"])

    def test_incomplete_stream_does_not_authorize_tools(self):
        with self.assertRaises(ModelUnavailable):
            self.run_reply([{"message": {"tool_calls": [{"function": {"name": "project_write", "arguments": {}}}]}, "done": False}])

    def test_output_limit_is_reported_instead_of_partial_success(self):
        with self.assertRaises(ModelUnavailable):
            self.run_reply([{"message": {"content": "unfinished"}, "done": True, "done_reason": "length"}])

    def test_invalid_model_names_are_rejected(self):
        for name in ("", "name; command", "$(secret)", "https://bad host"):
            with self.assertRaises(ValueError):
                Ollama(name)

    def test_actual_local_http_protocol(self):
        captured = []
        class Handler(BaseHTTPRequestHandler):
            def do_POST(self):
                captured.append((self.path, json.loads(self.rfile.read(int(self.headers["Content-Length"])))))
                self.send_response(200)
                self.send_header("Content-Type", "application/x-ndjson")
                self.end_headers()
                self.wfile.write(b'{"message":{"content":"fixture reply"},"done":true,"eval_count":2}\n')
            def log_message(self, *args):
                pass
        server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        try:
            client = Ollama("test-fixture")
            client.HOST = f"http://127.0.0.1:{server.server_port}"
            result, metrics = client.reply([{"role": "user", "content": "hello"}], [], PROFILES["Quick"],
                                            threading.Event(), lambda x: None, time.monotonic()+5)
            self.assertEqual(result["content"], "fixture reply")
            self.assertEqual(captured[0][0], "/api/chat")
            self.assertEqual(captured[0][1]["model"], "test-fixture")
        finally:
            server.shutdown()
            server.server_close()
            thread.join(timeout=2)
