"""BLOOM v32 independent calculation, provenance, and anti-discovery controls."""
import json
import math
from pathlib import Path
import tempfile
import unittest

from bie.exoplanets import ExoplanetLab
from bie.config import PACKAGE
from bie.planet_reconstruction import (_grid, reconstruct, load_evidence_file,
                                       export_reconstruction, SCENARIOS)


class ReconstructionTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.home = Path(self.tmp.name)
        self.lab = ExoplanetLab(self.home)
        self.lab.import_csv((PACKAGE / 'examples' / 'NASA_REFERENCE_EXAMPLES.csv').read_bytes(),
                            kind='reference_examples', source='Bundled NASA-referenced EXAMPLES, not live observations')

    def tearDown(self):
        self.tmp.cleanup()

    def run_recon(self, **kwargs):
        return reconstruct('Proxima Cen b', self.lab, draws=20, seed=77, **kwargs)

    def test_five_distinct_scenarios(self):
        r = self.run_recon()
        self.assertEqual({x['scenario'] for x in r['results']}, set(SCENARIOS))
        self.assertEqual(r['kind'], 'HYPOTHETICAL_CLIMATE_ENSEMBLE_NOT_SURFACE_OBSERVATION')
        self.assertIn('no actual mountains/oceans mapped', r['thoughtpacket']['no_claim'])
        self.assertEqual(r['catalog_provenance']['kind'], 'reference_examples')

    def test_grid_shapes_units_and_valid_ranges(self):
        for s in self.run_recon()['results']:
            grid = s['illustrative_grid']['surface_temperature_proxy_k']
            self.assertEqual(len(grid), 18)
            self.assertTrue(all(len(row) == 36 for row in grid))
            self.assertTrue(all(0 <= t < 1000 and math.isfinite(t) for row in grid for t in row))
            self.assertTrue(0 <= s['fraction_of_area_in_273_373_k_band']['median'] <= 1)

    def test_energy_conservation(self):
        for rotating in (True, False):
            r = _grid(.641, .31, .7, .42, tidally_locked=rotating)
            expected = 1361 * .641 * (1 - .31) / 4
            self.assertAlmostEqual(r['energy_check_w_m2'], expected, places=8)

    def test_known_fourth_root_scaling(self):
        one = _grid(.641, .3, 1, 1)
        two = _grid(1.282, .3, 1, 1)
        self.assertAlmostEqual(two['mean_surface_proxy_k']/one['mean_surface_proxy_k'], 2**.25, places=6)

    def test_rotation_changes_distribution_but_not_total_energy(self):
        a = _grid(.641, .3, .7, .1, tidally_locked=True)
        b = _grid(.641, .3, .7, .1, tidally_locked=False)
        self.assertNotAlmostEqual(a['min_surface_proxy_k'], b['min_surface_proxy_k'])
        self.assertAlmostEqual(a['energy_check_w_m2'], b['energy_check_w_m2'], places=8)

    def test_scenarios_have_different_medians(self):
        r = self.run_recon()
        meds = {s['scenario']: s['mean_surface_temperature_k']['median'] for s in r['results']}
        self.assertGreater(meds['dense_greenhouse'], meds['airless_rock'])
        self.assertLess(meds['ice_rich_assumed'], meds['dense_greenhouse'])

    def test_determinism(self):
        a = self.run_recon()
        b = self.run_recon()
        self.assertEqual(a['digest_sha256'], b['digest_sha256'])
        self.assertEqual(a['results'], b['results'])

    def test_seed_changes_ensembles(self):
        a = self.run_recon()['results'][0]['mean_surface_temperature_k']
        b = reconstruct('Proxima Cen b', self.lab, draws=20, seed=78)['results'][0]['mean_surface_temperature_k']
        self.assertNotEqual(a, b)

    def test_xray_converts_to_orbital_flux_not_surface(self):
        evidence = {'planet':'Proxima Cen b', 'source':'User provided hypothetical stellar luminosity TEST ONLY',
                    'xray':{'stellar_luminosity_erg_s':1e27}}
        a = self.run_recon(evidence=evidence)
        val = a['ancillary_evidence']['orbital_xray_flux_w_m2']
        expected = 1e20/(4*math.pi*(.04848*149597870700.)**2)
        self.assertAlmostEqual(val, expected, places=10)
        self.assertIn('NOT a surface radiation dose', a['ancillary_evidence']['xray_interpretation'])
        self.assertEqual(a['ancillary_evidence']['kind'], 'user_supplied_unverified')

    def test_spectrum_is_assertion_not_detection(self):
        evidence = {'planet':'Proxima Cen b', 'source':'Synthetic detector statement',
                    'spectrum':[{'species':'CO2','assessment':'detected'}]}
        a = self.run_recon(evidence=evidence)
        self.assertIn('User-supplied assertion only', a['ancillary_evidence']['spectrum_caveat'])
        self.assertEqual(a['ancillary_evidence']['spectrum'][0]['species'], 'CO2')
        self.assertEqual([s['mean_surface_temperature_k'] for s in a['results']],
                         [s['mean_surface_temperature_k'] for s in self.run_recon()['results']])
        self.assertTrue(a['results'][0]['evidence_consistency_cautions'])

    def test_no_hidden_assumptions_when_irradiance_missing(self):
        template = (PACKAGE / 'examples' / 'NASA_REFERENCE_EXAMPLES.csv').read_text()
        self.lab.import_csv(template.replace('1.145,,,,0.86,,37.423457', '1.145,,,,,,37.423457'), source='deliberately missing insolation test')
        with self.assertRaisesRegex(ValueError, 'insolation'):
            reconstruct('TOI-700 d', self.lab, draws=20)

    def test_unknown_planet_not_fabricated(self):
        with self.assertRaisesRegex(ValueError, 'absent'):
            reconstruct('Imaginary b', self.lab)

    def test_wrong_planet_evidence_refused(self):
        with self.assertRaisesRegex(ValueError, 'matching'):
            self.run_recon(evidence={'planet':'TRAPPIST-1 e','source':'test'})

    def test_uncalibrated_or_malformed_evidence_refused(self):
        with self.assertRaises(ValueError):
            self.run_recon(evidence={'planet':'Proxima Cen b','source':'hi','xray':{'stellar_luminosity_erg_s':float('inf')}})
        with self.assertRaises(ValueError):
            self.run_recon(evidence={'planet':'Proxima Cen b','source':'test validated','spectrum':[{'species':'CO2','assessment':'definitely life'}]})

    def test_no_nan_and_reject_extreme_inputs(self):
        for kwargs in [{'draws':9},{'seed':-1},{'rotation':'unknown'}, {'assumed_insolation_relative_error':float('nan')}]:
            with self.assertRaises(ValueError):
                reconstruct('Proxima Cen b', self.lab, **kwargs)

    def test_export_only_creates_new_file(self):
        r = self.run_recon()
        path = self.home / 'new.json'
        out = export_reconstruction(r, path)
        self.assertTrue(path.exists())
        self.assertEqual(json.loads(path.read_text())['digest_sha256'], r['digest_sha256'])
        self.assertEqual(len(out['sha256']), 64)
        with self.assertRaises(FileExistsError):
            export_reconstruction(r, path)

    def test_assistant_read_only_tool_exposed(self):
        from bie.tools import TOOLS
        spec = next(x for x in TOOLS if x.name == 'astro_reconstruct')
        self.assertFalse(spec.mutates)
        self.assertEqual(spec.required, ('name',))

    def test_cli_works_after_importing_catalog(self):
        import subprocess, sys, os
        cmd = [sys.executable, '-m', 'bie', '--home', str(self.home),
               'planet-reconstruct', 'Proxima Cen b', '--draws', '10', '--seed', '1']
        run = subprocess.run(cmd, text=True, capture_output=True, timeout=25,
                             env=dict(os.environ, PYTHONPATH=str(PACKAGE)))
        self.assertEqual(run.returncode, 0, run.stderr)
        data = json.loads(run.stdout)
        self.assertEqual(data['target'], 'Proxima Cen b')
        self.assertEqual(len(data['results']), 5)

    def test_file_limit_and_json_schema(self):
        p = self.home / 'observation.json'
        p.write_text(json.dumps({'planet':'Proxima Cen b','source':'Example input'}))
        self.assertEqual(load_evidence_file(p)['planet'], 'Proxima Cen b')
        p.write_text('x' * 101000)
        with self.assertRaisesRegex(ValueError,'100 kB'):
            load_evidence_file(p)


if __name__ == '__main__':
    unittest.main()
