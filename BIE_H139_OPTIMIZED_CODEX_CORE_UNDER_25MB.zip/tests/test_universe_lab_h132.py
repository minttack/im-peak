"""H132 independent feature and adversarial checks. Synthetic figures are NOT financial returns."""
import csv
from datetime import date, timedelta
import json
from pathlib import Path
import tempfile
import unittest
from dataclasses import replace

from bie.universe_lab_h132 import (TICKERS, WORLDS, BENCHMARKS, synthetic_world,
                                  analyze, battery, audit_csv, ask_experience_h132)
from bie.market_discovery_h129 import STRATEGIES


class H132ResearchTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.universe = synthetic_world(8111, 'rotation', size=185)
        cls.report = analyze(cls.universe)

    def test_ten_stocks(self):
        self.assertEqual(len(TICKERS), 10)
        self.assertEqual(set(TICKERS), {"MSFT", "AAPL", "NVDA", "AMZN", "GOOGL", "META", "JPM", "XOM", "WMT", "JNJ"})

    def test_benchmarks_not_stock_candidates(self):
        self.assertEqual(BENCHMARKS, ('SPY', 'QQQ'))
        self.assertEqual(set(self.universe), set(TICKERS + BENCHMARKS))
        self.assertNotIn(self.report['winner_chosen_without_holdout']['ticker'], BENCHMARKS)

    def test_all_worlds_supported(self):
        for world in WORLDS:
            sim = synthetic_world(8111, world, size=180)
            self.assertEqual(set(sim), set(TICKERS + BENCHMARKS))

    def test_seed_reproducible(self):
        a = synthetic_world(98, 'shock', size=180)
        b = synthetic_world(98, 'shock', size=180)
        self.assertEqual(a, b)
        self.assertNotEqual(a['MSFT'], synthetic_world(99, 'shock', size=180)['MSFT'])

    def test_calendar_strictly_increasing(self):
        for bars in self.universe.values():
            self.assertTrue(all(a.timestamp < b.timestamp for a, b in zip(bars, bars[1:])))

    def test_prices_finite_and_well_formed(self):
        for bars in self.universe.values():
            for b in bars:
                self.assertTrue(0 < b.low <= min(b.open, b.close) <= max(b.open, b.close) <= b.high)

    def test_freezes_one_of_predeclared_rules(self):
        self.assertIn(self.report['winner_chosen_without_holdout']['strategy'], STRATEGIES)
        self.assertIn(self.report['winner_chosen_without_holdout']['ticker'], TICKERS)
        self.assertIn(self.report['holdout_selected']['total_return'], [self.report['holdout_selected']['total_return']])

    def test_110_experiments_each_world(self):
        self.assertEqual(self.report['development_experiments'], 110)
        self.assertEqual(self.report['self_questions'], 111)

    def test_not_a_live_buy_signal(self):
        self.assertTrue(self.report['no_live_orders'])
        self.assertIn('RESEARCH_ONLY', self.report['promotion_status'])
        self.assertEqual(self.report['data_coverage']['status'], 'synthetic_only_no_data_quality_claim')

    def test_has_all_three_baseline_checks(self):
        self.assertEqual(set(self.report['holdout_beat_baselines']),
                         {'own_stock_buy_hold', 'SPY_buy_hold', 'QQQ_buy_hold'})

    def test_missing_one_stock_rejected(self):
        without = dict(self.universe)
        without.pop('WMT')
        with self.assertRaises(ValueError): analyze(without)

    def test_shifted_benchmark_calendar_rejected(self):
        altered = dict(self.universe)
        altered['SPY'] = [replace(b, timestamp=b.timestamp+timedelta(days=1)) for b in altered['SPY']]
        with self.assertRaises(ValueError): analyze(altered)

    def test_duplicate_prices_rejected(self):
        altered = dict(self.universe)
        altered['AAPL'] = list(altered['AAPL'])
        altered['AAPL'][12] = replace(altered['AAPL'][12], timestamp=altered['AAPL'][11].timestamp)
        with self.assertRaises(ValueError): analyze(altered)

    def test_future_prices_blocked_by_as_of(self):
        with self.assertRaises(ValueError): analyze(self.universe, as_of=date(2024, 5, 1))

    def test_invalid_cost_rejected(self):
        for c in (-1, 1001, float('nan')):
            with self.assertRaises(ValueError): analyze(self.universe, cost_bps=c)

    def test_invalid_world_and_seed_rejected(self):
        for world in ('market', 'best'):
            with self.assertRaises(ValueError): synthetic_world(1, world)
        with self.assertRaises(ValueError): synthetic_world(-1, 'noise')

    def test_future_holdout_change_does_not_change_selection(self):
        altered = {t:list(b) for t,b in self.universe.items()}
        for ticker in TICKERS:
            for i in range(155, 185):
                b = altered[ticker][i]
                altered[ticker][i] = replace(b, open=b.open*1.5, high=b.high*1.5,
                                             low=b.low*1.5, close=b.close*1.5)
        result = analyze(altered)
        self.assertEqual(result['winner_chosen_without_holdout'], self.report['winner_chosen_without_holdout'])
        self.assertNotEqual(result['data_fingerprint_sha256'], self.report['data_fingerprint_sha256'])

    def test_benchmarks_read_only(self):
        self.assertEqual(self.report['holdout_SPY']['status'], 'computed')
        self.assertEqual(self.report['holdout_QQQ']['status'], 'computed')

    def test_missing_benchmark_is_unavailable(self):
        altered = dict(self.universe)
        del altered['QQQ']
        report = analyze(altered)
        self.assertEqual(report['holdout_QQQ']['status'], 'missing_benchmark')
        self.assertNotIn('QQQ_buy_hold', report['holdout_beat_baselines'])

    def test_real_data_never_assumed_when_no_coverage(self):
        report = analyze(self.universe, source='user_supplied_csv:test.csv')
        self.assertEqual(report['data_coverage']['status'], 'unverified_stock_data_coverage')
        self.assertIn('unverified', report['source_claim'])

    def test_synthetic_battery_counts(self):
        r = battery(seeds=(21,), worlds=('noise', 'downtrend'), size=180)
        self.assertEqual(r['scenario_count'], 2)
        self.assertEqual(len(r['records']), 2)
        for key in ('positive_net_returns','beat_spy','beat_all_three'):
            self.assertTrue(0 <= r[key] <= 2)
        self.assertIn('SYNTHETIC', r['mode'])

    def test_battery_boundary(self):
        with self.assertRaises(ValueError): battery(seeds=(), worlds=('noise',))
        with self.assertRaises(ValueError): battery(seeds=(1,), worlds=())

    def test_regime_names_immutable(self):
        self.assertEqual(WORLDS, ('trend', 'downtrend', 'noise', 'rotation', 'shock'))

    def test_proposes_falsifiable_next_experiment(self):
        p = self.report['latest_next_experiment']
        self.assertTrue(p['question'])
        self.assertTrue(p['falsifier'])
        self.assertTrue(p['next_test'])

    def test_data_digest_has_sha256_length(self):
        self.assertEqual(len(self.report['data_fingerprint_sha256']), 64)

    def test_csv_round_trip_and_asof_reject(self):
        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / 'input.csv'
            with path.open('w', newline='') as f:
                writer = csv.writer(f)
                writer.writerow(['date','ticker','open','high','low','close','volume'])
                # Every bar in a ticker must be consecutive/ordered.
                for ticker, bars in self.universe.items():
                    for b in bars:
                        writer.writerow([b.timestamp, b.ticker, b.open, b.high, b.low, b.close, b.volume])
            out = audit_csv(path, as_of=date(2026, 10, 17))
            self.assertEqual(out['winner_chosen_without_holdout'], self.report['winner_chosen_without_holdout'])
            with self.assertRaises(ValueError): audit_csv(path, as_of=date(2024, 1, 1))

    def test_local_model_failure_is_recorded_not_invented(self):
        # Existing tests also check the actual local service; this tests return shape.
        from unittest.mock import patch
        from bie.model import ModelUnavailable
        with patch('bie.model.Ollama') as mk:
            mk.return_value.reply.side_effect = ModelUnavailable('not running')
            result = ask_experience_h132(self.report)
            self.assertEqual(result['status'], 'local_model_unavailable')
            self.assertNotIn('proposal_unverified', result)


if __name__ == '__main__': unittest.main()
