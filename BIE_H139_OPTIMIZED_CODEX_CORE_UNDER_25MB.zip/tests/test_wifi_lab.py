import json
from pathlib import Path
import sqlite3
import tempfile
import unittest
from unittest.mock import patch

from bie.wifi_lab import WifiLab, parse_networks, parse_interfaces, parse_drivers, capture_windows, forward_predictor_test

CONNECTION = '''There is 1 interface on the system:
    Name                   : Wi-Fi
    Description            : Example Wireless Adapter
    State                  : connected
    SSID                   : HOME-PRIVATE-SSID
    BSSID                  : 6c:00:00:aa:ff:01
    Network type           : Infrastructure
    Radio type             : 802.11ax
    Authentication         : WPA3-Personal
    Band                   : 6 GHz
    Channel                : 37
    Receive rate (Mbps)    : 1200
    Transmit rate (Mbps)   : 900
    Signal                 : 65%
'''
NEARBY = '''Interface name : Wi-Fi
There are 2 networks currently visible.
SSID 1 : HOME-PRIVATE-SSID
    Network type            : Infrastructure
    Authentication          : WPA3-Personal
    BSSID 1                 : 6c:00:00:aa:ff:01
         Signal             : 65%
         Radio type         : 802.11ax
         Band               : 6 GHz
         Channel            : 37
SSID 2 : BE-HYPOTHESIS
    Network type            : Infrastructure
    Authentication          : WPA2-Personal
    BSSID 1                 : 60:00:00:bb:ff:08
         Signal             : 82%
         Radio type         : 802.11be
         Band               : 5 GHz
         Channel            : 36
    BSSID 2                 : 60:00:00:bb:ff:09
         Signal             : 57%
         Radio type         : 802.11be
         Band               : 5 GHz
         Channel            : 149
'''
DRIVERS = '''Interface name: Wi-Fi
   Description: Example wireless card
   Radio types supported : 802.11b 802.11g 802.11n 802.11ac 802.11ax
'''


def demo(signal=65):
    connection = parse_interfaces(CONNECTION.replace('65%', f'{signal}%'))
    return {'ok': True, 'status': 'observed', 'captured_at':'2026-10-15T00:00:00+00:00',
            'connection': connection, 'access_points': parse_networks(NEARBY),
            'adapter': parse_drivers(DRIVERS), 'warnings': []}


class NetshTests(unittest.TestCase):
    def test_protocols_and_6e_not_confused_with_7(self):
        connection = parse_interfaces(CONNECTION)
        self.assertEqual(connection['standard'], 'Wi-Fi 6E')
        self.assertEqual(connection['signal_pct'], 65)
        self.assertNotIn('bssid', connection)
        aps = parse_networks(NEARBY)
        self.assertEqual(len(aps), 3)
        self.assertEqual(aps[0]['standard'], 'Wi-Fi 6E')
        self.assertEqual(aps[1]['standard'], 'Wi-Fi 7')
        self.assertEqual(aps[2]['signal_pct'], 57)

    def test_no_false_band_or_technology(self):
        aps = parse_networks('SSID 1 : unknown\nBSSID 1 : 11:22:33:44:55:66\n Signal : 92%\n')
        self.assertEqual(aps[0]['standard'], 'unknown')
        self.assertEqual(aps[0]['band'], '')
        self.assertEqual(parse_interfaces('State : disconnected')['signal_pct'], None)
        self.assertNotEqual(parse_interfaces('Radio type : 802.11ax')['standard'], 'Wi-Fi 6E')

    def test_read_only_and_no_password_cmd(self):
        calls = []
        outputs = [CONNECTION, NEARBY, DRIVERS]
        def fake_runner(cmd, **kwargs):
            calls.append((cmd, kwargs))
            class Result:
                returncode = 0
                stderr = ''
            r=Result()
            r.stdout=outputs[len(calls)-1]
            return r
        data=capture_windows(runner=fake_runner, platform_name='win32')
        self.assertTrue(data['ok'])
        self.assertEqual(len(calls),3)
        self.assertTrue(all(c[0][:3]==['netsh','wlan','show'] for c in calls))
        self.assertTrue(all(c[1]['shell'] is False for c in calls))
        self.assertTrue(all('key=clear' not in str(c) for c in calls))
        self.assertEqual(data['adapter']['best_standard'], 'Wi-Fi 6')

    def test_os_location_blocked_not_reported_as_no_wifi(self):
        def denied(cmd, **kwargs):
            class R:
                returncode=1
                stdout='Access is denied. Enable Location.'
                stderr=''
            return R()
        data=capture_windows(runner=denied, platform_name='win32')
        self.assertFalse(data['ok'])
        self.assertTrue(any('permission' in w.lower() for w in data['warnings']))
        self.assertEqual(data['access_points'], [])

    def test_other_platform_is_explicitly_unsupported(self):
        data=capture_windows(platform_name='linux')
        self.assertFalse(data['ok'])
        self.assertEqual(data['status'], 'unsupported')


class WiggleEvidenceTests(unittest.TestCase):
    def test_no_premature_claims(self):
        self.assertEqual(forward_predictor_test([20,30,40])['status'], 'insufficient_evidence')
        stable=forward_predictor_test([50]*12)
        self.assertTrue(stable['baseline_wins_or_ties'])
        self.assertIsNone(stable['relative_improvement_pct'])
        trend=forward_predictor_test([10,19,28,37,46,55,64,73,82,90,96])
        self.assertEqual(trend['status'], 'holdout_measured_no_promotion')
        self.assertIn('candidate_only',trend['decision'])

    def test_adversarial_pattern_defeats_wiggle_predictor(self):
        oscillating = forward_predictor_test([50, 90] * 8)
        self.assertTrue(oscillating['baseline_wins_or_ties'])
        self.assertLess(oscillating['relative_improvement_pct'], 0)
        self.assertIn('no_promotion', oscillating['status'])

    def test_private_ssid_never_written_to_database(self):
        with tempfile.TemporaryDirectory() as temp:
            lab=WifiLab(Path(temp))
            for pct in (65,55,82):
                result=lab.snapshot(demo(pct))
                self.assertTrue(result['saved'])
            evidence=lab.analyze()
            self.assertEqual(evidence['snapshots'],3)
            self.assertEqual(evidence['current_observations']['highest_advertised_generation'],7)
            self.assertEqual(evidence['current_observations']['adapter_reported_generation'],6)
            self.assertIn('hardware or driver update', evidence['hypotheses'][0]['then'])
            self.assertEqual(evidence['predictor']['status'],'insufficient_evidence')
            dbbytes=(Path(temp)/'wifi_wiggle.sqlite3').read_bytes()
            for secret in (b'HOME-PRIVATE-SSID', b'BE-HYPOTHESIS', b'6c:00:00:aa:ff:01'):
                self.assertNotIn(secret,dbbytes)
            self.assertNotIn('BE-HYPOTHESIS',json.dumps(evidence))

    def test_does_not_create_snapshot_on_unsupported_os(self):
        with tempfile.TemporaryDirectory() as temp:
            lab=WifiLab(temp)
            with patch('bie.wifi_lab.capture_windows',return_value={'ok':False,'status':'unsupported','warnings':['Windows only']}):
                self.assertFalse(lab.snapshot()['saved'])
            self.assertEqual(lab.analyze()['status'],'no_measurements')

    def test_9_snapshots_baseline_comparison_is_explicit(self):
        with tempfile.TemporaryDirectory() as temp:
            lab=WifiLab(temp)
            for pct in (31,39,55,37,44,58,75,62,52,45):
                lab.snapshot(demo(pct))
            result=lab.analyze()
            self.assertEqual(result['predictor']['status'],'holdout_measured_no_promotion')
            self.assertEqual(result['predictor']['samples'],10)
            self.assertEqual(result['status'],'hypotheses_not_proof')


if __name__ == '__main__':
    unittest.main()
