"""Adversarial independent checks for H133; no financial claims or order execution."""
import copy
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from bie.teacher_bloom_h133 import (
    starter_lesson, validate_lesson, load_lesson, study,
    _candidate_policies, _synthetic_challenges, _score, _predict,
    ask_local_experience, save_json_new, FEATURES,
)


class TeacherBloomH133Tests(unittest.TestCase):
    def setUp(self):
        self.lesson = starter_lesson()

    def test_starter_lesson_is_bounded_and_trading_off(self):
        validate_lesson(self.lesson)
        self.assertFalse(self.lesson['live_trading_allowed'])

    def test_rejects_invented_or_wrong_schema(self):
        x = copy.deepcopy(self.lesson); x['schema'] = 'unsafe'
        with self.assertRaises(ValueError): validate_lesson(x)

    def test_may_not_enable_trading(self):
        x = copy.deepcopy(self.lesson); x['live_trading_allowed'] = True
        with self.assertRaises(ValueError): validate_lesson(x)

    def test_must_retain_evidence_guards(self):
        x = copy.deepcopy(self.lesson); x['teacher_required_features'].remove(FEATURES[0])
        with self.assertRaises(ValueError): validate_lesson(x)

    def test_unbounded_candidate_space_rejected(self):
        x = copy.deepcopy(self.lesson); x['teacher_candidate_min_samples'] = list(range(100))
        with self.assertRaises(ValueError): validate_lesson(x)

    def test_missing_packet_rejected(self):
        with self.assertRaises(ValueError): load_lesson(Path('/nonexistent/h133.json'))

    def test_unique_create_no_silent_overwrite(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / 'lesson.json'
            save_json_new(p, self.lesson)
            self.assertEqual(load_lesson(p), self.lesson)
            with self.assertRaises(FileExistsError): save_json_new(p, self.lesson)

    def test_candidate_selection_evidence_guards(self):
        self.assertTrue(all(p['required_features'] == list(FEATURES) for p in _candidate_policies(self.lesson)))

    def test_policy_rejects_missing_provenance(self):
        p = {'required_features': list(FEATURES), 'min_samples': 30, 'min_excess': .01}
        case = {'features': {k: True for k in FEATURES}, 'samples': 200, 'net_excess': .30}
        self.assertTrue(_predict(p, case))
        case['features'][FEATURES[0]] = False
        self.assertFalse(_predict(p, case))

    def test_train_holdout_fingerprints_distinct(self):
        r = study(self.lesson)
        self.assertNotEqual(r['partition_fingerprints']['dev'], r['partition_fingerprints']['holdout'])
        self.assertIn('chosen_policy_frozen_sha256', r)

    def test_holdout_seed_does_not_change_selected_policy(self):
        a = study(self.lesson, holdout_seed=7033)
        b = study(self.lesson, holdout_seed=7034)
        self.assertEqual(a['chosen_policy_frozen_sha256'], b['chosen_policy_frozen_sha256'])
        self.assertNotEqual(a['partition_fingerprints']['holdout'], b['partition_fingerprints']['holdout'])

    def test_false_positive_stress_is_observable(self):
        r = study(self.lesson)
        self.assertGreater(r['holdout_selected']['false_accept'], 0)
        self.assertGreater(r['holdout_naive_baseline']['false_accept'], r['holdout_selected']['false_accept'])
        self.assertFalse(r['real_market_proof'])
        self.assertFalse(r['local_language_model_trained'])

    def test_toy_world_indeed_has_two_classes(self):
        cases = _synthetic_challenges(93144, 400, 'dev')
        self.assertTrue(any(c['label'] for c in cases))
        self.assertTrue(any(not c['label'] for c in cases))

    def test_distinct_seed_and_small_sample_refused(self):
        with self.assertRaises(ValueError): study(self.lesson, dev_seed=5, holdout_seed=5)
        with self.assertRaises(ValueError): study(self.lesson, development_size=1)

    def test_failed_model_connection_labeled_truthfully(self):
        # Avoid any live request here: observe that exceptions are treated as missing, not BIE answers.
        from unittest.mock import patch
        from bie.model import ModelUnavailable
        with patch('bie.model.Ollama', side_effect=ModelUnavailable('deliberate unavailable')):
            response = ask_local_experience({'test': 'synthetic'})
        self.assertEqual(response['status'], 'local_model_unavailable')
        self.assertTrue(response['no_model_answer_fabricated'])
        self.assertNotIn('response', response)

    def test_cli_fails_safe_on_bad_lesson(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d)/'malicious.json'; p.write_text('{}')
            root = Path(__file__).resolve().parents[1]
            run = subprocess.run([sys.executable, '-m', 'bie', 'teacher-h133-study', '--lesson', str(p)],
                                 cwd=root, capture_output=True, text=True, timeout=20)
            self.assertNotEqual(run.returncode, 0)


if __name__ == '__main__':
    unittest.main()
