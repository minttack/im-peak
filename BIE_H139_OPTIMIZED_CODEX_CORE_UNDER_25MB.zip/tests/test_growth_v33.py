from __future__ import annotations

import json
from pathlib import Path
import sqlite3
import tempfile
import threading
import unittest

from bie.growth import GrowthLedger, read_packet


def packet(context="stationary", strategy="two_speed", chance=0.8, base=0.5):
    return {"domain": "BIE decisions", "context": context, "strategy": strategy,
            "prediction": "This prospective binary outcome will be positive", "probability": chance,
            "baseline_probability": base, "source": "manual precommit from tester",
            "goal": "Evaluate measurable advantage against the original baseline",
            "verifier_plan": "Collect a binary result after this precommit and compare paired Brier scores",
            "uncertainty": "Synthetic test, not external proof", "anchor": "Never transfer across contexts"}


class GrowthLedgerTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.ledger = GrowthLedger(Path(self.temp.name))

    def test_empty_is_auditable(self):
        self.assertTrue(self.ledger.audit()["passed"])
        self.assertEqual(self.ledger.status()["resolved"], 0)

    def test_precommit_and_resolve(self):
        first = self.ledger.predict(packet())
        self.assertEqual(self.ledger.status()["open"], 1)
        self.ledger.resolve(first["id"], 1, "independent observer label")
        self.assertEqual(self.ledger.status()["resolved"], 1)
        self.assertTrue(self.ledger.audit()["passed"])
        with self.assertRaises(ValueError):
            self.ledger.resolve(first["id"], 0, "cannot edit")

    def test_invalidates_without_erasure(self):
        first = self.ledger.predict(packet())
        self.ledger.resolve(first["id"], 0, "reported")
        self.ledger.invalidate(first["id"], "Contradicted by a better control")
        r = self.ledger.review("BIE decisions", "stationary", "two_speed")
        self.assertEqual(r["matched_resolved_cases"], 0)
        self.assertEqual(self.ledger.status()["invalidated"], 1)
        self.assertEqual(self.ledger.audit()["events"], 3)

    def test_block_invalid_proof_claims(self):
        for changes in ({"probability": 2}, {"probability": float("nan")}, {"source": ""},
                        {"prediction": ""}, {"baseline_probability": -0.2}, {"goal": None}):
            p = packet(); p.update(changes)
            with self.assertRaises(ValueError):
                self.ledger.predict(p)
        self.assertEqual(self.ledger.status()["predictions"], 0)

    def test_missing_prediction_outcome_is_rejected(self):
        with self.assertRaises(ValueError):
            self.ledger.resolve("notreal", 1, "user")
        with self.assertRaises(ValueError):
            self.ledger.invalidate("notreal", "error")
        self.assertEqual(self.ledger.audit()["events"], 0)

    def test_evidence_file_hash_not_external_validation(self):
        evidence = Path(self.temp.name) / "measured.txt"
        evidence.write_text("synthetic result: true")
        ident = self.ledger.predict(packet())["id"]
        self.ledger.resolve(ident, 1, "user", evidence)
        case = self.ledger.cases()[0]
        self.assertEqual(case["resolution"]["evidence"]["bytes"], len(evidence.read_bytes()))
        self.assertEqual(case["resolution"]["verification"], "user_reported_even_if_file_hash_present")

    def test_detect_changed_record(self):
        ident = self.ledger.predict(packet())["id"]
        self.ledger.resolve(ident, 1, "user")
        with sqlite3.connect(self.ledger.database) as db:
            db.execute("UPDATE growth_events SET payload=? WHERE seq=1", ('{"chance":0.01}',))
        self.assertFalse(self.ledger.audit()["passed"])
        with self.assertRaises(ValueError):
            self.ledger.predict(packet())

    def test_negative_transfer_separated_by_context(self):
        self._fill("familiar", 1, .85, 0.5, 60)
        self._fill("changed", 1, .1, .5, 60)
        good = self.ledger.review("BIE decisions", "familiar", "two_speed")
        bad = self.ledger.review("BIE decisions", "changed", "two_speed")
        self.assertEqual(good["gate"], "candidate_for_external_replication")
        self.assertEqual(bad["gate"], "insufficient_or_contradictory")
        self.assertFalse(good["promoted"])

    def _fill(self, context, outcome, candidate, baseline, n):
        for i in range(n):
            ident = self.ledger.predict(packet(context=context, chance=candidate, base=baseline))["id"]
            self.ledger.resolve(ident, outcome, f"test source {i%2}")

    def test_no_premature_promotion(self):
        self._fill("familiar", 1, .85, .5, 3)
        report = self.ledger.review("BIE decisions", "familiar", "two_speed")
        self.assertEqual(report["gate"], "insufficient_or_contradictory")
        self.assertFalse(report["promoted"])

    def test_matching_only_untrusted_candidates(self):
        self._fill("familiar", 1, .85, .5, 40)
        self.assertEqual(self.ledger.context_for_goal("Write a novel"), [])
        x = self.ledger.context_for_goal("Improve BIE decisions this week")
        self.assertTrue(x)
        self.assertTrue(x[0]["reference_only"])

    def test_concurrent_journal_append(self):
        errors = []
        def job():
            try:
                self.ledger.predict(packet())
            except Exception as e:
                errors.append(e)
        threads = [threading.Thread(target=job) for _ in range(12)]
        for t in threads: t.start()
        for t in threads: t.join()
        self.assertFalse(errors, errors)
        self.assertEqual(self.ledger.status()["predictions"], 12)
        self.assertTrue(self.ledger.audit()["passed"])

    def test_oversize_source_rejected(self):
        big = Path(self.temp.name) / 'big.json'
        big.write_bytes(b' ' * 16400)
        with self.assertRaises(ValueError):
            read_packet(big)
        with self.assertRaises(ValueError):
            self.ledger.resolve('123', 1, 'user', big)


if __name__ == "__main__":
    unittest.main()
