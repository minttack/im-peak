import unittest
from bie.bloom_geometry_h114n1 import compare_layouts,run_holdout,_check,_params

class GeometryNextTests(unittest.TestCase):
    def test_integrity(self):
        res=compare_layouts(480,128,8,32,5)
        self.assertTrue(res['integrity_pass'])
        self.assertTrue(all(res['integrity_by_layout'].values()))
    def test_edge(self):
        self.assertTrue(compare_layouts(240,64,16,0,0)['integrity_pass'])
    def test_reject_illegal_oversize(self):
        with self.assertRaises(ValueError): compare_layouts(480,60,8,40,3)
    def test_bad_nonfinite(self):
        with self.assertRaises(ValueError): compare_layouts(480,128,8,float('nan'),5)
    def test_detect_collision(self):
        self.assertFalse(_check([(9,9),(9,9)],480,128,8))
    def test_hex_grid_vs_row(self):
        res=compare_layouts(480,128,8,32,5)
        self.assertGreater(res['counts']['hex'],res['counts']['straight'])
    def test_reproducible_seed(self):
        a=run_holdout();b=run_holdout()
        for key in ('num_trials','median_wiggle_vs_hex_ratio','wiggle_beats_hex_by_over_5_percent'):
            self.assertEqual(a['summary'][key],b['summary'][key])
    def test_nonpromotion(self):
        self.assertEqual(run_holdout()['promotion_decision'],'HOLD')

if __name__=='__main__': unittest.main()
