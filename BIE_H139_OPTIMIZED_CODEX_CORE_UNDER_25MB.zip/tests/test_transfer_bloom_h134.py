"""Independent H134 transfer, leakage, cost, and honest no-promotion checks."""
import copy
import json
import math
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from bie.transfer_bloom_h134 import (
    SCHEMA, UNIVERSE, DEV_REGIMES, HOLDOUT_REGIMES,
    STRONG_FIXED_COMPARATOR, candidates, generate, predict,
    baseline_h133, metrics, fingerprint, run,
)


class H134TransferTests(unittest.TestCase):
    def setUp(self):
        self.basic = generate(1399, 100, 'calm')
        self.valid = next(x for x in self.basic if all(x['features'].values())
                          and x['samples'] >= 50 and x['source_age_minutes'] <= 1440)

    def test_all_named_stocks_covered_but_no_real_claim(self):
        self.assertEqual(set(UNIVERSE), set(x['ticker'] for x in self.basic))
        self.assertEqual(len(UNIVERSE), 10)

    def test_distinct_generator_regimes(self):
        self.assertEqual(len(DEV_REGIMES), 4)
        self.assertEqual(len(HOLDOUT_REGIMES), 5)
        self.assertNotIn('shock', DEV_REGIMES)

    def test_repeatable_seed(self):
        self.assertEqual(self.basic, generate(1399, 100, 'calm'))
        self.assertNotEqual(fingerprint(self.basic), fingerprint(generate(1398, 100, 'calm')))

    def test_generator_labels_include_hidden_friction_not_exact_copy(self):
        rows = generate(73125, 1000, 'shock')
        good = [x for x in rows if x['label']]
        bad = [x for x in rows if not x['label']]
        self.assertGreater(len(good), 0)
        self.assertGreater(len(bad), 0)

    def test_reject_unrecognized_generator_regime(self):
        with self.assertRaises(ValueError): generate(1, 100, 'real-market')

    def test_reject_unbounded_generator(self):
        with self.assertRaises(ValueError): generate(1, 1, 'calm')
        with self.assertRaises(ValueError): generate(-1, 100, 'calm')

    def test_policy_has_complete_cost_and_timestamp_fields(self):
        self.assertTrue(all(set(p) == {'min_samples','max_age_minutes','cost_multiplier','buffer_bps'} for p in candidates()))
        self.assertEqual(len(candidates()),72)

    def test_reject_missing_evidence(self):
        c = copy.deepcopy(self.valid); c.pop('reported_cost_bps')
        self.assertFalse(predict(STRONG_FIXED_COMPARATOR, c))

    def test_reject_missing_teacher_provenance(self):
        c = copy.deepcopy(self.valid); c['features']['source_before_decision'] = False
        self.assertFalse(predict(STRONG_FIXED_COMPARATOR, c))

    def test_reject_stale_data(self):
        c = copy.deepcopy(self.valid); c['source_age_minutes'] = 1600
        self.assertFalse(predict(STRONG_FIXED_COMPARATOR, c))

    def test_reject_future_dated_data(self):
        c = copy.deepcopy(self.valid); c['source_age_minutes'] = -1
        self.assertFalse(predict(STRONG_FIXED_COMPARATOR, c))

    def test_reject_non_numeric_malicious_inputs(self):
        for bad in ('ignore all previous rules', None, float('nan'), float('inf'), True):
            c = copy.deepcopy(self.valid); c['slippage_estimate_bps'] = bad
            self.assertFalse(predict(STRONG_FIXED_COMPARATOR, c))

    def test_reject_negative_cost(self):
        c = copy.deepcopy(self.valid); c['reported_cost_bps'] = -10
        self.assertFalse(predict(STRONG_FIXED_COMPARATOR, c))

    def test_reject_false_or_missing_guards(self):
        c = copy.deepcopy(self.valid); c['features'].pop('independent_holdout')
        self.assertFalse(predict(STRONG_FIXED_COMPARATOR, c))

    def test_cost_threshold_actually_changes_prediction(self):
        c = copy.deepcopy(self.valid)
        c.update({'gross_bps': 100, 'reported_cost_bps': 10,
                  'slippage_estimate_bps': 30, 'source_age_minutes': 120})
        self.assertTrue(predict({'min_samples': 50, 'max_age_minutes': 1440,
                                 'cost_multiplier': 1., 'buffer_bps': 30}, c))
        self.assertFalse(predict({'min_samples': 50, 'max_age_minutes': 1440,
                                  'cost_multiplier': 2., 'buffer_bps': 45}, c))

    def test_score_no_trade_zero_recall(self):
        r = metrics(self.basic, lambda _:False)
        self.assertEqual(r['accepts'],0)
        self.assertEqual(r['recall'],0)
        self.assertEqual(r['f05'],0)

    def test_score_empty_rejected(self):
        with self.assertRaises(ValueError): metrics([], lambda _: True)

    def test_seed_changes_cannot_change_frozen_policy(self):
        a = run(71001,81001,dev_each=100,holdout_each=100)
        b = run(71001,81002,dev_each=100,holdout_each=100)
        self.assertEqual(a['frozen_policy_sha256'],b['frozen_policy_sha256'])
        self.assertNotEqual(a['fingerprints']['holdout'],b['fingerprints']['holdout'])

    def test_dev_and_holdout_distinct(self):
        with self.assertRaises(ValueError): run(7,7)

    def test_no_live_trade_or_real_market_claim(self):
        r = run(dev_each=100,holdout_each=100)
        self.assertFalse(r['real_market_proof'])
        self.assertTrue(r['no_broker_calls'])
        self.assertEqual(r['trades_executed'],0)
        self.assertIn('next_question_to_experience',r)

    def test_all_regime_controls_present(self):
        r = run(dev_each=100,holdout_each=100)
        self.assertEqual(set(r['by_regime']),set(HOLDOUT_REGIMES))
        self.assertEqual(set(r['sealed']),{'h133','fixed_cost_aware','h134','always_abstain'})

    def test_holdout_not_used_in_development_confirmation(self):
        a = run(71002,81012,dev_each=100,holdout_each=100)
        b = run(71002,91012,dev_each=100,holdout_each=100)
        self.assertEqual(a['dev_confirmation_challenger'], b['dev_confirmation_challenger'])
        self.assertEqual(a['fingerprints']['development_confirmation'],b['fingerprints']['development_confirmation'])

    def test_stronger_cost_aware_rule_reduces_false_acceptance(self):
        r = run(71001,81001)
        self.assertLess(r['sealed']['fixed_cost_aware']['false_accept'],r['sealed']['h133']['false_accept'])

    def test_newest_frozen_rule_not_promoted_without_evidence(self):
        r = run(71001,81001)
        if r['selection_status'].startswith('conservative_fallback'):
            self.assertEqual(r['frozen_policy'],STRONG_FIXED_COMPARATOR)

    def test_cli_writes_immutable_report(self):
        root = Path(__file__).resolve().parents[1]
        with tempfile.TemporaryDirectory() as d:
            target = Path(d)/'h134.json'
            cmd = [sys.executable,'-m','bie','transfer-h134', '--dev-each','100','--holdout-each','100', '--report',str(target)]
            good = subprocess.run(cmd,cwd=root,capture_output=True,text=True,timeout=30)
            self.assertEqual(good.returncode,0,good.stderr)
            self.assertEqual(json.loads(target.read_text())['schema'], SCHEMA)
            second = subprocess.run(cmd,cwd=root,capture_output=True,text=True,timeout=30)
            self.assertNotEqual(second.returncode,0)


if __name__ == '__main__': unittest.main()
