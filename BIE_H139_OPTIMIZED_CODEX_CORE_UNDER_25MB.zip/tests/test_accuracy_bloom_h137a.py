"""Independent tests for H137A symbol-concept vs market-data causal attribution."""
from datetime import datetime, timedelta
import copy
import unittest
from bie import accuracy_bloom_h137a as a
from bie import familiarity_money_h136 as h

class AccuracyBloomH137ATests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.base=h.synthetic(seed=23701,world='familiarity_trap',days=94)
        cls.result=a.analyze(cls.base)

    def test_schema_and_symbol_claim(self):
        self.assertEqual(self.result['schema'],a.SCHEMA)
        self.assertEqual(self.result['percentage_new_glyph_derived_market_decisions'],0)
        self.assertFalse(self.result['original_accuracy_glyph_bytes_available_in_this_branch'])
        self.assertIn('NOT RUN',self.result['authentic_glyph_visual_ablation'])

    def test_no_broker_orders(self):
        self.assertEqual(self.result['broker_orders_executed'],0)
        self.assertTrue(self.result['not_evidence_of_live_market_edge'])
        for v in self.result['comparison'].values():
            self.assertTrue(v['never_live_orders'])

    def test_initial_weight_untrained(self):
        self.assertEqual(a.accuracy_weight([]),1)
        self.assertEqual(a.accuracy_weight([-.2]*5),1)

    def test_feedback_correct_direction(self):
        self.assertEqual(a.accuracy_weight([-.1]*6),0)
        self.assertEqual(a.accuracy_weight([.03]*6),1)

    def test_future_outcomes_do_not_modify_past_decisions(self):
        changed=copy.deepcopy(self.base)
        _,dates,rows=h.validate(changed)
        cut=dates[-6].isoformat()
        for r in changed['rows']:
            if r['decision_at_utc']>=cut:
                r['close']*=1.3 if r['ticker'] in h.STOCKS else 1.
        one=a.analyze(self.base)['decision_log']
        two=a.analyze(changed)['decision_log']
        for x,y in zip(one,two):
            if x['day']<cut:
                self.assertEqual(x['weight_before_label'],y['weight_before_label'])
                self.assertEqual(x['tickers'],y['tickers'])

    def test_attribution_counts_not_total_knowledge(self):
        t=self.result['accuracy_concept_intervention']
        self.assertGreater(t['decision_days'],0)
        self.assertTrue(0<=t['decisions_changed_pct']<=100)
        self.assertTrue(0<=t['feedback_weight_reduced_pct']<=100)
        self.assertIn('NOT the creator glyph',t['source'])

    def test_order_invariance(self):
        changed=copy.deepcopy(self.base)
        changed['rows'].reverse()
        self.assertEqual(self.result['comparison'],a.analyze(changed)['comparison'])

    def test_returns_reconcile_baseline(self):
        b=self.result['comparison']['baseline']
        self.assertAlmostEqual(b['net_pnl_dollars'],b['net_return_pct']*10000/100,delta=.02)

    def test_paper_trades_are_bounded(self):
        self.assertTrue(all(len(x['tickers'])<=3 for x in self.result['decision_log']))

    def test_brier_is_proper_range(self):
        self.assertTrue(all(0<=v['brier']<=1 for v in self.result['comparison'].values()))

    def test_calibration_report(self):
        self.assertTrue(all(0<=v['ece']<=1 for v in self.result['comparison'].values()))

    def test_confident_error_count_bounded(self):
        self.assertTrue(all(0<=v['confident_errors']<=v['samples'] for v in self.result['comparison'].values()))

    def test_frozen_dev_policy(self):
        self.assertIn(self.result['market_policy_frozen_on_development'],('prior',)+h.POLICIES)

    def test_virtual_budget_validation(self):
        for x in (float('nan'),float('inf'),-5,0,True):
            with self.assertRaises(ValueError): a.analyze(self.base,virtual_budget=x)

    def test_holdout_causality_future_signal_rejected(self):
        changed=copy.deepcopy(self.base)
        for r in changed['rows']:
            if r['ticker'] in h.STOCKS:
                r['signals']['trend']['observed_at_utc']=(h.utc(r['decision_at_utc'])+timedelta(days=1)).isoformat()
                break
        with self.assertRaisesRegex(ValueError,'future|Future'):a.analyze(changed)

    def test_cost_screen_never_adds_trades_over_feedback(self):
        g=self.result['comparison']
        self.assertLessEqual(g['accuracy_cost']['paper_trades'],g['accuracy_feedback']['paper_trades'])

    def test_stock_staleness_not_forward_filled(self):
        changed=copy.deepcopy(self.base)
        r=next(r for r in changed['rows'] if r['ticker'] in h.STOCKS)
        r['signals']['trend']['observed_at_utc']=(h.utc(r['decision_at_utc'])-timedelta(days=40)).isoformat()
        self.assertEqual(changed['schema'],h.SCHEMA)
        self.assertEqual(a.analyze(changed)['schema'],a.SCHEMA)

    def test_sham_accuracy_is_a_negative_control(self):
        self.assertIn('sham_accuracy',self.result['comparison'])
        self.assertNotEqual([x['weight_before_label'] for x in self.result['decision_log']],[])

    def test_original_h136_drift_is_unchanged_by_optional_flag(self):
        _,dates,data=h.validate(self.base)
        start=int(len(dates)*.75)
        control=h._paper(data,dates,start,10000,'trend_familiarity',dynamic=True,drift_guard=True)
        optional_false=h._paper(data,dates,start,10000,'trend_familiarity',dynamic=True,drift_guard=True,cost_guard=False)
        self.assertEqual(control,optional_false)

    def test_optional_overlay_paper_only(self):
        r=a.compare_h136_guard_overlay(self.base)
        self.assertEqual(r['real_broker_orders'],0)
        self.assertFalse(r['authentic_glyph_geometry_used'])
        self.assertEqual(r['frozen_selected'],self.result['market_policy_frozen_on_development'])

    def test_optional_overlay_has_no_more_trades(self):
        r=a.compare_h136_guard_overlay(h.synthetic(23702,'thin_liquidity',94))
        self.assertLessEqual(r['h137a_cost_overlay']['paper_rebalance_trades'],
                             r['existing_h136_drift_guard']['paper_rebalance_trades'])

    def test_synthetic_study_count(self):
        r=a.synthetic_study(('null',),(24601,24602),days=90)
        self.assertEqual(len(r['results']),2)
        self.assertEqual(r['worlds']['null']['count'],2)
        self.assertTrue(r['no_live_trading'])

    def test_seed_bounds(self):
        with self.assertRaises(ValueError):a.synthetic_study(('null',),list(range(300)))

if __name__=='__main__':unittest.main()
