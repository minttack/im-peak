from pathlib import Path
import tempfile
import unittest

from bie.native import BIEBridge, original_desktop, verify_vendor
from bie.migration import import_v1
from bie.store import Store


class InheritanceTests(unittest.TestCase):
    def test_vendor_bytes_are_unchanged(self):
        self.assertTrue(verify_vendor()["passed"])

    def test_real_v24_retrieval_and_recorded_failed_promotion(self):
        with tempfile.TemporaryDirectory() as temp:
            bridge = BIEBridge(Path(temp))
            self.assertTrue(bridge.search("intelligence accuracy"))
            history = bridge.history()
            self.assertEqual(history["inherited_counts"]["sources"], 62)
            self.assertEqual(history["inherited_counts"]["processor_events"], 345)
            self.assertFalse(history["v24_recorded_findings"]["experimental_policy_general_promotion"])

    def test_v1_notes_and_conversation_import_is_repeatable(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            old = original_desktop().ConversationStore(root / "old")
            old.remember("Preferred project is BIE")
            old.message("user", "A prior question", "intelligence")
            before = old.path.read_bytes()
            new = Store(root / "new")
            first = import_v1(new, old.path)
            second = import_v1(new, old.path)
            self.assertEqual(first["imported"], 2)
            self.assertEqual(second["imported"], 0)
            self.assertEqual(len(new.recall("Preferred")), 1)
            self.assertTrue(new.audit()["passed"])
            self.assertEqual(old.path.read_bytes(), before)

    def test_tampered_v1_note_is_not_imported(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            old = original_desktop().ConversationStore(root / "old")
            old.remember("Original")
            with old._db() as con:
                con.execute("UPDATE notes SET content='Altered'")
            with self.assertRaises(ValueError):
                import_v1(Store(root / "new"), old.path)
