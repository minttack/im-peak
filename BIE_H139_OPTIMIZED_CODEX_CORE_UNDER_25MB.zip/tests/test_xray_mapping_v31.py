"""V31 regression and synthetic evidence tests, not astronomical detections."""
import csv
import io
import json
import math
from pathlib import Path
import tempfile
import unittest

from bie.xray_mapping import (Bin, analyze, analyze_file, parse_counts_csv, phase_at,
                               published_reference, synthetic_demo)
from bie.tools import TOOLS, ToolRuntime


class XrayV31Tests(unittest.TestCase):
    def setUp(self):
        self.ex = synthetic_demo()

    def test_injected_positive(self):
        self.assertEqual(self.ex['injected']['verdict'], 'repeatable-dip-for-independent-review')
    def test_depth_close_to_injection(self):
        self.assertAlmostEqual(self.ex['injected']['pooled']['depth_fraction'], .09, delta=.025)
    def test_null_does_not_pass(self):
        self.assertNotEqual(self.ex['null']['verdict'], 'repeatable-dip-for-independent-review')
    def test_provenance_synthetic(self):
        self.assertIn('NOT-astronomical',self.ex['kind'])
    def test_bad_period(self):
        with self.assertRaises(ValueError):
            analyze([Bin(1,1,0,1,1,'a')]*30,period_days=0,epoch_days=0)
    def test_bad_epoch(self):
        with self.assertRaises(ValueError):
            analyze([Bin(1,1,0,1,1,'a')]*30,period_days=2,epoch_days=-1)
    def test_phases(self):
        self.assertAlmostEqual(phase_at(102.5,5,100),-.5)
        self.assertAlmostEqual(phase_at(105,5,100),0)
    def test_literature_calculation(self):
        obj=published_reference()
        self.assertEqual(obj['status'],'published-aggregate-only')
        self.assertAlmostEqual(obj['effective_radius_ratio_range'][0],math.sqrt(.06/.0241),delta=.0001)
    def test_no_raw_claim(self):
        self.assertIn('no original photon/event counts',published_reference()['provenance'])
    def test_parse_requires_background(self):
        with self.assertRaisesRegex(ValueError,'columns required'):
            parse_counts_csv(b'time_days,source_counts,exposure_s,visit\n1,20,5,a\n')
    def test_parse_rejects_negative_counts(self):
        txt='time_days,source_counts,background_counts,exposure_s,visit\n'+'\n'.join(f'{i},{-1 if i==3 else 1},0,1,a' for i in range(30))
        with self.assertRaises(ValueError):parse_counts_csv(txt.encode())
    def test_parse_rejects_nan(self):
        txt='time_days,source_counts,background_counts,exposure_s,visit\n'+'\n'.join(f'{i},{"nan" if i==3 else 1},0,1,a' for i in range(30))
        with self.assertRaises(ValueError):parse_counts_csv(txt.encode())
    def test_parse_rejects_duplicate_time(self):
        txt='time_days,source_counts,background_counts,exposure_s,visit\n'+'\n'.join(f'{i//2},1,0,1,a' for i in range(30))
        with self.assertRaisesRegex(ValueError,'Duplicate time'):parse_counts_csv(txt.encode())
    def test_parse_rejects_invalid_background_area(self):
        txt='time_days,source_counts,background_counts,exposure_s,visit,background_scale\n'+'\n'.join(f'{i},1,0,1,a,0' for i in range(30))
        with self.assertRaisesRegex(ValueError,'scale'):parse_counts_csv(txt.encode())
    def test_insufficient_visits(self):
        items=[Bin(10+i*.01,1000,10,100,1,'v1') for i in range(40)]
        obj=analyze(items,period_days=1,epoch_days=10.2)
        self.assertEqual(obj['verdict'],'insufficient-independent-visits')
    def test_wrong_epoch_fails(self):
        from bie.xray_mapping import read_counts_csv
        sample=Path(__file__).parent.parent/'examples'/'XRAY_SYNTHETIC_INJECTED_V31.csv'
        bins, _ = read_counts_csv(sample)
        wrong=analyze(bins,period_days=2.21857312,epoch_days=100+2.21857312*.25)
        self.assertNotEqual(wrong['verdict'],'repeatable-dip-for-independent-review')
    def test_larger_background_scale_changes_rate(self):
        source='time_days,source_counts,background_counts,exposure_s,visit,background_scale\n'
        lines=[f'{100+vi*2+(j-15)*.05},1000,5,100,v{vi},{scale}' for vi in range(2) for j in range(30) for scale in (1,)]
        parsed=parse_counts_csv((source+'\n'.join(lines)).encode())
        self.assertEqual(len(parsed),60)
    def test_file_sha256_provenance(self):
        hdr='time_days,source_counts,background_counts,exposure_s,visit\n'
        rows=[f'{100+vi*2+(j-20)*.05},1000,10,100,v{vi}' for vi in range(2) for j in range(40)]
        with tempfile.TemporaryDirectory() as d:
            f=Path(d)/'data.csv';f.write_text(hdr+'\n'.join(rows))
            r=analyze_file(f,2,100)
            self.assertEqual(len(r['source']['sha256']),64)
            self.assertEqual(r['source']['origin'],'user-selected-local-csv')
    def test_file_extension_restricted(self):
        with self.assertRaisesRegex(ValueError,'Only prepared'):
            analyze_file('passwords.txt',2,100)
    def test_no_overclaim_from_noisy_outcomes(self):
        self.assertIn('NOT proof', self.ex['injected']['interpretation'])
    def test_plugin_is_readonly_and_exposed(self):
        specs={t.name:t for t in TOOLS}
        self.assertIn('astro_xray_analyze',specs)
        self.assertFalse(specs['astro_xray_analyze'].mutates)
        self.assertIn('astro_xray_reference',specs)
    def test_schema_rejects_nonnumeric(self):
        t=object.__new__(ToolRuntime)
        t.specs={x.name:x for x in TOOLS}
        with self.assertRaises(ValueError):t.validate('astro_xray_analyze',{'path':'a.csv','period_days':'x','epoch_days':1.})
    def test_schema_rejects_nan(self):
        t=object.__new__(ToolRuntime)
        t.specs={x.name:x for x in TOOLS}
        with self.assertRaises(ValueError):t.validate('astro_xray_analyze',{'path':'a.csv','period_days':float('nan'),'epoch_days':1.})

if __name__=='__main__':unittest.main()
