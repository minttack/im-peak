"""Independent controls and integration checks for Adaptive BLOOM Wiggle."""
import heapq
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

from bie.adaptive_wiggle import DEFAULT_MAP, plan, recovery_hint
from bie.agent import Assistant
from bie.tools import ToolRuntime
from bie.workspace import Workspace


def exact_cost(grid):
    """Separate Dijkstra reference, not using the planner's own path scores."""
    rows = grid.splitlines()
    start = next((x, y) for y, row in enumerate(rows) for x, c in enumerate(row) if c == "S")
    end = next((x, y) for y, row in enumerate(rows) for x, c in enumerate(row) if c == "G")
    pq, scores = [(0, start)], {start: 0}
    while pq:
        cost, (x, y) = heapq.heappop(pq)
        if cost != scores[(x, y)]:
            continue
        if (x, y) == end:
            return cost
        for nx, ny in ((x+1, y), (x, y+1), (x-1, y), (x, y-1)):
            if 0 <= ny < len(rows) and 0 <= nx < len(rows[0]) and rows[ny][nx] != '#':
                c = rows[ny][nx]
                n = cost + (int(c) if c.isdigit() else 1)
                if n < scores.get((nx, ny), 1e12):
                    scores[(nx, ny)] = n
                    heapq.heappush(pq, (n, (nx, ny)))
    return None


class AdaptiveWiggleTests(unittest.TestCase):
    def test_control_stuck_adaptive_escapes(self):
        a = plan(DEFAULT_MAP)
        self.assertEqual(a['baseline_greedy']['status'], 'stalled')
        self.assertEqual(a['status'], 'reached')
        self.assertTrue(a['optimal'])
        self.assertTrue(a['obstacle_detour'])
        self.assertGreater(len(a['intensification_stages']), 1)
        self.assertEqual(a['cost'], exact_cost(DEFAULT_MAP))

    def test_simple_direct_path(self):
        a = plan('S..G')
        self.assertEqual(a['steps'], 3)
        self.assertEqual(a['cost'], 3)
        self.assertFalse(a['obstacle_detour'])

    def test_weighted_terrain_avoids_expensive_shortcut(self):
        g = 'S99G\n....'
        a = plan(g)
        self.assertEqual(a['cost'], 5)
        self.assertEqual(a['cost'], exact_cost(g))
        self.assertEqual(a['baseline_greedy']['cost'], 19)

    def test_unreachable_not_claimed_optimal(self):
        a = plan('S#G')
        self.assertEqual(a['status'], 'unreachable')
        self.assertIsNone(a['cost'])
        self.assertFalse(a['optimal'])

    def test_exhausted_not_claimed_unreachable(self):
        a = plan(DEFAULT_MAP, initial_budget=1, max_expansions=1)
        self.assertEqual(a['status'], 'budget_exhausted')
        self.assertFalse(a['optimal'])
        self.assertEqual(a['expanded'], 1)

    def test_adaptive_deterministic(self):
        self.assertEqual(plan(DEFAULT_MAP), plan(DEFAULT_MAP))

    def test_random_control_crosschecks_optimum(self):
        import random
        r = random.Random(337)
        for _ in range(75):
            rows = [['#' if r.random() < .29 else str(r.randrange(1, 6))
                     for _ in range(10)] for _ in range(9)]
            rows[0][0], rows[8][9] = 'S', 'G'
            grid = '\n'.join(''.join(row) for row in rows)
            a = plan(grid)
            expected = exact_cost(grid)
            self.assertEqual(a['cost'], expected)
            self.assertEqual(a['status'] == 'reached', expected is not None)

    def test_invalid_maps_and_budgets(self):
        for bad in ('', 'S', 'G', 'S#\nG', 'SSG', 'SG\n#?', 'S G', 'S' + '.'*64 + 'G'):
            with self.subTest(grid=bad), self.assertRaises(ValueError):
                plan(bad)
        for budget in (0, -5, True, 129, 1.5):
            with self.assertRaises(ValueError):
                plan('SG', initial_budget=budget)
        for budget in (0, -1, True, 5000):
            with self.assertRaises(ValueError):
                plan('SG', max_expansions=budget)

    def test_windows_newlines(self):
        self.assertEqual(plan("SG\r\n..") ["status"], "reached")

    def test_must_not_escalate_permissions(self):
        hint = recovery_hint('project_read', 2)
        self.assertIn('do not turn on execution', hint)
        self.assertIn('same inputs', hint)
        self.assertEqual(recovery_hint('project_read', 1), '')

    def test_schema_and_read_only_tool(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            app = Assistant(root / 'state')
            tid = app.submit('test', workspace=root / 'project', allow_write=False, allow_exec=False)
            runtime = ToolRuntime(app.store, app.bridge, Workspace(root / 'project', root / 'backups'), allow_write=False, allow_exec=False)
            self.assertIn('adaptive_wiggle', [t['function']['name'] for t in runtime.schemas()])
            result = runtime.call('adaptive_wiggle', {'map': DEFAULT_MAP}, task_id=tid, call_id='wiggle:0')
            self.assertTrue(result['ok'], result)
            self.assertEqual(result['data']['status'], 'reached')
            self.assertTrue(app.store.audit()['passed'])

    def test_adaptive_hint_injected_after_repeat(self):
        from test_agent import ScriptedProvider, call
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            provider = ScriptedProvider([
                [call('project_read', path='missing')],
                [call('project_read', path='missing')],
                [call('project_list', path='.')],
                'Read-only alternative succeeded.'
            ])
            app = Assistant(root/'state', provider_factory=lambda _: provider)
            tid = app.submit('Read the project carefully', workspace=root/'project')
            result = app.run(tid)
            self.assertEqual(result['status'], 'done', result)
            self.assertIn('ADAPTIVE BLOOM WIGGLE RUNTIME SIGNAL', str(provider.prompts[2]))
            self.assertEqual(result['calls'], 3)

    def test_cli_demo(self):
        with tempfile.TemporaryDirectory() as td:
            run = subprocess.run([sys.executable, '-m', 'bie', '--home', str(Path(td)/'state'), 'wiggle-demo'],
                                 capture_output=True, text=True, timeout=30)
        self.assertEqual(run.returncode, 0, run.stderr)
        self.assertIn('"status": "reached"', run.stdout)


if __name__ == '__main__':
    unittest.main()
