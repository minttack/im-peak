"""Independent H135-R acceptance suite; read-only synthetic testing."""
import copy
from datetime import datetime, timedelta, timezone
from pathlib import Path
import json
import subprocess
import sys
import tempfile
import unittest

from bie import relevance_ladder_h135r as h


class TestH135R(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.causal = h.synthetic(13501, "causal", days=64)

    def test_worlds_have_no_broker_calls(self):
        for world in ("causal", "shift", "null"):
            rep = h.analyze(h.synthetic(13501, world, days=64))
            self.assertEqual(rep['promotion_decision'], 'NO_LIVE_TRADING_AUTHORIZED')
            self.assertTrue(rep['no_automatic_brokerage_orders'])
            self.assertEqual(rep['capital_proof_ladder'][0]['real_money'], 0)

    def test_chronology_embargo(self):
        _, a, b, c, s = h.validate(self.causal)
        self.assertTrue(max(x['outcome'] for x in a) < min(x['decision'] for x in b))
        self.assertTrue(max(x['outcome'] for x in b) < min(x['decision'] for x in c))
        self.assertGreaterEqual(s['embargo_discarded'], 0)
        shifted = copy.deepcopy(self.causal)
        for e in shifted['events']:
            if h.utc(e['decision_at_utc']) == h.utc(shifted['events'][310]['decision_at_utc']):
                e['outcome_at_utc'] = (h.utc(e['decision_at_utc']) + timedelta(days=3)).isoformat()
        _, _, _, _, embargo = h.validate(shifted)
        self.assertGreater(embargo['embargo_discarded'], 0)

    def test_future_feature_rejected(self):
        data = copy.deepcopy(self.causal)
        data['events'][0]['signals']['trend']['observed_at_utc'] = (h.utc(data['events'][0]['decision_at_utc']) + timedelta(hours=1)).isoformat()
        with self.assertRaisesRegex(ValueError, 'future'):
            h.analyze(data)

    def test_future_label_rejected(self):
        data = copy.deepcopy(self.causal)
        data['events'][0]['outcome_at_utc'] = (h.utc(data['as_of_utc']) + timedelta(days=1)).isoformat()
        with self.assertRaises(ValueError):
            h.analyze(data)

    def test_wrong_input_schema_rejected(self):
        data = copy.deepcopy(self.causal)
        data['schema'] = 'fake'
        with self.assertRaises(ValueError):
            h.analyze(data)

    def test_invalid_ticker_rejected(self):
        data = copy.deepcopy(self.causal)
        data['events'][0]['ticker'] = 'X-FAKE'
        with self.assertRaises(ValueError):
            h.analyze(data)

    def test_unknown_signal_rejected(self):
        data = copy.deepcopy(self.causal)
        data['events'][0]['signals']['magic'] = data['events'][0]['signals']['trend']
        with self.assertRaises(ValueError):
            h.analyze(data)

    def test_nan_signal_rejected(self):
        data = copy.deepcopy(self.causal)
        data['events'][0]['signals']['trend']['value'] = float('nan')
        with self.assertRaises(ValueError):
            h.analyze(data)

    def test_invalid_source_rejected(self):
        data = copy.deepcopy(self.causal)
        data['events'][0]['signals']['trend']['source'] = 'secret'
        with self.assertRaises(ValueError):
            h.analyze(data)

    def test_missing_reference_rejected(self):
        data = copy.deepcopy(self.causal)
        data['events'][0]['signals']['trend']['reference'] = ''
        with self.assertRaises(ValueError):
            h.analyze(data)

    def test_stale_feature_ignored(self):
        data = copy.deepcopy(self.causal)
        data['events'][0]['signals']['news']['observed_at_utc'] = (h.utc(data['events'][0]['decision_at_utc']) - timedelta(days=30)).isoformat()
        _, train, _, _, _ = h.validate(data)
        found = [r for r in train if r['ticker'] == data['events'][0]['ticker'] and r['decision'] == h.utc(data['events'][0]['decision_at_utc'])]
        self.assertTrue(found)
        self.assertNotIn('news', found[0]['x'])

    def test_missing_outcomes_rejected(self):
        data = copy.deepcopy(self.causal)
        data['events'][0].pop('target_up_after_costs')
        with self.assertRaises(ValueError):
            h.analyze(data)

    def test_fake_historical_source_rejected(self):
        data = copy.deepcopy(self.causal)
        data['source_mode'] = 'historical_user_supplied'
        with self.assertRaises(ValueError):
            h.analyze(data)

    def test_same_day_stock_duplicate_rejected(self):
        data = copy.deepcopy(self.causal)
        data['events'].append(copy.deepcopy(data['events'][0]))
        with self.assertRaises(ValueError):
            h.analyze(data)

    def test_out_of_bounds_position_count_rejected(self):
        with self.assertRaises(ValueError):
            h.analyze(self.causal, paper_positions=6)

    def test_bad_money_inputs_rejected(self):
        for amount in (float('nan'), float('inf'), 0, -1, 1e15):
            with self.subTest(amount=amount), self.assertRaises(ValueError):
                h.analyze(self.causal, paper_budget=amount)

    def test_diversified_research_only(self):
        result = h.analyze(self.causal)
        tickers = result['diversified_research_list']
        self.assertLessEqual(len(tickers), 5)
        self.assertEqual(len(set(tickers)), len(tickers))
        self.assertFalse(any(sum(h.SECTORS[t] == h.SECTORS[x] for x in tickers) > 2 for t in tickers))
        self.assertFalse(any(result['stock_research_scores_not_return_forecasts'][ticker]['buy_recommendation'] for ticker in tickers))

    def test_training_only_feature_choice(self):
        before = h.analyze(self.causal)
        data = copy.deepcopy(self.causal)
        holdout = h.utc(before['split']['holdout_start'])
        for row in data['events']:
            if h.utc(row['decision_at_utc']) >= holdout:
                row['target_up_after_costs'] = not row['target_up_after_costs']
        after = h.analyze(data)
        self.assertEqual(before['predictive_relevance_validation'], after['predictive_relevance_validation'])
        self.assertEqual(before['diversified_research_list'], after['diversified_research_list'])
        self.assertNotEqual(before['sealed_holdout_evaluation'], after['sealed_holdout_evaluation'])

    def test_holdout_report_unmistakably_synthetic(self):
        report = h.analyze(self.causal)
        self.assertEqual(report['source_mode'], 'synthetic')
        self.assertTrue(report['source_authentication'].lower().startswith('user/agent'))
        self.assertIn('NOT_GRANTED', report['capital_proof_ladder'][2]['permission'])

    def test_null_has_no_forced_proof(self):
        r = h.analyze(h.synthetic(13503, 'null'))
        self.assertEqual(r['promotion_decision'], 'NO_LIVE_TRADING_AUTHORIZED')
        self.assertFalse(r['no_automatic_brokerage_orders'] is False)

    def test_shift_exposes_loss(self):
        r = h.analyze(h.synthetic(13502, 'shift'))
        self.assertLess(r['sealed_holdout_evaluation']['gain'], 0)
        self.assertIn('did not survive', r['next_test']['current_finding'])

    def test_create_only_files(self):
        with tempfile.TemporaryDirectory() as tmp:
            p = Path(tmp) / 'report.json'
            h.save_new(p, h.analyze(self.causal))
            with self.assertRaises(FileExistsError):
                h.save_new(p, h.analyze(self.causal))

    def test_cli_smoke(self):
        with tempfile.TemporaryDirectory() as tmp:
            report = Path(tmp) / 'res.json'
            cmd = [sys.executable, '-m', 'bie', 'relevance-h135r-demo', '--seed', '13501', '--report', str(report)]
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=35)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(json.loads(report.read_text())['promotion_decision'], 'NO_LIVE_TRADING_AUTHORIZED')

    def test_20_seed_causal_advantage_not_proof(self):
        gain = []
        for seed in range(14000, 14020):
            report = h.analyze(h.synthetic(seed, 'causal', days=48))
            gain.append(report['sealed_holdout_evaluation']['gain'])
            self.assertEqual(report['promotion_decision'], 'NO_LIVE_TRADING_AUTHORIZED')
        self.assertGreater(sum(gain) / len(gain), 0)

    def test_20_seed_reversal_exposes_failure(self):
        gain = []
        for seed in range(15000, 15020):
            report = h.analyze(h.synthetic(seed, 'shift', days=48))
            gain.append(report['sealed_holdout_evaluation']['gain'])
        self.assertLess(sum(gain) / len(gain), 0)

if __name__ == '__main__':
    unittest.main()
