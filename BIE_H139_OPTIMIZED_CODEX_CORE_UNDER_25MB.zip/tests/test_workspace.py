from pathlib import Path
import tempfile
import threading
import unittest

from bie.workspace import Workspace
from bie.process import run_tests


class WorkspaceTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.base = Path(self.temp.name)
        self.workspace = Workspace(self.base / "project", self.base / "backups")

    def tearDown(self):
        self.temp.cleanup()

    def test_create_edit_backup_and_stale_write(self):
        first = self.workspace.write("module.py", "x = 1\n")
        with self.assertRaises(ValueError):
            self.workspace.write("module.py", "x = 2\n")
        second = self.workspace.write("module.py", "x = 2\n", first["sha256"])
        self.assertTrue(second["changed"])
        self.assertEqual((self.base / "backups" / first["sha256"]).read_text(), "x = 1\n")
        with self.assertRaises(ValueError):
            self.workspace.write("module.py", "x = 3\n", first["sha256"])

    def test_replay_of_identical_write_is_noop(self):
        self.workspace.write("hello.txt", "hello")
        result = self.workspace.write("hello.txt", "hello")
        self.assertFalse(result["changed"])

    def test_traversal_and_secret_paths_rejected(self):
        for path in ("../outside", "/etc/passwd", "C:/Windows/test", "a/../../b", ".env", ".env.local", ".git/config", "a\\b", "x\x00y"):
            with self.subTest(path=path), self.assertRaises(ValueError):
                self.workspace.path(path)

    def test_symlink_cannot_escape(self):
        try:
            (self.workspace.root / "escape").symlink_to(self.base, target_is_directory=True)
        except (OSError, NotImplementedError):
            self.skipTest("Symlinks unavailable on this host")
        with self.assertRaises(ValueError):
            self.workspace.write("escape/changed.txt", "no")

    def test_large_or_binary_content_rejected(self):
        with self.assertRaises(ValueError):
            self.workspace.write("large", "x" * (Workspace.MAX_BYTES + 1))
        (self.workspace.root / "binary").write_bytes(b"\x00\x01")
        with self.assertRaises(ValueError):
            self.workspace.read("binary")

    def test_syntax_check_does_not_execute_code(self):
        self.workspace.write("danger.py", "raise RuntimeError('do not run')\n")
        self.assertTrue(self.workspace.check_python("danger.py")["passed"])
        self.workspace.write("broken.py", "def broken(:\n")
        self.assertFalse(self.workspace.check_python("broken.py")["passed"])

    def test_real_project_tests_and_zero_test_detection(self):
        (self.workspace.root / "tests").mkdir()
        empty = run_tests(self.workspace.root, threading.Event())
        self.assertFalse(empty["passed"])
        self.workspace.write("calculator.py", "def add(a,b):\n    return a+b\n")
        self.workspace.write("tests/test_calc.py", "import unittest\nfrom calculator import add\nclass Check(unittest.TestCase):\n    def test_sum(self):\n        self.assertEqual(add(2,3),5)\n")
        result = run_tests(self.workspace.root, threading.Event())
        self.assertTrue(result["passed"], result)
        self.assertEqual(result["tests"], 1)

    def test_running_project_test_can_be_cancelled(self):
        self.workspace.write("tests/test_wait.py", "import unittest, time\nclass Check(unittest.TestCase):\n    def test_wait(self):\n        time.sleep(60)\n")
        token = threading.Event()
        timer = threading.Timer(.2, token.set)
        timer.start()
        try:
            result = run_tests(self.workspace.root, token)
        finally:
            timer.cancel()
        self.assertFalse(result["passed"])
        self.assertEqual(result["stopped"], "cancelled")

    def test_runaway_test_output_is_bounded(self):
        self.workspace.write("tests/test_loud.py", "import unittest\nclass Check(unittest.TestCase):\n    def test_loud(self):\n        while True: print('x'*10000, flush=True)\n")
        result = run_tests(self.workspace.root, threading.Event(), timeout=3)
        self.assertFalse(result["passed"])
        self.assertEqual(result["stopped"], "output limit")
        self.assertLessEqual(len(result["output"]), 65536)
