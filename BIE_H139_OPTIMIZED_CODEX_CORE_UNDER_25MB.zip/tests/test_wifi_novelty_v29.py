"""Synthetic only: no real radio access or novel WLAN discovery in tests."""
import json
from pathlib import Path
import sqlite3
import tempfile
import unittest
from unittest.mock import patch
from io import StringIO

from bie.wifi_lab import WifiLab, parse_networks
from bie.wifi_novelty import WifiNovelty, _normalized_label
from bie.__main__ import main


def data(t="2026-10-15T10:00:00+00:00", radio="802.11be", band="5 GHz", channel="36", warnings=None):
    a = parse_networks(f'''SSID 1 : PRIVATE_NETWORK_DO_NOT_EXPORT
    Authentication : WPA2-Personal
    BSSID 1 : de:ad:be:ef:00:01
      Signal : 73%
      Radio type : {radio}
      Band : {band}
      Channel : {channel}
''')
    return {"ok": True, "captured_at": t,
            "connection": {"ssid": "PRIVATE_NETWORK_DO_NOT_EXPORT", "signal_pct": 73},
            "access_points": a, "adapter": {"supported_radios": ["802.11be"]},
            "warnings": warnings or []}


class Novelty29(unittest.TestCase):
    def setUp(self):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        self.home = Path(tmp.name)
        self.lab = WifiLab(self.home)
        self.novelty = WifiNovelty(self.home)

    def add(self, idx=0, **kwargs):
        return self.lab.snapshot(data(t=f"2026-10-15T10:{idx:02d}:00+00:00", **kwargs))

    def test_01_no_measurement_never_claims_discovery(self):
        report = self.novelty.report()
        self.assertEqual(report["status"], "no_measurements")
        self.assertFalse(report["new_protocol_discovered"])

    def test_02_known_wifi7_no_faux_novelty(self):
        self.add()
        report = self.novelty.report()
        self.assertEqual(report["status"], "no_unclassified_metadata_detected")
        self.assertEqual(report["candidates"], [])

    def test_03_unknown_label_is_only_hypothesis(self):
        self.add(radio="802.11bn")
        report = self.novelty.report()
        self.assertEqual(report["cases_count"], 1)
        self.assertEqual(report["candidates"][0]["indicator"], "unrecognized_radio_label")
        self.assertEqual(report["candidates"][0]["review_status"], "needs_repeated_measurements")
        self.assertFalse(report["candidates"][0]["supports_new_wifi_protocol"])
        self.assertNotIn("PRIVATE_NETWORK_DO_NOT_EXPORT", json.dumps(report))
        self.assertNotIn("de:ad:be:ef:00:01", json.dumps(report))

    def test_04_two_sessions_and_three_distinct_timestamps_still_unverified(self):
        for i in range(4):
            if i == 2: self.lab.new_session()
            self.add(i, radio="802.11bn")
        report = self.novelty.report()
        self.assertEqual(report["candidates"][0]["review_status"], "repeated_os_reports_unverified")
        self.assertFalse(report["new_protocol_discovered"])

    def test_05_reused_timestamps_cannot_count_as_replication(self):
        for i in range(4):
            if i == 2: self.lab.new_session()
            self.lab.snapshot(data(radio="802.11bn"))
        r = self.novelty.report()
        self.assertEqual(r["candidates"][0]["review_status"], "needs_repeated_measurements")
        self.assertEqual(r["distinct_eligible_timestamps"], 1)

    def test_06_incomplete_reports_excluded(self):
        self.add(radio="802.11bn", warnings=["access denied"])
        r = self.novelty.report()
        self.assertEqual(r["status"], "incomplete_reports")
        self.assertEqual(r["candidates"], [])

    def test_07_channel_band_mismatch_not_new_protocol(self):
        self.add(band="2.4 GHz", channel="149")
        r = self.novelty.report()
        self.assertEqual(r["candidates"][0]["indicator"], "band_channel_inconsistency")
        self.assertFalse(r["new_protocol_discovered"])

    def test_08_6ghz_ch37_not_false_positive(self):
        self.add(band="6 GHz", channel="37")
        self.assertEqual(self.novelty.report()["cases_count"], 0)

    def test_09_changing_ordinary_radio_is_not_novel_protocol(self):
        self.add(0, radio="802.11ax")
        self.add(1, radio="802.11be")
        r = self.novelty.report()
        self.assertEqual([x["indicator"] for x in r["candidates"]], ["radio_label_changed"])
        self.assertFalse(r["new_protocol_discovered"])

    def test_10_malformed_radio_not_reported_as_discovery(self):
        self.add(radio="secret password: HIDDEN")
        r = self.novelty.report()
        self.assertEqual(r["cases_count"], 0)

    def test_11_radio_metadata_is_not_raw_rf(self):
        self.add(radio="802.11bn")
        r = self.novelty.report()
        self.assertIn("not a radio spectrum sweep", r["measurement_scope"])
        self.assertNotIn("802.11bn", json.dumps(r))

    def test_12_old_database_rows_preserved(self):
        self.add()
        with sqlite3.connect(self.lab.db_path) as con:
            count = con.execute("SELECT count(*) FROM readings").fetchone()[0]
        self.novelty.report()
        with sqlite3.connect(self.lab.db_path) as con:
            self.assertEqual(con.execute("SELECT count(*) FROM readings").fetchone()[0], count)

    def test_13_capture_not_possible_here(self):
        with patch("bie.wifi_novelty.WifiLab.snapshot", return_value={"saved": False}):
            r = self.novelty.observe_and_report()
        self.assertEqual(r["status"], "capture_unavailable")
        self.assertFalse(r["new_protocol_discovered"])

    def test_14_snapshot_return_does_not_export_network_names(self):
        original = self.lab.snapshot
        with patch("bie.wifi_novelty.WifiLab.snapshot", side_effect=lambda *a, **k: original(data(radio="802.11bn"))):
            r = self.novelty.observe_and_report()
        self.assertTrue(r["capture_saved"])
        self.assertNotIn("PRIVATE_NETWORK", json.dumps(r))

    def test_15_cli_offline_novelty_read(self):
        self.add(radio="802.11bn")
        output = StringIO()
        with patch("sys.stdout", new=output):
            code = main(["--home", str(self.home), "wifi-novelty"])
        self.assertIn("unrecognized_radio_label", output.getvalue())
        self.assertNotIn("PRIVATE_NETWORK", output.getvalue())
        self.assertEqual(code, 0)

    def test_16_unknown_and_missing_radio_not_promoted(self):
        self.add(radio="unknown")
        self.add(1, radio="")
        self.assertEqual(self.novelty.report()["cases_count"], 0)

    def test_17_bad_timestamp_ignored(self):
        self.lab.snapshot(data(t="not-a-date", radio="802.11bn"))
        self.assertEqual(self.novelty.report()["status"], "incomplete_reports")

    def test_18_untrusted_radio_sanitizer(self):
        self.assertEqual(_normalized_label("xxx\ncredential=abcdef"), "")
        self.assertEqual(_normalized_label("802.11be"), "802.11be")


if __name__ == "__main__":
    unittest.main()
