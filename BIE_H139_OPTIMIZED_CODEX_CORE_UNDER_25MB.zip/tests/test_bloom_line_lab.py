"""Offline, opt-in BIE Bloom/Wiggle data/geometry integrity checks."""
from __future__ import annotations

import hashlib
import math
import random
import unittest
import zlib

from bie.bloom_line_lab import (Geometry, safe_pack, arc_pack_naive, straight_pack,
    check_integrity, packetize, code_order, encode, decode, visual_compaction_suite,
    geometry_suite)


class BloomLineTests(unittest.TestCase):
    def test_zero_amplitude_equals_straight_for_exact_grid(self):
        c=Geometry(radius=8,amplitude=0,cycles=7,center_focus=False)
        self.assertEqual(safe_pack(c),straight_pack(c))

    def test_legal_grid_clearance_and_order(self):
        for radius in (6,8,12,16):
            for amp in (0,10,30,72):
                for cyc in (1,3,7,13):
                    c=Geometry(radius=radius,amplitude=amp,cycles=cyc,phase=.75)
                    a=safe_pack(c,resolution=.5)
                    self.assertTrue(check_integrity(a,c)['valid'],(radius,amp,cyc))
                    self.assertEqual(a[0][0],0)
                    self.assertTrue(all(a[i][0]<a[i+1][0] for i in range(len(a)-1)))

    def test_arc_length_only_is_not_a_collision_proof(self):
        failing=0
        for amp in (8,24,48,72):
            for cyc in (3,7,13):
                c=Geometry(amplitude=amp,cycles=cyc)
                if not check_integrity(arc_pack_naive(c),c)['valid']:
                    failing+=1
        self.assertGreater(failing,0)

    def test_straight_is_clear(self):
        c=Geometry(amplitude=0,cycles=0)
        self.assertTrue(check_integrity(straight_pack(c),c)['valid'])

    def test_invalid_geometry_rejected(self):
        for c in [Geometry(radius=0),Geometry(radius=-1),Geometry(amplitude=-1),
                  Geometry(amplitude=math.inf),Geometry(cycles=math.nan),Geometry(width=999999)]:
            with self.assertRaises(ValueError): safe_pack(c)

    def test_collision_is_detected(self):
        c=Geometry(radius=8,amplitude=0)
        self.assertFalse(check_integrity([(0,0),(10,0)],c)['valid'])

    def test_nonfinite_x_and_duplicate_x_rejected(self):
        c=Geometry()
        self.assertFalse(check_integrity([(0,0),(0,10)],c)['valid'])
        self.assertFalse(check_integrity([(0,0),(math.inf,1)],c)['valid'])

    def test_bytes_roundtrip_varied_sizes(self):
        rng=random.Random(12345)
        for length in (1,2,17,127,128,129,256,1023,8193,100_003):
            original=rng.randbytes(length)
            for order in ('linear','wiggle','random'):
                with self.subTest(length=length,order=order):
                    self.assertEqual(decode(encode(original,order)),original)

    def test_repetitive_source_and_utf8_roundtrip(self):
        source=('BIE THRIVES 🌸'*310).encode('utf-8')+b'\0\0\xff\xfe'
        for order in ('linear','wiggle','random'):
            self.assertEqual(decode(encode(source,order,chunk_size=33)),source)

    def test_decode_rejects_modified_payload_even_with_valid_zlib(self):
        source=b'abc'*100
        encoded=encode(source,'wiggle')
        clear=bytearray(zlib.decompress(encoded))
        clear[-3]^=1
        with self.assertRaises(ValueError): decode(zlib.compress(clear))

    def test_decode_rejects_duplicates_and_damaged_streams(self):
        sample=encode(b'C'*1000,'linear')
        with self.assertRaises(Exception):decode(sample[:-2])
        raw=bytearray(zlib.decompress(sample))
        # first index begins after MAGIC(8), count/total/chunk (12), sha (32)
        index_offset=8+12+32
        raw[index_offset+128+8:index_offset+128+12]=(0).to_bytes(4,'little')
        with self.assertRaises(ValueError):decode(zlib.compress(raw))

    def test_rejects_bomb_large_and_empty_and_bad_strategy(self):
        with self.assertRaises(ValueError):encode(b'','linear')
        with self.assertRaises(ValueError):encode(b'x'*1_000_001,'linear')
        with self.assertRaises(ValueError):encode(b'hello','invalid')
        with self.assertRaises(ValueError):decode(zlib.compress(b'no-header'))

    def test_stable_code_order_deterministic(self):
        chunks=packetize(b'0123456789'*100)
        for mode in ('linear','wiggle','random'):
            self.assertEqual(code_order(chunks,mode),code_order(chunks,mode))

    def test_visual_squeezing_requires_recipe_to_preserve_shape(self):
        cases=visual_compaction_suite()
        self.assertEqual(cases[0]['max_pixel_displacement'],0)
        self.assertTrue(all(a['reversible_with_recipe'] for a in cases))
        self.assertTrue(all(a['max_pixel_displacement']>0 for a in cases[1:]))
        self.assertFalse(cases[-1]['without_metadata_restorable'])

    def test_fresh_heldout_integrity(self):
        ret=geometry_suite(seed=771701,random_cases=10,quick=True)
        self.assertEqual(ret['fresh_seeded']['safe_integrity_passes'],10)
        self.assertEqual(ret['design']['safe_integrity_passes'],6)


if __name__=='__main__': unittest.main()
