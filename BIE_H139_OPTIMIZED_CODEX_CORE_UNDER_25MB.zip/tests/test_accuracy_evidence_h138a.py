"""Independent chronological source-handling and paired-policy checks H138A."""
import copy
import unittest
from datetime import datetime
from bie import familiarity_money_h136 as h
from bie import accuracy_evidence_h138a as x

class H138AEvidenceTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.base=h.synthetic(58120,'familiarity_signal',days=96)

    def test_normal_no_modification(self):
        p,c,_=x.altered_information(self.base,mode='normal');self.assertEqual(p,self.base);self.assertEqual(c,0)
    def test_wrong_disturbance(self):
        with self.assertRaises(ValueError): x.altered_information(self.base,mode='time_machine')
    def test_bad_seed(self):
        with self.assertRaises(ValueError): x.altered_information(self.base,mode='stale',seed=-3)
    def test_normal_both_identical_to_original(self):
        r=x.probe(self.base,modes=('normal',))['disturbances']['normal']
        self.assertEqual(r['existing_h136']['net_pnl_dollars'],r['h138a_availability']['net_pnl_dollars'])
        self.assertEqual(r['existing_h136']['paper_rebalance_trades'],r['h138a_availability']['paper_rebalance_trades'])
    def test_expensive_retains_close_prices(self):
        p,c,_=x.altered_information(self.base,mode='expensive');self.assertGreater(c,0)
        self.assertEqual([r['close'] for r in p['rows']],[r['close'] for r in self.base['rows']])
    def test_misleading_changes_no_prices(self):
        p,c,_=x.altered_information(self.base,mode='misleading');self.assertGreater(c,0)
        self.assertEqual([r['close'] for r in p['rows']],[r['close'] for r in self.base['rows']])
    def test_stale_features_fail_closed(self):
        p,c,_=x.altered_information(self.base,mode='stale');self.assertGreater(c,0)
        _,dates,data=h.validate(p)
        hold=dates[int(len(dates)*.75)]
        self.assertTrue(any('investor_familiarity' not in data[(d,t)]['x'] for d in dates if d>=hold for t in h.STOCKS))
    def test_no_train_validation_modification(self):
        _,dates,_=h.validate(self.base);hold=dates[int(len(dates)*.75)]
        early=[r for r in self.base['rows'] if datetime.fromisoformat(r['decision_at_utc'])<hold]
        for mode in ('normal','missing','stale','misleading','expensive'):
            p,_,_=x.altered_information(self.base,mode=mode)
            early2=[r for r in p['rows'] if datetime.fromisoformat(r['decision_at_utc'])<hold]
            self.assertEqual(early,early2)
    def test_deterministic_disturbance(self):
        p,c,_=x.altered_information(self.base,mode='missing',seed=8)
        q,d,_=x.altered_information(self.base,mode='missing',seed=8)
        self.assertEqual((p,c),(q,d))
    def test_different_seed_different_missingness(self):
        p,_,_=x.altered_information(self.base,mode='missing',seed=8)
        q,_,_=x.altered_information(self.base,mode='missing',seed=9)
        self.assertNotEqual(p,q)
    def test_no_mutation_of_input(self):
        original=copy.deepcopy(self.base)
        x.probe(self.base,modes=('normal','stale'))
        self.assertEqual(original,self.base)
    def test_zero_broker_orders(self):
        r=x.probe(self.base,modes=('normal','expensive'))
        self.assertEqual(r['orders_executed'],0)
        self.assertFalse(r['original_glyph_bytes_used'])
    def test_budget_limits(self):
        for b in (0,-20,float('nan'),1e9,'100'):
            with self.assertRaises(ValueError): x.probe(self.base,modes=('normal',),virtual_budget=b)
    def test_model_selection_same_all_disturbances(self):
        a=x.probe(self.base,modes=('normal',))['frozen_development_policy']
        b=x.probe(self.base,modes=('missing','stale','misleading','expensive'))['frozen_development_policy']
        self.assertEqual(a,b)
    def test_future_price_changes_do_not_change_prior_policy(self):
        p=copy.deepcopy(self.base)
        _,dates,_=h.validate(p);hold=dates[int(len(dates)*.75)]
        for row in p['rows']:
            if datetime.fromisoformat(row['decision_at_utc'])>=hold:
                row['close']=row['close']*1.15
        self.assertEqual(x.probe(self.base,modes=('normal',))['frozen_development_policy'], x.probe(p,modes=('normal',))['frozen_development_policy'])
    def test_study_rejects_unbounded_request(self):
        with self.assertRaises(ValueError): x.study(seeds=list(range(60)))
    def test_study_rejects_unknown_world(self):
        with self.assertRaises(ValueError): x.study(seeds=[1],worlds=['future_known'])
    def test_fully_missing_stock_does_not_pass_guard(self):
        p=copy.deepcopy(self.base)
        _,dates,_=h.validate(p);hold=dates[int(len(dates)*.75)]
        for row in p['rows']:
            if datetime.fromisoformat(row['decision_at_utc'])>=hold and row['ticker'] in h.STOCKS:
                row['signals']={}
        _,dates,data=h.validate(p)
        selected,_=h._validation(data,dates,int(len(dates)*.5),int(len(dates)*.75))
        v=h._paper(data,dates,int(len(dates)*.75),10000,selected,dynamic=True,drift_guard=True,signal_guard=True)
        self.assertEqual(v['paper_rebalance_trades'],0)
    def test_provenance_source_mode_rejects_false_historical(self):
        p=copy.deepcopy(self.base);p['source_mode']='historical_user_supplied'
        with self.assertRaises(ValueError): x.probe(p,modes=('normal',))
    def test_no_long_run_claimed(self):
        r=x.probe(self.base,modes=('normal',))
        self.assertIn('original glyph',r['symbol_accuracy_attribution'])
        self.assertEqual(r['schema'],x.SCHEMA)

if __name__=='__main__':unittest.main()
