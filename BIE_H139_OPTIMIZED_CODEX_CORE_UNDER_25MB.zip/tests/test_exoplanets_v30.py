from __future__ import annotations

import csv
import io
import json
import math
from pathlib import Path
import tempfile
import unittest

from bie.exoplanets import ExoplanetLab, COLUMNS, PARSEC_LIGHT_YEARS, parse_archive_csv, public_fields
from bie.astro_signals import inspect_curve


def make_csv(rows):
    f = io.StringIO(newline='')
    w = csv.DictWriter(f, fieldnames=COLUMNS)
    w.writeheader()
    w.writerows(rows)
    return f.getvalue().encode()


class ExoplanetTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.lab = ExoplanetLab(self.tmp.name)
        self.rows = [
          dict(pl_name='Test One b', hostname='Test One', sy_dist='2', sy_disterr1='0.2', sy_disterr2='-0.1', pl_rade='1.0', pl_insol='1.0', pl_orbper='10', ra='0', dec='0'),
          dict(pl_name='Test Two c', hostname='Test Two', sy_dist='2', pl_rade='10', pl_insol='50', ra='90', dec='0'),
          dict(pl_name='Distant d', hostname='Distant', sy_dist='', pl_rade='1.0', pl_insol='0.8', ra='270', dec='0')]
        self.csv = make_csv(self.rows)

    def tearDown(self):
        self.tmp.cleanup()

    def test_import_distance(self):
        r = self.lab.import_csv(self.csv)
        self.assertEqual(r['imported'], 3)
        p = self.lab.target('Test One b')['planet']
        self.assertAlmostEqual(p['distance_light_years'], round(2 * PARSEC_LIGHT_YEARS,3))
        self.assertEqual(p['distance_uncertainty_ly'], round(.2*PARSEC_LIGHT_YEARS,3))
        self.assertIsNone(p['life_detected'])

    def test_parse_reject_wrong_schema(self):
        with self.assertRaises(ValueError): parse_archive_csv(b'name,distance\nFake,4\n')

    def test_import_atomic_preserves_previous_on_bad_response(self):
        self.lab.import_csv(self.csv)
        with self.assertRaises(ValueError): self.lab.import_csv(b'<html>Unexpected response</html>')
        self.assertEqual(self.lab.status()['records'], 3)

    def test_missing_distance_stays_missing(self):
        self.lab.import_csv(self.csv)
        p = self.lab.target('Distant d')['planet']
        self.assertIsNone(p['distance_light_years'])
        self.assertEqual(p['screen'], 'follow-up-screen')

    def test_ranking_and_distance_filter(self):
        self.lab.import_csv(self.csv)
        matches = self.lab.search(max_distance_ly=7.0)
        self.assertEqual(matches['matches'], 2)
        self.assertNotIn('Distant d', [p['pl_name'] for p in matches['returned']])

    def test_screen_not_life_claim(self):
        self.lab.import_csv(self.csv)
        rows = self.lab.search(screen_only=True)['returned']
        self.assertEqual(len(rows),2)
        self.assertNotIn('habitable planet confirmed', json.dumps(rows))

    def test_reasoning_packet_provenance(self):
        self.lab.import_csv(self.csv)
        packet = self.lab.target('Test One b')
        self.assertEqual(packet['source_kind'], 'manual_csv')
        self.assertIn('No inference of life', packet['thoughtpacket']['verdict'])

    def test_3d_separation_two_orthogonal_systems(self):
        self.lab.import_csv(self.csv)
        r = self.lab.between('Test One b', 'Test Two c')
        self.assertAlmostEqual(r['host_star_system_separation_ly'], round(2**.5*2*PARSEC_LIGHT_YEARS,3))

    def test_3d_separation_requires_coordinates(self):
        self.rows[1].pop('ra')
        self.lab.import_csv(make_csv(self.rows))
        self.assertIsNone(self.lab.between('Test One b','Test Two c')['stellar_separation_ly'])

    def test_synchronous_fetch_injected_and_labeled(self):
        request_urls = []
        def fake_fetch(url):
            request_urls.append(url)
            return self.csv
        r = self.lab.sync(fetch=fake_fetch)
        self.assertEqual(r['source_kind'],'nasa_tap')
        self.assertEqual(r['imported'],3)
        self.assertIn('pscomppars', request_urls[0])
        self.assertIn('format=csv', request_urls[0])

    def test_non_finite_and_negative_values(self):
        self.rows[0]['sy_dist'] = '-9'
        self.rows[0]['pl_insol'] = 'nan'
        self.rows[0]['ra'] = '999'
        self.lab.import_csv(make_csv(self.rows))
        p = self.lab.target('Test One b')['planet']
        self.assertIsNone(p['distance_light_years'])
        self.assertIsNone(p['ra'])
        self.assertEqual(p['screen'],'insufficient-data')

    def test_export_refuses_overwrite(self):
        self.lab.import_csv(self.csv)
        file = Path(self.tmp.name)/'report.json'
        self.lab.export(file)
        with self.assertRaises(FileExistsError): self.lab.export(file)
        self.assertIn('research_boundary',json.loads(file.read_text()))

    def test_reference_examples(self):
        example = Path(__file__).parents[1]/'examples'/'NASA_REFERENCE_EXAMPLES.csv'
        r = self.lab.import_csv(example.read_bytes(),kind='reference_examples')
        self.assertEqual(r['imported'],3)
        self.assertTrue(4 < self.lab.target('Proxima Cen b')['planet']['distance_light_years'] < 4.5)

    def test_empty_query_and_cap(self):
        self.lab.import_csv(self.csv)
        self.assertEqual(self.lab.search(limit=10000)['matches'],3)
        self.assertEqual(self.lab.search('not-real')['matches'],0)


class LightCurveTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.file = Path(self.tmp.name)/'lc.csv'

    def tearDown(self):
        self.tmp.cleanup()

    def curve(self, dip):
        import random
        random.seed(42)
        with self.file.open('w',newline='') as f:
            w=csv.writer(f);w.writerow(['time','flux'])
            for idx in range(6000):
                t=idx/40.0
                center=abs(t/5 - math.floor(t/5 + .5)) < .08/2
                w.writerow([t,1+random.gauss(0,.001)-(.015 if (dip and center) else 0)])

    def test_dip_repeats_in_separate_cycle_groups(self):
        self.curve(True)
        r=inspect_curve(self.file,5,0)
        self.assertEqual(r['verdict'],'repeatable-dip-for-follow-up')
        self.assertEqual(len(r['holdouts']),2)

    def test_no_dip_no_detection(self):
        self.curve(False)
        r=inspect_curve(self.file,5,0)
        self.assertEqual(r['verdict'],'not-verified')

    def test_bad_csv(self):
        self.file.write_text('x,y\n1,1')
        with self.assertRaises(ValueError): inspect_curve(self.file,5,0)

    def test_reject_invalid_period(self):
        self.curve(True)
        with self.assertRaises(ValueError): inspect_curve(self.file,0,0)

    def test_low_observations(self):
        self.file.write_text('time,flux\n1,1\n2,1\n')
        self.assertEqual(inspect_curve(self.file,5,0)['verdict'],'insufficient-data')


if __name__=='__main__':unittest.main()

class ExoplanetToolIntegrationTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.lab = ExoplanetLab(self.tmp.name)
        self.lab.import_csv(make_csv([dict(pl_name='Assistant Test b', hostname='Assistant Test',sy_dist='3',pl_rade='1.1',pl_insol='1.0')]))
        class FakeStore:
            def __init__(self, home): self.home = Path(home)
            def prior_receipt(self, *args): return None
            def receipt(self, *args): return None
        from bie.tools import ToolRuntime
        self.runtime = ToolRuntime(FakeStore(self.tmp.name), None, None, allow_write=False)

    def tearDown(self): self.tmp.cleanup()

    def test_read_only_tools_exposed_to_assistant(self):
        names = [v['function']['name'] for v in self.runtime.schemas()]
        for tool in ('astro_status','astro_search','astro_target','astro_between'):
            self.assertIn(tool, names)

    def test_assistant_readonly_status_and_target(self):
        r = self.runtime.call('astro_status',{},task_id='q',call_id='status-1')
        self.assertTrue(r['ok'])
        self.assertEqual(r['data']['records'], 1)
        q = self.runtime.call('astro_target',{'name':'Assistant Test b'},task_id='q',call_id='target-1')
        self.assertTrue(q['ok'])
        self.assertEqual(q['data']['planet']['distance_light_years'],round(3*PARSEC_LIGHT_YEARS,3))
        self.assertIsNone(q['data']['planet']['life_detected'])

    def test_bad_tool_args_denied(self):
        with self.assertRaises(ValueError):
            self.runtime.call('astro_search',{'query':'','unauthorized':'yes'},task_id='q',call_id='wrong')
