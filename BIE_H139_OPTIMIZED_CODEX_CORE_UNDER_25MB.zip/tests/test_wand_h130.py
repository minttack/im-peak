"""Independent bounded research-Wand tests, no brokerage credentials or API calls."""
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from bie.wand_h130 import (FocusTask, default_focus_tasks, select_focus,
                           prepare, run_codex, _research_summary, SELF_QUESTION)


class TestWandH130(unittest.TestCase):
    def report(self):
        return {"source_label": "synthetic test only", "selection": {
            "ticker": "DEMOA", "strategy": "cash",
            "holdout_metrics": {"total_return": 0},
            "holdout_excess_over_buy_hold": -.015},
            "next_step": {"proposal": "Check forward-only calendar", "falsifier": "Leakage found",
                          "acceptance_test": "Sealed external data holdout"}}

    def write_report(self, folder):
        path = Path(folder) / "h129.json"
        path.write_text(json.dumps(self.report()), encoding="utf-8")
        return path

    def test_focus_valid_and_budget(self):
        plan = select_focus(default_focus_tasks(), 60)
        self.assertLessEqual(plan["planned_seconds"], 60)
        self.assertGreater(len(plan["tasks"]), 1)
        self.assertIn("NOT physical", plan["interpretation"])

    def test_focus_excludes_duplicates(self):
        x = FocusTask("repeat", 20, 30, 5)
        self.assertEqual(len(select_focus([x, x], 20)["tasks"]), 1)

    def test_focus_ignores_untestable(self):
        x = FocusTask("untestable", 90, 50, 1, False)
        self.assertEqual(select_focus([x], 20)["tasks"], [])

    def test_focus_prioritizes_information_per_second(self):
        tasks = [FocusTask("slow", 50, 0, 50), FocusTask("fast", 50, 50, 4)]
        self.assertEqual(select_focus(tasks, 5)["tasks"][0]["label"], "fast")

    def test_focus_bad_input(self):
        for budget in (0, -1, 3601):
            with self.subTest(budget=budget), self.assertRaises(ValueError):
                select_focus([], budget)
        with self.assertRaises(ValueError):
            select_focus([FocusTask("x", 101, 20, 3)], 5)

    def test_summary_does_not_echo_untrusted_excess(self):
        r = self.report()
        r["selection"]["ticker"] = "X" * 1000
        self.assertEqual(len(_research_summary(r)["chosen_ticker"]), 24)

    def test_prepare_creates_auditable_prompt(self):
        with tempfile.TemporaryDirectory() as td:
            report = self.write_report(td)
            out = Path(td)/"run"
            result = prepare(report, out)
            self.assertFalse(result["codex_executed"])
            self.assertFalse(result["broker_connected"])
            mission = json.loads((out/"mission.json").read_text())
            self.assertEqual(mission["permissions"]["broker_orders"], "DISABLED")
            self.assertEqual(mission["self_question"], SELF_QUESTION)
            prompt = (out/"codex_prompt.txt").read_text()
            self.assertIn("DO NOT access Robinhood MCP", prompt)
            self.assertIn("falsifiable", prompt)
            self.assertIn("NEVER repeat", prompt)

    def test_prepare_immutable_run_dir(self):
        with tempfile.TemporaryDirectory() as td:
            report = self.write_report(td)
            out = Path(td)/"run"
            prepare(report,out)
            with self.assertRaises(FileExistsError):
                prepare(report,out)

    def test_prepare_rejects_bad_report(self):
        with tempfile.TemporaryDirectory() as td:
            bad = Path(td)/"bad.json"
            bad.write_text('{"selection": 5, "next_step": {}}')
            with self.assertRaises(ValueError):
                prepare(bad,Path(td)/"run")

    def test_missing_codex_reports_not_invoked(self):
        with tempfile.TemporaryDirectory() as td:
            report = self.write_report(td)
            out = Path(td)/"run"
            prepare(report,out)
            project = Path(__file__).resolve().parents[1]
            with patch('bie.wand_h130.shutil.which', return_value=None):
                result = run_codex(project,out)
            self.assertEqual(result["status"],"codex_unavailable")
            self.assertEqual(result["attempts"],[])
            self.assertFalse((out/"verification_summary.json").exists())

    def test_no_change_not_false_success_and_broker_mcp_disabled(self):
        with tempfile.TemporaryDirectory() as td:
            report = self.write_report(td)
            out = Path(td)/"run"
            prepare(report, out)
            project = Path(__file__).resolve().parents[1]
            calls = []
            def fake_run(command, cwd, timeout, stdin=None):
                calls.append(command)
                return {"exit_code": 0, "seconds": 0.01, "output_tail": "simulated pass"}
            with patch('bie.wand_h130.shutil.which', return_value='/fake/codex'), \
                 patch('bie.wand_h130._run', side_effect=fake_run):
                result = run_codex(project, out, attempts=1)
            self.assertEqual(result["status"], "not_verified")
            self.assertIn("mcp_servers.robinhood-trading.enabled=false", calls[0])
            detail = json.loads((out / "codex_attempt_1" / "result.json").read_text())
            self.assertFalse(detail["source_changed_this_attempt"])
            self.assertFalse(detail["passed"])

    def test_zero_information_is_not_scheduled(self):
        tasks = [FocusTask("unhelpful", 0, 0, 2)]
        self.assertEqual(select_focus(tasks, 10)["tasks"], [])

    def test_attempt_limits(self):
        with tempfile.TemporaryDirectory() as td:
            with self.assertRaises(ValueError):
                run_codex(td,td,attempts=9)
            with self.assertRaises(ValueError):
                run_codex(td,td,seconds_per_attempt=1)


if __name__ == "__main__":
    unittest.main()
