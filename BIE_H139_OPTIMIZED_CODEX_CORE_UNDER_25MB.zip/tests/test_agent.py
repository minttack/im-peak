import copy
import json
from pathlib import Path
import tempfile
import unittest

from bie.agent import Assistant, fit_context, SYSTEM
from bie.model import ModelUnavailable
from bie.tools import ToolRuntime, PermissionNeeded
from bie.workspace import Workspace


def call(name, **args):
    return {"function": {"name": name, "arguments": args}}


class ScriptedProvider:
    """Protocol fixture, deliberately not a real LLM or intelligence benchmark."""
    def __init__(self, steps):
        self.steps = iter(steps)
        self.prompts = []

    def reply(self, messages, tools, budget, cancel, on_text, deadline):
        self.prompts.append(copy.deepcopy(messages))
        step = next(self.steps)
        if isinstance(step, Exception):
            raise step
        if isinstance(step, str):
            on_text(step)
            result = {"role": "assistant", "content": step, "tool_calls": []}
        else:
            result = {"role": "assistant", "content": "", "tool_calls": copy.deepcopy(step)}
        return result, {"elapsed_ms": 1., "source": "test fixture"}


class AgentTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)

    def tearDown(self):
        self.temp.cleanup()

    def assistant(self, steps):
        self.provider = ScriptedProvider(steps)
        return Assistant(self.root / "state", provider_factory=lambda model: self.provider)

    def submit(self, app, **kwargs):
        return app.submit("Build the requested useful increment", workspace=self.root / "project", **kwargs)

    def test_multistep_coding_executes_real_tests(self):
        app = self.assistant([
            [call("project_write", path="maths.py", content="def square(x):\n    return x*x\n", expected_sha256="")],
            [call("project_write", path="tests/test_square.py", content="import unittest\nfrom maths import square\nclass Tests(unittest.TestCase):\n    def test_square(self):\n        self.assertEqual(square(-4),16)\n        self.assertEqual(square(0),0)\n", expected_sha256="")],
            "Implemented square and regression coverage."
        ])
        tid = self.submit(app, allow_exec=True)
        result = app.run(tid)
        self.assertEqual(result["status"], "done", result["error"])
        self.assertEqual(result["calls"], 3)
        self.assertIn("tests passed", result["output"])
        self.assertTrue(app.store.audit()["passed"])

    def test_syntax_failure_triggers_correction_before_completion(self):
        broken = "def nope(:\n"
        import hashlib
        app = self.assistant([
            [call("project_write", path="a.py", content=broken, expected_sha256="")],
            "Done.",
            [call("project_write", path="a.py", content="answer = 42\n", expected_sha256=hashlib.sha256(broken.encode()).hexdigest())],
            "Corrected syntax."
        ])
        tid = self.submit(app)
        result = app.run(tid)
        self.assertEqual(result["status"], "done", result)
        self.assertIn("Application verification failed", json.dumps(self.provider.prompts[2]))
        self.assertEqual((self.root / "project/a.py").read_text(), "answer = 42\n")

    def test_budget_resume_preserves_pending_calls_without_duplicates(self):
        writes = [call("project_write", path=f"note{i}.txt", content=f"unique {i}", expected_sha256="") for i in range(9)]
        app = self.assistant([writes, "Finished all nine files."])
        tid = self.submit(app, profile="Quick")
        first = app.run(tid)
        self.assertEqual(first["status"], "paused")
        self.assertEqual(first["calls"], 8)
        app.store.resume(tid)
        second = app.run(tid)
        self.assertEqual(second["status"], "done", second)
        self.assertEqual(second["calls"], 9)
        self.assertEqual(len(list((self.root / "project").glob("*.txt"))), 9)
        self.assertTrue(app.store.audit()["passed"])

    def test_receipt_prevents_repeating_side_effect_after_interrupted_checkpoint(self):
        app = self.assistant(["Resumed."])
        tid = self.submit(app)
        task = app.store.claim(task_id=tid)
        cid = tid + ":1:0"
        action = call("memory_note", text="Preserve one observation", subject="checkpoint")
        action["id"] = cid
        messages = [{"role": "system", "content": SYSTEM}, {"role": "user", "content": "Remember"},
                    {"role": "assistant", "content": "", "tool_calls": [action]}]
        runtime = ToolRuntime(app.store, app.bridge, Workspace(self.root / "project", self.root / "backups"))
        runtime.call("memory_note", action["function"]["arguments"], task_id=tid, call_id=cid)
        app.store.checkpoint(tid, task["owner"], messages=messages, round_number=1, calls=0, status="paused")
        app.store.resume(tid)
        self.assertEqual(app.run(tid)["status"], "done")
        self.assertEqual(len(app.store.recall("observation")), 1)

    def test_model_cannot_enable_execution_or_arbitrary_commands(self):
        app = self.assistant([[call("python_tests")]])
        tid = self.submit(app)
        result = app.run(tid)
        self.assertEqual(result["status"], "waiting")
        options = json.loads(result["options"])
        self.assertFalse(options["allow_exec"])
        runtime = ToolRuntime(app.store, app.bridge, Workspace(self.root / "project", self.root / "backups"))
        with self.assertRaises(ValueError):
            runtime.call("shell", {"command": "anything"}, task_id=tid, call_id="bad")
        with self.assertRaises(ValueError):
            runtime.call("python_tests", {"allow_exec": True}, task_id=tid, call_id="bad2")

    def test_user_can_grant_execution_to_a_waiting_task(self):
        app = self.assistant([[call("python_tests")], "Tests finished."])
        project = self.root / "project"
        (project / "tests").mkdir(parents=True)
        (project / "tests/test_ok.py").write_text("import unittest\nclass T(unittest.TestCase):\n    def test_one(self): self.assertEqual(3+3,6)\n")
        tid = self.submit(app)
        self.assertEqual(app.run(tid)["status"], "waiting")
        app.store.set_execution(tid, True)
        app.store.resume(tid)
        self.assertEqual(app.run(tid)["status"], "done")
        self.assertTrue(app.store.audit()["passed"])

    def test_missing_model_pauses_with_honest_status(self):
        app = self.assistant([ModelUnavailable("No model installed")])
        tid = self.submit(app)
        result = app.run(tid)
        self.assertEqual(result["status"], "paused")
        self.assertIn("No model", result["error"])
        self.assertEqual(result["calls"], 0)

    def test_readonly_task_does_not_write(self):
        app = self.assistant([[call("project_write", path="new.txt", content="no", expected_sha256="")]])
        tid = self.submit(app, allow_write=False)
        self.assertEqual(app.run(tid)["status"], "waiting")
        self.assertFalse((self.root / "project/new.txt").exists())

    def test_repeated_identical_failure_stops(self):
        bad = [call("project_read", path="missing")]
        app = self.assistant([bad, bad, bad])
        result = app.run(self.submit(app))
        self.assertEqual(result["status"], "failed")
        self.assertIn("three times", result["error"])

    def test_cancel_does_not_execute_next_action(self):
        app = self.assistant([[call("project_write", path="one.txt", content="one", expected_sha256=""),
                               call("project_write", path="two.txt", content="two", expected_sha256="")]])
        tid = self.submit(app)
        def event(kind, data):
            if kind == "tool_finished":
                app.cancel(tid)
        result = app.run(tid, on_event=event)
        self.assertEqual(result["status"], "cancelled")
        self.assertTrue((self.root / "project/one.txt").exists())
        self.assertFalse((self.root / "project/two.txt").exists())

    def test_later_task_receives_recent_conversation_and_experience(self):
        app = self.assistant([[call("project_list", path=".")], "First remembered response.", "Second response."])
        app.run(self.submit(app))
        app.run(self.submit(app))
        context = self.provider.prompts[-1][0]["content"]
        self.assertIn("First remembered response", context)
        self.assertIn("project_list", context)
        self.assertIn("predicted_ms_from_recent_median", context)

    def test_project_cannot_be_assistant_state_or_program_directory(self):
        app = self.assistant([])
        from bie.config import PACKAGE
        for path in (app.home, app.home / "backups", app.home / "native_v8", app.home.parent, PACKAGE, PACKAGE / "bie"):
            with self.assertRaises(ValueError):
                app.submit("goal", workspace=path)

    def test_context_compaction_preserves_goal_and_tool_group(self):
        messages = [{"role": "system", "content": "system"}, {"role": "user", "content": "original goal"},
                    {"role": "assistant", "content": "old" * 1500},
                    {"role": "assistant", "content": "", "tool_calls": [{"id": "x", "function": {"name": "project_read", "arguments": {"path": "x"}}}]},
                    {"role": "tool", "tool_call_id": "x", "content": "result"}]
        packed = fit_context(messages, 2000)
        self.assertEqual(packed[1]["content"], "original goal")
        self.assertEqual(packed[-2]["tool_calls"][0]["id"], packed[-1]["tool_call_id"])
        self.assertLessEqual(len(json.dumps(packed)), 2000)
