import json
from pathlib import Path
import sqlite3
import tempfile
import unittest
from unittest.mock import patch

from bie.datahub import KnowledgeHub
from bie.network_storage import _parse_advertisement, discover_storage, discover_ssdp
from bie.public_data import get_json, search_public, save_results


class KnowledgeHubTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        base = Path(self.temp.name)
        self.share = base / "nas"
        self.share.mkdir()
        self.hub = KnowledgeHub(base / "state")

    def tearDown(self):
        self.temp.cleanup()

    def test_storage_opt_in_then_index_and_retrieve(self):
        (self.share / "note.md").write_text("Recoil daughters: unverified BIE evidence", encoding="utf-8")
        reg = self.hub.register_storage("NAS", str(self.share))
        self.assertIn("No files indexed yet", reg["notice"])
        self.assertEqual(self.hub.search("recoil"), [])
        result = self.hub.import_storage("NAS")
        self.assertEqual(result["imported"], 1)
        hits = self.hub.search("recoil")
        self.assertEqual(len(hits), 1)
        self.assertEqual(hits[0]["origin"], "storage:NAS")
        self.assertEqual(hits[0]["evidence"], "unverified")
        self.assertEqual(len(self.hub.search("recoil")), 1)
        self.hub.import_storage("NAS")
        self.assertEqual(self.hub.status()["documents"], 1)
        (self.share / "note.md").write_text("Entirely changed trusted input", encoding="utf-8")
        self.hub.import_storage("NAS")
        self.assertEqual(self.hub.search("recoil"), [])
        self.assertEqual(len(self.hub.search("entirely")), 1)
        self.assertEqual(self.hub.status()["documents"], 1)

    def test_no_symlinks_secrets_or_subfolder_implicit_import(self):
        (self.share / "notes.txt").write_text("ordinary data")
        (self.share / ".env").write_text("SECRET=should-never-index")
        (self.share / "passwords.csv").write_text("bank password")
        (self.share / "long.csv").write_bytes(b"x" * 2_000_100)
        nested = self.share / "nested"
        nested.mkdir()
        (nested / "other.md").write_text("buried evidence")
        (self.share / "pointer.md").symlink_to(nested / "other.md")
        self.hub.register_storage("NAS", str(self.share))
        imported = self.hub.import_storage("NAS")
        self.assertEqual(imported["imported"], 1)
        self.assertEqual(self.hub.search("buried"), [])
        self.assertEqual(self.hub.search("should-never-index"), [])
        self.assertIn("nested", [x["name"] for x in self.hub.browse("NAS")["items"]])
        imported_nested = self.hub.import_storage("NAS", "nested")
        self.assertEqual(imported_nested["imported"], 1)
        self.assertEqual(len(self.hub.search("buried")), 1)

    def test_no_path_escape_no_parent_or_state(self):
        self.hub.register_storage("NAS", str(self.share))
        with self.assertRaises(ValueError):
            self.hub.browse("NAS", "../")
        with self.assertRaises(ValueError):
            self.hub.import_storage("NAS", "../")
        with self.assertRaises(ValueError):
            self.hub.register_storage("BIE", str(self.hub.home))
        with self.assertRaises(ValueError):
            self.hub.register_storage("BIE", str(self.hub.home.parent))
        with self.assertRaises(ValueError):
            self.hub.register_storage("INVALID!", str(self.share))

    def test_remove_does_not_destroy_imported_evidence(self):
        (self.share / "note.txt").write_text("measured alpha")
        self.hub.register_storage("NAS", str(self.share))
        self.hub.import_storage("NAS")
        self.assertTrue(self.hub.remove_storage("NAS")["removed"])
        self.assertEqual(len(self.hub.search("measured")), 1)

    def test_csv_is_never_executed(self):
        (self.share / "metrics.csv").write_text('test,score\nA,"=CMD(foo)"\nB,99\n')
        self.hub.register_storage("NAS", str(self.share))
        self.hub.import_storage("NAS")
        self.assertIn("metrics.csv", self.hub.search("CMD")[0]["title"])


class PublicDataTests(unittest.TestCase):
    def test_openalex_fixed_domain_and_records(self):
        urls = []
        def fake(url):
            urls.append(url)
            return {"results": [{"id": "https://openalex.org/W001", "title": "Brain research",
                                 "doi": "https://doi.org/10.example", "type": "article", "publication_year": 2025}]}
        r = search_public("openalex", "glioblastoma 225Ac", fetch=fake)
        self.assertEqual(r["count"], 1)
        self.assertFalse(r["saved"])
        self.assertTrue(urls[0].startswith("https://api.openalex.org/works?"))
        self.assertNotIn("local", urls[0])

    def test_pubmed_two_request_search_summary(self):
        urls=[]
        def fake(url):
            urls.append(url)
            if "esearch.fcgi" in url:
                return {"esearchresult": {"idlist": ["123", "999"]}}
            return {"result": {"123": {"title": "Real Article", "pubdate": "2024"},
                               "999": {"title": "Another", "pubdate": "2025"}}}
        r=search_public("pubmed", "care", fetch=fake)
        self.assertEqual(r["count"], 2)
        self.assertEqual(len(urls), 2)
        self.assertEqual(r["records"][0]["url"], "https://pubmed.ncbi.nlm.nih.gov/123/")

    def test_crossref_bibliographic(self):
        result = search_public("crossref", "quantum materials", fetch=lambda url: {"message":{"items":[
            {"DOI":"10.1/x", "title":["Published paper"], "published":{"date-parts":[[2025,2,1]]}, "URL":"https://doi.org/10.1/x"}]}})
        self.assertEqual(result["records"][0]["year"],2025)
        self.assertEqual(result["records"][0]["title"],"Published paper")

    def test_wikipedia_strips_markup_and_links_by_pageid(self):
        result=search_public("wikipedia","remote storage",fetch=lambda url: {"query":{"search":[
            {"title":"NAS", "pageid":123,"snippet":"A <span class='searchmatch'>network</span> device"}]}})
        self.assertEqual(result["records"][0]["url"],"https://en.wikipedia.org/?curid=123")
        self.assertNotIn("<span",result["records"][0]["description"])

    def test_worldbank_requires_country_indicator_code(self):
        with self.assertRaises(ValueError):
            search_public("worldbank","soup",fetch=lambda _: {})
        result=search_public("worldbank","US:SP.POP.TOTL", fetch=lambda _: [{"page":1},[
            {"country":{"value":"United States"},"indicator":{"value":"Population total"},
             "countryiso3code":"USA","date":"2024","value":123}]])
        self.assertEqual(result["records"][0]["description"],"Value: 123")

    def test_save_is_explicit(self):
        with tempfile.TemporaryDirectory() as d:
            hub=KnowledgeHub(Path(d)/"state")
            r=search_public("openalex", "medicine", fetch=lambda url: {"results":[
                {"id":"https://openalex.org/W20", "title":"Medicine Study", "publication_year":2024}]})
            self.assertEqual(hub.status()["documents"], 0)
            self.assertEqual(save_results(hub,r)["imported"],1)
            self.assertEqual(hub.search("Medicine")[0]["evidence"], "external-source-unverified")

    def test_reject_arbitrary_urls_and_provider(self):
        for url in ["http://api.openalex.org/works", "https://127.0.0.1/private",
                    "https://api.openalex.org.attacker.tld/", "file:///etc/passwd"]:
            with self.assertRaises(ValueError):
                get_json(url)
        with self.assertRaises(ValueError):
            search_public("external", "x", fetch=lambda _: {})


class WifiDiscoveryTests(unittest.TestCase):
    def test_parses_advertisement_without_fetching_url(self):
        result=_parse_advertisement(b'HTTP/1.1 200 OK\r\nST: upnp:rootdevice\r\nLOCATION: http://192.168.0.42:80/description.xml\r\nUSN: xyz\r\n\r\n',"192.168.0.42")
        self.assertEqual(result["advertised_host"], "192.168.0.42")
        self.assertFalse(result["connected"])
        self.assertIsNone(result["share_path"])

    def test_resists_blocked_multicast(self):
        def blocked(*a):
            raise OSError("not available")
        devices, warning = discover_ssdp(seconds=.2, socket_factory=blocked)
        self.assertEqual(devices, [])
        self.assertIn("unavailable", warning)

    def test_aggregate_results_no_bypass(self):
        with patch("bie.network_storage.discover_ssdp",return_value=([{"type":"NAS"}],None)), patch(
             "bie.network_storage.windows_network_servers",return_value=([],None)):
            result=discover_storage()
        self.assertEqual(len(result["devices"]),1)
        self.assertTrue(result["no_subnet_scan"])
        self.assertTrue(result["no_credentials_collected"])


if __name__=='__main__':
    unittest.main()
