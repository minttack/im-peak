"""Offline, deterministic gates for the Auto -> MaximumSafe target."""
import json
import tempfile
from pathlib import Path
import unittest

from bie.learning_accelerator import LearningAccelerator, PROFILES


class AutoMaxTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.home = Path(self.tmp.name)
        self.accel = LearningAccelerator(self.home)
        self.manifest = self.home / 'jobs.json'

    def jobs(self, prefix, total=24):
        self.manifest.write_text(json.dumps({'jobs': [
            {'provider': 'openalex', 'query': f'{prefix} topic {i}', 'limit': 1}
            for i in range(total)
        ]}), encoding='utf-8')
        return self.manifest

    def good(self, provider, query, limit):
        return {'provider': provider, 'records': [
            {'title': query, 'url': 'https://example.org/research/' + query.replace(' ', '_')}
        ]}

    def bad(self, provider, query, limit):
        raise RuntimeError('synthetic rate limit')

    def test_default_auto_targets_max_safely(self):
        p = self.accel.plan(self.jobs('initial'))
        self.assertEqual(p['requested_profile'], 'Auto')
        self.assertEqual(p['auto_target'], 'MaximumSafe')
        self.assertEqual(p['selected_profile'], 'Balanced')
        self.assertTrue(p['requires_manual_confirmation'])
        self.assertEqual(p['network_requests_this_command'], 0)
        self.assertEqual(PROFILES['MaximumSafe'].workers, 4)
        with self.assertRaises(PermissionError):
            self.accel.run(self.manifest, pace=False, fetch=self.good)

    def test_auto_climbs_to_max_then_drops_on_failures(self):
        first = self.accel.run(self.jobs('first'), confirmed=True, fetch=self.good, pace=False)
        self.assertEqual(first['selected_profile'], 'Balanced')
        self.assertEqual(self.accel.plan(self.jobs('second'))['selected_profile'], 'Accelerated')
        second = self.accel.run(self.manifest, confirmed=True, fetch=self.good, pace=False)
        self.assertEqual(second['selected_profile'], 'Accelerated')
        self.assertEqual(self.accel.plan(self.jobs('third'))['selected_profile'], 'MaximumSafe')
        third = self.accel.run(self.manifest, confirmed=True, fetch=self.bad, pace=False)
        self.assertEqual(third['selected_profile'], 'MaximumSafe')
        status = self.accel.status()
        self.assertEqual(status['default_profile'], 'Auto')
        self.assertEqual(status['auto_target'], 'MaximumSafe')
        self.assertEqual(status['auto_next_selected_profile'], 'Evidence')

    def test_no_scaling_on_repeats_or_small_batches(self):
        self.accel.run(self.jobs('repeat'), confirmed=True, fetch=self.good, pace=False)
        self.assertEqual(self.accel.plan(self.jobs('repeat'), start_at=0)['selected_profile'], 'Accelerated')
        second = self.accel.run(self.manifest, start_at=0, confirmed=True, fetch=self.good, pace=False)
        self.assertEqual(second['new_references'], 0)
        self.assertEqual(self.accel.plan(self.manifest)['selected_profile'], 'Accelerated')
        other = self.accel.run(self.jobs('small', 2), confirmed=True, fetch=self.good, pace=False)
        self.assertEqual(other['completed_jobs'], 2)
        self.assertEqual(self.accel.plan(self.jobs('new'))['selected_profile'], 'Accelerated')

    def test_moderate_failures_drop_one_level(self):
        self.accel.run(self.jobs('first'), confirmed=True, fetch=self.good, pace=False)
        self.accel.run(self.jobs('second'), confirmed=True, fetch=self.good, pace=False)
        self.assertEqual(self.accel.plan(self.jobs('third'))['selected_profile'], 'MaximumSafe')
        def some_fail(provider, query, limit):
            # 3 of 24 = 12.5%, should step back exactly one rung.
            if query.endswith(('topic 1', 'topic 2', 'topic 3')):
                raise RuntimeError('synthetic provider intermittent failure')
            return self.good(provider, query, limit)
        r = self.accel.run(self.manifest, confirmed=True, fetch=some_fail, pace=False)
        self.assertEqual(r['failed_jobs'], 3)
        self.assertEqual(self.accel.plan(self.jobs('fourth'))['selected_profile'], 'Accelerated')


if __name__ == '__main__':
    unittest.main()
