from concurrent.futures import ProcessPoolExecutor
import json
from pathlib import Path
import tempfile
import unittest

from bie.store import Store


def claim_one(home):
    task = Store(Path(home)).claim()
    return task["id"] if task else None


class MemoryTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.store = Store(self.root)

    def tearDown(self):
        self.temp.cleanup()

    def test_recall_persists_with_provenance(self):
        self.store.remember("Orlando uses BIE for modular coding", source="user", confidence=.6)
        hit = Store(self.root).recall("modular")[0]
        self.assertEqual(hit["source"], "user")
        self.assertEqual(hit["status"], "unverified")
        self.assertEqual(hit["confidence"], .6)

    def test_correction_preserves_replay_without_future_leakage(self):
        first = self.store.remember("The project color is blue", subject="color")
        second = self.store.remember("The project color is green", subject="color", supersedes=first["id"], status="corrected")
        self.assertEqual(self.store.recall("color")[0]["id"], second["id"])
        self.assertEqual(self.store.recall("color", before=second["created_seq"])[0]["id"], first["id"])
        self.assertEqual(self.store.recall("color", before=first["created_seq"]), [])
        self.assertTrue(self.store.audit()["passed"])

    def test_conflicting_claims_remain_separate(self):
        self.store.remember("Benchmark result is fast", subject="benchmark", source="run-a")
        self.store.remember("Benchmark result is slow", subject="benchmark", source="run-b")
        self.assertEqual(len(self.store.recall("benchmark")), 2)

    def test_correction_cannot_cross_scope_or_retire_twice(self):
        first = self.store.remember("Project constraint", subject="build", scope="project-a")
        with self.assertRaises(ValueError):
            self.store.remember("Replace", subject="build", scope="project-b", supersedes=first["id"])
        self.store.remember("New constraint", subject="build", scope="project-a", supersedes=first["id"])
        with self.assertRaises(ValueError):
            self.store.remember("Again", subject="build", scope="project-a", supersedes=first["id"])

    def test_fts_input_is_data_not_query_syntax(self):
        self.store.remember('alpha near project')
        self.assertIsInstance(self.store.recall('" OR * - NEAR(foo) :'), list)
        self.assertEqual(self.store.recall("alpha", scope="elsewhere"), [])

    def test_nonfinite_confidence_rejected(self):
        for value in (float("nan"), float("inf"), -1, 2, True):
            with self.assertRaises(ValueError):
                self.store.remember("test", confidence=value)

    def test_integer_confidence_preserves_audit(self):
        self.store.remember("Observed test", confidence=1)
        self.assertTrue(self.store.audit()["passed"])

    def test_deleted_and_modified_memory_are_detected(self):
        item = self.store.remember("Original evidence")
        with self.store.db(write=True) as con:
            con.execute("UPDATE memories SET body='Changed' WHERE id=?", (item["id"],))
        self.assertFalse(self.store.audit()["passed"])

    def test_fts_tampering_is_detected(self):
        self.store.remember("Stored observation")
        with self.store.db(write=True) as con:
            con.execute("DELETE FROM memory_fts")
        self.assertFalse(self.store.audit()["passed"])

    def test_event_tampering_is_detected(self):
        self.store.remember("Stored observation")
        with self.store.db(write=True) as con:
            con.execute("UPDATE events SET payload='{}'")
        self.assertFalse(self.store.audit()["passed"])

    def test_message_deletion_is_detected(self):
        self.store.message("x", "user", "An actual request")
        with self.store.db(write=True) as con:
            con.execute("DELETE FROM messages")
        self.assertFalse(self.store.audit()["passed"])


class TaskTests(MemoryTests):
    # Do not repeat inherited MemoryTests here; these tests focus on task state.
    def test_cross_process_single_claim(self):
        tid = self.store.enqueue("One job", self.root / "project", {})
        with ProcessPoolExecutor(max_workers=6) as pool:
            results = list(pool.map(claim_one, [str(self.root)] * 6))
        self.assertEqual(results.count(tid), 1)
        self.assertTrue(self.store.audit()["passed"])

    def test_same_workspace_serializes_and_other_workspace_can_run(self):
        a = self.store.enqueue("one", self.root / "a", {})
        b = self.store.enqueue("two", self.root / "a", {})
        c = self.store.enqueue("three", self.root / "b", {})
        self.assertEqual(self.store.claim()["id"], a)
        self.assertIsNone(self.store.claim(task_id=b))
        self.assertEqual(self.store.claim()["id"], c)

    def test_expired_work_is_paused_without_silent_replay(self):
        tid = self.store.enqueue("job", self.root / "a", {})
        self.store.claim(lease_seconds=-1)
        self.assertIsNone(self.store.claim())
        self.assertEqual(self.store.task(tid)["status"], "paused")
        self.store.resume(tid)
        self.assertEqual(self.store.claim()["id"], tid)

    def test_only_current_worker_can_finish(self):
        tid = self.store.enqueue("job", self.root / "a", {})
        claimed = self.store.claim()
        with self.assertRaises(RuntimeError):
            self.store.checkpoint(tid, "wrong", messages=[], round_number=0, calls=0, status="done")
        self.store.checkpoint(tid, claimed["owner"], messages=[], round_number=0, calls=0, status="done")
        self.assertTrue(self.store.audit()["passed"])

    def test_receipt_idempotency_rejects_argument_changes(self):
        self.store.receipt("call", "job", "tool", {"a": 1}, {"ok": True}, 4., True)
        self.assertEqual(self.store.prior_receipt("call", "tool", {"a": 1}), {"ok": True})
        with self.assertRaises(ValueError):
            self.store.prior_receipt("call", "tool", {"a": 2})
        self.assertTrue(self.store.audit()["passed"])

    def test_task_row_tampering_and_deletion_detected(self):
        tid = self.store.enqueue("job", self.root / "a", {})
        with self.store.db(write=True) as con:
            con.execute("DELETE FROM tasks WHERE id=?", (tid,))
        self.assertFalse(self.store.audit()["passed"])

    def test_experience_is_project_scoped_and_chronological(self):
        a = self.store.enqueue("job", self.root / "a", {})
        b = self.store.enqueue("job", self.root / "b", {})
        cutoff = self.store.head() + 1
        self.store.receipt("a", a, "test", {}, {"ok": False, "error": "syntax"}, 10., False)
        self.store.receipt("b", b, "test", {}, {"ok": True}, 1., True)
        self.assertEqual(self.store.experience(self.root / "a", cutoff)["project_scoped_tool_outcomes"], {})
        self.assertEqual(self.store.experience(self.root / "a")["project_scoped_tool_outcomes"]["test"]["failures"], 1)


# Reuse setup/teardown without duplicating inherited test methods.
for _name in list(MemoryTests.__dict__):
    if _name.startswith("test_"):
        setattr(TaskTests, _name, None)
