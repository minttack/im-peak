"""Independent adversarial H136 offline research acceptance checks."""
import copy
from datetime import timedelta
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

from bie import familiarity_money_h136 as h


class TestFamiliarityMoneyH136(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.base = h.synthetic(13601, 'familiarity_signal', 95)
        cls.result = h.analyze(cls.base)

    def mutate(self, mutator):
        obj = copy.deepcopy(self.base)
        mutator(obj)
        return obj

    def test_offline_and_no_orders(self):
        self.assertTrue(self.result['no_live_broker_calls'])
        self.assertIn('NO_BROKER_ORDERS', self.result['decision'])
        self.assertTrue(all(x['no_real_orders'] for x in self.result['paper_portfolio'].values()))

    def test_shadow_pnl_reconciles(self):
        audit = self.result['simulated_audit']
        self.assertAlmostEqual(audit[-1]['virtual_after'] - 10000,
                               self.result['paper_portfolio']['pnl_feedback_guard']['net_pnl_dollars'], delta=.011)

    def test_no_signal_abstains(self):
        r = h.analyze(h.synthetic(13601, 'null', 95))
        if r['pre_holdout_policy_selection']['selected'] == 'prior':
            self.assertEqual(r['paper_portfolio']['pnl_feedback_guard']['paper_rebalance_trades'], 0)

    def test_sectors_and_exposure_limit(self):
        for d in self.result['simulated_audit']:
            self.assertLessEqual(d['exposure_fraction'], 0.30001)
            sectors = [h.SECTORS[t] for t in d['selected_tickers']]
            self.assertEqual(len(sectors), len(set(sectors)))

    def test_predeclared_drift_guard(self):
        r = h.analyze(h.synthetic(13601, 'familiarity_trap', 95))
        self.assertTrue(any(d['drift_guard_active'] for d in r['simulated_audit']) is False)
        # Note: the published H136 shadow audit represents the regular feedback guard;
        # compare the other guard via its independent portfolio metrics.
        self.assertIn('drift_guard_precommitted', r['paper_portfolio'])

    def test_observed_simulated_market_costs(self):
        r = self.result['paper_portfolio']['pnl_feedback_guard']
        self.assertGreaterEqual(r['transaction_costs_dollars'], 0)
        self.assertGreaterEqual(r['paper_rebalance_trades'], 0)

    def test_liquidity_cost_rises_with_size(self):
        row = {'spread':12.,'volume':20000.}
        self.assertGreater(h._cost_bps(1000,row),h._cost_bps(100,row))

    def test_dollar_scale_cost_is_not_free(self):
        row = {'spread':12.,'volume':20000.}
        self.assertGreater(1000*h._cost_bps(1000,row),100*h._cost_bps(100,row))

    def test_missing_schema(self):
        with self.assertRaises(ValueError):
            h.validate(self.mutate(lambda d: d.update(schema='wrong')))

    def test_negative_or_future_date(self):
        with self.assertRaises(ValueError):
            h.validate(self.mutate(lambda d: d.update(as_of_utc='2020-01-01T00:00:00+00:00')))

    def test_future_feature_rejected(self):
        def f(d):
            r=d['rows'][0]
            r['signals']['trend']['observed_at_utc']=(h.utc(r['decision_at_utc'])+timedelta(days=1)).isoformat()
        with self.assertRaisesRegex(ValueError,'future|Future'):
            h.validate(self.mutate(f))

    def test_stale_feature_not_used(self):
        def f(d):
            r=d['rows'][0]
            r['signals']['attention']['observed_at_utc']=(h.utc(r['decision_at_utc'])-timedelta(days=40)).isoformat()
        _,dates,data=h.validate(self.mutate(f))
        self.assertNotIn('attention',data[(dates[0],h.STOCKS[0])]['x'])

    def test_bad_source(self):
        with self.assertRaisesRegex(ValueError,'provenance'):
            h.validate(self.mutate(lambda d: d['rows'][0]['signals']['trend'].update(source='secret_instructions')))

    def test_fake_historical_rejected(self):
        with self.assertRaisesRegex(ValueError,'Synthetic'):
            h.validate(self.mutate(lambda d: d.update(source_mode='historical_user_supplied')))

    def test_unknown_feature(self):
        with self.assertRaisesRegex(ValueError,'signal'):
            h.validate(self.mutate(lambda d: d['rows'][0]['signals'].update(fake={'value':1})))

    def test_nan_feature(self):
        with self.assertRaisesRegex(ValueError,'range'):
            h.validate(self.mutate(lambda d: d['rows'][0]['signals']['trend'].update(value=float('nan'))))

    def test_bool_price_rejected(self):
        with self.assertRaises(ValueError):
            h.validate(self.mutate(lambda d: d['rows'][0].update(close=True)))

    def test_negative_price_rejected(self):
        with self.assertRaises(ValueError):
            h.validate(self.mutate(lambda d: d['rows'][0].update(close=-1)))

    def test_duplicate_ticker_date(self):
        with self.assertRaisesRegex(ValueError,'Duplicate'):
            h.validate(self.mutate(lambda d: d['rows'].append(d['rows'][0])))

    def test_missing_ticker_rejected(self):
        with self.assertRaises(ValueError):
            h.validate(self.mutate(lambda d: d['rows'].pop(0)))

    def test_unknown_ticker(self):
        with self.assertRaises(ValueError):
            h.validate(self.mutate(lambda d: d['rows'][0].update(ticker='FAKE')))

    def test_nonfinite_budget(self):
        with self.assertRaises(ValueError):
            h.analyze(self.base,virtual_budget=float('inf'))

    def test_independent_benchmark_series(self):
        _, dates, data = h.validate(self.base)
        path_spy = [data[(d,'SPY')]['close'] for d in dates]
        path_qqq = [data[(d,'QQQ')]['close'] for d in dates]
        self.assertNotEqual(path_spy, path_qqq)

    def test_reverse_guard_tracks_matured_errors_only(self):
        _, dates, data = h.validate(h.synthetic(13601,'familiarity_trap',100))
        start = int(len(dates) * .75)
        check = h._paper(data,dates,start,10000,'trend_familiarity',dynamic=True,drift_guard=True)
        self.assertTrue(any(day['drift_guard_active'] for day in check['audit']))

    def test_not_live_proof(self):
        self.assertEqual(self.result['source_mode'], 'synthetic')
        self.assertIn('unverified', self.result['provenance_status'])

    def test_no_advance_future_prices_in_prediction(self):
        _, dates, data = h.validate(self.base)
        start = int(len(dates)*.75)
        pred = h._paper(data,dates,start,10000.,'trend_familiarity',dynamic=True)
        altered = copy.deepcopy(data)
        later = dates[start+8]
        altered[(later,h.STOCKS[0])]['close'] *= 1.4
        pred2 = h._paper(altered,dates,start,10000.,'trend_familiarity',dynamic=True)
        # All decisions BEFORE the modified price are unchanged, including exposures.
        for before, after in zip(pred['audit'][:7], pred2['audit'][:7]):
            self.assertEqual(before['selected_tickers'],after['selected_tickers'])
            self.assertEqual(before['exposure_fraction'],after['exposure_fraction'])

    def test_date_order_independent_of_input_order(self):
        o=self.mutate(lambda d: d['rows'].reverse())
        r=h.analyze(o)
        self.assertEqual(r['pre_holdout_policy_selection'],self.result['pre_holdout_policy_selection'])
        self.assertEqual(r['paper_portfolio'],self.result['paper_portfolio'])

    def test_manual_market_provenance_is_claim_not_verification(self):
        obj=self.mutate(lambda d:d.update(source_mode='historical_user_supplied'))
        for row in obj['rows']:
            for v in row['signals'].values():v['source']='manual_csv'
        r=h.analyze(obj)
        self.assertEqual(r['source_mode'],'historical_user_supplied')
        self.assertIn('unverified',r['provenance_status'])

    def test_null_signal_yields_not_truth_claim(self):
        r=h.analyze(h.synthetic(13690,'null',95))
        self.assertIn('cash',r['next_test']['falsifier'])

    def test_separate_people_and_pattern_familiarity(self):
        self.assertIn('investor_familiarity',self.result['relevance_assumptions'])
        self.assertIn('experience_analogy',self.result['relevance_assumptions'])

    def test_profit_chaser_can_exceed_sane_allocation_but_only_negative_control(self):
        x=self.result['paper_portfolio']['profit_chase_negative_control']
        self.assertLessEqual(x['mean_paper_exposure_fraction'], .9)
        self.assertNotIn('profit_chase',self.result['decision'])

    def test_report_requires_new_file(self):
        with tempfile.TemporaryDirectory() as folder:
            dest=Path(folder)/'x.json'
            h.save_new(dest, self.result)
            with self.assertRaises(FileExistsError):
                h.save_new(dest, self.result)

    def test_real_profit_is_not_claimed(self):
        self.assertIn('SHADOW_ONLY',self.result['decision'])
        self.assertTrue(all(x['no_real_orders'] for x in self.result['paper_portfolio'].values()))


if __name__=='__main__':
    unittest.main()
