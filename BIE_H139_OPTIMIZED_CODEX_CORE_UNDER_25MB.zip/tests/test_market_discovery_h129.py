"""Independent safety/causality checks for bounded H129 financial research candidate."""
import csv
from dataclasses import replace
from datetime import timedelta
import tempfile
from pathlib import Path
import unittest
from unittest import mock

from bie.market_discovery_h129 import (
    Bar, MISSION, SELF_QUESTION, STRATEGIES, evaluate, evaluate_universe,
    synthetic_universe, read_ohlcv, signal, ask_local_experience, MIN_BARS,
)


class MarketH129Tests(unittest.TestCase):
    def setUp(self):
        self.world = synthetic_universe(seed=19)
        self.symbol = 'DEMOA'
        self.bars = self.world[self.symbol]

    def test_adaptive_next_candidate_actually_runs(self):
        result=evaluate_universe(self.world)
        for ticker in self.world:
            dev=[event for event in result['discoveries'] if event['ticker']==ticker and event['phase']=='development']
            self.assertEqual(set(event['strategy'] for event in dev),set(STRATEGIES))
            for a,b in zip(dev,dev[1:]):
                self.assertEqual(a['next_experiment']['next_candidate_to_test'],b['strategy'])
            self.assertNotIn('next_candidate_to_test',dev[-1]['next_experiment'])

    def test_adaptive_order_ignores_modified_holdout(self):
        split=int(len(self.bars)*.78)
        changed={k:[replace(x,open=x.open*.6,high=x.high*.6,low=x.low*.6,close=x.close*.6)
                    if i>=split else x for i,x in enumerate(v)] for k,v in self.world.items()}
        a=evaluate_universe(self.world)
        b=evaluate_universe(changed)
        self.assertEqual([(x['ticker'],x['strategy']) for x in a['discoveries'] if x['phase']=='development'],
                         [(x['ticker'],x['strategy']) for x in b['discoveries'] if x['phase']=='development'])

    def test_deterministic_replay(self):
        self.assertEqual(evaluate_universe(self.world),evaluate_universe(self.world))

    def test_every_development_test_asks_question(self):
        output=evaluate_universe(self.world)
        self.assertEqual(output['discovery_count'],len(self.world)*len(STRATEGIES)+1)
        self.assertTrue(all(e['self_question']==SELF_QUESTION for e in output['discoveries']))
        self.assertTrue(all(e['next_experiment']['falsifier'] for e in output['discoveries']))
        self.assertTrue(all(e['next_experiment']['acceptance_test'] for e in output['discoveries']))

    def test_dream_answer_is_conditional_not_guaranteed(self):
        output=evaluate_universe(self.world)
        self.assertIn('dream',output['creator_question'])
        self.assertIn('cannot truthfully promise',output['provisional_experience_answer'])
        self.assertIn('NO',output['financial_authorization'])
        self.assertIn('NOT_ELIGIBLE',output['promotion_status'])

    def test_evaluation_prefix_independent_of_future(self):
        point=200
        a=evaluate(self.bars,'ema_10_30',135,point)
        tail=[replace(x,open=x.open*9,high=x.high*9,low=x.low*9,close=x.close*9)
              if i>point else x for i,x in enumerate(self.bars)]
        b=evaluate(tail,'ema_10_30',135,point)
        self.assertEqual(a,b)

    def test_holdout_change_cannot_change_selection_or_validation(self):
        a=evaluate_universe(self.world)
        # Critical: the validation's LAST return must not touch index holdout_start.
        split=int(len(self.bars)*.78)
        modified={k:[replace(x,open=x.open*1.5,high=x.high*1.5,low=x.low*1.5,close=x.close*1.5)
                         if i>=split else x for i,x in enumerate(v)] for k,v in self.world.items()}
        b=evaluate_universe(modified)
        self.assertEqual(a['selection']['ticker'],b['selection']['ticker'])
        self.assertEqual(a['selection']['strategy'],b['selection']['strategy'])
        self.assertEqual(a['selection']['validation_metrics'],b['selection']['validation_metrics'])
        self.assertEqual(a['selection']['ranking_top_five'],b['selection']['ranking_top_five'])

    def test_signal_only_historical_closes(self):
        i=170
        partial=self.bars[:i]
        extra=self.bars[i:]
        future_changed=[replace(x,close=x.close*.3) for x in extra]
        for strategy in STRATEGIES:
            self.assertEqual(signal(strategy,partial),signal(strategy, (partial+future_changed)[:i]))

    def test_signal_for_short_history_default(self):
        for name in STRATEGIES:
            if name not in ('buy_hold','cash'):
                self.assertEqual(signal(name,self.bars[:20]),0)

    def test_unknown_strategy_fails(self):
        with self.assertRaises(ValueError):
            signal('hindsight_secret',self.bars)

    def test_no_trade_win_rate_not_100(self):
        m=evaluate(self.bars,'cash',143,201)
        self.assertIsNone(m['positive_exposed_day_rate'])
        self.assertEqual(m['entries'],0)
        self.assertEqual(m['total_return'],0)

    def test_cost_reduces_hold_return(self):
        high=evaluate(self.bars,'buy_hold',150,250,30)
        low=evaluate(self.bars,'buy_hold',150,250,0)
        self.assertLess(high['total_return'],low['total_return'])

    def test_cash_not_disqualified(self):
        self.assertIn('cash',evaluate_universe(self.world)['predeclared_candidates'])

    def test_csv_roundtrip(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'stocks.csv'
            with p.open('w',newline='') as stream:
                writer=csv.writer(stream)
                writer.writerow(['date','ticker','open','high','low','close','volume'])
                for b in self.bars:
                    writer.writerow([b.timestamp,b.ticker,b.open,b.high,b.low,b.close,b.volume])
            loaded=read_ohlcv(p)
            self.assertEqual(loaded[self.symbol],self.bars)
            self.assertEqual(evaluate_universe(loaded)['selection']['ticker'],self.symbol)

    def test_unsorted_csv_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'stocks.csv'
            with p.open('w') as f:
                f.write('date,ticker,open,high,low,close,volume\n')
                for b in reversed(self.bars):
                    f.write(f'{b.timestamp},{b.ticker},{b.open},{b.high},{b.low},{b.close},{b.volume}\n')
            with self.assertRaisesRegex(ValueError,'chronological'):
                read_ohlcv(p)

    def test_duplicate_csv_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'stocks.csv'
            with p.open('w') as f:
                f.write('date,ticker,open,high,low,close,volume\n')
                for b in self.bars+[self.bars[-1]]:
                    f.write(f'{b.timestamp},{b.ticker},{b.open},{b.high},{b.low},{b.close},{b.volume}\n')
            with self.assertRaisesRegex(ValueError,'Duplicate'):
                read_ohlcv(p)

    def test_corrupt_price_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'s.csv'
            p.write_text('date,ticker,open,high,low,close,volume\n2024-01-02,STOCK,100,99,100,100,100\n')
            with self.assertRaisesRegex(ValueError,'Invalid OHLCV'):
                read_ohlcv(p)

    def test_missing_columns_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'s.csv'
            p.write_text('date,ticker,close\n2024-01-02,STOCK,100\n')
            with self.assertRaisesRegex(ValueError,'headers'):
                read_ohlcv(p)

    def test_invalid_ticker_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'s.csv'
            p.write_text('date,ticker,open,high,low,close,volume\n2024-01-02,../../etc,100,101,99,100,500\n')
            with self.assertRaisesRegex(ValueError,'Ticker'):
                read_ohlcv(p)

    def test_small_data_rejected(self):
        with self.assertRaisesRegex(ValueError,'Insufficient'):
            evaluate_universe({'X':self.bars[:100]})

    def test_calendar_mismatch_rejected(self):
        bad={'X':self.bars,'Y':[replace(b,timestamp=b.timestamp+timedelta(days=1)) for b in self.bars]}
        with self.assertRaisesRegex(ValueError,'calendar'):
            evaluate_universe(bad)

    def test_not_permissioned_to_trade(self):
        import inspect
        from bie import market_discovery_h129 as module
        src=inspect.getsource(module)
        self.assertNotIn('submit_order(',src)
        self.assertNotIn('place_order(',src)
        self.assertIn('NONE',evaluate_universe(self.world)['financial_authorization'])

    def test_local_model_failure_not_fake_response(self):
        report=evaluate_universe(self.world)
        with mock.patch('bie.model.Ollama.models',side_effect=OSError('offline')):
            # reply, not models, is called; confirm any exception is honest.
            with mock.patch('bie.model.Ollama.reply',side_effect=OSError('offline')):
                m=ask_local_experience(report)
        self.assertEqual(m['status'],'local_model_unavailable')
        self.assertNotIn('answer',m)

    def test_no_nan_cost(self):
        with self.assertRaises(ValueError):
            evaluate_universe(self.world,cost_bps=-4)

    def test_wrong_size_demo_rejected(self):
        with self.assertRaises(ValueError):
            synthetic_universe(size=MIN_BARS-1)

    def test_comparator_has_same_test_dates(self):
        result=evaluate_universe(self.world)
        self.assertEqual(result['selection']['holdout_metrics']['bars'],
                         result['selection']['holdout_buy_hold']['bars'])
        self.assertEqual(result['selection']['holdout_metrics']['bars'],
                         result['selection']['holdout_cash']['bars'])

if __name__ == '__main__':
    unittest.main()
