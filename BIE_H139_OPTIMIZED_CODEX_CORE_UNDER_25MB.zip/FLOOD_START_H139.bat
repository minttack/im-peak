@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>&1
if %errorlevel%==0 (set "PY=py -3") else (set "PY=python")
if not exist reports mkdir reports
set "REPORT=reports\H139_FLOOD_DEMO_%RANDOM%_%RANDOM%.json"
echo BIE THRIVES - FLOOD MOVEMENT H139 - SYNTHETIC RESEARCH ONLY
echo No brokerage login, orders, trades or funding will be executed.
%PY% -m bie flood-h139-demo --world flow --seed 13901 --days 260 --report "%REPORT%"
if errorlevel 1 (echo Failed; review Python installation and traceback.& pause & exit /b 1)
echo Research report: %REPORT%
echo Open this folder in Codex and read START_HERE_FLOOD_H139.md and AGENTS.md
pause
