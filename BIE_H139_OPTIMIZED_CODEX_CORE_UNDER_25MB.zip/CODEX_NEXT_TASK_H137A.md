# Codex objective — H137A Accuracy symbol direct-attribution experiment

Objective: increase verifiably useful *Accuracy* functionality in BIE THRIVES Experience without falsely attributing conventional statistics to the creator's Accuracy drawing.

1. Identify the authoritative existing BIE Windows source; never merge incompatible branches just by overwrite. H137A is built on isolated H136, not the user's running installation.
2. Recover original creator-owned Accuracy PNG from the verified Oct 16 unified symbol gallery, verify SHA against its source registry before analysis, and preserve the bytes exactly. If unavailable, keep `glyph benefit: NOT TESTED`.
3. Implement a clean experimental switch: image-free conventional verifier; meaning-only Accuracy verifier; unmodified authentic-image geometry; shuffled geometry; random matched features; same data/tuning/compute for all.
4. Timestamp all sources and prediction decisions; score Brier, calibration ECE, falsely confident guesses, paper P&L after realistic transaction costs and max drawdown. Test separately across market shifts and data corruption.
5. Pre-register metrics and improvements on development only; use new sealed holdouts; explicitly count all explored variants. If it loses to a simpler rule or effects vanish, roll back.
6. Have the actually running local BIE model, if connected, generate a *distinct* next hypothesis and its falsifier. If not connected, record `local_model_unavailable`; do not fabricate dialogue.
7. Do not send orders through Robinhood (even via Codex MCP). No automatic budget increase, live staking or permissions changes. Research + shadow only until separate user authorization after prospective independent proof.

Commands:
`py -3 -m unittest discover -s tests -q`
`py -3 -m bie verify-vendor`
`py -3 -m bie accuracy-h137a-demo --world familiarity_trap --seed 33701 --days 104`

Report changes, full reproducibility, failure cases, compute cost, input hashes and rollback decision. Passing unittests are not market prediction proof.
