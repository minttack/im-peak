"""H116 reproducible offline retrieval-only benchmark. No model, network or user state."""
from __future__ import annotations
import hashlib, json, random, tempfile, time
from pathlib import Path
from bie.datahub import KnowledgeHub
from bie.evidence_retrieval_h116 import evidence_search


def run(fixture):
    path=Path(fixture)
    raw=path.read_bytes()
    spec=json.loads(raw)
    docs=spec['documents']
    questions=spec['holdout']
    seeds=[20261015,20261016,20261017]
    trials=[]
    for seed in seeds:
        with tempfile.TemporaryDirectory() as home:
            hub=KnowledgeHub(Path(home)/'isolated_state')
            shuffled=list(docs)
            random.Random(seed).shuffle(shuffled)
            for ident,title,content in shuffled:
                hub.put(origin='synthetic:h116',title=title,uri='https://example.org/bie-h116/'+ident,
                        content=content,category='test_only',evidence='unverified_synthetic_study')
            for query,gold in questions:
                t0=time.perf_counter_ns()
                base=hub.search(query,limit=50)
                base_ns=time.perf_counter_ns()-t0
                t1=time.perf_counter_ns()
                cand=evidence_search(hub,query,limit=3)
                cand_ns=time.perf_counter_ns()-t1
                def gold_at(results,k):
                    return any(r['uri'].split('/')[-1]==gold for r in results[:k])
                trials.append({'seed':seed,'query':query,'expected_reference':gold,
                    'baseline_top1':base[0]['uri'].split('/')[-1] if base else None,
                    'candidate_top1':cand['results'][0]['uri'].split('/')[-1] if cand['results'] else None,
                    'baseline_hit1':gold_at(base,1),'candidate_hit1':gold_at(cand['results'],1),
                    'baseline_hit3':gold_at(base,3),'candidate_hit3':gold_at(cand['results'],3),
                    'baseline_duration_ms':base_ns/1e6,'candidate_duration_ms':cand_ns/1e6,
                    'candidate_facts_verified':cand['facts_verified']})
    n=len(trials)
    return {'experiment':'H116 bounded synthetic local retrieval','fixture_sha256':hashlib.sha256(raw).hexdigest(),
            'seed_count':len(seeds),'holdout_questions_per_seed':len(questions),'paired_trials':n,
            'primary_metric':'gold-document hit@1 (not answer correctness)',
            'baseline_hit1':sum(x['baseline_hit1'] for x in trials),
            'candidate_hit1':sum(x['candidate_hit1'] for x in trials),
            'baseline_hit3':sum(x['baseline_hit3'] for x in trials),
            'candidate_hit3':sum(x['candidate_hit3'] for x in trials),
            'wins':sum(x['candidate_hit1'] and not x['baseline_hit1'] for x in trials),
            'losses':sum(x['baseline_hit1'] and not x['candidate_hit1'] for x in trials),
            'ties':sum(x['baseline_hit1']==x['candidate_hit1'] for x in trials),
            'baseline_total_ms':round(sum(x['baseline_duration_ms'] for x in trials),3),
            'candidate_total_ms':round(sum(x['candidate_duration_ms'] for x in trials),3),
            'verified_facts':sum(x['candidate_facts_verified'] for x in trials),
            'inference_boundary':'Tests only retrieving hand-labeled passages in synthetic documents, not truth, live internet understanding or model learning',
            'trials':trials}

if __name__=='__main__':
    import argparse
    ap=argparse.ArgumentParser()
    ap.add_argument('fixture',type=Path)
    ap.add_argument('--report',type=Path)
    args=ap.parse_args()
    result=run(args.fixture)
    if args.report:
        with args.report.open('x',encoding='utf-8') as f:json.dump(result,f,indent=2)
    print(json.dumps({k:v for k,v in result.items() if k!='trials'},indent=2))
