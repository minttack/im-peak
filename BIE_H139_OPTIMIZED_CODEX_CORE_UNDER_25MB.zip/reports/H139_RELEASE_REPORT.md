# BIE THRIVES Experience H139 — Flood Movement integration and verification
**Date:** 2026-10-17. **Source:** isolated H138A descendant, not the separately evolving BIE unified branch. **Funding:** $0 and no orders.

## What was remade from the conversation

The read-only research package contains retained BIE source for H129–H138A and new H139 Flood Movement scoring, source as-of validation, training-only diversified stock selection, fitted multi-feature models, validation-only model selection, an embargoed chronological holdout, feature relevance ablations, a virtual split allocation, cash and two kinds of SPY/QQQ comparisons, optional actual local BIE self-query, Windows one-tap start and tests, and project-wide persistent Codex instructions. `CHAT_MASTER_BLUEPRINT_FLOOD_H139.md` includes the user's target and the contradictory results rather than only successes.

## Completed validation

- **272 / 272** targeted market/learning/Accuracy/integration Python tests PASS across the 11 selected H129–H139 test modules (including 30 H139 tests).
- **11 / 11** inherited original vendor integrity checks PASS.
- Existing **entire** miscellaneous BIE regression suite was ATTEMPTED but exceeded the execution limit and is **NOT counted as passed**. Previous inherited results in other chats are not substitutes for a current full run.
- New H139 tests reject future-dated data, future-dated attention, omitted/misordered bars, duplicates, invalid OHLC, NaN and negative volume, and unauthenticated historical input; confirm deterministic row-order invariance, no-change-before-future counterfactual, virtual stake ceiling, fallback to cash, no-order behavior, no report overwrites, and correct next-open-to-close outcome labels.
- Real local BIE/Ollama query tried: **local_model_unavailable**. This is NOT a reply from the BIE model.
- Real Robinhood account not connected. No real prices or proprietary feeds fetched. Codex was not run in this environment; the Windows launch and MCP authentication remain unverified here.

## 48 new synthetic stress worlds (12 seeds each, predeclared 13940–13951)

| Programmed world | Chosen nonprior /12 | Mean holdout Brier improvement (positive better) | Mean *virtual* return | Beat cash /12 | Mean SPY 30% buy-and-hold |
|---|---:|---:|---:|---:|---:|
| Flow-friendly | 7 | +0.006269 | **−0.220%** | 3 | −0.233% |
| Reversal | 4 | **−0.009974** | **−1.736%** | 0 | −0.233% |
| No predictive signal | 0 | 0 | 0.000% | 0 | −0.233% |
| Very high spreads / poor liquidity | 0 | 0 | 0.000% | 0 | −1.823% |

Additional matched SPY/QQQ **daily intraday turnover** baselines were harshly penalized by their daily buy/sell costs; added lower-turnover ETF buy-and-hold benchmarks to avoid an unfair appearance of superiority. These comparisons are *not* identical risk exposures and include a simplified spread assumption. A small synthetic winner on one seed must not override these more informative means.

### Critical failures and next hypothesis

1. In flow-friendly synthetic worlds, higher probability precision did **not** reliably translate to profitable paper trades after modeled costs.
2. In reversal worlds, a validation-selected model still sometimes lost its advantage on untouched data. The existing H136 drift guard is a useful candidate, but its H137A replacement **was not superior**. A new label-lagged online drift guard must be tested against frozen holdouts and simpler no-trade rules without peeking.
3. Real historical sources may be revised. H139 source IDs and timestamp checks do **not** independently authenticate Robinhood bars, news, corporate-action adjustments, historic spread, fillings or sentiment.
4. The creator's authentic Accuracy glyph did not contribute to the H139 decisions; this branch's direct original-drawing predictive contribution is still **0 verified**. Image-geometry benefits require authentic source and randomized image-vs-meaning controls.
5. SPY/QQQ historical benchmarks are *simulated* in the synthetic worlds and show independent data paths, but none of these are real-market claims.

**Next falsifiable task:** Import 250+ as-of real daily bars for selected liquid names and SPY/QQQ, establish corporate-action integrity and historical costs, then test multiple new untouched calendar periods. Add a prospective paper-time layer (including earnings/news release timestamps and drift detection with known-label delay). Freeze acceptance rules before seeing new outcomes; only promote if after-cost risk-adjusted evidence beats cash and reasonable passive alternatives.

## How to use

See `START_HERE_FLOOD_H139.md`. Run `FLOOD_START_H139.bat`, `FLOOD_TEST_H139.bat`, then open the extracted project folder in Codex; see `CODEX_FIRST_TASK_FLOOD_H139.md` and `ROBINHOOD_CODEX_READ_ONLY_H139.md`. External MCP trade approvals default off and may be unavailable during rollout: do not connect unrestricted brokerage access if approvals cannot be enabled. Research/paper only.
