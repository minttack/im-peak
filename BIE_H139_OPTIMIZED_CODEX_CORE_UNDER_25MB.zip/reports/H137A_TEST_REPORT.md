# BIE H137A Accuracy Attribution & Verification — October 17, 2026

**Status:** fully executed **offline synthetic research** on isolated H136-based BIE source; not user's Windows installation, not Robinhood or a running local BIE language model. Does not establish actual symbol-derived intelligence or market alpha.

## Source accountability

- Previous audit: 6/7 recent market modules implement ordinary outcome/error evaluation (85.7%), while **0/7 used creator's Accuracy PNG** (0% traced original-glyph inputs). No denominator for "percentage of all knowledge learned from symbol" exists.
- H137A adds an explicit Accuracy-*concept* experiment with traceable timestamps, squared-error/Brier skill, confidence diagnostics, per-day decision intervention rates, raw and sham ablations, and a cost filter. `authentic_glyph_visual_ablation: NOT RUN`: original SHA-verified Accuracy image is not contained in this H136-derived source. **Measured improvement attributable to the original drawing: none established.**
- Real BIE/Ollama did not independently supply an answer during these tests. Source edits and experimental hypotheses here came from an assistant-authored controlled research candidate, not autonomous model self-training.

## Development and strict confirmation

Five synthetic environments × eight development seeds (40 tests, dates with 104 snapshots/12 synthetic instruments per world). The first cost gate rejected favorable stable signals, so it was revised on **development only** to avoid orders when **both** modeled cost exceeds 50 bps and pre-holdout conditional return estimate fails cost plus 10 bps. Parameters were then frozen.

100 fresh confirmation environments: five regimes × seeds 33701–33720, separate from dev seeds 23701–23708. The table shows **average virtual after-cost percent return**, starting with $10,000 of *imaginary* capital per world, ~25 evaluation days per simulated world. These are not actual Robinhood gains.

| Synthetic world | Raw forecasting rule | Accuracy-feedback | Feedback + cost screening | Randomized sham feedback |
|---|---:|---:|---:|---:|
| Familiarity genuinely informative | +5.13% | +5.13% | +5.13% | +3.49% |
| Familiarity reverses in holdout | −10.14% | −2.46% | −2.46% | −8.16% |
| Investor attention informative | +6.21% | +6.21% | +6.21% | +5.20% |
| No predictive signal | 0.00% | 0.00% | 0.00% | 0.00% |
| Thin liquidity/high trading costs | −0.57% | −0.57% | 0.00% | −0.39% |

- Reversal: feedback + cost method had a **+7.6766 percentage-point** return difference over the *raw* control (20/20 favorable paired synthetic seeds). Brier gain from feedback was **0.14153** in that particular designed regime. It **did not** remove all losses.
- Illiquid regime: +0.5722 percentage-point return difference from screening (15/20 favorable, other five could have been profits missed). Calibration score was unchanged; abstaining does not make probability forecasts better.
- In stable, attention and no-signal synthetic worlds, accuracy method matched raw returns (0 improvement). No general global gain claim.
- Paired bootstrap intervals over artificially seeded worlds are in `reports/H137A_FROZEN_CONFIRMATION.json`; they reflect only this simulator family, not market uncertainty or prospective validation.

## 18 independent adverse input tests

Six seeds each for signed familiarity metadata corruption, observed-signal staleness and extreme spread/low-liquidity shocks. Average **synthetic** percent returns:

| Stress | Raw | Accuracy-feedback | Feedback + cost screen |
|---|---:|---:|---:|
| False familiarity polarity | −6.87% | −1.65% | −1.65% |
| Stale familiarity data | +0.03% | +0.08% | +0.08% |
| Liquidity shock | −12.57% | −12.57% | 0.00% |

These data corruptions were scripted, not unexpectedly encountered in an actual exchange. This is strong evidence the *code* notices specific designed failures, not proof of actual predictive generalization.

## Critical comparison against stronger existing H136

An independent paired 6-seed head-to-head on the **same reversal worlds** revealed H136's existing drift guard averaged **−1.70%**, while the separate H137A error-feedback prototype averaged **−2.53%**: **the purported new method was worse than the existing one**. That vetoes replacing H136's guard.

We therefore added a *separate, optional* high-cost screen to the **unchanged-by-default H136 drift guard** and ran **60 different fresh worlds** (12 new seeds × five regimes; seeds 55701–55712). In liquid, reversal, attention and no-signal scenarios, existing and overlay results were identical. In thin-liquidity worlds, H136 averaged **−0.3093%** versus overlay **0.0000%**. However, the overlay was better only **7/12** seeds and worse in **5/12**, with bootstrap paired 95% interval **[−0.1514, +0.7636] percentage points**, crossing zero. **Not enough evidence to promote as proven improvement.** Filtering trades may miss profit as well as avoid loss.

This head-to-head is more relevant than the large gain versus the weak raw control. The user should not receive only favorable comparisons.

## Correctly interpreting the percentages

In one illustrative familiarity-reversal world (seed 33701), the added Accuracy-concept mechanism changed the simulated stock choices on **19/25** holdout days (**76%**). In a stable-world illustration, it changed **0/25**. In a thin-liquidity example it changed **25/25** by rejecting expensive paper trades. **These are fractions of hypothetical decisions affected by conventional error/cost rules, NOT fractions of knowledge learned from glyph geometry.** Original-glyph-derived market decisions remain 0/7 from the previous audit and 0 directly verified in H137A.

## Integrity and commands

- `python -m unittest discover -s tests -q` → **467/467** passed (444 inherited +23 new H137A); existing runtime emitted sqlite ResourceWarnings, not failing test assertions.
- `python -m bie verify-vendor` → **11/11** SHA checks pass.
- New commands: `python -m bie accuracy-h137a-demo --world familiarity_trap --seed 33701 --days 104` and `accuracy-h137a-file <compatible_h136.json>`; paper-only.
- No real trades, no Robinhood connection, no model weights retrained, no original symbol image geometry matched.

## Decision

**KEEP:** the original Accuracy drawing in the official original-symbol gallery; conceptual checks/feedback; current proven H136 drift implementation. **RESEARCH ONLY:** optional H137A high-cost overlay and separate calibration policy. **DO NOT PROMOTE:** glyph geometry, live trading, or stronger intelligence claims. Next: acquire the authentic verified Accuracy image and perform true image/no-image/meaning-only/random-feature matched holdouts; acquire genuine as-of exchange history and prospective paper outcomes for the trading benefit claim.
