BLOOM × BIE THRIVES 31 — Computational X-ray Transit Lab. See README_BIE_BLOOM_XRAY_31.md. No new astronomical discovery claimed.
