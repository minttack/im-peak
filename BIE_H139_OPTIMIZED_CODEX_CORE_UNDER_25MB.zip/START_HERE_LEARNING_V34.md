# BIE THRIVES Experience v34 — Learning Accelerator candidate

**Project creator:** the user. **Status:** source-bearing, locally tested additive candidate, **not** installed on your Windows PC and **not** an independently measured intelligence improvement.

## What's new

- A native **BIE · Learning Accelerator** tab with an offline plan button, explicit Internet/search-import approval, speed profile chooser and measured run reports.
- `bie/learning_accelerator.py`: manually triggered batch research, using five existing named public APIs only (PubMed, OpenAlex, Crossref, English Wikipedia, World Bank). No general web crawler, paywall bypass, secret upload, autonomous scheduled run, or AI model retraining.
- SQLite indexing reuses BIE's v26 knowledge hub; all remote titles, dates, links, and metadata are flagged **external-source-unverified**. It is a research *reference collector*, not a fact validator or a tool that learns full papers.
- Exact-URL and record-key deduplication, distinct new / changed / repeated counts, per-query failures, elapsed time, measured new-reference throughput. The manifest digest and progress index permit **manual continuation** through a long query list without restarting from its first job.
- `Auto` profile selects Balanced initially, drops to Evidence when the last batch has substantial failures, and tests Accelerated after at least 10 completed queries with 40% novel citations. This is a bounded heuristic, not scientific proof that BIE learned better.
- New optional coding **Deep** work-budget preset (48 model rounds, 96 tool calls, 40 minutes, 16,384 model context tokens). Older Quick/Balanced/Burst profiles remain unchanged. Actual model limits, RAM/VRAM, performance and local model capacity still apply. Deep is not a model-quality upgrade.

## Adjustable research profiles

| Profile | Queries / manual run | Results / query | Concurrent query jobs | Minimum spacing between starting query jobs | Time budget |
|---|---:|---:|---:|---:|---:|
| Evidence | 10 | 5 | 1 | 2.0 s | 120 s |
| Balanced | 40 | 10 | 2 | 1.2 s | 300 s |
| Accelerated | 150 | 10 | 3 | 0.75 s | 600 s |
| MaximumSafe | 300 | 10 | 4 | 0.6 s | 900 s |

**These are maximum software budgets, not guaranteed rates.** Some providers (e.g., PubMed) require more than one HTTPS request per query; their own rate limits and terms apply. Don't assume MaximumSafe will be faster than Balanced in all situations. The local model *does not absorb* every reference into its weights. Up to 3,000 **reference entries** are possible per manually approved run, not 3,000 verified things learned. Manifest holds at most 2,000 distinct jobs and files are limited to 1 MB; run further lists in later sessions.

## Windows setup

1. Extract the **FULL SOURCE** v34 ZIP into a **new folder** (keep your old BIE untouched). Install Python 3.10+ with Tkinter if needed. Launch `START_BIE.bat`.
2. Open **BIE · Learning Accelerator**. Click **Choose JSON**, selecting `examples/LEARNING_BATCH_V34_EXAMPLE.json` or your manually edited copy.
3. Select `Auto` (recommended for first use), or manually `Accelerated` / `MaximumSafe` if you understand the workload.
4. Choose **Preview no network** to inspect precisely what could be sent or indexed. Choose **Approve & run online import** for that one batch; an explicit confirmation is required.
5. Review **View measured history** for unique references, duplicates, failures, and citations per second. Run again to process the next batch from the same file. Changes to the manifest content create a distinct work queue; data deduplication still prevents re-counting identical URLs.
6. Research terms are sent to the selected public API providers, never your private local notes or memories. Do not put private data into the query text. Remote responses cannot grant BIE agent permissions.

The new module uses the existing `--home` knowledge SQLite DB only when you explicitly import; it adds `learning_runs_v34.sqlite3`. Back up your state. The full-source ZIP can be run with a separate `--home` for full isolation.

## CLI

```powershell
py -3 -m bie --home C:\BIE_Test learn-plan examples\LEARNING_BATCH_V34_EXAMPLE.json --profile Auto
py -3 -m bie --home C:\BIE_Test learn-run examples\LEARNING_BATCH_V34_EXAMPLE.json --profile Accelerated --confirm-network
py -3 -m bie --home C:\BIE_Test learn-status
py -3 -m bie --home C:\BIE_Test knowledge-search "calibration"
py -3 -m bie --home C:\BIE_Test learn-plan examples\LEARNING_BATCH_V34_EXAMPLE.json --profile Evidence --start-at 0
py -3 -m bie verify-vendor
py -3 -m unittest discover -s tests
```

`--start-at 0` starts an intentional refresh of an earlier batch. Normally the saved progress cursor automatically continues; no autonomous loop is started. To extend beyond one manifest's batch, author another manifest or add more queries, then manually approve that batch.

## What does NOT work yet

- No one-click unlimited ongoing internet learning, no automatic code self-rewriting/installation, and no training of your local Ollama model's neural weights.
- Live throughput, public API rate-limits, resilience to network interruptions, Windows GUI, and your hardware's model speed **not measured** in this hosted Linux environment. No promise of 100 million concepts or 100 million lines of correct code.
- Each metadata entry requires subsequent reading, independent source comparison, testing and possible retraction before BIE could count it as verified knowledge. That evidence-promotion pipeline remains future research.

## Verification

210/210 Python unit tests passed (197 inherited + 13 new); 11/11 inherited vendor integrity checks passed; new offline `learn-plan`, `learn-status` and non-consented `learn-run` refusal passed; Tk GUI 12-tab virtual-Xvfb smoke test passed. Offline synthetic API tests showed dedup, changed records, invalid URL handling, adaptive speed selection and cross-run manual continuation. No live Internet batch was run here.

Source provenance and file hashes: `SOURCE_SHA256_MANIFEST_LEARNING_V34.json`; `reports/learning_v34_integration.json`. Earlier BIE v33 Growth Ledger and v32 Adaptive Wiggle are preserved with intact original vendor files. `BIE THRIVES Experience` is a user-originated project, distinct from any scientifically verified discovery.
