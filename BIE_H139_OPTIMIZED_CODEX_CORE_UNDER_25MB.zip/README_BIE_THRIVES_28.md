# BIE THRIVES Experience v28 — Start here

## Run on your Windows PC

1. Extract the **complete** v28 ZIP to a normal folder, such as Documents\BIE_THRIVES_Experience_v28. If you have v27, leave its folder as a backup. The new ZIP retains the bundled research, history and source code.
2. Install a compatible Python 3 if needed. Launch `START_BIE.bat` inside the extracted folder. In the native window choose **Wi-Fi Wiggle Lab**.
3. Click **Snapshot current Wi-Fi** to ask Windows for read-only WLAN reports. Depending on Windows settings and driver, allow appropriate *Windows Location* access yourself, if you want nearby network observations. BIE cannot override that setting.
4. Take several manually requested snapshots. Click **Advanced discovery** for a source-linked observation and reasoning report. A single snapshot is useful to identify OS-reported standards, but not a forecast.
5. Click **New test session** before collecting measurements in another experimental period or condition. That button does *not* start automatic scanning and a label is not proof that sessions are statistically independent.
6. Click **Export evidence** to save a pseudonymized JSON report you can inspect or share carefully. It excludes SSID/MAC/BSSID/password data, but locally stable pseudonyms and measurements may still be sensitive.

No Wi-Fi connection is attempted. The tool neither requests Wi-Fi passwords nor probes other devices. Results describe Windows' visible environment, not permission to use those networks.

## Command line

From the extracted project root (Windows Command Prompt / PowerShell):

```
py -3 -m bie wifi-snapshot
py -3 -m bie wifi-discovery
py -3 -m bie wifi-new-session
py -3 -m bie wifi-snapshot
py -3 -m bie wifi-export evidence_v28.json
py -3 -m bie wifi-infer
py -3 -m unittest discover -s tests -v
```

`wifi-export` refuses to overwrite an existing file. The older v27 `wifi-infer`, Wi-Fi storage, public research and assistant commands continue to be available.

To try with no Wi-Fi hardware or Windows: `python examples/wifi_v28_demo.py` — clearly **synthetic observations**, not physical evidence.

## What the results mean

- **Observation:** Windows reported `802.11be` in a nearby AP entry. This suggests an advertised Wi-Fi 7 capability, not actual access, MLO, router ownership, higher throughput or unknown radio technology.
- **Inference:** An advertised radio generation may exceed your current adapter's reported capability. This is a lead for checking device specs, not proof of incompatibility.
- **Alternative explanations:** Movement, multipath, beacon scheduling, interference and OS/driver noise can all cause a changing observed list or strength value. Compare with independent authorized measurements.
- **Prediction:** The Wiggle predictor may outperform (or lose to) a simpler numeric baseline. Only later, repeated data are evaluated. No predictive improvement establishes faster Wi-Fi.
- **Privacy:** No plaintext SSIDs, BSSIDs, passwords or location are persisted by the new lab. Do not confuse the locally salted AP pseudonyms with a universally private identifier if you export/share many records.

## Limits

This version is **not omnipotent** and cannot discover arbitrary unseen devices, secret storage, unknown networks, Wi-Fi 8 deployments or new physical communication methods. Captured frequencies/channel widths depend on Windows driver reports, not an RF spectrum instrument. Channel *advertisement counts* are not airtime congestion. A physical claim requires a proper instrument, pre-registered controls and independent replication. Windows hardware and permission tests have not happened in the release-building environment.

## Data storage

The lab uses `wifi_wiggle.sqlite3` in the configured BIE assistant home. The user controls the home folder with `--home <folder>` (CLI); v28 migrates v27 DB columns without deleting old rows or changing its salt. Avoid importing private third-party measurements without consent. The BIE public research sources and existing native memory are unchanged.
