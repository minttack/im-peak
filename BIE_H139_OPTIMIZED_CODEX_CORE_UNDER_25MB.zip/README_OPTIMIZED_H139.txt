BIE THRIVES EXPERIENCE H139 -- OPTIMIZED CODEX WORKING PACKAGE
============================================================

WHAT CHANGED
- Exactly one large nested, historical ZIP was moved into optional archive packs:
  vendor/desktop_v1/ORIGINAL_BIE_V8_UNMODIFIED.zip
- All 298 other original files are preserved byte-for-byte in this lean package.
- New documentation, offline manifest, and safe Windows tests were added.
- The original Flood Movement synthetic/demo code and AGENTS.md are unchanged.

WHY
- The moved historical archive alone consumes 80,676,415 bytes.
- It holds an older BIE v8 lineage and more nested previous ZIPs, not the H139
  Flood Movement code executed by the H139 demo.
- Running H139 demonstrations and *focused* H139 tests does not require this archive.

USE ON WINDOWS
1) Extract BIE_H139_OPTIMIZED_CODEX_CORE_UNDER_25MB.zip to a clean folder.
2) Run FLOOD_START_H139.bat to reproduce the synthetic research demo.
3) Run TEST_H139_LEAN.bat to execute focused code tests. This explicitly skips
   vendor-archive integrity verification until the legacy archive is restored.
4) Open that extracted folder in Codex and read AGENTS.md and
   START_HERE_FLOOD_H139.md.
5) No brokerage order/funding permissions are needed or granted.

OPTIONAL ORIGINAL LEGACY LINEAGE
- Download all 4 BIE_H139_LEGACY_ARCHIVE_PACK_N_OF_4.zip files.
- Extract each ZIP *into this same extracted H139 root directory*, allowing
  each ZIP's legacy_parts/ folder to merge.
- Double-click RESTORE_LEGACY_VENDOR_H139.bat. It recreates the exact historical
  vendor ZIP and checks its SHA-256 before declaring success.
- After successful restoration, FLOOD_TEST_H139.bat can check all vendor archives.

  ORIGINAL LEGACY ZIP SHA256: eabaa057a42a6905f768c9d01306e82ef3b309612c524fa5118a6f1853cdf79a
  ORIGINAL H139 SOURCE ZIP SHA256: e6ada57ff11c463e576f354fc72680ccae71c4f46acc95391153563d7d1097f6

IMPORTANT LIMITS
- This compact file is a runnable research subset, NOT a byte-for-byte full-source
  archive. For full historical file fidelity download/restore all optional packs.
- Existing historical hashes/manifest entries intentionally still reference the
  missing legacy archive; absence is NOT a successful vendor check.
- No historical lineage has been silently replaced or rewritten.
- No live brokerage integration, real alpha, or real orders are claimed.
