@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>&1
if %errorlevel%==0 (set "PY=py -3") else (set "PY=python")
echo Offline research integrity tests. NO Robinhood connection.
%PY% -m unittest tests.test_flood_movement_h139 -v
if errorlevel 1 (pause & exit /b 1)
%PY% -m bie verify-vendor
if errorlevel 1 (pause & exit /b 1)
echo Targeted checks complete. For full inherited suite: %PY% -m unittest discover -s tests -p "test_*.py"
pause
