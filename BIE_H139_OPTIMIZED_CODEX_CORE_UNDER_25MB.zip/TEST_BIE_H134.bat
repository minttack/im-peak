@echo off
setlocal
cd /d "%~dp0"
if not exist reports mkdir reports
for /f %%I in ('powershell -NoProfile -Command "Get-Date -Format yyyyMMdd_HHmmss"') do set "STAMP=%%I"
if not defined STAMP (echo Cannot create timestamp & exit /b 2)
py -3 -m unittest discover -s tests -p "test_*.py"
if errorlevel 1 (echo Unit test failure - STOP & exit /b 1)
py -3 -m bie verify-vendor
if errorlevel 1 (echo Integrity failure - STOP & exit /b 1)
py -3 -m bie transfer-h134 --ask-experience --report "reports\H134_%STAMP%.json"
if errorlevel 1 (echo H134 failed - STOP & exit /b 1)
echo Finished offline synthetic tests. No live trades and no automatic model update.
echo Evidence report in reports\H134_%STAMP%.json
pause
