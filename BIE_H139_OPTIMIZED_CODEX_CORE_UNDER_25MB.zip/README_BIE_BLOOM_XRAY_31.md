# BLOOM × BIE THRIVES Experience v31 — Computational X-ray Transit Lab

The owner's unified BIE source v30 is preserved, with a real **read-only, locally executed** X-ray transit calculation added. This is an analysis toolkit for *already reduced astronomical observations* and reproducible synthetic controls; **not** a telescope, omnipotence, X-ray vision, new physical discovery, or an end-to-end Chandra CIAO reduction system.

## Start on Windows

1. Extract the **full-source v31 ZIP**. Install Python 3.10+ with Tkinter. Run `START_BIE.bat` from the extracted folder.
2. Open the **BLOOM · X-ray Lab** tab. Choose **Published HD 189733 b reference** for the externally published depth comparison, or **Run synthetic + null controls** to validate the local calculation.
3. To use *actual* observations, first obtain authorized public Chandra or XMM-Newton measurements, reduce with instrument-specific science tools (CIAO/SAS, appropriate source/background regions, calibration, exposure/GTI and time conversion), and save prepared binned CSV or compatible FITS as described below. Then select **Analyze selected X-ray file**.
4. For a published HD 189733 b example the period is `2.21857312` days and the older reference epoch is `2453988.80261 BJD`. **Do not enter an epoch in BJD if the file uses relative spacecraft elapsed time.** A validated time conversion and up-to-date ephemeris are required for meaningful scientific comparison.
5. Read the `independent_visits`, `placebo_phases`, and `limits` in the output. Export a new JSON evidence file if needed; exporting refuses to overwrite existing files.

## Command-line reproducibility

From the extracted project root:

```powershell
py -3 -m bie xray-reference
py -3 -m bie xray-demo
py -3 -m bie xray-analyze examples/XRAY_SYNTHETIC_INJECTED_V31.csv --period-days 2.21857312 --epoch-days 100 --target "SYNTHETIC TEST"
py -3 -m bie xray-analyze examples/XRAY_SYNTHETIC_NULL_V31.csv --period-days 2.21857312 --epoch-days 100 --target "SYNTHETIC NULL"
py -3 -m bie xray-analyze my_prepared_xray.csv --period-days 2.21857312 --epoch-days 2453988.80261 --target "HD 189733 b" --report my_xray_report.json
py -3 -m unittest discover -s tests
py -3 -m bie verify-vendor
```

`--report` creates a new file and will refuse an existing destination. If you choose a prepared FITS, install optional `astropy` (`py -3 -m pip install astropy`). This program requires a table with the named prepared columns, **not unfiltered raw spacecraft FITS events**. Raw events must be calibrated and extracted with telescope-specific tools first.

## Prepared measurement schema

CSV columns:

- `time_days`: mid-bin observation time in days in a consistent specified time reference (for HD 189733 b ephemerides, barycentric BJD_TDB after correction)
- `source_counts`: nonnegative counts in a fixed source-extraction region including background
- `background_counts`: nonnegative counts in an appropriate background region
- `exposure_s`: usable exposure in seconds after instrument good-time and dead-time filtering
- `visit`: stable identifier for physically distinct observations; changing a label does not create independent observations
- `background_scale`: optional relative background-area/exposure scale factor, default 1; normally needs careful instrumental calculation

A matching prepared FITS table can use uppercase equivalents of those column names. Native OGIP RATE FITS without explicit background and exposure is **not** sufficient for the pipeline; re-extract the complete source/background data first. Spectral energy filtering and other calibrations happen upstream.

## What is actually computed

BLOOM folds measured counts on a **predeclared** period/epoch, estimates the background-corrected in-transit and out-of-transit count rates, derives an approximate transit depth and independent-Poisson one-sigma error by propagation, checks at least two separate visit groups, and compares quarter- and half-cycle phase placebo windows. It writes source SHA-256, source origin and limits to JSON. Its heuristic z-score is **not** a formal discovery significance; noise correlations and trials factors are not treated.

A signal is merely marked `repeatable-dip-for-independent-review`, never `confirmed planet`. A negative control, insufficient phase coverage, inconsistent visits or placebo-phase deficits can prevent this classification. False positives due to stellar flares, corona variability, instrumental response, background selection, look-elsewhere effects, or uncorrected spacecraft timing remain possible.

## Literature comparison actually reproduced

Poppenhaeger, Schmitt & Wolk (2013), **Transit Observations of the Hot Jupiter HD 189733b at X-ray Wavelengths**, ApJ 773, 62 (DOI 10.1088/0004-637X/773/1/62), reported a broadband optical transit depth of **2.41%** and X-ray depths favored in the **6–8%** range. A **simple** uniform-emission radius-proxy model gives sqrt(0.06/0.0241) to sqrt(0.08/0.0241), approximately **1.58–1.82 times** the optical radius. This derivation is not a calibrated coronal geometry or new measurement. The authors cautioned that coronal inhomogeneity cannot fully be ruled out.

Primary source: https://arxiv.org/abs/1306.2311
NASA: https://www.nasa.gov/news-release/nasas-chandra-sees-eclipsing-planet-in-x-rays-for-first-time/
Chandra observation 2011 IDs: **12340–12345**; public archive: https://cda.harvard.edu/chaser/
XMM-Newton ObsID discussed in paper: **0506070201**; ESA archive provides XMM-Newton public data.
NASA's HEASARC cookbook explains source reduction, good-time intervals, background subtraction and light-curve extraction: https://heasarc.gsfc.nasa.gov/docs/cookbook/

## Verified and not verified

- **Verified locally:** Original regression suite plus 23 new test cases; user-prepared CSV pipeline run on independently generated injected and null input; original vendor checks; actual Tk tab opened in Xvfb.
- **NOT verified:** End-to-end real Chandra/XMM raw-event processing, public archive download, independent detection from telescope observations, a new planet, an atmosphere discovery, alien life or a new form of X-ray vision. This execution environment could not reach the archive to retrieve raw observations.
- **Preservation:** Prior v30 source files retained; new functionality is additive except three necessary integration files (`bie/__main__.py`, `bie/gui.py`, `bie/tools.py`). Existing BIE memory databases are bundled without modification.

## Files

- `bie/xray_mapping.py`: numerical analysis implementation
- `tests/test_xray_mapping_v31.py`: negative controls and regression tests
- `examples/XRAY_SYNTHETIC_*_V31.csv`: **invented test data only**
- `reports/v31_*`: evidence, test output and continuity audit
- `SOURCE_SHA256_MANIFEST_V31.json`: file integrity snapshot

This software may help users scrutinize real data, but published or independent scientific review is still necessary before claiming an observational discovery.
