"""Reuse the original desktop adapter and read the later v24 checkpoint."""
from __future__ import annotations

import hashlib
import importlib.util
import json
from pathlib import Path
import re
import sqlite3
import threading

from .config import PACKAGE

VENDOR = PACKAGE / "vendor"
_module = None
_module_lock = threading.Lock()


def original_desktop():
    global _module
    with _module_lock:
        if _module is None:
            path = VENDOR / "desktop_v1" / "bie_ai.py"
            spec = importlib.util.spec_from_file_location("bie_desktop_original", path)
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            _module = mod
    return _module


def verify_vendor():
    manifest = json.loads((PACKAGE / "PROVENANCE.json").read_text())
    for rel, hh in manifest["unmodified_vendor_files"].items():
        path = PACKAGE / rel
        actual = hashlib.sha256(path.read_bytes()).hexdigest()
        if actual != hh:
            raise ValueError(f"Inherited BIE file changed: {rel}")
    return {"passed": True, "files": len(manifest["unmodified_vendor_files"]),
            "v24_parent": manifest["v24_parent_zip_sha256"]}


def verify_vendor_lean():
    """Verify present vendor files while reporting the intentional omission.

    This is a separate compact-package check. It does not replace or relax
    verify_vendor(), which still requires every artifact in PROVENANCE.json.
    """
    manifest = json.loads((PACKAGE / "PROVENANCE.json").read_text())
    expected = manifest["unmodified_vendor_files"]
    legacy = "vendor/desktop_v1/ORIGINAL_BIE_V8_UNMODIFIED.zip"
    checked=[];missing=[]
    for rel, wanted in expected.items():
        path=PACKAGE/rel
        if not path.is_file():
            missing.append(rel);continue
        actual=hashlib.sha256(path.read_bytes()).hexdigest()
        if actual!=wanted:raise ValueError(f"Inherited BIE file changed: {rel}")
        checked.append(rel)
    unexpected=[p for p in missing if p!=legacy]
    if unexpected:raise FileNotFoundError("Missing required lean vendor files: "+", ".join(unexpected))
    return {"lean_check_passed":True,"full_archive_verified":not missing,
            "verified_present_files":len(checked),"expected_full_files":len(expected),
            "legacy_archive_status":"present_and_verified" if legacy not in missing else "legacy_archive_absent",
            "legacy_archive_path":legacy,"legacy_archive_expected_sha256":expected[legacy],
            "full_verification_command":"python -m bie verify-vendor"}


class BIEBridge:
    def __init__(self, home):
        self.home = Path(home)
        self.db = VENDOR / "v24" / "results" / "BIE_V24_EXPERIENCE.sqlite3"
        self._native = None
        self._lock = threading.RLock()

    def search(self, query, limit=5):
        words = re.findall(r"\w+", query)[:20]
        if not words:
            return []
        match = " OR ".join('"' + w + '"' for w in words)
        con = sqlite3.connect(self.db.as_uri() + "?mode=ro", uri=True)
        con.row_factory = sqlite3.Row
        try:
            sql = """SELECT s.name,s.source_id,s.domain,s.provenance_level,s.sha256,
                     c.heading,substr(c.text,1,1200) AS excerpt FROM chunks_fts
                     JOIN chunks c ON c.rowid=chunks_fts.rowid JOIN sources s ON s.source_id=c.source_id
                     WHERE chunks_fts MATCH ? ORDER BY bm25(chunks_fts) LIMIT ?"""
            return [dict(r) for r in con.execute(sql, (match, min(8, max(1, limit))))]
        finally:
            con.close()

    def history(self):
        con = sqlite3.connect(self.db.as_uri() + "?mode=ro", uri=True)
        try:
            counts = {table: con.execute(f"SELECT count(*) FROM {table}").fetchone()[0]
                      for table in ("sources", "processor_events", "v24_evidence_packets")}
        finally:
            con.close()
        report = json.loads((VENDOR / "v24" / "results" / "V24_HISTORY_AUDIT.json").read_text())
        return {"inherited_counts": counts, "v24_recorded_findings": report,
                "scope": "Historical saved results; assistant performance is measured separately."}

    def native(self):
        with self._lock:
            if self._native is None:
                self._native = original_desktop().NativeBIE(self.home / "native_v8")
            self._native.install()
            return self._native

    def goal(self, query, domain="intelligence"):
        with self._lock:
            return self.native().goal(query, domain)

    def audit(self):
        with self._lock:
            return self.native().audit()
