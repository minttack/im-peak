"""H140 real-market robustness audit: offline, causal and paper-only."""
from __future__ import annotations
import math, statistics
from . import flood_movement_h139 as h139

HORIZONS=(1,3,5)
REBALANCE_DAYS=(1,5,10)

def _split(dates):
    valid=dates[21:-5];a=int(.50*len(valid));b=int(.75*len(valid));gap=5
    train=set(valid[:a]);validation=set(valid[a+gap:b]);holdout=set(valid[b+gap:])
    if min(len(train),len(validation),len(holdout))<20:raise ValueError("Need longer H140 history")
    return train,validation,holdout,{"train_end":str(valid[a-1]),
        "validation_start":str(valid[a+gap]),"validation_end":str(valid[b-1]),
        "holdout_start":str(valid[b+gap]),"embargo_sessions":gap,
        "holdout_status":"new_dataset_only; never reuse consumed H139 holdout for promotion"}

def _horizon_rows(samples,dates,book,horizon):
    index={d:i for i,d in enumerate(dates)};out=[]
    for row in samples:
        i=index[row["date"]]
        if i+horizon>=len(dates):continue
        entry=book[(dates[i+1],row["ticker"])];exit_bar=book[(dates[i+horizon],row["ticker"])]
        gross=exit_bar["close"]/entry["open"]-1
        copy=dict(row);copy.update({"gross":gross,"y":int(gross>0),
            "outcome_date":dates[i+horizon],"horizon_sessions":horizon})
        out.append(copy)
    return out

def _calibration(rows,model):
    bins=[];ece=0.
    for lo in (0.,.2,.4,.6,.8):
        part=[r for r in rows if lo<=h139._predict(model,r)<lo+.2]
        if part:
            mean_p=statistics.mean(h139._predict(model,r) for r in part)
            actual=statistics.mean(r["y"] for r in part)
            ece+=len(part)/len(rows)*abs(mean_p-actual)
            bins.append({"range":[lo,lo+.2],"samples":len(part),
                         "mean_probability":round(mean_p,6),"observed_frequency":round(actual,6)})
    return {"expected_calibration_error":round(ece,7),"bins":bins}

def _paired_uncertainty(rows,model,prior):
    differences=[(h139._predict(prior,r)-r["y"])**2-(h139._predict(model,r)-r["y"])**2 for r in rows]
    mean=statistics.mean(differences)
    se=statistics.stdev(differences)/math.sqrt(len(differences)) if len(differences)>1 else 0.
    return {"mean_brier_gain":round(mean,7),"standard_error":round(se,7),
            "approx_95pct_interval":[round(mean-1.96*se,7),round(mean+1.96*se,7)]}

def _every_n(rows,n):
    dates=sorted({r["date"] for r in rows});keep=set(dates[::n])
    return [r for r in rows if r["date"] in keep]

def _regimes(rows,model,prior):
    dates=sorted({r["date"] for r in rows});cuts=(len(dates)//3,2*len(dates)//3)
    groups=(dates[:cuts[0]],dates[cuts[0]:cuts[1]],dates[cuts[1]:]);result={}
    for i,group in enumerate(groups,1):
        part=[r for r in rows if r["date"] in set(group)]
        result[f"chronological_regime_{i}"]={"start":str(group[0]),"end":str(group[-1]),
            "samples":len(part),"brier_gain_vs_prior":round(h139._brier(part,prior)-h139._brier(part,model),7),
            "virtual_return_pct":h139.paper(part,model)["virtual_return_pct"]}
    return result

def analyze(payload,*,allow_synthetic=False):
    mode,dates,names,book,sectors=h139.validate(payload)
    if mode!="user_supplied_historical" and not allow_synthetic:
        raise ValueError("H140 promotion analysis requires genuine reviewed historical input")
    samples=h139.feature_matrix(dates,names,book)
    train_dates,val_dates,hold_dates,split=_split(dates)
    chosen,ranking=h139.choose_universe(samples,train_dates,names,sectors)
    if len(chosen)<2:raise ValueError("Insufficient training-only universe")
    experiments={};primary=None
    for horizon in HORIZONS:
        rows=[r for r in _horizon_rows(samples,dates,book,horizon) if r["ticker"] in chosen]
        tr=[r for r in rows if r["date"] in train_dates];va=[r for r in rows if r["date"] in val_dates]
        te=[r for r in rows if r["date"] in hold_dates]
        models={name:h139._fit(tr,features) for name,features in h139.MODELS.items()}
        validation={name:h139._brier(va,model) for name,model in models.items()}
        best=min(validation,key=lambda name:(validation[name],len(h139.MODELS[name]),name))
        gain=validation["prior"]-validation[best]
        promoted=best!="prior" and gain>=.002 and h139.paper(va,models[best])["virtual_return_pct"]>0
        selected=best if promoted else "prior";model=models[selected];prior=models["prior"]
        diagnostic_model=models[best]
        comparisons={}
        for name,candidate in models.items():
            shadow=h139.paper(te,candidate)
            comparisons[name]={"validation_brier":round(validation[name],7),
                "holdout_brier_frozen_diagnostic":round(h139._brier(te,candidate),7),
                "return_after_cost_pct":shadow["virtual_return_pct"],"drawdown_pct":shadow["max_drawdown_pct"],
                "trades":shadow["trade_count"]}
        turnover={}
        for every in REBALANCE_DAYS:
            shadow=h139.paper(_every_n(te,every),diagnostic_model)
            turnover[str(every)]={"rebalance_every_sessions":every,"return_after_cost_pct":shadow["virtual_return_pct"],
                "drawdown_pct":shadow["max_drawdown_pct"],"trades":shadow["trade_count"]}
        cost_stress={str(multiplier):h139.paper(te,diagnostic_model,cost_multiplier=multiplier)["virtual_return_pct"]
                     for multiplier in (.5,1.,2.)}
        experiment={"horizon_sessions":horizon,"selected_on_validation":selected,
            "validation_best_diagnostic_candidate":best,
            "complexity_promoted":promoted,"validation_gain_vs_prior":round(gain,7),
            "frozen_model_comparisons":comparisons,"explicit_no_trade":{"return_pct":0.,"drawdown_pct":0.,"trades":0},
            "lower_turnover_of_validation_best_candidate":turnover,
            "cost_stress_of_validation_best_candidate":cost_stress,
            "calibration":_calibration(te,model),
            "uncertainty":_paired_uncertainty(te,model,prior),"market_regimes":_regimes(te,model,prior)}
        if horizon==1:
            delayed=[]
            for row in te:
                if row.get("delayed_session_gross") is not None:
                    copy=dict(row);copy["gross"]=row["delayed_session_gross"];delayed.append(copy)
            experiment["one_session_execution_delay_of_validation_best_candidate"]={
                "undelayed_return_pct":h139.paper(te,diagnostic_model)["virtual_return_pct"],
                "delayed_return_pct":h139.paper(delayed,diagnostic_model)["virtual_return_pct"]}
        experiments[str(horizon)]=experiment
        if horizon==1:primary=(te,model,prior,experiment)
    te,model,prior,one=primary
    result={"schema":"bie.h140.real-market-robustness.v1","source_mode":mode,
        "data_provenance":payload.get("provenance",{"warning":"no top-level provenance supplied"}),
        "promotion_eligible_input":mode=="user_supplied_historical","chronological_split":split,
        "universe_ranked_on_train_only":ranking,"research_stocks_selected":chosen,
        "experiments":experiments,"cash":{"return_pct":0.,"drawdown_pct":0.},
        "SPY":h139.benchmark_buy_hold(dates,hold_dates,book,"SPY"),
        "QQQ":h139.benchmark_buy_hold(dates,hold_dates,book,"QQQ"),
        "information_attribution":{"accuracy_glyph_verified_contribution":0,
            "conventional_error_correction":"Brier score and calibration only",
            "investor_attention":"evaluated only when authentic timestamped observations exist"},
        "promotion_decision":"not_evaluated_without_new_genuine_history" if mode!="user_supplied_historical" else
            ("provisional_real_evidence_only" if one["complexity_promoted"] else "no_trade"),
        "orders":0,"allocations":"virtual_only",
        "thought_packet":{"hypothesis":"all_evidence survives new real regimes, costs and delays better than frozen simpler controls",
            "falsifier":"nonpositive Brier gain, unstable calibration, nonpositive after-cost return, or failure versus cash/SPY/QQQ",
            "next_experiment":"Run an untouched prospective paper period with the frozen winning policy, or retain no-trade."}}
    return result
