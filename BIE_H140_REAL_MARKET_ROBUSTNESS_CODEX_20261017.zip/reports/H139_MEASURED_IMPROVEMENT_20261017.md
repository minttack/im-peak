# H139 measured improvement and next research plan

Date: 2026-10-17. Scope: offline research and virtual allocations only. No
broker connection, account query, permission change, order, or real position.

## Reproduction and regression evidence

- The fixed seed-13901 flow replay reproduced the prior five research names:
  META, MSFT, XOM, AMZN, and JNJ. The ranking is based on training-only data
  coverage, liquidity, and sector constraints; it is not a stock recommendation.
- The split, validation scores, frozen `all_evidence` model, holdout Brier
  0.2400746 versus prior 0.2473745, and virtual return +0.8717% matched the
  saved demonstration. New buy-and-hold ETF controls explain the only report
  shape difference from the older demo.
- Focused H139 tests passed 30/30 before the change and 35/35 after the new
  audit/import work. The full suite ran 517 tests: 516 passed and one errored
  because the optimized package omitted the manifest-listed
  `vendor/desktop_v1/ORIGINAL_BIE_V8_UNMODIFIED.zip`. Vendor integrity cannot
  be claimed from this archive.
- The actual `qwen2.5:3b` local-model query returned
  `local_model_unavailable`. No BIE model reply was invented.

## New frozen diagnostic

The diagnostic compares every train-fitted model on validation and then reports
holdout outcomes as consumed diagnostics. It cannot select or tune a model.

| Model | Validation Brier | Holdout Brier | Virtual return | Trades |
|---|---:|---:|---:|---:|
| prior | 0.2505961 | 0.2473745 | 0.0000% | 0 |
| price | 0.2499125 | 0.2469240 | 0.0000% | 0 |
| flood | 0.2489295 | 0.2421984 | +0.3226% | 94 |
| price_flood | 0.2469421 | 0.2405650 | +0.6881% | 90 |
| all_evidence | 0.2466539 | 0.2400746 | +0.8717% | 89 |

`all_evidence` improved holdout Brier only 0.0004904 beyond `price_flood` in
this already-consumed synthetic holdout. Familiarity's validation ablation gain
was 0.0002882; timestamped investor attention was unavailable and contributed
zero. The Accuracy attribution remains generic error/Brier correction; verified
contribution from the creator's original Accuracy glyph remains zero.

Changing conditions were material. The selected model's Brier gain versus prior
was +0.0041579 in the early holdout and +0.0103255 late. Paper return was
+0.0191% early and +0.8524% late. This is evidence of period dependence, not a
stable real-market edge.

Execution assumptions dominate the result: return was +4.7108% at zero modeled
cost, +2.7738% at 0.5x cost, +0.8717% at 1x cost, and -2.8303% at 2x cost. The
causal next-session open-to-close timing returned +0.8717%; one additional
session delay returned -2.9911%. The same-session result (+4.6881%) is retained
only as an impossible leakage control because its features already use that
session's close.

## Historical-data ingestion

`scripts/prepare_h139_history.py` now converts reviewed daily CSV exports for
META, MSFT, XOM, AMZN, JNJ, SPY, and QQQ into the H139 schema. It intersects
dates across all symbols, requires 140+ aligned bars, records a timezone-aware
retrieval timestamp and per-bar source reference, labels spread as an explicit
cost assumption, and flags corporate actions for review. It performs no network
or brokerage action and does not invent attention data.

Both attempted public downloads (Yahoo chart and Stooq CSV) returned HTTP 403 in
this environment. No authentic history was therefore analyzed. A human-reviewed
export remains required; source licenses, split/dividend adjustment, exchange
calendar, and historical spread assumptions must be reviewed before ingestion.

## Next falsifiable research plan

1. Restore the omitted vendor ZIP from its hash-verified parent package and rerun
   all 517 tests; do not weaken the manifest.
2. Export at least 250 completed daily bars for the seven symbols from one
   reviewed source, record retrieval time, and review splits/dividends. Omit
   attention unless its observation timestamps and provenance are authentic.
3. Freeze calendar train/validation/holdout boundaries, cost assumptions, and
   acceptance gates before ingestion. The next hypothesis is that
   `all_evidence` beats prior and price-only models on untouched real periods.
   Falsify it if Brier gain is non-positive, calibration is unstable, after-cost
   virtual return is non-positive, or cash/SPY/QQQ controls are not beaten.
4. Repeat across multiple non-overlapping calendar regimes and a prospective
   paper period. Treat each examined holdout as consumed and never tune against
   it. Stress one-session delay, doubled costs, missing bars, stale attention,
   corporate actions, and label changes.
5. After each run invoke `--ask-experience`. Record an actual model response only
   when Ollama replies; otherwise preserve `local_model_unavailable` and use the
   deterministic ThoughtPacket as a fallback, clearly labeled as program logic.

Current conclusion: software diagnostics improved, but real predictive advantage
is **not yet demonstrated**.
