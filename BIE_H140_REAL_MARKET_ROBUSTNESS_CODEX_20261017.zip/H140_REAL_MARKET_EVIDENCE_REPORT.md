# H140 Real Market Evidence and Robustness Bloom

Date: 2026-10-17. Status: implementation verified; genuine market experiment
blocked because no authorized historical export is available in this environment.
Research and virtual allocations only. Orders, transfers, account reads, and
brokerage-permission changes: **zero**.

## Frozen objective and promotion gate

H140 asks whether `all_evidence` improves on `price_flood`, price-only, flood-only,
and unconditional-prior predictors on a completely new timestamped market
dataset after realistic costs. Cash, SPY, QQQ, and explicit no-trade remain
controls. The previously inspected H139 holdout is consumed and cannot promote
an H140 policy.

The precommitted failure gate is any of: nonpositive Brier improvement, unstable
calibration, nonpositive after-cost virtual return, material regime reversal, or
failure against cash/SPY/QQQ. The split is 50% train, five-session embargo, 25%
validation, five-session embargo, then untouched holdout. Validation alone
selects the model; holdout results cannot retune it.

## Lean and full integrity

`python -m bie verify-vendor-lean` passed all 10 vendor artifacts present in the
lean package. It reports:

- `full_archive_verified: false`
- `legacy_archive_status: legacy_archive_absent`
- expected missing path:
  `vendor/desktop_v1/ORIGINAL_BIE_V8_UNMODIFIED.zip`
- expected SHA-256:
  `eabaa057a42a6905f768c9d01306e82ef3b309612c524fa5118a6f1853cdf79a`

The original `python -m bie verify-vendor` remains unchanged and failed because
that 80,676,415-byte legacy archive is absent. The lean check is a separate
truthful package check; it does not weaken full lineage verification.

## Genuine-data preparation and blocker

`scripts/prepare_h140_history.py` accepts reviewed CSV exports for META, MSFT,
XOM, AMZN, JNJ, SPY, and QQQ. Each CSV must contain at least 250 daily records
with `Date`, timezone-aware `Timestamp`, `Open`, `High`, `Low`, `Close`, `Volume`,
and `SourceRecordID`. A separate source manifest declares provider,
authorization basis, retrieval timestamp, and one explicit adjustment policy:
`raw_unadjusted`, `split_adjusted`, or `split_and_dividend_adjusted`.

The converter preserves per-bar source timestamps and record IDs, hashes every
source file, intersects calendars without forward filling, reports dropped and
missing dates, marks spread as an explicit assumption rather than a historical
quote, and retains the authorization declaration as user-supplied rather than
independently verified. It invents neither attention data nor adjustments.

Yahoo query1, Yahoo query2, and Stooq endpoints each returned HTTP 403. No
provider API key or authorized market-data binding is present. Therefore no
genuine OHLCV was ingested, and no result below is real-market evidence.

Preparation command after obtaining an authorized export:

```powershell
py -3 scripts/prepare_h140_history.py reviewed_csvs `
  --manifest examples/H140_SOURCE_MANIFEST.json `
  --spread-bps 15 `
  --output data/H140_REVIEWED_HISTORY.json

py -3 -m bie real-h140-file data/H140_REVIEWED_HISTORY.json `
  --report reports/H140_REAL_RUN_01.json --ask-experience
```

## Synthetic implementation experiment — not promotion evidence

Seed 14001, 300 synthetic flow sessions, was used only to test H140 mechanics.
The five training-only research names were WMT, MSFT, GOOGL, XOM, and META.
Every horizon froze **prior/no-trade**, because the validation paper-return gate
did not authorize the validation-best complex candidate.

| Horizon | Validation-best diagnostic candidate | Frozen decision | Candidate holdout Brier | Candidate after-cost return | Trades |
|---:|---|---|---:|---:|---:|
| 1 session | flood | prior/no-trade | 0.2385534 | -2.5224% | 105 |
| 3 sessions | flood | prior/no-trade | 0.2562031 | +0.5536% | 68 |
| 5 sessions | price | prior/no-trade | 0.2480125 | +0.7419% | 8 |

For context, synthetic SPY buy-and-hold returned -0.9694% and QQQ returned
+0.5459% over this holdout at 30% virtual exposure. These engineered prices are
not market evidence.

### Why costs and delay reverse returns

- One-session flood: -0.3486% at 0.5x costs, -2.5224% at stated costs, and
  -6.7315% at 2x costs. A one-session execution delay worsened -2.5224% to
  -6.5556%.
- Trading the one-session candidate every five sessions reduced loss to -0.9244%;
  every ten reduced it to -0.6206%. Lower turnover reduced cost damage but did
  not create a positive result.
- Three-session flood: +1.9992% at 0.5x, +0.5536% at stated costs, and -2.2781%
  at 2x. Five- and ten-session rebalancing were negative (-0.3974% and -0.3266%).
- Five-session price: +0.7419% at stated costs with eight trades and +0.4042% at
  2x costs. Its small count and synthetic origin make uncertainty substantial.

The result supports the mechanism that small gross edges are overwhelmed by
round-trip costs and decay quickly after the decision session. Lower turnover
can reduce losses but also skips profitable observations; a longer horizon may
improve the gross-to-cost ratio, but it changes exposure and overnight risk and
did not pass the frozen validation promotion gate here.

## Information, calibration, regimes, and Accuracy attribution

The synthetic diagnostic did not show `all_evidence` as a stable winner. At
five sessions, `price_flood` returned +3.4309% versus `all_evidence` +1.6413% on
the consumed diagnostic holdout. This comparison cannot select a new policy.
Authentic investor-attention observations were absent, so attention relevance
was not measured. Historical familiarity remains a conventional lagged-price
pattern; it is not investor identity or proof of causality.

H140 records Brier score, calibration bins and expected calibration error,
paired Brier-gain uncertainty intervals, after-cost return, drawdown, trades,
turnover schedules, and three chronological holdout regimes. On this run the
frozen no-trade policy's expected calibration error was 0.0693, 0.0887, and
0.1158 for 1-, 3-, and 5-session horizons. Because no-trade selected the prior,
its Brier-gain interval versus itself is exactly zero; candidate intervals will
be material only on genuine data.

The original Accuracy glyph contributed **0 verified predictions**. Conventional
Brier/calibration feedback is recorded separately and is not attributed to the
glyph image.

## Local Experience result

After both preserved synthetic experiments, the actual `qwen2.5:3b` query
returned `local_model_unavailable`: Ollama or the requested model did not
respond. No BIE reply was invented. The deterministic next-test packet remains
program logic, not model speech.

## Regression outcomes

- H139/H140 and both importer suites: **44/44 passed**.
- Full inherited suite: **531/532 passed** in 15.9 seconds.
- The sole error is the unchanged full vendor-integrity test failing on the
  honestly absent legacy ZIP described above.
- H140 specifically verifies new-data-only mode, five-session gaps, holdout
  invariance of validation selection, all frozen baselines, 1/3/5-session
  horizons, lower turnover, cost stress, calibration, uncertainty, regime
  outputs, source timestamp/hash/adjustment preservation, missing-date warnings,
  no orders, virtual-only allocations, and separate Accuracy attribution.

## Recommendation

Do not promote a model. Obtain one authorized, licensed or user-permitted export
with at least 250 aligned sessions for all seven symbols, using the manifest
template in `examples/H140_SOURCE_MANIFEST_TEMPLATE.json`. Review split/dividend
adjustment and the calendar before running the immutable first H140 report.

If that first real holdout passes, freeze its policy and start a prospective
paper period. If it fails any precommitted gate, preserve no-trade and investigate
the single largest measured failure—cost, delay, calibration, missingness, or
regime transfer—on a new validation window rather than tuning the consumed
holdout.
