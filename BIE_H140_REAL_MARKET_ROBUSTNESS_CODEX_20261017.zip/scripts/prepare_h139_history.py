"""Convert reviewed per-symbol OHLCV CSV files to the H139 JSON contract.

No network or brokerage operation occurs. Inputs are SYMBOL.csv files with
Date/Open/High/Low/Close/Volume columns. Only dates common to every symbol are
kept, and the output keeps the supplied source and retrieval timestamp.
"""
from __future__ import annotations
import argparse, csv, json
from datetime import datetime
from pathlib import Path

SYMBOLS=("META","MSFT","XOM","AMZN","JNJ","SPY","QQQ")
SECTORS={"META":"Communication","MSFT":"Technology","XOM":"Energy",
         "AMZN":"Consumer","JNJ":"Healthcare"}

def load_csv(path):
    rows={}
    with Path(path).open(newline="",encoding="utf-8-sig") as f:
        for raw in csv.DictReader(f):
            day=raw.get("Date","").strip();datetime.strptime(day,"%Y-%m-%d")
            if day in rows:raise ValueError(f"{path} contains duplicate date {day}")
            rows[day]={k:float(raw[k]) for k in ("Open","High","Low","Close","Volume")}
    if len(rows)<140:raise ValueError(f"{path} has fewer than 140 unique daily bars")
    return rows

def build(input_dir,source,retrieved_at,spread_bps):
    if not source.strip() or source.lower().startswith("synthetic"):
        raise ValueError("Name the authentic reviewed data source")
    stamp=datetime.fromisoformat(retrieved_at.replace("Z","+00:00"))
    if stamp.tzinfo is None:raise ValueError("retrieved-at must include a timezone")
    root=Path(input_dir);tables={s:load_csv(root/f"{s}.csv") for s in SYMBOLS}
    dates=sorted(set.intersection(*(set(table) for table in tables.values())))
    if len(dates)<140:raise ValueError("Fewer than 140 aligned dates remain")
    bars=[]
    for day in dates:
        for symbol in SYMBOLS:
            r=tables[symbol][day]
            bars.append({"ticker":symbol,"date":day,"open":r["Open"],"high":r["High"],
                "low":r["Low"],"close":r["Close"],"volume":r["Volume"],
                "spread_bps":spread_bps,"spread_basis":"explicit_cost_assumption",
                "source_ref":f"{source}; {symbol}; bar={day}; retrieved={stamp.isoformat()}"})
    return {"schema":"bie.h139.flood-movement.v1","source_mode":"user_supplied_historical",
        "as_of_date":dates[-1],"sectors":SECTORS,"bars":bars,
        "provenance":{"source":source,"retrieved_at":stamp.isoformat(),
            "aligned_dates":len(dates),"symbols":list(SYMBOLS),
            "corporate_action_review_required":True,"spread_is_observed_history":False}}

def main(argv=None):
    p=argparse.ArgumentParser();p.add_argument("input_dir",type=Path)
    p.add_argument("--source",required=True);p.add_argument("--retrieved-at",required=True)
    p.add_argument("--spread-bps",type=float,default=15.);p.add_argument("--output",type=Path,required=True)
    a=p.parse_args(argv);result=build(a.input_dir,a.source,a.retrieved_at,a.spread_bps)
    a.output.parent.mkdir(parents=True,exist_ok=True)
    with a.output.open("x",encoding="utf-8") as f:json.dump(result,f,indent=2,allow_nan=False)
    print(json.dumps({"saved":str(a.output),"bars":len(result["bars"]),"as_of":result["as_of_date"]}))

if __name__=="__main__":main()
