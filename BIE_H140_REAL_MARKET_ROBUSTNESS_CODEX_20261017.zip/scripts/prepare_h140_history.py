"""Strict H140 converter for authorized, reviewed daily market exports."""
from __future__ import annotations
import argparse,csv,hashlib,json,math
from datetime import datetime
from pathlib import Path
from scripts.prepare_h139_history import SYMBOLS,SECTORS

REQUIRED=("Date","Timestamp","Open","High","Low","Close","Volume","SourceRecordID")
POLICIES=("raw_unadjusted","split_adjusted","split_and_dividend_adjusted")

def _sha(path):
    h=hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda:f.read(1024*1024),b""):h.update(chunk)
    return h.hexdigest()

def _read(path):
    rows={}
    with path.open(newline="",encoding="utf-8-sig") as f:
        reader=csv.DictReader(f)
        missing=set(REQUIRED)-set(reader.fieldnames or ())
        if missing:raise ValueError(f"{path} missing columns: {sorted(missing)}")
        for raw in reader:
            day=raw["Date"].strip();datetime.strptime(day,"%Y-%m-%d")
            stamp=datetime.fromisoformat(raw["Timestamp"].strip().replace("Z","+00:00"))
            if stamp.tzinfo is None:raise ValueError(f"{path} timestamp lacks timezone")
            if day in rows:raise ValueError(f"{path} duplicate date {day}")
            values={k:float(raw[k]) for k in ("Open","High","Low","Close","Volume")}
            if any(not math.isfinite(v) for v in values.values()):raise ValueError(f"{path} nonfinite value")
            if not raw["SourceRecordID"].strip():raise ValueError(f"{path} missing source record ID")
            rows[day]=(values,raw["Timestamp"].strip(),raw["SourceRecordID"].strip())
    if len(rows)<250:raise ValueError(f"{path} requires at least 250 daily bars for H140")
    return rows

def build(input_dir,manifest_path,spread_bps):
    manifest=json.loads(Path(manifest_path).read_text(encoding="utf-8"))
    for key in ("provider","authorization_basis","retrieved_at","adjustment_policy"):
        if not isinstance(manifest.get(key),str) or not manifest[key].strip():raise ValueError(f"Missing source manifest {key}")
    retrieved=datetime.fromisoformat(manifest["retrieved_at"].replace("Z","+00:00"))
    if retrieved.tzinfo is None:raise ValueError("retrieved_at must include timezone")
    if manifest["adjustment_policy"] not in POLICIES:raise ValueError("Unsupported adjustment policy")
    root=Path(input_dir);paths={s:root/f"{s}.csv" for s in SYMBOLS};tables={s:_read(p) for s,p in paths.items()}
    union=set.union(*(set(t) for t in tables.values()));common=set.intersection(*(set(t) for t in tables.values()))
    dates=sorted(common)
    if len(dates)<250:raise ValueError("Fewer than 250 aligned sessions remain")
    warnings=[]
    for symbol,table in tables.items():
        dropped=len(set(table)-common);missing=len(union-set(table))
        if dropped or missing:warnings.append({"symbol":symbol,"unshared_rows_dropped":dropped,"dates_missing_vs_union":missing})
    bars=[];hashes={s:_sha(p) for s,p in paths.items()}
    for day in dates:
        for symbol in SYMBOLS:
            values,stamp,record=tables[symbol][day]
            bars.append({"ticker":symbol,"date":day,"open":values["Open"],"high":values["High"],
                "low":values["Low"],"close":values["Close"],"volume":values["Volume"],
                "spread_bps":spread_bps,"spread_basis":"explicit_cost_assumption",
                "source_timestamp":stamp,"adjustment_policy":manifest["adjustment_policy"],
                "source_ref":f"{manifest['provider']}; record={record}; file_sha256={hashes[symbol]}"})
    return {"schema":"bie.h139.flood-movement.v1","source_mode":"user_supplied_historical",
        "as_of_date":dates[-1],"sectors":SECTORS,"bars":bars,
        "provenance":{"provider":manifest["provider"],"authorization_basis":manifest["authorization_basis"],
            "authorization_is_user_declared_not_independently_verified":True,"retrieved_at":retrieved.isoformat(),
            "adjustment_policy":manifest["adjustment_policy"],"file_sha256":hashes,
            "aligned_sessions":len(dates),"missing_data_warnings":warnings,
            "spread_basis":"explicit_cost_assumption_not_historical_quote",
            "source_timestamps_preserved_per_bar":True}}

def main(argv=None):
    p=argparse.ArgumentParser();p.add_argument("input_dir",type=Path);p.add_argument("--manifest",type=Path,required=True)
    p.add_argument("--spread-bps",type=float,default=15.);p.add_argument("--output",type=Path,required=True)
    a=p.parse_args(argv);result=build(a.input_dir,a.manifest,a.spread_bps)
    a.output.parent.mkdir(parents=True,exist_ok=True)
    with a.output.open("x",encoding="utf-8") as f:json.dump(result,f,indent=2,allow_nan=False)
    print(json.dumps({"saved":str(a.output),"bars":len(result["bars"]),"as_of":result["as_of_date"],
        "warnings":len(result["provenance"]["missing_data_warnings"])}))

if __name__=="__main__":main()
