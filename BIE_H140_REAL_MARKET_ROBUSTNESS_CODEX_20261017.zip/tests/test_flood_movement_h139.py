"""Adversarial acceptance checks for standalone H139 market Flood Movement."""
import copy
import json
import tempfile
import unittest
from datetime import date, timedelta
from pathlib import Path
from bie import flood_movement_h139 as f

class H139FloodTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.data=f.synthetic(seed=13901,world="flow",days=190)
        cls.out=f.analyze(cls.data)

    def test_schema(self):self.assertEqual(self.out['schema'],'bie.h139.flood-report.v1')
    def test_zero_orders(self):self.assertEqual(self.out['proof_ladder']['live_orders_executed'],0)
    def test_large_purchase_disabled(self):self.assertFalse(self.out['proof_ladder']['large_real_purchase_authorized'])
    def test_no_auto_position_scale(self):self.assertFalse(self.out['proof_ladder']['automatic_live_position_scaling'])
    def test_source_mode_explicit(self):self.assertEqual(self.out['source_mode'],'synthetic')
    def test_all_stock_candidates(self):self.assertEqual(set(f.STOCK_SECTORS),set(self.data['sectors']))
    def test_actual_benchmark_labels(self):self.assertIn('SPY',self.out['comparison_benchmarks'])
    def test_buy_hold_benchmark_is_separate(self):
        self.assertIn('SPY_buy_hold',self.out['comparison_benchmarks'])
        self.assertEqual(self.out['comparison_benchmarks']['SPY_buy_hold']['trades'],2)
    def test_market_universe_diversified(self):
        self.assertTrue(len(self.out['research_stocks_selected'])<=5)
        sectors=[f.STOCK_SECTORS[t] for t in self.out['research_stocks_selected']]
        self.assertTrue(all(sectors.count(s)<=2 for s in sectors))
    def test_frozen_chooses_allowed_model(self):self.assertIn(self.out['selected_model_frozen_before_holdout'],f.MODELS)
    def test_brier_nonnegative(self):self.assertGreaterEqual(self.out['holdout_evaluation']['brier'],0)
    def test_relevance_is_measured_not_promise(self):
        self.assertEqual(set(self.out['relevance_attribution']),set(f.FEATURES))
        self.assertEqual(self.out['accuracy_glyph_derived_predictions'],0)
    def test_paper_stake_cap(self):
        self.assertTrue(all(r['gross_exposure']<=.30 for r in self.out['paper_portfolio']['decisions']))
        self.assertTrue(all(len(r['symbols'])<=3 for r in self.out['paper_portfolio']['decisions']))
    def test_pnl_reconciliation(self):
        p=self.out['paper_portfolio'];self.assertAlmostEqual((p['ending_virtual_cash']/10000-1)*100,p['virtual_return_pct'],delta=.01)
    def test_no_trades_when_validation_fails(self):
        o=f.analyze(f.synthetic(seed=13901,world='null',days=190))
        if not o['complexity_promotion']:
            self.assertEqual(o['paper_portfolio']['trade_count'],0)
    def test_no_future_prices(self):
        d=copy.deepcopy(self.data);d['bars'][0]['date']='2099-01-01'
        with self.assertRaises(ValueError):f.analyze(d)
    def test_no_future_attention(self):
        d=copy.deepcopy(self.data);row=d['bars'][0]
        row['investor_attention']={'value':.8,'observed_at':'2099-01-01','source_ref':'test'}
        with self.assertRaises(ValueError):f.analyze(d)
    def test_old_attention_not_used(self):
        d=copy.deepcopy(self.data);r=d['bars'][-12]
        stale=(date.fromisoformat(r['date'])-timedelta(days=20)).isoformat()
        r['investor_attention']={'value':.5,'observed_at':stale,'source_ref':'test'}
        _,dates,names,book,_=f.validate(d)
        self.assertFalse(book[(date.fromisoformat(r['date']),r['ticker'])]['extras'])
    def test_history_requires_provenance(self):
        d=copy.deepcopy(self.data);d['source_mode']='user_supplied_historical'
        with self.assertRaises(ValueError):f.analyze(d)
    def test_duplicated_row_rejected(self):
        d=copy.deepcopy(self.data);d['bars'][1]=d['bars'][0].copy()
        with self.assertRaises(ValueError):f.analyze(d)
    def test_missing_row_rejected(self):
        d=copy.deepcopy(self.data);d['bars'].pop()
        with self.assertRaises(ValueError):f.analyze(d)
    def test_invalid_bar_rejected(self):
        d=copy.deepcopy(self.data);d['bars'][0]['high']=0.01
        with self.assertRaises(ValueError):f.analyze(d)
    def test_no_nan(self):
        d=copy.deepcopy(self.data);d['bars'][0]['close']=float('nan')
        with self.assertRaises(ValueError):f.analyze(d)
    def test_no_negative_volume(self):
        d=copy.deepcopy(self.data);d['bars'][0]['volume']=-1
        with self.assertRaises(ValueError):f.analyze(d)
    def test_order_invariance(self):
        d=copy.deepcopy(self.data);d['bars'].reverse()
        o=f.analyze(d)
        self.assertEqual(self.out['selected_model_frozen_before_holdout'],o['selected_model_frozen_before_holdout'])
        self.assertEqual(self.out['holdout_evaluation'],o['holdout_evaluation'])
        self.assertEqual(self.out['paper_portfolio']['virtual_return_pct'],o['paper_portfolio']['virtual_return_pct'])
    def test_future_prices_cannot_change_past_features(self):
        _,dates,names,book,_=f.validate(self.data)
        early=f.feature_matrix(dates,names,book)
        d=copy.deepcopy(self.data);cut=dates[-15].isoformat()
        for r in d['bars']:
            if r['date']>=cut and r['ticker'] not in f.BENCHMARKS:
                op=r['open'];r['high']=max(op,r['high'])*1.5;r['close']=max(op,r['close'])*1.5
        _,ndates,names,nbook,_=f.validate(d)
        late=f.feature_matrix(ndates,names,nbook)
        for a,b in zip(early,late):
            if str(a['outcome_date'])<cut:
                self.assertEqual(a['x'],b['x']);self.assertEqual(a['gross'],b['gross'])
    def test_reference_costs_cannot_promote_expensive_liquidity(self):
        o=f.analyze(f.synthetic(seed=13901,world='illiquid',days=190))
        self.assertEqual(o['paper_portfolio']['trade_count'],0)
    def test_write_no_overwrite(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'report.json';f.write_new(p,self.out)
            self.assertEqual(json.loads(p.read_text())['schema'],self.out['schema'])
            with self.assertRaises(FileExistsError):f.write_new(p,self.out)
    def test_all_labels_are_future_open_to_close(self):
        _,dates,names,book,_=f.validate(self.data)
        first=f.feature_matrix(dates,names,book)[0]
        future=book[(first['outcome_date'],first['ticker'])]
        self.assertAlmostEqual(first['gross'],future['close']/future['open']-1)
    def test_past_feature_missing_spy_rejected(self):
        d=copy.deepcopy(self.data);d['bars']=[r for r in d['bars'] if not(r['ticker']=='SPY' and r['date']==d['bars'][0]['date'])]
        with self.assertRaises(ValueError):f.validate(d)
    def test_diagnostic_audit_never_selects_on_holdout(self):
        audit=self.out['diagnostic_audit']
        self.assertEqual(audit['status'],'diagnostic_only_holdout_consumed_no_selection_or_tuning')
        self.assertEqual(set(audit['all_evidence_vs_simpler_baselines']),set(f.MODELS))
        self.assertEqual(audit['accuracy_attribution'].endswith('0 verified'),True)
    def test_cost_stress_is_monotonic_for_frozen_decisions(self):
        costs=self.out['diagnostic_audit']['execution_cost_multiplier_returns_pct']
        self.assertGreaterEqual(costs['0.0'],costs['0.5'])
        self.assertGreaterEqual(costs['0.5'],costs['1.0'])
        self.assertGreaterEqual(costs['1.0'],costs['2.0'])
    def test_timing_audit_labels_impossible_control(self):
        timing=self.out['diagnostic_audit']['execution_timing_returns_pct']
        self.assertIn('same_session_impossible_leakage_control',timing)
        self.assertIn('one_additional_session_delay',timing)

if __name__=='__main__':unittest.main()
