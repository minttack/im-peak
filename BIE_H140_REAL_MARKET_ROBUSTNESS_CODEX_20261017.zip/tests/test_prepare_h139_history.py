import csv
from datetime import date,timedelta
from pathlib import Path
import tempfile, unittest
from bie.flood_movement_h139 import validate
from scripts.prepare_h139_history import SYMBOLS,build

class PrepareHistoryTests(unittest.TestCase):
    def test_builds_aligned_reviewable_history(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td)
            for symbol in SYMBOLS:
                with (root/f"{symbol}.csv").open("w",newline="",encoding="utf-8") as f:
                    w=csv.writer(f);w.writerow(["Date","Open","High","Low","Close","Volume"])
                    for i in range(150):w.writerow([date(2025,1,1)+timedelta(days=i),100,102,99,101,1000000])
            payload=build(root,"reviewed public export","2026-10-17T16:00:00-05:00",15)
            mode,dates,names,_,_=validate(payload)
            self.assertEqual(mode,"user_supplied_historical");self.assertEqual(len(dates),150)
            self.assertEqual(set(names),set(SYMBOLS)-{"SPY","QQQ"})
            self.assertTrue(all("retrieved=" in r["source_ref"] for r in payload["bars"]))
    def test_rejects_timestamp_without_timezone(self):
        with tempfile.TemporaryDirectory() as td:
            with self.assertRaises(ValueError):build(Path(td),"reviewed","2026-10-17T16:00:00",15)

if __name__=='__main__':unittest.main()
