import csv,json
from datetime import date,timedelta
from pathlib import Path
import tempfile,unittest
from bie.flood_movement_h139 import validate
from scripts.prepare_h140_history import SYMBOLS,build

class PrepareH140Tests(unittest.TestCase):
    def _fixture(self,root,missing=False):
        d=date(2024,1,2);days=[]
        while len(days)<270:
            if d.weekday()<5:days.append(d)
            d+=timedelta(days=1)
        for symbol in SYMBOLS:
            with (root/f"{symbol}.csv").open("w",newline="",encoding="utf-8") as f:
                w=csv.writer(f);w.writerow(["Date","Timestamp","Open","High","Low","Close","Volume","SourceRecordID"])
                for i,day in enumerate(days):
                    if missing and symbol=="META" and i==10:continue
                    w.writerow([day,f"{day}T21:00:00Z",100,102,99,101,1000000,f"{symbol}-{day}"])
        manifest=root/"source.json";manifest.write_text(json.dumps({"provider":"authorized test fixture",
            "authorization_basis":"user-reviewed export permission","retrieved_at":"2026-10-17T16:00:00-05:00",
            "adjustment_policy":"split_adjusted"}),encoding="utf-8")
        return manifest
    def test_preserves_timestamp_adjustment_hashes_and_authorization(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);manifest=self._fixture(root);payload=build(root,manifest,15)
            mode,dates,names,_,_=validate(payload)
            self.assertEqual(mode,"user_supplied_historical");self.assertEqual(len(dates),270)
            self.assertEqual(len(payload["provenance"]["file_sha256"]),7)
            self.assertTrue(payload["bars"][0]["source_timestamp"].endswith("Z"))
            self.assertEqual(payload["bars"][0]["adjustment_policy"],"split_adjusted")
    def test_reports_missing_alignment(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);manifest=self._fixture(root,missing=True);payload=build(root,manifest,15)
            self.assertEqual(payload["provenance"]["aligned_sessions"],269)
            self.assertTrue(payload["provenance"]["missing_data_warnings"])
    def test_requires_timezone_timestamp(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);manifest=self._fixture(root)
            p=root/"META.csv";text=p.read_text();p.write_text(text.replace("T21:00:00Z","T21:00:00",1))
            with self.assertRaises(ValueError):build(root,manifest,15)

if __name__=="__main__":unittest.main()
