import copy, unittest
from bie import flood_movement_h139 as h139
from bie import real_market_h140 as h140

class H140Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.synthetic=h139.synthetic(seed=14001,world="flow",days=300)
        cls.result=h140.analyze(cls.synthetic,allow_synthetic=True)
    def test_real_mode_required_for_promotion_path(self):
        with self.assertRaises(ValueError):h140.analyze(self.synthetic)
    def test_split_has_five_session_gaps(self):
        self.assertEqual(self.result["chronological_split"]["embargo_sessions"],5)
        self.assertIn("never reuse",self.result["chronological_split"]["holdout_status"])
    def test_all_frozen_baselines_and_horizons(self):
        self.assertEqual(set(self.result["experiments"]),{"1","3","5"})
        for experiment in self.result["experiments"].values():
            self.assertEqual(set(experiment["frozen_model_comparisons"]),set(h139.MODELS))
            self.assertEqual(experiment["explicit_no_trade"]["trades"],0)
    def test_lower_turnover_and_risk_metrics(self):
        for experiment in self.result["experiments"].values():
            self.assertEqual(set(experiment["lower_turnover_of_validation_best_candidate"]),{"1","5","10"})
            self.assertEqual(set(experiment["cost_stress_of_validation_best_candidate"]),{"0.5","1.0","2.0"})
            self.assertIn("expected_calibration_error",experiment["calibration"])
            self.assertIn("approx_95pct_interval",experiment["uncertainty"])
            self.assertEqual(len(experiment["market_regimes"]),3)
        self.assertIn("delayed_return_pct",self.result["experiments"]["1"]["one_session_execution_delay_of_validation_best_candidate"])
    def test_research_only_and_accuracy_separate(self):
        self.assertEqual(self.result["orders"],0)
        self.assertEqual(self.result["allocations"],"virtual_only")
        self.assertEqual(self.result["information_attribution"]["accuracy_glyph_verified_contribution"],0)
        self.assertFalse(self.result["promotion_eligible_input"])
    def test_future_holdout_cannot_change_selection(self):
        _,dates,_,_,_=h139.validate(self.synthetic);cut=dates[-40].isoformat()
        changed=copy.deepcopy(self.synthetic)
        for row in changed["bars"]:
            if row["date"]>=cut and row["ticker"] not in h139.BENCHMARKS:
                row["close"]=row["open"]*1.03;row["high"]=max(row["high"],row["close"])
        other=h140.analyze(changed,allow_synthetic=True)
        for horizon in ("1","3","5"):
            self.assertEqual(self.result["experiments"][horizon]["selected_on_validation"],
                             other["experiments"][horizon]["selected_on_validation"])

if __name__=="__main__":unittest.main()
